'use strict';
/** Stops the running LMS cleanly (Start menu → "Stop Jacob Davis LMS"). */
const path = require('path');
const http = require('http');
const core = require('./core');

const ROOT = process.env.LMS_INSTALL_ROOT ? path.resolve(process.env.LMS_INSTALL_ROOT) : path.dirname(__dirname);
const P = core.paths(ROOT);
const run = core.readJson(P.run, null);
if (!run) { console.log('Jacob Davis LMS is not running.'); setTimeout(() => process.exit(0), 1200); } else {
  const req = http.request({ host: '127.0.0.1', port: run.port, path: '/_ctl/shutdown', method: 'POST', headers: { 'x-ctl-token': run.token, 'content-length': '0' }, timeout: 3000 }, (res) => { res.resume(); });
  const done = () => setTimeout(() => {
    [run.serverPid].forEach((pid) => { try { if (pid) process.kill(pid); } catch (e) { /* already stopped */ } });
    console.log('Jacob Davis LMS stopped.');
    process.exit(0);
  }, 2500);
  req.on('error', done); req.on('close', done); req.on('timeout', () => req.destroy());
  req.end();
}
