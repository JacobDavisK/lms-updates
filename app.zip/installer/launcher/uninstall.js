'use strict';
/**
 * Removes Jacob Davis LMS from this computer (Start menu → "Uninstall Jacob Davis LMS").
 * The records in data/ are KEPT unless the person types DELETE when asked.
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const readline = require('readline');
const { spawn, spawnSync } = require('child_process');
const core = require('./core');

const ROOT = process.env.LMS_INSTALL_ROOT ? path.resolve(process.env.LMS_INSTALL_ROOT) : path.dirname(__dirname);
const P = core.paths(ROOT);
const ask = (q) => new Promise((r) => { const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); rl.question(q, (a) => { rl.close(); r(String(a).trim()); }); });

(async () => {
  console.log('\n  Uninstall Jacob Davis LMS\n  =========================\n  Installed in: ' + ROOT + '\n');
  if ((await ask('  Remove the program from this computer? Type YES and press Enter: ')).toUpperCase() !== 'YES') { console.log('  Nothing was removed.'); return; }
  const wipe = (await ask('  Your records (courses, students, marks) are kept by default.\n  To delete them as well, type DELETE — or just press Enter to keep them: ')) === 'DELETE';
  const run = core.readJson(P.run, null);
  if (run) {
    await new Promise((resolve) => { const req = http.request({ host: '127.0.0.1', port: run.port, path: '/_ctl/shutdown', method: 'POST', headers: { 'x-ctl-token': run.token, 'content-length': '0' }, timeout: 3000 }, (res) => { res.resume(); res.on('end', resolve); }); req.on('error', resolve); req.on('timeout', () => { req.destroy(); resolve(); }); req.end(); });
    await core.sleep(2500);
    [run.serverPid, run.pid].forEach((pid) => { try { if (pid) process.kill(pid); } catch (e) { /* stopped */ } });
  }
  if (process.platform === 'win32') {
    spawnSync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command',
      'Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath("Desktop")) "Jacob Davis LMS.lnk") -Force -ErrorAction SilentlyContinue; Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath("Programs")) "Jacob Davis LMS") -Recurse -Force -ErrorAction SilentlyContinue'], { windowsHide: true });
  }
  ['app', 'app.new', 'backup', 'updates', 'logs', 'run.json'].concat(wipe ? ['data', 'config.json'] : []).forEach((d) => core.rmrf(path.join(ROOT, d)));
  console.log(wipe ? '  The program and its records were removed.' : '  The program was removed. Your records are still in ' + P.data + '\n  (installing again will pick them up).');
  // This script is running from runtime\node.exe and launcher\, so those go last, after we exit.
  if (process.platform === 'win32') {
    const rest = ['runtime', 'launcher'].map((d) => 'rmdir /s /q "' + path.join(ROOT, d) + '"').join(' & ') + (wipe ? ' & rmdir /s /q "' + ROOT + '"' : '');
    spawn('cmd', ['/c', 'ping -n 3 127.0.0.1 >nul & ' + rest], { detached: true, stdio: 'ignore', windowsHide: true, cwd: require('os').tmpdir(), windowsVerbatimArguments: false }).unref();
  } else { core.rmrf(P.runtime); core.rmrf(P.launcher); if (wipe) core.rmrf(ROOT); }
  await ask('  Press Enter to close this window. ');
  process.exit(0);
})();
