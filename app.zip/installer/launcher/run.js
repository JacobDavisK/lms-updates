'use strict';
/**
 * Jacob Davis LMS — launcher for an installed copy.
 *
 *   • starts the LMS (or, if it is already running, just opens it in the browser)
 *   • keeps it up to date: checks the update page when it starts and every few hours, downloads a newer
 *     version, verifies its checksum, waits until nobody is using the site, then swaps the app folder
 *     and restarts. If the new version fails to start, the previous one is put back.
 *   • never touches ROOT/data (the records).
 *
 *   node run.js [--no-open]
 */
const fs = require('fs');
const path = require('path');
const net = require('net');
const http = require('http');
const crypto = require('crypto');
const { spawn } = require('child_process');
const core = require('./core');

const ROOT = process.env.LMS_INSTALL_ROOT ? path.resolve(process.env.LMS_INSTALL_ROOT) : path.dirname(__dirname);
const P = core.paths(ROOT);
const ARGS = process.argv.slice(2);
const NO_OPEN = ARGS.indexOf('--no-open') >= 0;
const CHECK_MS = Number(process.env.LMS_UPDATE_CHECK_MS) || 6 * 3600000;   // how often to look for an update
const IDLE_SEC = Number(process.env.LMS_UPDATE_IDLE_SEC) || 15 * 60;        // nobody active for this long → safe to restart

fs.mkdirSync(P.logs, { recursive: true });
const LOG = path.join(P.logs, 'lms.log');
try { if (fs.existsSync(LOG) && fs.statSync(LOG).size > 5 * 1024 * 1024) fs.renameSync(LOG, LOG + '.1'); } catch (e) { /* keep going */ }
const ascii = (s) => String(s).replace(/[\u2014\u2013]/g, '-').replace(/\u2026/g, '...').replace(/[\u2018\u2019]/g, "'").replace(/\u2022/g, '*').replace(/[^\x20-\x7E]/g, ''); // the Windows console garbles anything else
function log(msg) {
  const line = '[' + new Date().toISOString().replace('T', ' ').slice(0, 19) + '] ' + msg;
  console.log(ascii(msg));
  try { fs.appendFileSync(LOG, line + '\n'); } catch (e) { /* console still has it */ }
}
const cfg = () => Object.assign({ mode: 'demo', port: 3000, feed: core.DEFAULT_FEED, autoUpdate: true }, core.readJson(P.config, {}));
const state = () => core.readJson(P.state, {});
const setState = (patch) => core.writeJson(P.state, Object.assign(state(), patch));

/* ---------- talking to the running server (this computer only) ---------- */
function local(port, method, pathname, headers) {
  return new Promise((resolve) => {
    const req = http.request({ host: '127.0.0.1', port, path: pathname, method, headers: headers || {}, timeout: 3000 }, (res) => {
      let b = '';
      res.on('data', (c) => { b += c; });
      res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve(null); } });
    });
    req.on('timeout', () => req.destroy());
    req.on('error', () => resolve(null));
    req.end();
  });
}
const versionOf = async (port) => { const v = await local(port, 'GET', '/version'); return v && v.app === core.APP_ID ? v : null; };
function portFree(port) {
  return new Promise((resolve) => {
    const s = net.createServer();
    s.once('error', () => resolve(false));
    s.once('listening', () => s.close(() => resolve(true)));
    s.listen(port, '127.0.0.1');
  });
}
async function pickPort(start) { for (let p = start; p < start + 20; p++) if (await portFree(p)) return p; return start; }
function openBrowser(url) {
  if (NO_OPEN) return;
  try {
    if (process.platform === 'win32') spawn('cmd', ['/c', 'start', '', url], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    else spawn(process.platform === 'darwin' ? 'open' : 'xdg-open', [url], { detached: true, stdio: 'ignore' }).unref();
  } catch (e) { log('Open ' + url + ' in your browser.'); }
}

/* ---------- updates ---------- */
/** Looks at the update page; downloads and verifies a newer bundle. Returns the staged version or ''. */
async function stageUpdate(timeoutMs) {
  const c = cfg();
  if (!c.autoUpdate) return '';
  const cur = core.installedVersion(P);
  const st = state();
  if (st.staged && core.cmpVersion(st.staged.version, cur) > 0 && fs.existsSync(st.staged.file)) return st.staged.version;
  let info;
  try { info = await core.fetchJson(c.feed.replace(/\/+$/, '') + '/version.json?t=' + Date.now(), timeoutMs || 15000); } catch (e) { setState({ lastCheck: Date.now(), lastError: e.message }); return ''; }
  setState({ lastCheck: Date.now(), lastError: '', latest: info && info.version });
  if (!info || !/^\d+(\.\d+){1,3}$/.test(String(info.version)) || !/^[a-f0-9]{64}$/.test(String(info.sha256))) return '';
  if (core.cmpVersion(info.version, cur) <= 0) return '';
  if ((st.bad || []).indexOf(info.version) >= 0) return ''; // this version failed to start here before
  const file = path.join(P.updates, 'app-' + info.version + '.zip');
  log('Update ' + info.version + ' is available (installed: ' + cur + '). Downloading…');
  try {
    await core.download(c.feed.replace(/\/+$/, '') + '/' + (info.file || 'app.zip') + '?v=' + info.version, file, 120000);
    if (core.sha256File(file) !== info.sha256) { core.rmrf(file); throw new Error('checksum does not match — download discarded'); }
  } catch (e) { log('Update download failed: ' + e.message); setState({ lastError: e.message }); return ''; }
  setState({ staged: { version: info.version, file, at: Date.now() } });
  log('Update ' + info.version + ' downloaded and verified.');
  return info.version;
}
/** Applies a staged bundle. Only called while the server is stopped. */
function applyStaged() {
  const st = state();
  if (!st.staged || !fs.existsSync(st.staged.file)) return null;
  if (core.cmpVersion(st.staged.version, core.installedVersion(P)) <= 0) { core.rmrf(st.staged.file); setState({ staged: null }); return null; }
  try {
    const r = core.applyBundle(ROOT, st.staged.file, st.staged.version);
    core.rmrf(st.staged.file);
    setState({ staged: null, updatedAt: Date.now(), updatedFrom: r.from, justUpdated: r.to });
    log('Updated from ' + r.from + ' to ' + r.to + '.');
    return r;
  } catch (e) {
    log('Could not apply the update (' + e.message + '). Staying on ' + core.installedVersion(P) + '.');
    setState({ staged: null, lastError: e.message });
    return null;
  }
}

/* ---------- running the server ---------- */
function startServer(port, token) {
  const c = cfg();
  const node = fs.existsSync(path.join(P.runtime, 'node.exe')) ? path.join(P.runtime, 'node.exe') : process.execPath;
  const env = Object.assign({}, process.env, { LMS_DATA_DIR: P.data, PORT: String(port), HOST: process.env.HOST || '127.0.0.1', LMS_INSTALLED: '1', LMS_CTL_TOKEN: token });
  delete env.LMS_DEMO; delete env.LMS_ALERTS_OFF;
  if (c.mode === 'demo') { env.LMS_DEMO = '1'; env.LMS_ALERTS_OFF = '1'; }
  const child = spawn(node, ['server.js'], { cwd: P.app, env, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  const pipe = (s) => s.on('data', (d) => String(d).split(/\r?\n/).filter(Boolean).forEach((l) => log('  ' + l)));
  pipe(child.stdout); pipe(child.stderr);
  return child;
}
async function waitHealthy(port, child, ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    if (child.exitCode !== null) return false;
    if (await versionOf(port)) return true;
    await core.sleep(500);
  }
  return false;
}
const stopServer = (port, token) => local(port, 'POST', '/_ctl/shutdown', { 'x-ctl-token': token, 'content-length': '0' });
const exited = (child) => new Promise((r) => { if (child.exitCode !== null) r(child.exitCode); else child.once('exit', (code) => r(code)); });

async function main() {
  if (!fs.existsSync(path.join(P.app, 'server.js'))) { log('The app folder is missing. Please run the installer again.'); process.exit(1); }
  // Already running? Just open it.
  const running = core.readJson(P.run, null);
  if (running && running.port && await versionOf(running.port)) { log('Jacob Davis LMS is already running.'); openBrowser('http://localhost:' + running.port); return; }

  log('Jacob Davis LMS ' + core.installedVersion(P) + ' — starting. Keep this window open; closing it stops the LMS.');
  await stageUpdate(8000);
  applyStaged();

  let first = true;
  for (;;) {
    const c = cfg();
    const port = await pickPort(Number(c.port) || 3000);
    const token = crypto.randomBytes(24).toString('hex');
    const justUpdated = state().justUpdated || '';
    let child = startServer(port, token);
    const ok = await waitHealthy(port, child, 90000);
    if (!ok) {
      try { child.kill(); } catch (e) { /* gone */ }
      await exited(child);
      if (justUpdated) {
        // The new version did not start: put the previous one back and don't try this version again.
        const r = core.rollback(ROOT);
        setState({ justUpdated: '', bad: (state().bad || []).concat([justUpdated]).slice(-10) });
        log(r ? 'Version ' + justUpdated + ' did not start. Restored ' + r.restored + '.' : 'Version ' + justUpdated + ' did not start and there is no previous version to restore.');
        if (r) continue;
      }
      log('The LMS could not start. See ' + LOG);
      process.exit(1);
    }
    if (justUpdated) setState({ justUpdated: '' });
    core.writeJson(P.run, { pid: process.pid, serverPid: child.pid, port, token, startedAt: Date.now(), version: core.installedVersion(P) });
    const url = 'http://localhost:' + port;
    log('Running at ' + url);
    if (first) openBrowser(url);
    first = false;

    // Look for updates now and then; restart only when the site has been idle.
    let restart = false, busy = false;
    const tick = async () => {
      if (busy || restart) return;
      busy = true;
      try {
        const st = state();
        let staged = st.staged && fs.existsSync(st.staged.file) ? st.staged.version : '';
        if (!staged && Date.now() - (st.lastCheck || 0) >= CHECK_MS) staged = await stageUpdate(15000);
        if (staged) {
          const v = await versionOf(port);
          if (v && v.idleSec >= IDLE_SEC) {
            log('Nobody is using the site — restarting to apply update ' + staged + '.');
            restart = true;
            if (!await stopServer(port, token)) restart = false; // could not reach it; try again on the next tick
          }
        }
      } catch (e) { log('Update check failed: ' + e.message); } finally { busy = false; }
    };
    // Checks the update page every CHECK_MS; a downloaded update is retried every few minutes until the site is idle.
    const t2 = setInterval(tick, Math.min(CHECK_MS, 5 * 60000));
    const onSignal = () => { stopServer(port, token).then(() => setTimeout(() => { try { child.kill(); } catch (e) { /* gone */ } }, 3000)); };
    ['SIGINT', 'SIGTERM', 'SIGHUP'].forEach((s) => process.on(s, onSignal));

    const code = await exited(child);
    clearInterval(t2);
    ['SIGINT', 'SIGTERM', 'SIGHUP'].forEach((s) => process.removeListener(s, onSignal));
    core.rmrf(P.run);
    if (!restart) { log('Jacob Davis LMS stopped.'); process.exit(code || 0); }
    applyStaged();
  }
}
main().catch((e) => { log('Launcher error: ' + (e && e.stack ? e.stack : e)); process.exit(1); });
