'use strict';
/**
 * Shared by the installer (installer/setup.js) and the launcher (run.js): files, downloads,
 * checksums, a small safe unzip, and applying / rolling back an app bundle.
 *
 * An installed copy looks like this (ROOT is %LOCALAPPDATA%\JacobDavisLMS on Windows):
 *   ROOT/app/        the application — replaced as a whole on every update
 *   ROOT/runtime/    node.exe
 *   ROOT/launcher/   this folder (refreshed from app/installer/launcher after each update)
 *   ROOT/data/       the institution's records — never touched by setup or updates
 *   ROOT/updates/    downloaded bundles and update state
 *   ROOT/backup/     the previous version, kept for rollback
 *   ROOT/config.json { mode, port, feed, autoUpdate }
 *
 * Uses only Node's standard library, so it works before anything is installed.
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const http = require('http');
const https = require('https');
const crypto = require('crypto');

const DEFAULT_FEED = 'https://raw.githubusercontent.com/JacobDavisK/lms-updates/main';
const APP_ID = 'jd-lms';
const MAX_BUNDLE = 300 * 1024 * 1024;

function readJson(file, def) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { return def; } }
function writeJson(file, obj) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2));
  fs.renameSync(tmp, file);
}
function rmrf(p) { try { fs.rmSync(p, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 }); } catch (e) { /* best effort */ } }
function copyDir(from, to) { fs.mkdirSync(to, { recursive: true }); fs.cpSync(from, to, { recursive: true, force: true }); }
function sha256File(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 1 if a is newer than b, -1 if older, 0 if the same. Versions are dotted numbers (1.4.0). */
function cmpVersion(a, b) {
  const pa = String(a || '0').split('.').map((x) => parseInt(x, 10) || 0);
  const pb = String(b || '0').split('.').map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

/* ---------- network: https only (plain http is accepted for this computer, used by the tests) ---------- */
function allowedUrl(u) {
  let x;
  try { x = new URL(u); } catch (e) { return null; }
  if (x.protocol === 'https:') return x;
  if (x.protocol === 'http:' && (x.hostname === '127.0.0.1' || x.hostname === 'localhost')) return x;
  return null;
}
function request(url, timeoutMs, redirects) {
  return new Promise((resolve, reject) => {
    const u = allowedUrl(url);
    if (!u) { reject(new Error('Refusing to download from ' + url)); return; }
    const req = (u.protocol === 'https:' ? https : http).get(u, { headers: { 'User-Agent': 'jd-lms-updater', 'Cache-Control': 'no-cache' } }, (res) => {
      if ([301, 302, 303, 307, 308].indexOf(res.statusCode) >= 0 && res.headers.location) {
        res.resume();
        if ((redirects || 0) >= 5) { reject(new Error('Too many redirects')); return; }
        resolve(request(new URL(res.headers.location, u).toString(), timeoutMs, (redirects || 0) + 1));
        return;
      }
      if (res.statusCode !== 200) { res.resume(); reject(new Error('HTTP ' + res.statusCode + ' for ' + u.pathname)); return; }
      resolve(res);
    });
    req.setTimeout(timeoutMs || 15000, () => req.destroy(new Error('Timed out')));
    req.on('error', reject);
  });
}
async function fetchJson(url, timeoutMs) {
  const res = await request(url, timeoutMs);
  const chunks = [];
  let n = 0;
  for await (const c of res) { n += c.length; if (n > 1024 * 1024) throw new Error('Response too large'); chunks.push(c); }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}
async function download(url, dest, timeoutMs) {
  const res = await request(url, timeoutMs || 30000);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const tmp = dest + '.part';
  const out = fs.createWriteStream(tmp);
  let n = 0;
  try {
    for await (const c of res) {
      n += c.length;
      if (n > MAX_BUNDLE) throw new Error('Download is larger than expected');
      if (!out.write(c)) await new Promise((r) => out.once('drain', r));
    }
    await new Promise((r, j) => out.end((e) => (e ? j(e) : r())));
  } catch (e) { out.destroy(); rmrf(tmp); throw e; }
  fs.renameSync(tmp, dest);
  return n;
}

/* ---------- unzip (stored + deflate), refusing paths that would escape the destination ---------- */
function unzip(zipFile, destDir) {
  const buf = fs.readFileSync(zipFile);
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 66000); i--) { if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; } }
  if (eocd < 0) throw new Error('Not a zip file');
  const count = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  const root = path.resolve(destDir);
  let files = 0;
  for (let i = 0; i < count; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('Damaged zip file');
    const method = buf.readUInt16LE(p + 10);
    const crc = buf.readUInt32LE(p + 16);
    const csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nlen = buf.readUInt16LE(p + 28), elen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32);
    const local = buf.readUInt32LE(p + 42);
    const name = buf.slice(p + 46, p + 46 + nlen).toString('utf8').replace(/\\/g, '/');
    p += 46 + nlen + elen + clen;
    if (!name || name.endsWith('/')) { continue; }
    const target = path.resolve(root, name);
    if (target !== root && !target.startsWith(root + path.sep)) throw new Error('Unsafe path in zip: ' + name);
    const lnlen = buf.readUInt16LE(local + 26), lelen = buf.readUInt16LE(local + 28);
    const start = local + 30 + lnlen + lelen;
    const raw = buf.slice(start, start + csize);
    let data;
    if (method === 0) data = raw;
    else if (method === 8) data = zlib.inflateRawSync(raw);
    else throw new Error('Unsupported compression in zip');
    if (data.length !== usize || (zlib.crc32 && zlib.crc32(data) !== crc)) throw new Error('Damaged file in zip: ' + name);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, data);
    files++;
  }
  return files;
}

/* ---------- install layout ---------- */
function paths(root) {
  return {
    root, app: path.join(root, 'app'), appNew: path.join(root, 'app.new'), runtime: path.join(root, 'runtime'), launcher: path.join(root, 'launcher'),
    data: path.join(root, 'data'), updates: path.join(root, 'updates'), backup: path.join(root, 'backup'), logs: path.join(root, 'logs'),
    config: path.join(root, 'config.json'), run: path.join(root, 'run.json'), state: path.join(root, 'updates', 'state.json')
  };
}
function defaultRoot() {
  if (process.env.LMS_INSTALL_ROOT) return path.resolve(process.env.LMS_INSTALL_ROOT);
  if (process.platform === 'win32') return path.join(process.env.LOCALAPPDATA || path.join(require('os').homedir(), 'AppData', 'Local'), 'JacobDavisLMS');
  return path.join(require('os').homedir(), '.jacob-davis-lms');
}
function installedVersion(P) { return (readJson(path.join(P.app, 'package.json'), {}) || {}).version || '0.0.0'; }
function renameRetry(from, to) {
  let last;
  for (let i = 0; i < 25; i++) {
    try { fs.renameSync(from, to); return; } catch (e) { last = e; const t = Date.now() + 200; while (Date.now() < t) { /* brief wait: antivirus or a closing process may still hold a file */ } }
  }
  throw last;
}

/**
 * Replaces ROOT/app with the bundle. The old app is kept in ROOT/backup/app-<version> for rollback.
 * data/ is never part of a bundle and is never touched.
 */
function applyBundle(root, zipFile, expectVersion) {
  const P = paths(root);
  rmrf(P.appNew);
  unzip(zipFile, P.appNew);
  const pkg = readJson(path.join(P.appNew, 'package.json'), null);
  if (!pkg || !fs.existsSync(path.join(P.appNew, 'server.js')) || !fs.existsSync(path.join(P.appNew, 'node_modules', 'express'))) { rmrf(P.appNew); throw new Error('The update bundle is incomplete.'); }
  if (expectVersion && pkg.version !== expectVersion) { rmrf(P.appNew); throw new Error('The update bundle is version ' + pkg.version + ', expected ' + expectVersion + '.'); }
  const old = fs.existsSync(P.app) ? installedVersion(P) : '';
  if (old) {
    fs.mkdirSync(P.backup, { recursive: true });
    const keep = path.join(P.backup, 'app-' + old);
    rmrf(keep);
    renameRetry(P.app, keep);
    // keep only the most recent previous version
    fs.readdirSync(P.backup).filter((d) => d !== 'app-' + old).forEach((d) => rmrf(path.join(P.backup, d)));
  }
  try { renameRetry(P.appNew, P.app); } catch (e) {
    if (old) { try { renameRetry(path.join(P.backup, 'app-' + old), P.app); } catch (e2) { /* reported below */ } }
    throw e;
  }
  refreshLauncher(P);
  return { from: old, to: pkg.version };
}
/** The launcher lives outside app/ so it can replace app/; it picks up its own new version here. */
function refreshLauncher(P) {
  const src = path.join(P.app, 'installer', 'launcher');
  if (fs.existsSync(src)) { try { copyDir(src, P.launcher); } catch (e) { /* takes effect next time */ } }
}
function rollback(root) {
  const P = paths(root);
  const prev = fs.existsSync(P.backup) ? fs.readdirSync(P.backup).filter((d) => /^app-/.test(d))[0] : null;
  if (!prev) return null;
  const bad = installedVersion(P);
  rmrf(path.join(P.root, 'app.bad'));
  if (fs.existsSync(P.app)) renameRetry(P.app, path.join(P.root, 'app.bad'));
  renameRetry(path.join(P.backup, prev), P.app);
  rmrf(path.join(P.root, 'app.bad'));
  refreshLauncher(P);
  return { bad, restored: prev.slice(4) };
}

module.exports = { DEFAULT_FEED, APP_ID, readJson, writeJson, rmrf, copyDir, sha256File, sleep, cmpVersion, fetchJson, download, unzip, paths, defaultRoot, installedVersion, applyBundle, rollback, refreshLauncher, allowedUrl };
