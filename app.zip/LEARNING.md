# Learning Paths — adaptive practice, reviews and progress dashboards

Short lessons, practice with immediate feedback, spaced reviews, transparent adaptive recommendations, learning
habits (XP, goals, streaks, badges, challenges), a progress dashboard across every subject, privacy-safe class
progress, and faculty analytics. It is built into the LMS in the LMS's own stack: Node/Express, JSON stores and the
vanilla single-page app, with no new services or dependencies.

**Off until switched on.** Nothing changes for anyone until an administrator turns Learning Paths on (*Learning
settings*) and a teacher switches it on for a course. Practice never touches the gradebook.

## 1. Repository review (what it builds on)

| Area | Existing | Used for |
|---|---|---|
| Architecture | Express `POST /rpc` → route tables `{roles, fn}` merged in `lib/api.js`; JSON stores with debounced writes; vanilla SPA (`route()`, `ACT`/`FORMS`/`INPUTS`) | The new `lp*` routes and the `/learn/*` pages |
| Courses | `Courses`, `Sections` (units), `Modules`, `Enrolments` (`role` student/teacher), `lms.courseRole` | Subject = course, Unit = section; permissions |
| Assessment and grades | Quiz engine (`Quizzes`, `Attempts`), assignments, `lms.gradeItems/gradeCell` (respects release settings) | Released results on the subject page (read only) |
| Permissions | Session roles (student/teacher/admin/parent), per-course role, `ROLES` | Every `lp*` route; course editors author, students learn |
| Analytics | `lib/analytics.js` (usage), audit log | Audit entries `LEARN_*` |
| Background | Timers in each module, exit handlers | Debounced saves; no new background service |
| AI | `lib/ai.js` provider adapter (Anthropic/OpenAI/Google/local, built-in fallback) | Optional AI drafts |

## 2. Implementation plan and progress

| Stage | Scope | Status |
|---|---|---|
| 1 | Skill model (topics, skills, prerequisites), lessons and 9 activity types with variants, authoring, formative practice, immediate feedback, personal subject progress | Done |
| 2 | Spaced repetition (LP-SR-1), rule-based adaptation (LP-ADAPT-1), proficiency (LP-PROF-1) | Done |
| 3 | XP ledger (LP-XP-1), goals, streaks, badges, weekly challenges, class progress with visibility controls | Done |
| 4 | Faculty analytics, overrides, CSV, accessibility, caching, load test | Done |

Checklist, so work can resume safely:

- [x] Engine: grading, presentation, proficiency, scheduler, adaptation, XP, habits, peers (`lib/learnengine.js`)
- [x] Storage, append-only history, replay, clock injection (`lib/learnstore.js`)
- [x] Authoring, lessons, practice, answers, overrides, settings, routes (`lib/learning.js`)
- [x] Dashboards, class progress, analytics, inspection, export (`lib/learnviews.js`)
- [x] Student UI (`public/js/learn.js`), faculty/admin UI (`public/js/learn-teach.js`), styles (`public/css/learn.css`)
- [x] Demo seed (`scripts/seed-learning.js`), tests (`tests/learning.test.js`), load test (`tests/learning.load.js`)
- [ ] Later: data-driven difficulty calibration (needs enough answers per question; see § 9)
- [ ] Later: archiving old history to keep start-up memory small after several terms (see § 9)

## 3. Model

```
Subject (course) → Unit (course section) → Topic → Skill → Lesson / practice question
```

| Record | Where | Key fields |
|---|---|---|
| Topic | `content.json` `topics` | courseId, sectionId (unit), name, position |
| Skill | `topics` → `skills` | topicId, name, description, `prereqIds` (no cycles) |
| Lesson | `lessons` | topicId, minutes, objectives, blocks (text / image / video + transcript / worked example), `itemIds` (activities), `skillIds`, `prereqIds`, `required`, `dueAt`, status draft/review/published/archived, `v` (edit) and `major` (significant change) |
| Question (activity) | `items` | type, skillIds, difficulty 1–3 (faculty), level recognise/recall/apply, context, purpose practice/assessment, hints, explanation, misconceptions, **variants** (each with its own prompt and answer data), `ai`/`aiReviewed` |
| Curriculum version | `courses[id].versions` | a new version whenever the set of required published lessons changes or a lesson has a significant change |
| Accommodations | `accommodations[courseId][uid]` | extra days, weekly goal, leave out of ranking, private note |
| Assigned practice, unlocks | `assignments`, `unlocks` | faculty overrides |
| Preferences | `state.json` `prefs` | time zone, weekly days, daily XP goal, visibility, comparisons, celebrations |
| **History** | `events.ndjson` (append-only) | `a` answer · `x` XP award · `l` lesson completed · `b` badge · `p` skill status change |

An answer record holds who answered, the course, question, question type, variant, mode (lesson, practice, review,
assigned or preview), correctness, score, hints used, whether it was independent, whether the answer was revealed,
the try number, the server time, when the question was shown, the local day, a short summary of the answer, and the
capped active time.

**Server-side only.** Correctness, scores, schedules, proficiency, XP and completion are all calculated on the
server from the answer. A browser never sends progress, percentages or correctness.

## 4. Algorithms (versioned)

**Grading.** Normalised text matching (case, spaces, punctuation), numeric tolerance (absolute or %), thousands
separators and ₹ ignored, unit aliases, partial credit (multi-select, blanks, matching, ordering, case parts).
Reflections are never marked right or wrong; they need a minimum number of words. Options are shuffled per
presentation, matching sides are shuffled separately, and an ordering is never shown already in order. Answers,
accepted texts and explanations never leave the server before an answer is submitted.

**Feedback.** Correctness is shown at once.
- After a wrong answer, the student sees a misconception note if one matches: either an option, an exact wrong
  answer, or a numeric "common mistake".
- The full answer and explanation appear after a correct answer, after two tries, or when the student asks for them.
- Retrying is always allowed. Hints, retries and revealed answers are recorded and are kept distinct from
  independent success.

**Proficiency — LP-PROF-1** (per learner and skill):
1. Keep at most the latest 2 answers per question, so repeating a question cannot inflate the estimate. Then take
   the latest 12 answers.
2. Each answer is worth its score, or 60 % of it if a hint was used. Its weight is 0.85^recency × difficulty
   (0.8 / 1 / 1.2), halved for a question's second answer.
3. A prior of 0.3 with weight 1.5 pulls small samples down: estimate = (Σ weight·value + 0.45) ÷ (Σ weight + 1.5).
4. Statuses:
   - **Proficient:** estimate ≥ 0.8, with ≥ 3 different questions answered right on the learner's own, over ≥ 2 days.
   - **Practising:** estimate ≥ 0.5, with ≥ 2 questions.
   - **Developing:** anything below that.
   - **Due for review:** proficient, with review questions due.

   The thresholds are configurable per course.
5. "Enough evidence" means 3 different questions.

Limitations: it is an estimate, not a grade. It does not model forgetting between reviews, and answers with hints
only partly count. A single correct answer never makes a skill proficient, and 40 correct answers to one question
don't either (both are tested).

**Reviews — LP-SR-1** (per question, dates in the learner's time zone):
- **New card:** ease 2.3.
- **Wrong answer ("again"):** the question comes back tomorrow, counts a lapse, and ease drops by 0.2 (minimum 1.3).
- **Correct with a hint ("hard"):** interval × 1.2, ease drops by 0.15.
- **Correct on the learner's own ("good"):** 1 day, then 3 days, then interval × ease.
- **Answering before the due date** moves nothing forward; a mistake always brings the question back.
- **Cap:** 180 days.
- **Late answers:** an answer to a question shown *before* a newer answer was recorded never rewinds the schedule.

Review cards are rebuilt from the history on start-up, so the history is the single source of truth.

**Adaptation — LP-ADAPT-1** (transparent rules, not a learned model):
- **Candidates:** published practice questions for skills that are ready. A skill is ready when its prerequisites
  are Practising or better and its lesson is completed. A new learner gets the skills of their first open lesson.
  Teacher-assigned practice is always ready.
- **Score:**

  | Rule | Points |
  |---|---|
  | Assigned by the teacher | +100 |
  | Due for review | +40, plus 2 per overdue day (up to +20 more) |
  | Wrong within the last 7 days | +30 |
  | Skill developing or not started | +25 |
  | Skill practising | +12 |
  | Skill proficient and not due | −20 |
  | Difficulty fits the estimate (<0.45 intro, <0.75 core, otherwise stretch) | +10 |
  | Difficulty two levels off | −15 |
  | Answered right on the learner's own twice in a row | −40 |
  | Each time already seen today | −25 |
  | New question | +5 |
  | Application question, estimate ≥ 0.5 | +5 |

- **Choosing:** ties break deterministically, with at most 3 questions per skill in a session. The variant chosen is
  the least recently seen.
- **Explanation:** every question carries the main reason in plain words, for example "Recommended because you need
  more practice with this concept."
- **Speed is never used.** The active time is recorded (idle time and hidden tabs excluded), but only for
  information.
- **Faculty:** teachers see the scores, reasons and held-back questions for any student, and can assign practice or
  unlock lessons.
- **Switching off:** with adaptation switched off, practice follows the learning path in order.

**XP — LP-XP-1.** Every award has a unique key in the ledger, so the same event can never pay twice, whether a
request is repeated, replayed or arrives out of order.

| Event | XP | Once per |
|---|---|---|
| Lesson completed | 20 | lesson |
| Correct on the learner's own / with a hint | 10 / 5 | question and day, on at most 3 days |
| Correct after a mistake the same day | 3 | question and day |
| Review of a due question (recalled / not) | 8 / 4 | question and due date |
| Reflection | 10 | question |
| Daily goal reached | 15 | day |
| Skill reaches Practising / Proficient | 25 | skill and level |
| Weekly challenge | 40 | course, week and challenge |

Practice and review XP are capped at 400 a day. Wrong answers earn nothing. Teachers can change every value per
course.

**Habits.**
- **Active day:** a lesson completed, 3 questions answered, a review done, or a reflection written, counted in the
  learner's time zone.
- **Streak:** consecutive active days. It is kept until the end of today.
- **Weekly goal:** active days in the week (Monday to Sunday) against the learner's target.
- **Badges** reward consistency, improvement and application across *different* questions, including "Welcome back"
  after a break.
- **Weekly challenges:** three personal challenges and one class challenge, which everyone's answers count towards.
- **Not used:** there are no lives, no payments and no failure labels.
- **Opting out:** students can switch off comparisons and celebrations. Animations follow the device's
  reduced-motion setting.

## 5. Class progress and privacy

| Mode | Students see |
|---|---|
| Aggregate (default) | Class median completion, how many were active this week, and the class challenge |
| Pseudonymous | A list with automatic aliases, which are stable per course and different between courses |
| Named | Names. Only possible when the institution switches on *Allow named classmate lists* |

How the list is controlled:
- **Students** can choose "always an alias" or "hide me" when the institution allows it.
- **Small groups:** a group smaller than the threshold (5 by default) sees nothing individual, and neither does a
  group where too many classmates are hidden.
- **Rankings** need the institution's permission, the course setting and weekly XP shown. A student who switches off
  comparisons never sees rankings, and students with a "leave out of ranking" accommodation are never ranked.
- **Classmates** are the course's students, or only the same batch in that course (a course setting).
- **Fields shown:** a display name or alias, required-lesson completion %, milestones (units finished plus skills
  proficient), whether the student was active this week, and optionally weekly XP and badge count.
- **Never shown:** grades, answers, mistakes, accommodations, teacher feedback, exact times, exam or proctoring data.
  The tests check this.

## 6. Dashboards

- **Student overview, across all enrolled subjects:**
  - per-subject cards with required completion and its denominator (or "No required activities yet"), the skill
    status distribution (never a single number across subjects) and reviews due;
  - Today, streak, the week, personal bests and achievements;
  - recommended next actions, upcoming deadlines (from the calendar, plus suggested lesson dates adjusted for
    accommodations) and recent activity.
- **Subject:**
  - the learning path, with states: done / open / locked / updated since completed;
  - skills, each with its estimate or "not enough evidence";
  - a 14-day review schedule;
  - an 8-week trend;
  - this week's challenges;
  - released assessment results (from the gradebook, respecting release settings);
  - class progress.
- **Every metric** has a definition (the ⓘ button) and an update time.
- **Faculty:**
  - summary, participation over 28 days, lessons per week, unit completion;
  - skills, hardest first, with how often they were answered right independently and with hints;
  - common wrong answers, with the misconception note where one exists;
  - question performance (right first time, hints, answers revealed, "very easy" / "many find this hard" flags);
  - curriculum coverage;
  - students who may benefit from support, described by recent activity only;
  - per-student inspection with overrides (assign practice, unlock, accommodation);
  - CSV export (course teachers only);
  - course settings (availability, cohort, visibility, rewards, proficiency rules, version history).

## 7. Configuration and rollout

1. **Administrator:** open *Learning settings* and switch on Learning Paths. Optionally adjust the features (adaptive
   practice, reviews, gamification, class progress, AI drafts), named lists, rankings, student choice, the
   smallest-group threshold and the default time zone.
2. **Teacher:** open *Learning paths*, then a course.
   - Add topics and skills, write questions (with variants) and lessons, and publish them.
   - Under **Settings**, switch the course on for students and choose the class-progress visibility.
3. **AI drafts** use the AI provider already set up for the site. Drafts always land as drafts and cannot be
   published until a teacher ticks "I have reviewed this". The prompt forbids invented references and citations.
   Everything works without any AI.

## 8. Migrations, rollback and backfill

- **Additive only.** A new folder `data/learning/` is created on first use. No existing record is changed or
  deleted, and the gradebook, quizzes, completions and enrolments are only read.
- **Rollback.** Switch Learning Paths off: everything is hidden and the LMS behaves as before. To remove it entirely,
  run the previous version of the app; `data/learning/` is simply ignored. Deleting that folder removes all learning
  data and nothing else.
- **Backfill.** There is none, deliberately. Existing quiz attempts and grades are not converted into practice
  history, because they are summative and would distort proficiency. Proficiency starts from the first practice.
- **Algorithm changes.** Review cards are rebuilt from the history at start-up, so a new scheduler version
  reschedules from the same answers without rewriting history. Each card records its scheduler version, and each
  completion records the lesson and curriculum version it was made on.
- **Backups.** `npm run backup` already includes `data/learning/`.

## 9. Performance (measured on 2026-10-14, on this laptop)

`node tests/learning.load.js 450 60`: real HTTP against the real server.
- **Set-up:** one class of 456 students (450 virtual plus 6 demo), each signed in with their own session.
- **Each virtual student repeats this, with think time:** dashboard → subject → a 5-question practice session →
  class progress (half the time) → reviews (40 % of the time).

| Action | Requests | p50 ms | p95 ms | p99 ms | max ms |
|---|---|---|---|---|---|
| Answer (`lpAnswer`) | 2,875 | 8.4 | 31.3 | 48.3 | 85.2 |
| Dashboard (`lpHome`) | 1,217 | 5.2 | 32.1 | 56.6 | 98.5 |
| Class progress (`lpPeers`) | 585 | 20.4 | 53.7 | 79.0 | 101.2 |
| Practice / review session (`lpPractice`) | 1,677 | 7.6 | 35.5 | 57.5 | 91.4 |
| Subject (`lpSubject`) | 1,217 | 12.5 | 43.3 | 62.1 | 82.3 |

Overall: 8,788 requests, 115 a second, **0 errors**, p95 37 ms, peak server memory 120 MB.

How it stays fast:
- learners' histories are indexed in memory;
- proficiency is memoised until a learner's history changes;
- class summaries and faculty analytics are computed in one pass and cached for 15 s while the class is active,
  or up to 60 s when nothing changed. Privacy changes clear the cache at once;
- there is no per-classmate query and no polling.

Limits, measured:
- **Start-up and memory.** A term of history (562,000 records for 450 students) replays in 1.7 s and uses about
  330 MB. Plan for 1 GB or more, and archive history after several terms (not built yet).
- **One process.** The JSON store runs in a single Node process, so it scales up, not out.
- **Numbers.** These are measured on one laptop; a server will differ.
- **Re-checking.** Re-run the load test after changes: `npm run load:learning`. CI runs a short version
  (150 students, 20 s) on every push.

## 10. Tests

`npm run test:learning` runs 119 checks on a throwaway demo copy with an injected clock. They cover:
- grading of every type, and that no answers leak before submission;
- proficiency, including the single-answer and repetition limits;
- review scheduling and late (out-of-order) answers;
- time zones, daylight saving and week and streak boundaries;
- idempotent and replayed answers, and history replay after a restart;
- repeated-question and refresh XP abuse, and the daily cap;
- course and cohort isolation, and batch cohorts;
- every visibility mode, student choices, ranking opt-outs and small-group suppression;
- that class progress never carries grades, answers or accommodations;
- curriculum versions (drafts, new required lessons, significant changes);
- empty courses, and dashboard sums matching the underlying data;
- feature flags, role checks, AI-draft review, CSV and assigned practice.

## 11. Known limitations

- **Difficulty** is the teacher's label. Data-driven calibration should only be added once a question has about 30+
  first attempts from different students; analytics already flags questions as "very easy" or "many find this hard".
- **Images** in lessons are stored inline (up to 400 KB each); there is no image library yet.
- **Video** supports YouTube and Vimeo links, with a transcript for accessibility.
- **Parents** don't see learning progress yet.
- **Notifications** are only sent for assigned practice; there are no reminder notifications, by design.
- **Time zones:** a learner's past days keep the time zone they were recorded in. Changing time zone affects only new
  activity.

## 12. Run it locally

```
LMS_DEMO=1 LMS_DATA_DIR=../demo-data node scripts/seed-learning.js   # after seed-demo and seed-studio
npm run test:learning
npm run load:learning                                                 # 450 students, 60 s
```

On the demo site, sign in with the Student tile (Anitha) and open **My learning**. With the Faculty tile, open
**Learning paths → FM301**.
