/**
 * Learning Paths — DEMO DATA (fictional students). For demo installations only.
 *
 *   LMS_DEMO=1 node scripts/seed-learning.js          (after scripts/seed-demo.js)
 *
 * Switches Learning Paths on and gives the demo faculty (Priya Sharma) two learning paths:
 *   • FM301 Financial Management — 9 lessons, 8 skills, 19 practice questions with variants (numerical answers
 *     with units and tolerance, cases, matching, ordering, reflection …); classmates shown under aliases.
 *   • FACC101 Financial Accounting — 3 lessons, 3 skills, 7 questions; a group of 4, so classmates see totals only.
 * Then six demo students learn for three weeks — through the real APIs, with the clock moved back day by day —
 * so every dashboard number is produced by the actual engine. Each student has a different pattern (steady,
 * struggling, stopped a week ago …). Anitha (the Student tile) has reviews due and lessons left to do.
 *
 * Refuses to run without LMS_DEMO=1, or on a database that holds real student accounts. Runs once.
 */
'use strict';
if (process.env.LMS_DEMO !== '1') { console.error('Refusing to run: set LMS_DEMO=1. The learning demo is only for demo installations.'); process.exit(1); }
process.env.LMS_ALERTS_OFF = '1';
const store = require('../lib/store');
const DEMO_USER = /^(demo|userdemo|mdemo)\./;
const real = store.rows('Users').filter((u) => u.role === 'student' && u.status === 'active' && !DEMO_USER.test(String(u.username)));
if (real.length) { console.error('Refusing to run: this database has ' + real.length + ' real student account(s). The learning demo is only for demo installations.'); process.exit(1); }
const byName = (n) => store.rows('Users').find((u) => u.username === n);
if (!byName('demo.teacher')) { console.error('Run scripts/seed-demo.js first.'); process.exit(1); }
require('../lib/api');
const LRN = require('../lib/learning');
const L = LRN._store;
const E = LRN._engine;
if (!store.rows('Courses').some((c) => c.shortname === 'FM301' && c.deleted !== 'Y')) { console.error('Run scripts/seed-studio.js first (it creates the FM301 course).'); process.exit(1); }
if (L.C.settings.demoSeeded) { console.log('Learning Paths demo data is already installed. Nothing to do.'); process.exit(0); }

const sess = (u) => ({ uid: u.id, username: String(u.username), name: String(u.name), role: u.role });
function as(u) {
  const s = sess(u);
  return (action, p) => { const r = LRN.ROUTES[action]; if (!r || r.roles.indexOf(s.role) < 0) throw new Error(u.username + ' may not ' + action); return r.fn(s, p || {}); };
}
const T = as(byName('demo.teacher'));
const A = as(byName('demo.admin'));
const course = (short) => store.rows('Courses').find((c) => c.deleted !== 'Y' && c.shortname === short);
const sectionsOf = (cid) => store.rows('Sections').filter((x) => x.courseId === cid && x.deleted !== 'Y').sort((a, b) => a.position - b.position);

/* ---------- content helpers ---------- */
const rupee = { unit: '₹', unitAliases: 'rs|inr|rupees|rs.' };
const opts = (...t) => t.map((x, i) => ({ id: 'abcdefgh'[i], text: x }));
function mkTopic(cid, sectionId, name) { T('lpSaveTopic', { courseId: cid, sectionId, name }); return L.topicsOf(cid).find((t) => t.name === name).id; }
function mkSkill(cid, topicId, name, description, prereqNames) {
  const pre = (prereqNames || []).map((n) => L.skillsOf(cid).find((k) => k.name === n).id);
  T('lpSaveSkill', { courseId: cid, topicId, name, description, prereqIds: pre });
  return L.skillsOf(cid).find((k) => k.name === name).id;
}
function mkItem(cid, skillIds, item) { const r = T('lpSaveItem', { courseId: cid, item: Object.assign({ skillIds }, item) }); T('lpSetItemStatus', { id: r.id, status: 'published' }); return r.id; }
function mkLesson(cid, topicId, l) {
  T('lpSaveLesson', Object.assign({ courseId: cid, topicId }, l));
  const id = L.lessonsOf(cid).find((x) => x.title === l.title).id;
  T('lpSetLessonStatus', { id, status: 'published' });
  return id;
}

/* ======================================================================
 * FM301 — Financial Management
 * ==================================================================== */
function financialManagement() {
  const c = course('FM301');
  const cid = c.id;
  const sec = sectionsOf(cid).filter((x) => /Unit/.test(x.title));
  const tTvm = mkTopic(cid, sec[0].id, 'Time value of money');
  const tInv = mkTopic(cid, sec[1].id, 'Investment appraisal');
  const tCoc = mkTopic(cid, sec[2].id, 'Cost of capital');
  const tWc = mkTopic(cid, sec[3].id, 'Working capital management');
  const S1 = mkSkill(cid, tTvm, 'Future value and compounding', 'Grow a sum of money at a compound rate over several periods.');
  const S2 = mkSkill(cid, tTvm, 'Present value and discounting', 'Find what a future amount is worth today.', ['Future value and compounding']);
  const S3 = mkSkill(cid, tInv, 'Payback period', 'How long a project takes to recover its cost.');
  const S4 = mkSkill(cid, tInv, 'Net present value (NPV)', 'Discount all cash flows and compare with the investment.', ['Present value and discounting']);
  const S5 = mkSkill(cid, tCoc, 'Cost of debt and equity', 'The return lenders and shareholders require.');
  const S6 = mkSkill(cid, tCoc, 'Weighted average cost of capital (WACC)', 'Combine the costs of each source by its weight.', ['Cost of debt and equity']);
  const S7 = mkSkill(cid, tWc, 'Operating cycle', 'The time from buying materials to collecting cash.');
  const S8 = mkSkill(cid, tWc, 'Working capital needs', 'How the business situation changes the money tied up in operations.');

  const fv = mkItem(cid, [S1], {
    type: 'numeric', title: 'Future value of a deposit', difficulty: 2, level: 'application', context: 'real-world',
    hints: ['Future value = Principal × (1 + r)ⁿ', 'Use r as a decimal: 8% = 0.08.'],
    explanation: 'Each year’s interest is added to the balance, so the next year earns interest on a larger amount: FV = P × (1 + r)ⁿ.',
    variants: [
      { prompt: 'Kavya deposits ₹10,000 in a bank fixed deposit at 8% a year, compounded annually. How much will she have after 3 years?', data: Object.assign({ answer: 12597.12, tolerancePct: 0.2, wrong: [{ value: 12400, text: 'That is simple interest (₹800 × 3). With compounding, interest also earns interest.' }] }, rupee) },
      { prompt: 'A cooperative society invests ₹25,000 at 10% a year, compounded annually. What is the value after 2 years?', data: Object.assign({ answer: 30250, tolerancePct: 0.2, wrong: [{ value: 30000, text: 'That is simple interest. The second year earns interest on ₹27,500, not ₹25,000.' }] }, rupee) },
      { prompt: 'Rahul invests ₹50,000 at 6% a year, compounded annually. What will it grow to in 4 years?', data: Object.assign({ answer: 63123.85, tolerancePct: 0.2, wrong: [{ value: 62000, text: 'That is simple interest. Compounding gives a little more each year.' }] }, rupee) }
    ]
  });
  const fvFormula = mkItem(cid, [S1], {
    type: 'mcq', title: 'Formula for future value', difficulty: 1, level: 'recognition',
    hints: ['Compounding multiplies by (1 + r) once for every period.'],
    explanation: 'FV = PV × (1 + r)ⁿ. PV × (1 + r × n) is simple interest; dividing by (1 + r)ⁿ gives a present value instead.',
    misconceptions: [{ when: 'c', text: 'PV × (1 + r × n) is simple interest — it ignores interest earned on interest.' }, { when: 'b', text: 'Dividing by (1 + r)ⁿ discounts to a present value; it goes the other way.' }],
    prompt: 'Which formula gives the future value (FV) of a single amount invested today (PV) at rate r for n periods, compounded each period?',
    data: { options: opts('FV = PV × (1 + r)ⁿ', 'FV = PV ÷ (1 + r)ⁿ', 'FV = PV × (1 + r × n)', 'FV = PV × r × n'), correct: 'a' }
  });
  const fill = mkItem(cid, [S1], {
    type: 'fill', title: 'What compounding means', difficulty: 1, level: 'recall',
    hints: ['Think of what the interest is calculated on.'],
    explanation: 'Compound interest is earned on the principal and on interest already added to the account.',
    prompt: 'Complete the sentence.', data: { text: 'Compounding means earning interest on both the {{1}} and the interest already {{2}}.', blanks: [{ accept: ['principal', 'principal amount', 'original amount'] }, { accept: ['earned', 'added', 'accumulated', 'credited'] }] }
  });
  const pv = mkItem(cid, [S2], {
    type: 'numeric', title: 'Present value of a future receipt', difficulty: 2, level: 'application', context: 'real-world',
    hints: ['PV = Future amount ÷ (1 + r)ⁿ', 'Discounting is compounding in reverse.'],
    explanation: 'Divide the future amount by (1 + r)ⁿ to find what it is worth today.',
    variants: [
      { prompt: 'A customer promises to pay ₹1,00,000 in 2 years. At a discount rate of 10%, what is it worth today?', data: Object.assign({ answer: 82644.63, tolerancePct: 0.2, wrong: [{ value: 121000, text: 'You compounded forward. To find today’s value, divide by (1 + r)ⁿ instead of multiplying.' }, { value: 80000, text: 'Taking off 10% for each year is simple discounting; divide by 1.10 twice instead.' }] }, rupee) },
      { prompt: 'What is the present value of ₹50,000 receivable in 3 years at 8%?', data: Object.assign({ answer: 39691.61, tolerancePct: 0.2, wrong: [{ value: 62985.6, text: 'You compounded forward. Divide by (1.08)³ instead.' }] }, rupee) },
      { prompt: 'A scholarship of ₹2,00,000 will be paid after 1 year. At 12%, what is its value today?', data: Object.assign({ answer: 178571.43, tolerancePct: 0.2, wrong: [{ value: 176000, text: 'Taking 12% off the future amount is not the same as dividing by 1.12.' }] }, rupee) }
    ]
  });
  const pvRate = mkItem(cid, [S2], {
    type: 'mcq', title: 'Discount rate and present value', difficulty: 1, level: 'recall',
    hints: ['A higher rate means a bigger divisor.'],
    explanation: 'PV = FV ÷ (1 + r)ⁿ, so a higher discount rate makes the present value smaller.',
    prompt: 'If the discount rate rises, the present value of a fixed future cash flow…',
    data: { options: opts('falls', 'rises', 'stays the same', 'becomes negative'), correct: 'a' }
  });
  const match = mkItem(cid, [S2], {
    type: 'match', title: 'Time value terms', difficulty: 2, level: 'recall',
    hints: ['An annuity has an end; a perpetuity does not.'],
    explanation: 'These four terms come up in every valuation problem.',
    prompt: 'Match each term with its meaning.',
    data: { pairs: [{ left: 'Discount rate', right: 'The rate used to convert future cash flows to today’s value' }, { left: 'Annuity', right: 'Equal cash flows at regular intervals for a fixed period' }, { left: 'Perpetuity', right: 'Equal cash flows that continue forever' }, { left: 'Present value', right: 'What a future amount is worth today' }] }
  });
  const reflect = mkItem(cid, [S2], {
    type: 'reflection', title: 'Time value in your own life', difficulty: 1, level: 'application', context: 'real-world',
    hints: ['Would ₹1 lakh now or ₹1.1 lakh in two years be better? What decides it?'],
    explanation: 'There is no single right answer. Good reflections mention the interest you could earn or pay, risk, and inflation.',
    prompt: 'Think of a money decision in your family — a two-wheeler on EMI, a fixed deposit, or expanding a shop. How does the time value of money change how you would decide?',
    data: { minWords: 25 }
  });
  const payback = mkItem(cid, [S3], {
    type: 'numeric', title: 'Payback period', difficulty: 1, level: 'application', context: 'real-world',
    hints: ['Payback = Investment ÷ Annual cash saving (when savings are equal each year).'],
    explanation: 'With equal yearly cash flows, divide the investment by the yearly cash flow.',
    variants: [
      { prompt: 'A textile unit in Tiruppur buys a machine for ₹6,00,000. It saves ₹1,50,000 a year. What is the payback period (in years)?', data: { answer: 4, tolerance: 0.01, unit: 'years', unitAliases: 'year|yrs|yr', wrong: [{ value: 0.25, text: 'You divided the saving by the investment. Divide the investment by the yearly saving.' }] } },
      { prompt: 'A bakery spends ₹7,50,000 on a new oven that brings in an extra ₹2,50,000 a year. Payback period in years?', data: { answer: 3, tolerance: 0.01, unit: 'years', unitAliases: 'year|yrs|yr', wrong: [] } },
      { prompt: 'Solar panels for a college cost ₹5,40,000 and cut electricity bills by ₹1,20,000 a year. Payback period in years?', data: { answer: 4.5, tolerance: 0.01, unit: 'years', unitAliases: 'year|yrs|yr', wrong: [{ value: 4, text: 'Close — but ₹1,20,000 × 4 = ₹4,80,000, so half a year more is needed.' }] } }
    ]
  });
  const paybackLim = mkItem(cid, [S3], {
    type: 'multi', title: 'Limits of the payback method', difficulty: 2, level: 'recall',
    hints: ['What happens to cash flows after the payback date?', 'Does payback discount anything?'],
    explanation: 'Payback ignores the time value of money and every cash flow after the payback date. It is easy to calculate, and it does not systematically favour large projects.',
    prompt: 'Select all the limitations of the payback period method.',
    data: { options: opts('It ignores the time value of money', 'It ignores cash flows after the payback period', 'It always favours larger projects', 'It is difficult to calculate'), correct: ['a', 'b'] }
  });
  const npv = mkItem(cid, [S4], {
    type: 'numeric', title: 'NPV of a two-year project', difficulty: 3, level: 'application', context: 'real-world',
    hints: ['Discount each year’s inflow: inflow ÷ (1 + r)ⁿ.', 'NPV = sum of present values − initial investment.'],
    explanation: 'Discount each inflow to today, add them, then subtract the investment. A positive NPV adds value.',
    variants: [
      { prompt: 'A project costs ₹1,00,000 and returns ₹60,000 at the end of each of the next 2 years. At 10%, what is its NPV?', data: Object.assign({ answer: 4132.23, tolerancePct: 1, wrong: [{ value: 20000, text: 'You added the inflows without discounting them. Discount each year first.' }] }, rupee) },
      { prompt: 'A delivery van costs ₹2,00,000 and earns ₹1,20,000 at the end of each of the next 2 years. At 12%, what is its NPV?', data: Object.assign({ answer: 2806.12, tolerancePct: 1, wrong: [{ value: 40000, text: 'You added the inflows without discounting them. Discount each year first.' }] }, rupee) }
    ]
  });
  const npvRule = mkItem(cid, [S4], {
    type: 'mcq', title: 'NPV decision rule', difficulty: 1, level: 'recall',
    hints: ['A positive NPV means the project earns more than the required return.'],
    explanation: 'Accept when NPV > 0: the project earns more than the cost of capital and adds to shareholders’ wealth.',
    prompt: 'Under the NPV method, a project should be accepted when its NPV is…',
    data: { options: opts('greater than zero', 'less than zero', 'equal to the payback period', 'greater than the initial investment'), correct: 'a' }
  });
  const npvSteps = mkItem(cid, [S4], {
    type: 'order', title: 'Steps to calculate NPV', difficulty: 2, level: 'recall',
    hints: ['You need a rate before you can discount anything.'],
    explanation: 'Estimate cash flows → choose the rate → discount → add → subtract the investment.',
    prompt: 'Put the steps for calculating NPV in order.',
    data: { steps: [{ text: 'Estimate the project’s cash flows' }, { text: 'Choose the discount rate (cost of capital)' }, { text: 'Discount each cash flow to its present value' }, { text: 'Add the present values' }, { text: 'Subtract the initial investment' }] }
  });
  const npvCase = mkItem(cid, [S4, S3], {
    type: 'case', title: 'Sundaram Foods: two projects', difficulty: 3, level: 'application', context: 'real-world',
    hints: ['Shareholder wealth is measured by NPV, not by how fast money comes back.'],
    explanation: 'Project A adds ₹15,000 more value even though it pays back more slowly. Payback ignores the time value of money, so it should only support, not decide, the choice.',
    variants: [{
      scenario: 'Sundaram Foods, a snack maker in Madurai, can fund only one project this year.\n\n- **Project A** (new packaging line): NPV ₹45,000, payback 4 years\n- **Project B** (delivery vans): NPV ₹30,000, payback 2 years\n\nThe board says its goal is to maximise shareholders’ wealth.',
      prompt: '',
      parts: [
        { type: 'mcq', prompt: 'Which project should the board choose?', data: { options: opts('Project A', 'Project B'), correct: 'a' } },
        { type: 'numeric', prompt: 'By how much (₹) does Project A’s NPV exceed Project B’s?', data: Object.assign({ answer: 15000, tolerance: 1 }, rupee) },
        { type: 'short', prompt: 'Name the appraisal method that ignores the time value of money.', data: { accept: ['payback', 'payback period', 'payback method', 'payback period method'] } }
      ]
    }]
  });
  const kd = mkItem(cid, [S5], {
    type: 'numeric', title: 'After-tax cost of debt', difficulty: 2, level: 'application',
    hints: ['Interest is tax-deductible: Kd = interest rate × (1 − tax rate).'],
    explanation: 'Because interest reduces taxable profit, the real cost of debt is the interest rate × (1 − tax rate).',
    variants: [
      { prompt: 'A company borrows at 10% interest. Its tax rate is 30%. What is its after-tax cost of debt (%)?', data: { answer: 7, tolerance: 0.01, unit: '%', unitAliases: 'percent|per cent', wrong: [{ value: 10, text: 'That is the cost before tax. Interest saves tax, so multiply by (1 − 0.30).' }, { value: 3, text: '10% × 30% is the tax saved, not the cost. Use 10% × (1 − 30%).' }] } },
      { prompt: 'Debentures carry 12% interest and the tax rate is 25%. After-tax cost of debt (%)?', data: { answer: 9, tolerance: 0.01, unit: '%', unitAliases: 'percent|per cent', wrong: [{ value: 12, text: 'That is the cost before tax. Multiply by (1 − 0.25).' }] } }
    ]
  });
  const capm = mkItem(cid, [S5], {
    type: 'short', title: 'CAPM', difficulty: 1, level: 'recall',
    hints: ['It prices an asset using its risk compared with the market.'],
    explanation: 'CAPM — the Capital Asset Pricing Model — estimates the cost of equity as Rf + β × (Rm − Rf).',
    prompt: 'What does CAPM stand for?', data: { accept: ['capital asset pricing model'], keywords: ['capital', 'asset', 'pricing', 'model'] }
  });
  const wacc = mkItem(cid, [S6], {
    type: 'numeric', title: 'WACC', difficulty: 3, level: 'application', context: 'real-world',
    hints: ['Multiply each cost by its weight, then add.'],
    explanation: 'WACC = (weight of equity × cost of equity) + (weight of debt × after-tax cost of debt).',
    variants: [
      { prompt: 'A firm is financed 60% by equity costing 14% and 40% by debt with an after-tax cost of 7%. What is its WACC (%)?', data: { answer: 11.2, tolerance: 0.05, unit: '%', unitAliases: 'percent|per cent', wrong: [{ value: 10.5, text: 'That is a simple average. Weight each cost: 0.6 × 14 + 0.4 × 7.' }] } },
      { prompt: 'Equity is 70% of capital at 15%; debt is 30% at an after-tax 6%. WACC (%)?', data: { answer: 12.3, tolerance: 0.05, unit: '%', unitAliases: 'percent|per cent', wrong: [{ value: 10.5, text: 'That is a simple average. Weight each cost by its share of capital.' }] } }
    ]
  });
  const cycle = mkItem(cid, [S7], {
    type: 'order', title: 'Operating cycle of a manufacturer', difficulty: 1, level: 'recall',
    hints: ['Cash goes out first and comes back last.'],
    explanation: 'Cash → raw materials → finished goods → debtors (credit sales) → cash.',
    prompt: 'Arrange the stages of a manufacturer’s operating cycle in order.',
    data: { steps: [{ text: 'Buy raw materials' }, { text: 'Convert them into finished goods' }, { text: 'Sell the goods on credit' }, { text: 'Collect cash from debtors' }] }
  });
  const ccc = mkItem(cid, [S7], {
    type: 'numeric', title: 'Cash conversion cycle', difficulty: 2, level: 'application',
    hints: ['Cash conversion cycle = inventory days + debtor days − creditor days.'],
    explanation: 'Credit from suppliers shortens the time your own cash is tied up, so creditor days are subtracted.',
    variants: [
      { prompt: 'Inventory is held for 60 days, customers pay in 45 days and suppliers are paid in 30 days. Cash conversion cycle (days)?', data: { answer: 75, tolerance: 0, unit: 'days', unitAliases: 'day', wrong: [{ value: 135, text: 'Creditor days should be subtracted, not added.' }] } },
      { prompt: 'Inventory days 50, debtor days 30, creditor days 40. Cash conversion cycle (days)?', data: { answer: 40, tolerance: 0, unit: 'days', unitAliases: 'day', wrong: [{ value: 120, text: 'Creditor days should be subtracted, not added.' }] } }
    ]
  });
  const festive = mkItem(cid, [S8], {
    type: 'mcq', title: 'Festive season and working capital', difficulty: 2, level: 'application', context: 'real-world',
    hints: ['More sales means more stock and more money owed by customers.'],
    explanation: 'Higher expected sales mean more inventory and receivables, so more working capital is needed — often arranged through a short-term loan.',
    prompt: 'A textile retailer in Madurai expects Deepavali sales to double next month. What happens to its working capital requirement?',
    data: { options: opts('It increases', 'It decreases', 'It does not change', 'It becomes zero'), correct: 'a' },
    misconceptions: [{ when: 'b', text: 'Sales bring cash in later — first the shop must buy more stock and give more credit, which ties up more money.' }]
  });

  const l1 = mkLesson(cid, tTvm, { title: 'Why money today is worth more', minutes: 6, required: true, skillIds: [S1], itemIds: [fvFormula, fv, fill],
    objectives: ['Explain why a rupee today is worth more than a rupee tomorrow', 'Calculate the future value of a single sum'],
    blocks: [{ kind: 'text', text: 'Money you have **today** can be invested to earn interest. That is why ₹10,000 today is worth more than ₹10,000 a year from now.\n\nWhen interest is added to the balance and itself earns interest, we call it **compounding**.' },
      { kind: 'example', title: 'Worked example', problem: '₹10,000 is invested at 8% a year, compounded annually, for 2 years. What is it worth?', steps: ['Year 1: ₹10,000 × 1.08 = ₹10,800', 'Year 2: ₹10,800 × 1.08 = ₹11,664', 'Or in one step: ₹10,000 × (1.08)² = ₹11,664'], answer: '₹11,664' }] });
  const l2 = mkLesson(cid, tTvm, { title: 'Discounting to present value', minutes: 7, required: true, skillIds: [S2], prereqIds: [l1], itemIds: [pvRate, pv, match, reflect],
    objectives: ['Find the present value of a future amount', 'Explain how the discount rate affects present value'],
    blocks: [{ kind: 'text', text: 'Discounting answers the opposite question: *what is a future amount worth today?*\n\nPV = FV ÷ (1 + r)ⁿ' },
      { kind: 'example', title: 'Worked example', problem: 'What is ₹11,664 received in 2 years worth today at 8%?', steps: ['Divide by (1.08)² = 1.1664', '₹11,664 ÷ 1.1664 = ₹10,000'], answer: '₹10,000 — the same amount we started with in the last lesson.' }] });
  const l3 = mkLesson(cid, tInv, { title: 'Payback period', minutes: 5, required: true, skillIds: [S3], itemIds: [payback, paybackLim],
    objectives: ['Calculate the payback period for equal cash flows', 'State two limitations of payback'],
    blocks: [{ kind: 'text', text: 'The **payback period** is how long it takes for a project’s cash inflows to repay its cost. It is quick to calculate and easy to explain, so many small businesses use it — but it has blind spots.' }] });
  const l4 = mkLesson(cid, tInv, { title: 'Net present value', minutes: 8, required: true, skillIds: [S4], prereqIds: [l2], itemIds: [npvRule, npvSteps, npv],
    objectives: ['Calculate NPV for a short project', 'Apply the NPV decision rule'],
    blocks: [{ kind: 'text', text: '**NPV** discounts every future cash flow at the cost of capital and subtracts the investment.\n\n- NPV > 0: the project earns more than investors require — accept\n- NPV < 0: reject' },
      { kind: 'example', title: 'Worked example', problem: 'Cost ₹50,000; inflow ₹30,000 at the end of years 1 and 2; rate 10%.', steps: ['Year 1: 30,000 ÷ 1.10 = 27,272.73', 'Year 2: 30,000 ÷ 1.21 = 24,793.39', 'Total PV = 52,066.12', 'NPV = 52,066.12 − 50,000 = ₹2,066.12'], answer: 'NPV ₹2,066.12 — accept.' }] });
  mkLesson(cid, tInv, { title: 'Choosing between projects (case)', minutes: 6, required: false, skillIds: [S4, S3], prereqIds: [l3, l4], itemIds: [npvCase],
    objectives: ['Choose between projects using NPV and payback'], blocks: [{ kind: 'text', text: 'Real decisions compare projects. Read the case and decide as the finance manager would.' }] });
  const l6 = mkLesson(cid, tCoc, { title: 'Cost of debt and equity', minutes: 6, required: true, skillIds: [S5], itemIds: [kd, capm],
    objectives: ['Calculate the after-tax cost of debt', 'Name the model used for the cost of equity'],
    blocks: [{ kind: 'text', text: 'Lenders want interest; shareholders want a return. Because interest is tax-deductible, debt costs less than its interest rate: **Kd = i × (1 − t)**.' }] });
  mkLesson(cid, tCoc, { title: 'Weighted average cost of capital', minutes: 6, required: true, skillIds: [S6], prereqIds: [l6], itemIds: [wacc],
    objectives: ['Calculate WACC from weights and costs'], blocks: [{ kind: 'text', text: 'WACC blends the cost of each source of finance by its share of total capital. It is the minimum return a new project must earn.' }] });
  mkLesson(cid, tWc, { title: 'The operating cycle', minutes: 5, required: true, skillIds: [S7], itemIds: [cycle, ccc],
    objectives: ['Describe the stages of the operating cycle', 'Calculate the cash conversion cycle'], blocks: [{ kind: 'text', text: 'Working capital funds the everyday cycle of buying, making, selling and collecting.' }] });
  mkLesson(cid, tWc, { title: 'Planning working capital', minutes: 4, required: true, skillIds: [S8], itemIds: [festive],
    objectives: ['Explain how seasonal sales change working capital needs'], blocks: [{ kind: 'text', text: 'Seasonal businesses — festive retail, agriculture, tourism — need more working capital before their busy season.' }] });
  T('lpSaveCourseCfg', { courseId: cid, enabled: true, peer: { mode: 'pseudonymous', showXp: true, showBadges: true } });
  return { cid, skills: { S2 } };
}

/* ======================================================================
 * FACC101 — Financial Accounting
 * ==================================================================== */
function financialAccounting() {
  const c = course('FACC101');
  const cid = c.id;
  const sec = sectionsOf(cid);
  const s1 = sec.find((x) => /Journal/.test(x.title)) || sec[0];
  const s2 = sec.find((x) => /Trial/.test(x.title)) || sec[sec.length - 1];
  const tEq = mkTopic(cid, s1.id, 'Accounting equation');
  const tJe = mkTopic(cid, s1.id, 'Journal entries');
  const tTb = mkTopic(cid, s2.id, 'Trial balance');
  const A1 = mkSkill(cid, tEq, 'Accounting equation', 'Assets = Liabilities + Capital');
  const A2 = mkSkill(cid, tJe, 'Debit and credit rules', 'Which account to debit and which to credit.', ['Accounting equation']);
  const A3 = mkSkill(cid, tTb, 'Preparing a trial balance', 'Listing ledger balances and what the trial balance can and cannot show.', ['Debit and credit rules']);
  const a1 = mkItem(cid, [A1], { type: 'numeric', title: 'Find the capital', difficulty: 1, level: 'application', hints: ['Capital = Assets − Liabilities'], explanation: 'Rearrange the accounting equation: Capital = Assets − Liabilities.',
    variants: [{ prompt: 'A shop has assets of ₹5,00,000 and liabilities of ₹2,00,000. What is the owner’s capital?', data: Object.assign({ answer: 300000, tolerance: 1, wrong: [{ value: 700000, text: 'Liabilities are subtracted from assets, not added.' }] }, rupee) },
      { prompt: 'Assets ₹8,50,000; liabilities ₹3,50,000. Capital?', data: Object.assign({ answer: 500000, tolerance: 1, wrong: [{ value: 1200000, text: 'Liabilities are subtracted from assets, not added.' }] }, rupee) }] });
  const a2 = mkItem(cid, [A1], { type: 'mcq', title: 'Effect of additional capital', difficulty: 1, level: 'recall', hints: ['Cash comes in — which side changes?'], explanation: 'Cash (an asset) increases and capital increases by the same amount, so the equation stays balanced.',
    prompt: 'The owner brings in additional capital in cash. What is the effect on the accounting equation?', data: { options: opts('Assets and capital both increase', 'Assets increase and liabilities decrease', 'Capital increases and liabilities increase', 'No effect'), correct: 'a' } });
  const a3 = mkItem(cid, [A2], { type: 'match', title: 'Nature of accounts', difficulty: 2, level: 'recall', hints: ['Expenses and incomes are nominal accounts.'], explanation: 'Classifying the account tells you which rule of debit and credit to apply.',
    prompt: 'Match each account with its type.', data: { pairs: [{ left: 'Rent paid', right: 'Expense (nominal account)' }, { left: 'Furniture', right: 'Asset (real account)' }, { left: 'Creditor – Ravi Traders', right: 'Liability (personal account)' }, { left: 'Commission received', right: 'Income (nominal account)' }] } });
  const a4 = mkItem(cid, [A2], { type: 'mcq', title: 'Goods bought for cash', difficulty: 1, level: 'application', hints: ['Goods bought for resale go to one specific account.'], explanation: 'Purchases A/c Dr, To Cash A/c — goods bought for resale are debited to Purchases.',
    misconceptions: [{ when: 'b', text: 'Goods for resale are recorded in Purchases, not in a goods or stock account.' }],
    prompt: 'Goods worth ₹20,000 are purchased for cash. Which account is debited?', data: { options: opts('Purchases account', 'Stock account', 'Cash account', 'Sales account'), correct: 'a' } });
  const a5 = mkItem(cid, [A2], { type: 'fill', title: 'Rule for real accounts', difficulty: 1, level: 'recall', hints: ['Think of an asset entering or leaving the business.'], explanation: 'Real accounts: debit what comes in, credit what goes out.',
    prompt: 'Complete the rule for real accounts.', data: { text: 'Debit what comes {{1}}, credit what goes {{2}}.', blanks: [{ accept: ['in'] }, { accept: ['out'] }] } });
  const a6 = mkItem(cid, [A3], { type: 'multi', title: 'Errors a trial balance cannot show', difficulty: 3, level: 'recall', hints: ['If both sides are affected equally, the totals still agree.'], explanation: 'Omission, compensating errors and errors of principle affect debits and credits equally, so the trial balance still agrees. Posting to the wrong side does change the totals.',
    prompt: 'Which of these errors will NOT be revealed by a trial balance? Select all that apply.', data: { options: opts('Complete omission of a transaction', 'Compensating errors', 'Errors of principle', 'Posting an amount to the wrong side of an account'), correct: ['a', 'b', 'c'] } });
  const a7 = mkItem(cid, [A3], { type: 'short', title: 'What a trial balance lists', difficulty: 1, level: 'recall', hints: ['Each ledger account ends with one of these.'], explanation: 'A trial balance lists the debit and credit balances of all ledger accounts on a date.',
    prompt: 'A trial balance is a statement of the debit and credit ______ of ledger accounts. Fill in the missing word.', data: { accept: ['balances', 'balance'] } });
  const f1 = mkLesson(cid, tEq, { title: 'The accounting equation', minutes: 5, required: true, skillIds: [A1], itemIds: [a2, a1], objectives: ['State the accounting equation', 'Find capital from assets and liabilities'],
    blocks: [{ kind: 'text', text: 'Everything a business owns (**assets**) is financed either by outsiders (**liabilities**) or by the owner (**capital**):\n\n**Assets = Liabilities + Capital**' }] });
  const f2 = mkLesson(cid, tJe, { title: 'Rules of debit and credit', minutes: 7, required: true, skillIds: [A2], prereqIds: [f1], itemIds: [a3, a5, a4], objectives: ['Classify accounts', 'Apply the rules of debit and credit'],
    blocks: [{ kind: 'text', text: '- **Personal:** debit the receiver, credit the giver\n- **Real:** debit what comes in, credit what goes out\n- **Nominal:** debit expenses and losses, credit incomes and gains' }] });
  mkLesson(cid, tTb, { title: 'The trial balance', minutes: 6, required: true, skillIds: [A3], prereqIds: [f2], itemIds: [a7, a6], objectives: ['Explain the purpose of a trial balance', 'Identify errors it cannot reveal'],
    blocks: [{ kind: 'text', text: 'A trial balance checks that total debits equal total credits. Agreement does not prove the books are free of errors.' }] });
  T('lpSaveCourseCfg', { courseId: cid, enabled: true, peer: { mode: 'pseudonymous', showXp: false } });
  return { cid };
}

/* ======================================================================
 * THREE WEEKS OF LEARNING (simulated learners, real engine)
 * ==================================================================== */
function answerFor(it, vi, right, r) {
  const v = E.variantOf(it, vi);
  const one = (type, d, ok) => {
    switch (type) {
      case 'mcq': return { choice: ok ? d.correct : (d.options.find((o) => o.id !== d.correct) || {}).id };
      case 'multi': return { choices: ok ? d.correct : d.correct.slice(0, 1).concat(d.options.filter((o) => d.correct.indexOf(o.id) < 0).slice(0, 1).map((o) => o.id)) };
      case 'fill': return { blanks: d.blanks.map((b, i) => (ok || i ? b.accept[0] : 'not sure')) };
      case 'match': { const m = {}; d.pairs.forEach((p, i) => { m[p.id] = ok ? p.id : d.pairs[(i + 1) % d.pairs.length].id; }); return { pairs: m }; }
      case 'order': return { order: ok ? d.steps.map((s) => s.id) : d.steps.map((s) => s.id).reverse() };
      case 'numeric': return { value: ok ? d.answer : (d.wrong[0] ? d.wrong[0].value : Math.round(d.answer * 1.1 * 100) / 100), unit: d.unit };
      case 'short': return { text: ok ? (d.accept[0] || d.keywords.join(' ')) : 'not sure' };
      default: return {};
    }
  };
  if (it.type === 'case') return { parts: v.parts.map((p) => one(p.type, p.data, right && r() > 0.1)) };
  if (it.type === 'reflection') return { text: 'If we take an EMI for a two-wheeler we pay interest, so the real cost is more than the sticker price. Money in a fixed deposit grows, so waiting can be better than buying today if we do not need it now.' };
  return one(it.type, v.data, right);
}
function simulate(fm, fa) {
  const DAY = E.DAY;
  const real = Date.now();
  const at6pm = (daysAgo, jitter) => { const d = new Date(real - daysAgo * DAY); d.setUTCHours(12, 30 + jitter, 0, 0); return d.getTime(); };
  // profile: chance of being active on a day, accuracy, hint use, last active day ago
  const people = [
    { u: 'demo.anitha', active: 0.85, acc: 0.82, hint: 0.15, stopAgo: 1, lessonsPerDay: 1, maxLessons: { [fm]: 5, [fa]: 2 } },
    { u: 'demo.bharath', active: 0.6, acc: 0.72, hint: 0.2, stopAgo: 1, lessonsPerDay: 1 },
    { u: 'demo.chitra', active: 0.55, acc: 0.48, hint: 0.45, stopAgo: 2, lessonsPerDay: 1, maxLessons: { [fm]: 3, [fa]: 2 } },
    { u: 'demo.dev', active: 0.8, acc: 0.78, hint: 0.1, stopAgo: 9, lessonsPerDay: 1 },
    { u: 'demo.esha', active: 0.95, acc: 0.9, hint: 0.05, stopAgo: 1, lessonsPerDay: 2 },
    { u: 'demo.farhan', active: 0.35, acc: 0.65, hint: 0.25, stopAgo: 3, lessonsPerDay: 1 }
  ];
  let n = 0;
  people.forEach((P) => {
    const u = byName(P.u);
    if (!u) return;
    const S = as(u);
    const r = E.rng('learning-demo', P.u);
    for (let ago = 21; ago >= P.stopAgo; ago--) {
      if (r() > P.active) continue;
      L._setClock(() => at6pm(ago, Math.floor(r() * 50)));
      [fm, fa].forEach((cid) => {
        if (!store.rows('Enrolments').some((e) => e.courseId === cid && e.userId === u.id && e.role === 'student')) return;
        // reviews first
        const rv = S('lpPractice', { courseId: cid, mode: 'review', size: 6 });
        rv.session.forEach((q) => { const it = L.ITEM_BY_ID.get(L.ST.pres[q.pres].i); S('lpAnswer', { pres: q.pres, ev: 'seed' + (n++) + 'x' + ago, answer: answerFor(it, L.ST.pres[q.pres].vi, r() < P.acc + 0.05, r) }); });
        // a lesson or two
        for (let k = 0; k < P.lessonsPerDay; k++) {
          const done = L.lessonsDone(u.id);
          const cap = P.maxLessons && P.maxLessons[cid];
          if (cap != null && [...done.values()].filter((x) => x.c === cid).length >= cap) break;
          const sub = S('lpSubject', { courseId: cid });
          if (!sub.next) break;
          const les = S('lpLesson', { id: sub.next.id });
          les.activities.forEach((q) => {
            const it = L.ITEM_BY_ID.get(L.ST.pres[q.pres].i);
            if (r() < P.hint && it.hints.length) S('lpHint', { pres: q.pres });
            const res = S('lpAnswer', { pres: q.pres, ev: 'seed' + (n++) + 'l' + ago, answer: answerFor(it, 0, r() < P.acc, r) });
            if (res.correct === false && r() < 0.7) S('lpAnswer', { pres: q.pres, ev: 'seed' + (n++) + 'r' + ago, answer: answerFor(it, 0, true, r) });
          });
          S('lpCompleteLesson', { id: les.lesson.id });
        }
        // adaptive practice
        if (r() < 0.75) {
          const pr = S('lpPractice', { courseId: cid, mode: 'practice', size: 3 + Math.floor(r() * 5) });
          pr.session.forEach((q) => {
            const p = L.ST.pres[q.pres];
            const it = L.ITEM_BY_ID.get(p.i);
            if (r() < P.hint && it.hints.length) S('lpHint', { pres: q.pres });
            S('lpAnswer', { pres: q.pres, ev: 'seed' + (n++) + 'p' + ago, answer: answerFor(it, p.vi, r() < P.acc + (it.difficulty === 1 ? 0.1 : it.difficulty === 3 ? -0.15 : 0), r) });
          });
        }
      });
    }
  });
  L._setClock(null);
  return n;
}

function main() {
  A('lpSaveSettings', { enabled: true, gamification: true, peers: true, reviews: true, adaptive: true });
  const fm = financialManagement();
  const fa = financialAccounting();
  // preferences: a mix of visibility choices and goals
  L.setPrefs(byName('demo.anitha').id, { weeklyDays: 5, dailyXp: 40 });
  L.setPrefs(byName('demo.chitra').id, { visibility: 'alias', competitive: false, weeklyDays: 3, dailyXp: 20 });
  L.setPrefs(byName('demo.farhan').id, { visibility: 'hidden' });
  const answers = simulate(fm.cid, fa.cid);
  // teacher follow-up: practice assigned to Chitra, and a private accommodation
  const chitra = byName('demo.chitra');
  T('lpAssign', { courseId: fm.cid, uids: [chitra.id], skillIds: [fm.skills.S2], note: 'Extra practice on discounting before the unit test', days: 10 });
  T('lpAccommodation', { courseId: fm.cid, uid: chitra.id, extraDays: 7, note: 'Extended time agreed with the counsellor.' });
  L.C.settings.demoSeeded = true;
  L.saveContent();
  console.log('Learning Paths demo installed: FM301 (9 lessons, 19 questions) and FACC101 (3 lessons, 7 questions); ' + answers + ' simulated answers over three weeks.');
}
try { main(); } catch (e) { console.error(e && e.stack || e); process.exitCode = 1; }
