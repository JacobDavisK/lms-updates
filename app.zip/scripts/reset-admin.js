'use strict';
const lms = require('../lib/api');
lms.emergencyResetAdmin();
