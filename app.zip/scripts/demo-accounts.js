/**
 * Adds (or repairs) the four demo accounts and shows them on the sign-in page.
 *
 *   npm run demo-accounts          create / repair them and show the sign-in tiles
 *   npm run demo-accounts -- off   hide the tiles and disable the demo accounts
 *   (Switching them on needs LMS_DEMO=1: a demo installation only.)
 *
 * Restart the server afterwards if it is running. Admins can also switch the tiles
 * on or off in Site administration > Settings.
 */
'use strict';
const store = require('../lib/store');
const demo = require('../lib/demo');

if (process.argv[2] === 'off') {
  store.setSetting('demoLogins', 'N');
  // Also disable the demo accounts: their passwords are public.
  let n = 0;
  store.rows('Users').filter((u) => demo.isDemoUser(u) && u.status === 'active').forEach((u) => { store.update('Users', u.id, { status: 'disabled' }); n++; });
  console.log('Demo sign-ins hidden and ' + n + ' demo account(s) disabled.');
  process.exit(0);
}
if (!demo.available()) {
  console.error('Demo sign-ins only work in a demo installation. Run with LMS_DEMO=1 — never on a site with real students.');
  process.exit(1);
}
const report = demo.ensureAccounts();
report.forEach((r) => console.log('  ' + r));
console.log('Demo sign-ins are shown on the sign-in page:');
demo.ACCOUNTS.forEach((a) => console.log('  ' + (a.label + '        ').slice(0, 8) + a.username + ' / ' + a.password));
