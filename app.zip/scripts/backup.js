/**
 * Encrypted backups of the data folder (every record, upload, setting and the audit log).
 *
 *   LMS_BACKUP_KEY="a long passphrase" npm run backup
 *        → backups/lms-data-YYYYMMDD-HHMM.lmsbak   (keeps the newest 14; LMS_BACKUP_KEEP to change)
 *   LMS_BACKUP_KEY="…" npm run restore -- backups/lms-data-….lmsbak  restored-data
 *        → unpacks into a NEW folder. Never touches the live data; point LMS_DATA_DIR at it to use it.
 *
 * Format: "LMSBAK1" | salt(16) | iv(12) | tag(16) | AES-256-GCM( gzip( entries ) ),
 * key = scrypt(passphrase, salt). Entries: u32 path length, path, u64 size, bytes.
 * Keep the passphrase somewhere safe and separate: without it a backup cannot be opened.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const { DATA_DIR } = require('../lib/store');

const MAGIC = Buffer.from('LMSBAK1');
const key = String(process.env.LMS_BACKUP_KEY || '');
if (key.length < 12) { console.error('Set LMS_BACKUP_KEY to a passphrase of at least 12 characters.'); process.exit(1); }
const deriveKey = (salt) => crypto.scryptSync(key, salt, 32, { N: 32768, r: 8, p: 1, maxmem: 128 * 1024 * 1024 });

function walk(dir, base, out) {
  fs.readdirSync(dir, { withFileTypes: true }).forEach((e) => {
    const full = path.join(dir, e.name), rel = path.join(base, e.name);
    if (e.isDirectory()) walk(full, rel, out);
    else if (e.isFile() && !e.name.endsWith('.tmp')) out.push({ full, rel: rel.split(path.sep).join('/') });
  });
  return out;
}

function backup() {
  const files = walk(DATA_DIR, '', []);
  const parts = [];
  files.forEach((f) => {
    const name = Buffer.from(f.rel, 'utf8'), data = fs.readFileSync(f.full);
    const h = Buffer.alloc(4); h.writeUInt32BE(name.length);
    const sz = Buffer.alloc(8); sz.writeBigUInt64BE(BigInt(data.length));
    parts.push(h, name, sz, data);
  });
  const plain = zlib.gzipSync(Buffer.concat(parts), { level: 9 });
  const salt = crypto.randomBytes(16), iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', deriveKey(salt), iv);
  const enc = Buffer.concat([c.update(plain), c.final()]);
  const outDir = process.env.LMS_BACKUP_DIR || path.join(__dirname, '..', 'backups');
  fs.mkdirSync(outDir, { recursive: true });
  const d = new Date(), p = (n) => String(n).padStart(2, '0');
  const file = path.join(outDir, 'lms-data-' + d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes()) + '.lmsbak');
  fs.writeFileSync(file, Buffer.concat([MAGIC, salt, iv, c.getAuthTag(), enc]));
  const keep = Math.max(1, Number(process.env.LMS_BACKUP_KEEP) || 14);
  const old = fs.readdirSync(outDir).filter((n) => /^lms-data-\d{8}-\d{4}\.lmsbak$/.test(n)).sort().reverse().slice(keep);
  old.forEach((n) => fs.unlinkSync(path.join(outDir, n)));
  console.log('Backup written: ' + file + ' (' + files.length + ' files, ' + (fs.statSync(file).size / 1048576).toFixed(1) + ' MB' + (old.length ? '; removed ' + old.length + ' old' : '') + ')');
}

function restore(src, target) {
  if (!src || !target) { console.error('Usage: npm run restore -- <backup file> <new folder>'); process.exit(1); }
  if (fs.existsSync(target) && fs.readdirSync(target).length) { console.error('The target folder must be new or empty — restore never overwrites existing data.'); process.exit(1); }
  const buf = fs.readFileSync(src);
  if (!buf.subarray(0, MAGIC.length).equals(MAGIC)) { console.error('Not an LMS backup file.'); process.exit(1); }
  let o = MAGIC.length;
  const salt = buf.subarray(o, o += 16), iv = buf.subarray(o, o += 12), tag = buf.subarray(o, o += 16);
  const d = crypto.createDecipheriv('aes-256-gcm', deriveKey(salt), iv);
  d.setAuthTag(tag);
  let plain;
  try { plain = zlib.gunzipSync(Buffer.concat([d.update(buf.subarray(o)), d.final()])); } catch (e) { console.error('Wrong passphrase, or the file is damaged.'); process.exit(1); }
  const root = path.resolve(target);
  let i = 0, n = 0;
  while (i < plain.length) {
    const len = plain.readUInt32BE(i); i += 4;
    const rel = plain.subarray(i, i + len).toString('utf8'); i += len;
    const size = Number(plain.readBigUInt64BE(i)); i += 8;
    const dest = path.resolve(root, rel);
    if (!dest.startsWith(root + path.sep)) { console.error('Refusing unsafe path in backup: ' + rel); process.exit(1); }
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, plain.subarray(i, i + size)); i += size; n++;
  }
  console.log('Restored ' + n + ' files into ' + root + '. To use them: set LMS_DATA_DIR=' + root + ' and start the server.');
}

if (process.argv[2] === 'restore') restore(process.argv[3], process.argv[4]);
else backup();
