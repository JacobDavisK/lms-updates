/**
 * Mentoring & Student Success — DEMO DATA (fictional people only). For demo installations only.
 *
 *   LMS_DEMO=1 node scripts/seed-mentoring.js          (after scripts/seed-demo.js)
 *
 * Adds 5 departments, 10 mentors (mdemo.f01–f10), a principal (mdemo.principal), 100 students
 * (mdemo.s001–s100) in five "(demo)" classes, one cohort course per department with six weeks of
 * attendance, and a mentoring history: sessions, goals, concerns, interventions, follow-ups, parent
 * notes, feedback and career profiles. demo.teacher (Priya Sharma) becomes mentor of the demo
 * students, so the one-click Faculty / Student / Parent tiles show mentoring as well.
 *
 * Refuses to run without LMS_DEMO=1, or on a database that holds real student accounts.
 */
'use strict';
if (process.env.LMS_DEMO !== '1') { console.error('Refusing to run: set LMS_DEMO=1. The mentoring demo is only for demo installations.'); process.exit(1); }
process.env.LMS_ALERTS_OFF = '1';
const store = require('../lib/store');
// Safety first: nothing else is loaded until we know this is a demo database.
const DEMO_USER = /^(demo|userdemo|mdemo)\./;
const real = store.rows('Users').filter((u) => u.role === 'student' && u.status === 'active' && !DEMO_USER.test(String(u.username)));
if (real.length) { console.error('Refusing to run: this database has ' + real.length + ' real student account(s). The mentoring demo is only for demo installations.'); process.exit(1); }
if (!store.rows('Users').some((u) => u.username === 'demo.teacher')) { console.error('Run scripts/seed-demo.js first.'); process.exit(1); }
const crypto = require('../lib/crypto');
const api = require('../lib/api');
const mentoring = require('../lib/mentoring');
if (mentoring._db.settings.demoData) { console.log('Mentoring demo data is already installed. Nothing to do.'); process.exit(0); }

const DAY = 86400000;
const NOW = Date.now();
const TEACHER_PW = 'Teach2026demo';
let seed = 20260926;
const rnd = () => { seed = (seed + 0x6D2B79F5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t ^= t + Math.imul(t ^ (t >>> 7), 61 | t); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
const pick = (a) => a[Math.floor(rnd() * a.length)];
const between = (a, b) => a + Math.floor(rnd() * (b - a + 1));
const pad = (n) => String(n).padStart(2, '0');
const ymd = (t) => { const d = new Date(t); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); };
const dayStr = (n) => ymd(NOW + n * DAY);
const at10 = (daysAgo, hour) => { const d = new Date(NOW - daysAgo * DAY); d.setHours(hour || between(9, 16), pick([0, 15, 30, 45]), 0, 0); return d.getTime(); };

const STUDENT_PW = 'Learn2026demo';
function ensureUser(username, name, role, batch, email) {
  let u = store.rows('Users').find((x) => x.username === username);
  if (u) return u;
  const salt = crypto.newSalt();
  u = { id: crypto.newId('U'), username, name, role, batch, email, phone: '', salt, hash: crypto.hashPw(role === 'student' ? STUDENT_PW : TEACHER_PW, salt), status: 'active', failed: 0, lockedUntil: 0, mustChange: 'N', createdAt: NOW - between(120, 400) * DAY, firstPwAt: NOW, lastLogin: 0, demoData: 'Y' };
  store.append('Users', u);
  return u;
}
const sess = (u) => ({ uid: u.id, username: String(u.username), name: String(u.name), role: u.role });
function as(u) {
  const s = sess(u);
  return (action, p) => {
    const r = mentoring.ROUTES[action];
    if (!r || r.roles.indexOf(s.role) < 0) throw new Error(u.username + ' may not ' + action);
    return r.fn(s, p || {});
  };
}
const D = mentoring._db;

/* ---------- people ---------- */
const DEPTS = [
  { name: 'Commerce', code: 'COM', batch: 'II B.Com A (demo)' },
  { name: 'Corporate Secretaryship', code: 'CS', batch: 'II B.Com CS (demo)' },
  { name: 'Accounting & Finance', code: 'AF', batch: 'II B.Com A&F (demo)' },
  { name: 'Business Administration', code: 'BBA', batch: 'II BBA (demo)' },
  { name: 'Computer Applications', code: 'BCA', batch: 'II BCA (demo)' }
];
const MENTORS = ['Dr. Kavitha Rao', 'Arvind Menon', 'Dr. Lakshmi Narayanan', 'Joseph Fernandes', 'Nandini Pillai', 'Dr. Suresh Babu', 'Farida Begum', 'Vikram Chandran', 'Deepa Raghavan', 'Dr. Thomas Kurian'];
const FIRST = ['Aarav', 'Aditi', 'Akash', 'Ananya', 'Arjun', 'Bhavya', 'Charan', 'Diya', 'Divya', 'Gautham', 'Harini', 'Ishaan', 'Janani', 'Karthik', 'Keerthana', 'Lavanya', 'Madhav', 'Meghna', 'Naveen', 'Nila', 'Pranav', 'Priyanka', 'Rahul', 'Rithika', 'Rohan', 'Sahana', 'Sanjay', 'Shruti', 'Siddharth', 'Sneha', 'Tanvi', 'Tarun', 'Varsha', 'Vignesh', 'Yamini', 'Zara', 'Abdul', 'Mary', 'Kevin', 'Ayesha'];
const INITIAL = ['A', 'B', 'D', 'G', 'J', 'K', 'M', 'N', 'P', 'R', 'S', 'T', 'V'];
const admin = store.rows('Users').find((u) => u.role === 'admin' && u.status === 'active' && !DEMO_USER.test(String(u.username))) || store.rows('Users').find((u) => u.username === 'demo.admin');
const AD = as(admin);
const demoTeacher = store.rows('Users').find((u) => u.username === 'demo.teacher');
const demoHod = store.rows('Users').find((u) => u.username === 'demo.hod');
const demoStudents = store.rows('Users').filter((u) => u.role === 'student' && /^demo\./.test(u.username) && u.status === 'active');

console.log('Creating 10 mentors, a principal and 100 fictional students…');
const mentors = MENTORS.map((n, i) => ensureUser('mdemo.f' + pad(i + 1), n, 'teacher', DEPTS[Math.floor(i / 2)].name, 'mdemo.f' + pad(i + 1) + '@demo.invalid'));
const principal = ensureUser('mdemo.principal', 'Dr. Maria Joseph', 'teacher', 'Principal', 'mdemo.principal@demo.invalid');
const students = [];
const used = new Set();
for (let i = 0; i < 100; i++) {
  let name;
  do { name = pick(FIRST) + ' ' + pick(INITIAL); } while (used.has(name));
  used.add(name);
  const u = ensureUser('mdemo.s' + String(i + 1).padStart(3, '0'), name, 'student', DEPTS[Math.floor(i / 20)].batch, 'mdemo.s' + String(i + 1).padStart(3, '0') + '@demo.invalid');
  // a profile for each student: most do well, some are slipping, a few struggle
  u._kind = rnd() < 0.68 ? 'good' : rnd() < 0.7 ? 'slipping' : 'low';
  students.push(u);
}

/* ---------- configuration ---------- */
const demoBatches = [...new Set(demoStudents.map((u) => String(u.batch || '')).filter(Boolean))];
AD('mtSaveConfig', {
  departments: DEPTS.map((d, i) => ({ name: d.name, code: d.code, batches: [d.batch].concat(i === 0 ? demoBatches : []), hodIds: [mentors[i * 2].id].concat(i === 0 && demoHod ? [demoHod.id] : []) })),
  grants: { coordinators: [], principals: [principal.id], restricted: [] }
});
D.settings.demoData = true;
const cfg = D.settings;
AD('mtCycleSave', { name: '2026–27 Semester 1', year: '2026–27', term: 'Semester 1', start: dayStr(-110), end: dayStr(80), objectives: 'Meet every mentee at least once a month; agree one academic and one career goal each; close every concern within two weeks.', action: 'start' });
const cycle = D.cycles.find((c) => c.status === 'active');
cycle.createdAt = NOW - 110 * DAY;

/* ---------- cohort courses & attendance (so academic indicators have data) ---------- */
console.log('Creating cohort courses and six weeks of attendance…');
const days = [];
for (let n = 42; n >= 1; n--) { const d = new Date(NOW - n * DAY); if (d.getDay() !== 0 && d.getDay() !== 6) days.push({ date: ymd(d.getTime()), n }); }
DEPTS.forEach((d, i) => {
  const c = api.asSystemAdmin('saveCourse', { fullname: 'Mentoring demo cohort — ' + d.name, shortname: 'MDEMO-' + d.code, category: d.name + ' (demo)', summary: 'Demo cohort for the mentoring module (fictional students).', visible: 'Y', sections: 1 });
  const cohort = students.slice(i * 20, i * 20 + 20);
  api.asSystemAdmin('enrolUsers', { courseId: c.id, userIds: cohort.map((u) => u.id).concat([mentors[i * 2].id, mentors[i * 2 + 1].id]) });
  days.forEach((day) => [1, 2].forEach((period) => {
    const marks = {};
    cohort.forEach((u) => {
      const late = day.n <= 21;
      const p = u._kind === 'good' ? 0.94 : u._kind === 'slipping' ? (late ? 0.58 : 0.9) : 0.64;
      marks[u.id] = rnd() < p ? 'P' : 'A';
    });
    api.asSystemAdmin('attSave', { courseId: c.id, date: day.date, period, marks, topic: 'Demo class' });
  }));
});

/* ---------- allocation ---------- */
console.log('Allocating mentors…');
DEPTS.forEach((d, i) => {
  const cohort = students.slice(i * 20, i * 20 + 20);
  AD('mtAllocAssign', { mentorId: mentors[i * 2].id, studentIds: cohort.slice(0, 10).map((u) => u.id), reason: 'Start of year allocation' });
  AD('mtAllocAssign', { mentorId: mentors[i * 2 + 1].id, studentIds: cohort.slice(10).map((u) => u.id), reason: 'Start of year allocation' });
});
if (demoTeacher && demoStudents.length) AD('mtAllocAssign', { mentorId: demoTeacher.id, studentIds: demoStudents.map((u) => u.id), reason: 'Start of year allocation' });
D.allocations.forEach((a) => { a.at = NOW - between(95, 105) * DAY; });
// one reassignment, so allocation history has a story
AD('mtAllocAssign', { mentorId: mentors[1].id, studentIds: [students[3].id], reason: 'Mentor change requested by the student (timetable clash)' });
D.allocations.filter((a) => a.studentId === students[3].id).forEach((a, k) => { if (a.active) a.at = NOW - 40 * DAY; else a.endedAt = NOW - 40 * DAY; });

/* ---------- mentoring history ---------- */
console.log('Writing sessions, goals, concerns, interventions and follow-ups…');
const SUMMARY = {
  Academic: ['Reviewed internal test results and agreed a weekly revision plan.', 'Went through the assignment backlog; two to be submitted this week.', 'Discussed exam preparation and past papers for the core papers.'],
  Attendance: ['Talked about recent absences; agreed to attend every first-hour class.', 'Checked attendance by course and the classes needed to recover.'],
  Career: ['Explored interest in audit and taxation; shortlisted two certifications.', 'Discussed internship options for the summer break and CV improvements.', 'Mapped skills needed for a business analyst role.'],
  Development: ['Worked on time management: a daily study timetable.', 'Encouraged joining the debate club to build communication skills.'],
  Examination: ['Planned revision for the end-semester examinations.'],
  'Personal development': ['Set up a routine for weekly goal check-ins.'],
  Other: ['General check-in; the student is settling in well.']
};
const OUTCOME = ['Plan agreed', 'Student to follow up with course teacher', 'Good progress — continue', 'Action items set', 'Referred to remedial classes'];
const ACTIONS = ['Attend remedial sessions twice a week', 'Submit pending assignment', 'Meet the course teacher about the internal test', 'Complete two past papers', 'Register for the Tally certification', 'Update CV and share with mentor', 'Keep a weekly study timetable', 'Attend every first-hour class for two weeks'];
const GOALS = [
  ['Academic', 'Score 60% or more in Financial Accounting'], ['Academic', 'Clear all internal assessments on the first attempt'], ['Career', 'Complete a summer internship in audit'],
  ['Skill', 'Finish the Advanced Excel course'], ['Skill', 'Learn Tally Prime with GST'], ['Professional', 'Build a LinkedIn profile and CV'], ['Higher Education', 'Prepare for CA Foundation'],
  ['Personal Development', 'Speak at one college event this semester'], ['Research', 'Write a short project report on MSME financing'], ['Entrepreneurship', 'Draft a business plan for a campus start-up']
];
const CONCERNS = [
  ['Academic', 'Finding Business Law hard to follow in class.', 'High'], ['Attendance', 'Missed classes due to long commute; worried about shortage.', 'Medium'], ['Examination', 'Anxious about the model exam timetable clash.', 'Medium'],
  ['Assignment', 'Need an extension for the marketing assignment.', 'Low'], ['Career', 'Unsure whether to pursue CA or MBA.', 'Low'], ['Financial', 'Need information about scholarship deadlines.', 'Medium'],
  ['Administrative', 'ID card not issued yet.', 'Low'], ['Peer-related', 'Group project member not contributing.', 'Medium']
];
const types = cfg.sessionTypes;
const mentorOf = (sid) => { const a = D.allocations.find((x) => x.studentId === sid && x.active); return a ? store.findById('Users', a.mentorId) : null; };
const allStudents = students.concat(demoStudents);
let sessionsMade = 0;
allStudents.forEach((u, idx) => {
  const m = mentorOf(u.id);
  if (!m) return;
  const M = as(m);
  const S = as(u);
  const kind = u._kind || (u.username === 'demo.anitha' ? 'slipping' : 'good');
  // completed sessions over the last ~100 days (fewer for a handful, so "no recent interaction" shows up)
  const n = idx % 11 === 0 ? 1 : between(2, 4);
  const lastGap = idx % 11 === 0 ? between(40, 70) : between(3, 25);
  for (let k = 0; k < n; k++) {
    const ago = k === 0 ? lastGap : between(lastGap + 10 * k, lastGap + 25 * k);
    const cat = pick(kind === 'good' ? ['Career', 'Development', 'Academic', 'Personal development'] : ['Academic', 'Attendance', 'Examination', 'Academic']);
    const tpl = cfg.templates.find((t) => t.category === cat);
    const x = M('mtSessionSave', { studentIds: [u.id], type: cat === 'Career' ? 'Career mentoring' : cat === 'Academic' ? 'Academic mentoring' : pick(['One-to-one', 'Development mentoring']), category: cat, at: at10(ago), duration: pick([20, 30, 45]), mode: pick(['In person', 'In person', 'Online']), level: 1, asMe: true });
    const answers = {};
    if (tpl) tpl.prompts.slice(0, 3).forEach((q) => { answers[q] = pick(['Discussed', 'Needs work', 'Improving', 'On track', 'Agreed next steps']); });
    const acts = rnd() < 0.55 ? [{ title: pick(ACTIONS), owner: 'student', due: dayStr(-ago + between(7, 21)) }] : [];
    M('mtSessionRecord', { id: x.id, complete: true, level: rnd() < 0.8 ? 1 : 2, template: tpl ? tpl.id : '', answers, summary: pick(SUMMARY[cat] || SUMMARY.Other), observation: pick(['Engaged and open.', 'Quiet today; follow up next time.', 'Clear about next steps.', 'Needs support with planning.']), outcome: pick(OUTCOME), actions: acts, requestFeedback: true });
    const rec = D.sessions.find((y) => y.id === x.id);
    rec.createdAt = rec.at - DAY; rec.recordedAt = rec.at + 3600000;
    D.actions.filter((a) => a.parentId === x.id).forEach((a) => {
      a.at = rec.at;
      // older items mostly done; recent ones open, some overdue
      if (ago > 30 && rnd() < 0.8) { a.status = 'done'; a.completedAt = rec.at + between(3, 14) * DAY; a.completedBy = u.id; a.outcome = pick(['Done', 'Completed on time', 'Partly done — continuing']); }
    });
    if (rec.level === 1 && rnd() < 0.6) { S('mtFeedback', { sessionId: x.id, rating: kind === 'good' ? between(4, 5) : between(3, 5), useful: true, helpful: pick(['', 'Clear plan', 'Felt listened to', 'Useful tips for exams', '']), needs: pick(['', '', 'More time before exams', 'Help with internships']), another: rnd() < 0.2 }); D.feedback[D.feedback.length - 1].at = rec.at + DAY; }
    sessionsMade++;
  }
  // upcoming session for some
  if (rnd() < 0.4) { M('mtSessionSave', { studentIds: [u.id], type: pick(types.slice(0, 5)), category: pick(cfg.sessionCategories), at: at10(-between(1, 12)), duration: 30, mode: pick(['In person', 'Online']), level: 1, location: pick(['Staff room 2', 'Mentoring room, Block B', '']), asMe: true }); sessionsMade++; }
  // goals
  const g = between(1, 2);
  for (let k = 0; k < g; k++) {
    const [cat, title] = pick(GOALS);
    const status = kind === 'good' ? pick(['In Progress', 'In Progress', 'Completed', 'Not Started']) : pick(['In Progress', 'At Risk', 'Not Started']);
    const gl = (rnd() < 0.5 ? S : M)('mtGoalSave', { studentId: u.id, title, category: cat, start: dayStr(-between(40, 90)), target: dayStr(between(-5, 60)), priority: pick(['Medium', 'High', 'Low']), status, progress: status === 'Completed' ? 100 : status === 'Not Started' ? 0 : between(15, 80), criteria: 'Agreed with the mentor', description: '' });
    const rec = D.goals.find((y) => y.id === gl.id);
    rec.at = NOW - between(40, 90) * DAY; rec.updatedAt = NOW - between(1, 30) * DAY;
    if (status === 'Completed') rec.completedAt = rec.updatedAt;
    if (rnd() < 0.3) M('mtGoalComment', { id: gl.id, text: pick(['Well done — keep going!', 'Let us review this in our next session.', 'Break this into weekly steps.']) });
  }
  // career profile
  if (rnd() < 0.55) S('mtCareerSave', { careerGoal: pick(['Chartered Accountant', 'Business analyst', 'Banking and finance', 'Company Secretary', 'Start my own business', 'MBA in marketing', 'Data analyst']), industry: pick(['Audit', 'Banking', 'IT services', 'Consulting', 'Retail']), jobRole: pick(['Analyst', 'Associate', 'Trainee']), placementStatus: pick(['Preparing', 'Not started', 'Applying', 'Preparing']), skills: [pick(['Excel', 'Tally', 'Communication', 'Python', 'Accounting'])].concat(rnd() < 0.5 ? [pick(['GST', 'Public speaking', 'SQL', 'Power BI'])] : []), certifications: rnd() < 0.4 ? [{ name: pick(['Tally Prime', 'Advanced Excel', 'NISM Series V-A']), issuer: 'Demo issuer', date: dayStr(-between(20, 200)) }] : [], internships: rnd() < 0.25 ? [{ org: pick(['Demo Audit LLP', 'Demo Bank Ltd', 'Demo Tech Pvt Ltd']), role: 'Intern', from: dayStr(-200), to: dayStr(-170) }] : [] });
});
// concerns (students raise most; a few logged by mentors)
const withConcerns = allStudents.filter((u, i) => i % 4 === 1 || (u._kind && u._kind !== 'good' && i % 2 === 0)).slice(0, 28);
withConcerns.forEach((u, i) => {
  const m = mentorOf(u.id); if (!m) return;
  const [cat, text, pri] = CONCERNS[i % CONCERNS.length];
  const c = as(u)('mtConcernSubmit', { category: cat, description: text, priority: pri });
  const rec = D.concerns.find((y) => y.id === c.id);
  const ago = between(2, 70);
  rec.at = NOW - ago * DAY; rec.trail[0].at = rec.at;
  const M = as(m);
  const r = rnd();
  if (r < 0.45) { M('mtConcernAct', { id: c.id, action: 'resolve', note: pick(['Spoke to the course teacher; extra classes arranged.', 'Shared the scholarship office contact and deadline.', 'Resolved after discussion with the group.', 'Issue fixed by the office.']), shared: true }); rec.closedAt = rec.at + between(2, 10) * DAY; }
  else if (r < 0.65) M('mtConcernAct', { id: c.id, action: 'await', note: 'Could you share more details when we meet?', shared: true });
  else if (r < 0.85) M('mtConcernAct', { id: c.id, action: 'progress', note: 'Looking into this.', shared: true });
  rec.trail.forEach((t, k) => { if (k) t.at = Math.min(NOW - DAY, rec.at + k * 2 * DAY); });
});
// interventions for students with difficulties
const struggling = allStudents.filter((u) => u._kind && u._kind !== 'good').slice(0, 14);
struggling.forEach((u, i) => {
  const m = mentorOf(u.id); if (!m) return;
  const M = as(m);
  const iv = M('mtInterventionSave', { studentId: u.id, problem: pick(['Attendance falling in the last three weeks', 'Low performance in Business Law', 'Several assignments not submitted', 'Internal test score below 50%']), plan: 'Weekly check-in; remedial classes; attendance tracked by the class representative.', actions: [{ title: pick(ACTIONS), owner: 'student', due: dayStr(between(-10, 14)) }, { title: 'Check progress with the course teacher', owner: 'mentor', due: dayStr(between(-5, 10)) }], followUp: dayStr(between(-6, 14)) });
  const rec = D.interventions.find((y) => y.id === iv.id);
  rec.at = NOW - between(10, 45) * DAY;
  if (i % 3 === 0) { M('mtInterventionOutcome', { id: iv.id, outcome: pick(['improved', 'partial', 'not_improved', 'improved']), note: 'Reviewed at the follow-up meeting.' }); rec.closedAt = NOW - between(1, 8) * DAY; }
});
// a few open student requests
allStudents.filter((u) => mentorOf(u.id)).slice(5, 8).forEach((u) => as(u)('mtSessionRequest', { topic: pick(['Would like help planning revision for the model exams.', 'Can we talk about internship options?', 'I am behind on assignments and want a plan.']) }));
// parent interaction for the demo parent tile
const anitha = store.rows('Users').find((u) => u.username === 'demo.anitha');
const raman = store.rows('Users').find((u) => u.username === 'demo.raman');
if (anitha && raman && demoTeacher) {
  const T = as(demoTeacher);
  T('mtGuardianLog', { studentId: anitha.id, parentIds: [raman.id], mode: 'Phone call', topic: 'Attendance discussion', date: dayStr(-9), purpose: 'Attendance in the last three weeks', discussion: 'Explained the recent dip and the plan agreed with Anitha.', sharedSummary: 'Anitha has agreed to attend every first-hour class for the next two weeks. We will review together on the follow-up date.', action: 'Weekly attendance check', followUp: dayStr(5), shared: true });
  T('mtSessionSave', { studentIds: [anitha.id], type: 'Parent/Guardian meeting', category: 'Attendance', at: at10(-6, 15), duration: 30, mode: 'In person', location: 'Department office', parentIds: [raman.id], level: 1, agenda: 'Review attendance plan and upcoming model exams.' });
}
// a restricted record (visible only to its author), to show level 3
if (demoTeacher && demoStudents[1]) as(demoTeacher)('mtConcernSubmit', { studentId: demoStudents[1].id, category: 'Other', description: 'Confidential note recorded by the mentor (demo). Only the author and staff with the Restricted grant can see this.', level: 3 });

/* ---------- indicators ---------- */
console.log('Running the early-warning check…');
mentoring._reset();
const sw = mentoring.sweep();
D.events.forEach((e) => { e.at = NOW - between(0, 12) * DAY; });
mentoring._flush();
console.log('');
console.log('Mentoring demo installed: ' + students.length + ' fictional students, ' + mentors.length + ' mentors, 5 departments, ' + sessionsMade + ' sessions, ' + D.goals.length + ' goals, ' + D.concerns.length + ' concerns, ' + D.interventions.length + ' interventions, ' + sw.created + ' support indicators.');
console.log('  Faculty tile (demo.teacher) mentors the demo students; demo.hod is HOD of Commerce.');
console.log('  Mentors  : mdemo.f01 … mdemo.f10 / ' + TEACHER_PW + '  (f01, f03, f05, f07, f09 are HODs)');
console.log('  Principal: mdemo.principal / ' + TEACHER_PW);
console.log('  Students : mdemo.s001 … mdemo.s100 / ' + STUDENT_PW);
setTimeout(() => process.exit(0), 600);
