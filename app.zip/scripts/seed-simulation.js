/**
 * Business Simulation Studio — DEMO DATA (fictional people and companies). For demo installations only.
 *
 *   LMS_DEMO=1 node scripts/seed-simulation.js          (after scripts/seed-demo.js)
 *
 * The demo faculty (Priya Sharma, demo.teacher) gets a "Business Strategy Lab" course with the demo students, the
 * five demo simulations (published v1.0), and two class runs:
 *   • "Evolution Motors — Section A": three teams with different strategies have played rounds 1–3; round 4
 *     (Government Incentive) is open, so the Student tile can play straight away.
 *   • "BrewCraft Cafés — Pilot": complete (six rounds), with a reflection, so analytics, the debrief and
 *     assessment have data.
 * Sign-ins are the demo tiles on the sign-in page; no passwords are created here.
 *
 * Refuses to run without LMS_DEMO=1, or on a database that holds real student accounts.
 */
'use strict';
if (process.env.LMS_DEMO !== '1') { console.error('Refusing to run: set LMS_DEMO=1. The simulation demo is only for demo installations.'); process.exit(1); }
process.env.LMS_ALERTS_OFF = '1';
const store = require('../lib/store');
const DEMO_USER = /^(demo|userdemo|mdemo)\./;
const real = store.rows('Users').filter((u) => u.role === 'student' && u.status === 'active' && !DEMO_USER.test(String(u.username)));
if (real.length) { console.error('Refusing to run: this database has ' + real.length + ' real student account(s). The simulation demo is only for demo installations.'); process.exit(1); }
const byName = (n) => store.rows('Users').find((u) => u.username === n);
if (!byName('demo.teacher')) { console.error('Run scripts/seed-demo.js first.'); process.exit(1); }
require('../lib/api');
const lms = require('../lib/lms');
const SIM = require('../lib/simulation');
if (SIM._db.settings.demoData) { console.log('Simulation demo data is already installed. Nothing to do.'); process.exit(0); }

const sess = (u) => ({ uid: u.id, username: String(u.username), name: String(u.name), role: u.role });
function as(u) {
  const s = sess(u);
  return async (action, p) => {
    const r = SIM.ROUTES[action] || lms.ROUTES[action];
    if (!r || r.roles.indexOf(s.role) < 0) throw new Error(u.username + ' may not ' + action);
    return r.fn(s, p || {});
  };
}
const teacher = byName('demo.teacher'), hod = byName('demo.hod');
const students = store.rows('Users').filter((u) => u.role === 'student' && u.status === 'active' && /^demo\./.test(u.username)).slice(0, 9);
const T = as(teacher);
const L = 1e5, CR = 1e7;

async function playRound(run, plans, r) {
  const db = SIM._db.runs.find((x) => x.id === run);
  for (const t of db.teams) {
    const m = t.members[0];
    if (!m) continue;
    const S = as(store.findById('Users', m.uid));
    const plan = plans[t.name] ? plans[t.name](r, db.states[t.id]) : {};
    await S('smDecide', { id: run, values: plan.values || plan, rationale: plan.why || '' });
    await S('smSubmit', { id: run });
  }
  await T('smControl', { id: run, action: 'run' });
}

async function main() {
  // course
  let course = store.rows('Courses').find((c) => c.deleted !== 'Y' && c.shortname === 'BSL-101');
  if (!course) { const r = await T('saveCourse', { fullname: 'Business Strategy Lab', shortname: 'BSL-101', category: 'Management', summary: 'Strategy, marketing and finance through business simulations.', color: 'indigo', visible: true, sections: 3 }); course = store.findById('Courses', r.id); }
  await T('enrolUsers', { courseId: course.id, userIds: students.map((u) => u.id) });
  // the five demo simulations, published
  const ids = {};
  for (const tid of ['ev-motors', 'coffee', 'bank', 'pricing', 'fundraising']) {
    const c = await T('smCreate', { templateId: tid });
    await T('smPublish', { id: c.id, note: 'Demo version' });
    ids[tid] = c.id;
  }
  await T('smShare', { id: ids['ev-motors'], library: true });
  console.log('Published 5 demo simulations.');

  // Run 1 — Evolution Motors, three teams, rounds 1–3 played, round 4 open
  const r1 = await T('smRunCreate', { simId: ids['ev-motors'], courseId: course.id, title: 'Evolution Motors — Section A', teams: 3, method: 'empty' });
  const db1 = SIM._db.runs.find((x) => x.id === r1.id);
  const names = ['Team Ampere', 'Team Voltage', 'Team Torque'];
  const groups = [students.slice(0, 3), students.slice(3, 6), students.slice(6, 9)];
  await T('smRunTeams', { id: r1.id, teams: db1.teams.map((t, i) => ({ id: t.id, name: names[i], members: (groups[i] || []).map((u, k) => ({ uid: u.id, role: ['CEO', 'CFO', 'CMO'][k] || '' })) })) });
  await T('smControl', { id: r1.id, action: 'observers', observers: hod ? [hod.id] : [] });
  await T('smLaunch', { id: r1.id });
  const evPlans = {
    'Team Ampere': (r, st) => ({ values: { price: 12.5 * L, production: Math.min(st.capacity, r === 1 ? 3000 : 5500), capacity: r <= 3 ? 4000 : 0, equity: r === 1 ? 60 * CR : 0, enterFleet: r >= 2 ? 1 : 0, fleetPrice: 11 * L, hiring: 40, charging: 20 * CR }, why: 'Scale up early and win fleets — capacity arrives a year after we invest.' }),
    'Team Voltage': () => ({ values: { price: 10.5 * L, production: 4000, marketing: 15 * CR, rd: 15 * CR }, why: 'Undercut the incumbent on price to buy share.' }),
    'Team Torque': () => ({ values: { price: 17 * L, production: 2500, rd: 45 * CR, battery: 25 * CR, green: 12 * CR }, why: 'Premium, high-range EV for enthusiasts and eco-conscious families.' })
  };
  for (let r = 1; r <= 3; r++) await playRound(r1.id, evPlans, r);
  await T('smAnnounce', { id: r1.id, text: 'Round 4 is open. Read the policy news carefully — and remember capacity takes a year to arrive.' });
  console.log('Evolution Motors run: rounds 1–3 played, round 4 open.');

  // Run 2 — BrewCraft Cafés, complete
  const r2 = await T('smRunCreate', { simId: ids.coffee, courseId: course.id, title: 'BrewCraft Cafés — Pilot', teams: 3, method: 'empty' });
  const db2 = SIM._db.runs.find((x) => x.id === r2.id);
  await T('smRunTeams', { id: r2.id, teams: db2.teams.map((t, i) => ({ id: t.id, name: ['Bean There', 'Daily Grind', 'Brew Crew'][i], members: (groups[i] || []).map((u, k) => ({ uid: u.id, role: ['CEO', 'CFO', 'COO'][k] || '' })) })) });
  await T('smLaunch', { id: r2.id });
  const cPlans = {
    'Bean There': () => ({ values: { price: 210, outlets: 4, hiring: 40, beans: 30 * L, marketing: 80 * L }, why: 'Grow steadily while keeping quality high.' }),
    'Daily Grind': () => ({ values: { price: 170, outlets: 8, hiring: 60, marketing: 120 * L, delivery: 60 * L }, why: 'Fast expansion with delivery and lower prices.' }),
    'Brew Crew': () => ({ values: { price: 260, outlets: 1, beans: 60 * L, green: 30 * L, training: 30 * L }, why: 'Premium specialty coffee and sustainable sourcing.' })
  };
  for (let r = 1; r <= 6; r++) await playRound(r2.id, cPlans, r);
  const S0 = as(students[0]);
  await S0('smReflect', { id: r2.id, answers: ['Investing in bean quality kept our regulars even when the global chain arrived.', 'We would open outlets earlier, before the cost squeeze, and train staff more.'] });
  console.log('BrewCraft run: complete with results and a reflection.');

  SIM._db.settings.demoData = true;
  SIM._flush();
  console.log('Business simulation demo ready: sign in with the Faculty tile → Business Simulations.');
}
main().then(() => setTimeout(() => process.exit(0), 600)).catch((e) => { console.error('Simulation demo failed: ' + (e && e.stack || e)); SIM._flush(); setTimeout(() => process.exit(1), 600); });
