/**
 * Academic Content Studio — DEMO DATA (fictional institution and people). For demo installations only.
 *
 *   LMS_DEMO=1 node scripts/seed-studio.js          (after scripts/seed-demo.js and seed-mentoring.js)
 *
 * Brands the Studio as "Global Business University", adds four courses with outcomes and units
 * (Legal Aspects of Business for B.Com Corporate Secretaryship, Financial Management, Marketing
 * Management, Human Resource Management) and walks the demo workflow once:
 *   Legal Aspects of Business → Unit I: Indian Contract Act → "Essentials of a valid contract" →
 *   "Create a 15-slide interactive lecture on essentials of a valid contract." → presentation, notes,
 *   infographic, case, 10 MCQs, discussion, assignment, flashcards → mapped to CO1, PO1, PO2 and
 *   Understand/Apply → reviewed → published to the course (quiz as an LMS quiz, assignment, forum).
 * Students view it, a live check is run, a colleague's infographic waits for HOD review, a resource is
 * in the university library and a student has made a poster — so every Studio page has something in it.
 *
 * Refuses to run without LMS_DEMO=1, or on a database that holds real student accounts.
 */
'use strict';
if (process.env.LMS_DEMO !== '1') { console.error('Refusing to run: set LMS_DEMO=1. The Studio demo is only for demo installations.'); process.exit(1); }
process.env.LMS_ALERTS_OFF = '1';
const store = require('../lib/store');
const DEMO_USER = /^(demo|userdemo|mdemo)\./;
const real = store.rows('Users').filter((u) => u.role === 'student' && u.status === 'active' && !DEMO_USER.test(String(u.username)));
if (real.length) { console.error('Refusing to run: this database has ' + real.length + ' real student account(s). The Studio demo is only for demo installations.'); process.exit(1); }
const byName = (n) => store.rows('Users').find((u) => u.username === n);
if (!byName('demo.teacher')) { console.error('Run scripts/seed-demo.js first.'); process.exit(1); }
require('../lib/api'); // wires the Studio to the course tools (publishing)
const lms = require('../lib/lms');
const studio = require('../lib/studio');
if (studio._db.settings.demoData) { console.log('Studio demo data is already installed. Nothing to do.'); process.exit(0); }

const DAY = 86400000;
const sess = (u) => ({ uid: u.id, username: String(u.username), name: String(u.name), role: u.role });
function as(u) {
  const s = sess(u);
  return async (action, p) => {
    const r = studio.ROUTES[action] || lms.ROUTES[action];
    if (!r || r.roles.indexOf(s.role) < 0) throw new Error(u.username + ' may not ' + action);
    return r.fn(s, p || {});
  };
}
const teacher = byName('demo.teacher'), meena = byName('demo.meena'), hod = byName('demo.hod');
const admin = byName('demo.admin') || store.rows('Users').find((u) => u.role === 'admin');
const students = store.rows('Users').filter((u) => u.role === 'student' && u.status === 'active' && /^demo\./.test(u.username));
// Faculty belong to a department (as the mentoring demo faculty do), so HOD review and department sharing work.
[teacher, meena].forEach((u) => { if (u && !String(u.batch || '')) store.update('Users', u.id, { batch: 'Commerce' }); });

const T = as(teacher), M = as(meena), A = as(admin), H = hod ? as(hod) : null;

const COURSES = [
  { shortname: 'BCS-LAB', fullname: 'Legal Aspects of Business', category: 'Corporate Secretaryship', color: 'indigo', programme: 'B.Com Corporate Secretaryship', semester: '3', department: 'Commerce',
    summary: 'The Indian Contract Act, special contracts, the Sale of Goods Act, negotiable instruments and consumer protection — the legal framework every business decision sits in.',
    co: ['Explain the essential elements of a valid contract under the Indian Contract Act, 1872', 'Apply the rules of offer, acceptance and consideration to business situations', 'Distinguish void, voidable and illegal agreements and their consequences', 'Analyse the remedies available for breach of contract', 'Explain the law relating to sale of goods and negotiable instruments'],
    po: ['Apply knowledge of commerce and law to solve business problems', 'Demonstrate ethical, legal and social responsibility in business decisions', 'Communicate business ideas clearly in writing and speech', 'Think critically and analyse business situations', 'Work effectively in teams'],
    pso: ['Apply company law and secretarial practice in corporate compliance', 'Draft basic business and legal documents'],
    units: [['Unit I: Indian Contract Act', ['Essentials of a valid contract', 'Offer and acceptance', 'Consideration', 'Capacity to contract', 'Free consent', 'Void agreements']], ['Unit II: Special Contracts', ['Indemnity and guarantee', 'Bailment and pledge', 'Contract of agency']], ['Unit III: Sale of Goods Act, 1930', ['Conditions and warranties', 'Transfer of property', 'Rights of an unpaid seller']], ['Unit IV: Negotiable Instruments Act, 1881', ['Promissory notes, bills and cheques', 'Holder in due course', 'Dishonour of cheques']], ['Unit V: Consumer Protection', ['Consumer rights', 'Consumer commissions']]] },
  { shortname: 'FM301', fullname: 'Financial Management', category: 'Commerce', color: 'green', programme: 'B.Com', semester: '5', department: 'Commerce', summary: 'Financing, investment and dividend decisions.',
    co: ['Explain the goals and functions of financial management', 'Evaluate investment proposals using capital budgeting techniques', 'Compute the cost of capital and analyse capital structure', 'Assess working capital requirements'],
    po: ['Apply knowledge of commerce and law to solve business problems', 'Think critically and analyse business situations', 'Use quantitative tools for decision making'], pso: [],
    units: [['Unit I: Introduction', ['Goals of financial management', 'Time value of money']], ['Unit II: Capital Budgeting', ['Payback period', 'Net present value', 'Internal rate of return']], ['Unit III: Cost of Capital', ['Cost of debt', 'Cost of equity', 'WACC']], ['Unit IV: Working Capital', ['Operating cycle', 'Cash management']]] },
  { shortname: 'MM201', fullname: 'Marketing Management', category: 'Management', color: 'pink', programme: 'BBA', semester: '3', department: 'Commerce', summary: 'Customers, markets and the marketing mix.',
    co: ['Explain core marketing concepts and the marketing environment', 'Apply segmentation, targeting and positioning', 'Design a marketing mix for a product or service', 'Evaluate digital and ethical marketing practices'],
    po: ['Apply management knowledge to solve business problems', 'Communicate business ideas clearly', 'Think critically and creatively'], pso: [],
    units: [['Unit I: Marketing Concepts', ['Needs, wants and demands', 'Marketing environment']], ['Unit II: STP', ['Segmentation', 'Targeting', 'Positioning']], ['Unit III: Marketing Mix', ['Product', 'Price', 'Place', 'Promotion']], ['Unit IV: Contemporary Marketing', ['Digital marketing', 'Green marketing']]] },
  { shortname: 'HRM202', fullname: 'Human Resource Management', category: 'Management', color: 'amber', programme: 'BBA', semester: '4', department: 'Commerce', summary: 'Acquiring, developing and retaining people.',
    co: ['Explain the functions and challenges of HRM', 'Apply recruitment and selection methods', 'Design training and performance appraisal systems', 'Analyse compensation and employee relations'],
    po: ['Apply management knowledge to solve business problems', 'Demonstrate ethical and social responsibility', 'Work effectively in teams'], pso: [],
    units: [['Unit I: Introduction to HRM', ['Functions of HRM', 'HR planning']], ['Unit II: Acquisition', ['Recruitment', 'Selection']], ['Unit III: Development', ['Training', 'Performance appraisal']], ['Unit IV: Compensation', ['Wage and salary administration', 'Incentives']]] }
];

const SOURCE = `Essentials of a Valid Contract

Meaning of a contract
Section 2(h) of the Indian Contract Act, 1872 defines a contract as an agreement enforceable by law. Every contract is an agreement, but every agreement is not a contract. An agreement becomes a contract only when it satisfies the conditions in Section 10. Section 10 states that all agreements are contracts if they are made by the free consent of parties competent to contract, for a lawful consideration and with a lawful object, and are not expressly declared to be void.

Offer and acceptance
There must be a lawful offer by one party and a lawful acceptance of it by the other. An offer is a proposal made by one person to another to obtain the assent of that other person. A general offer is made to the public at large, as in Carlill v Carbolic Smoke Ball Company. Acceptance must be absolute and unqualified and must be communicated to the offeror. A counter offer amounts to rejection of the original offer. In Lalman Shukla v Gauri Dutt the court held that a person who acts without knowledge of an offer cannot claim the reward.

Intention to create legal relations
The parties must intend to create legal obligations. Social and domestic agreements are usually not enforceable. In Balfour v Balfour a promise by a husband to pay his wife a monthly allowance was held not to be a contract because there was no intention to create legal relations.

Lawful consideration
Consideration means something in return. Section 2(d) defines consideration as an act, abstinence or promise done at the desire of the promisor. An agreement without consideration is void, except in the cases listed in Section 25. Consideration need not be adequate, but it must be real and lawful.

Capacity of the parties
Section 11 states that a person is competent to contract if he is of the age of majority, is of sound mind and is not disqualified from contracting by any law. In Mohori Bibee v Dharmodas Ghose the Privy Council held that an agreement with a minor is void from the beginning.

Free consent
Consent is free when it is not caused by coercion, undue influence, fraud, misrepresentation or mistake. Coercion is defined in Section 15, undue influence in Section 16, fraud in Section 17 and misrepresentation in Section 18. An agreement caused by coercion, undue influence, fraud or misrepresentation is voidable at the option of the party whose consent was not free.

Lawful object
The object of the agreement must be lawful. Section 23 says the object is unlawful if it is forbidden by law, would defeat the provisions of any law, is fraudulent, involves injury to the person or property of another, or is immoral or opposed to public policy.

Not expressly declared void
The agreement must not be one that the Act expressly declares void. Agreements in restraint of marriage (Section 26), in restraint of trade (Section 27), in restraint of legal proceedings (Section 28) and wagering agreements (Section 30) are void.

Certainty and possibility of performance
Section 29 states that agreements whose meaning is not certain, or capable of being made certain, are void. An agreement to do an act impossible in itself is void under Section 56.

Legal formalities
Where a particular law requires an agreement to be in writing, registered or stamped, those formalities must be completed for the contract to be enforceable.`;

// [question, options, correct index, explanation, Bloom, difficulty, CO]
const MCQS = [
  ['Under Section 2(h) of the Indian Contract Act, 1872, a contract is:', ['Any promise made by two persons', 'An agreement enforceable by law', 'An offer that has been made in writing', 'An agreement registered with the government'], 1, 'Section 2(h): "An agreement enforceable by law is a contract."', 'Remember', 'Easy', 'CO1'],
  ['Which section lists the conditions that make an agreement a contract?', ['Section 2(d)', 'Section 10', 'Section 25', 'Section 56'], 1, 'Section 10 sets out free consent, competent parties, lawful consideration, lawful object and not expressly void.', 'Remember', 'Easy', 'CO1'],
  ['Ravi promises to take his sister to a film; he later refuses. Why can she not sue him?', ['There was no consideration', 'There was no intention to create legal relations', 'The agreement was not in writing', 'Ravi is a minor'], 1, 'Social and domestic arrangements usually lack the intention to create legal relations (Balfour v Balfour).', 'Apply', 'Moderate', 'CO1'],
  ['An agreement with a minor is:', ['Valid', 'Voidable at the option of the minor', 'Void from the beginning', 'Illegal and punishable'], 2, 'Mohori Bibee v Dharmodas Ghose (1903): an agreement with a minor is void ab initio.', 'Remember', 'Easy', 'CO1'],
  ['Consent obtained by threatening to commit an act forbidden by the Indian Penal Code is:', ['Coercion', 'Undue influence', 'Misrepresentation', 'Mistake of fact'], 0, 'Section 15 defines coercion, which includes committing or threatening an act forbidden by the Indian Penal Code.', 'Understand', 'Moderate', 'CO1'],
  ['A contract caused by undue influence is:', ['Void', 'Voidable at the option of the party whose consent was not free', 'Valid and enforceable', 'Illegal'], 1, 'Consent that is not free makes the contract voidable at the option of the aggrieved party (Sections 19 and 19A).', 'Understand', 'Moderate', 'CO1'],
  ['Asha offers to sell her scooter for ₹40,000. Bina replies, "I will buy it for ₹35,000." Bina’s reply is:', ['An acceptance', 'A counter offer that rejects the original offer', 'An invitation to treat', 'A general offer'], 1, 'Acceptance must be absolute and unqualified; a changed term is a counter offer.', 'Apply', 'Moderate', 'CO2'],
  ['Which of these agreements is expressly declared void by the Act?', ['An agreement to sell goods on credit', 'A wagering agreement', 'An agreement made by email', 'An agreement between two companies'], 1, 'Section 30 declares agreements by way of wager void.', 'Remember', 'Easy', 'CO1'],
  ['"Consideration need not be adequate" means:', ['Consideration can be anything, even if unlawful', 'The court will not ask whether the parties made a good bargain, provided consideration is real', 'A contract without consideration is always valid', 'Consideration must equal the market value'], 1, 'Explanation 2 to Section 25: inadequacy of consideration does not make the agreement void, though it may be evidence on free consent.', 'Understand', 'Difficult', 'CO2'],
  ['A promises to pay B ₹10,000 if B beats up C. The agreement is void because:', ['There is no consideration', 'B is not competent to contract', 'The object is unlawful under Section 23', 'It is not in writing'], 2, 'An object that involves injury to the person of another is unlawful (Section 23); the agreement is void.', 'Apply', 'Moderate', 'CO1']
];
const CASE = `## Background
Meera runs a small catering business in Chennai. In October she agreed with the organisers of a college cultural festival to run a food stall for three days.

## The situation
On 1 October the festival secretary, Arjun (19), messaged Meera: "We offer you the main food stall for ₹15,000 for three days." Meera replied: "Agreed, but only if you also give me a second counter near the stage." Arjun did not reply. On 3 October, Meera saw the festival poster listing her business and started buying supplies worth ₹22,000.

Two days before the festival the organisers gave the stall to another caterer who offered ₹20,000. They told Meera there was "no contract". Meera says she was also pressured by a committee member, who told her that her daughter "might have problems in college" if she did not agree to lower prices.

## Data and exhibits
| Date | Event |
|---|---|
| 1 Oct | Arjun’s message (offer) |
| 1 Oct | Meera’s reply with a new condition |
| 3 Oct | Poster lists Meera’s business; Meera buys supplies (₹22,000) |
| 10 Oct | Stall given to another caterer |

## Questions for analysis
1. Was there a valid acceptance? Consider whether Meera’s reply was an acceptance or a counter offer.
2. Does the poster amount to acceptance by conduct? Why or why not?
3. Arjun is 19. Does his age affect the validity of the agreement?
4. If a contract existed, what effect does the committee member’s statement have on Meera’s consent? Name the relevant section.
5. Advise Meera on whether she can recover ₹22,000.

## Learning outcomes
- CO1: Explain the essential elements of a valid contract.
- CO2: Apply the rules of offer and acceptance to a business situation.

## Teaching note
Expected line of argument: Meera’s reply is a counter offer (no absolute acceptance), so no contract was formed on 1 October; whether the poster is an acceptance of her counter offer by conduct is the key debate. Arjun has attained majority (18), so capacity is not in issue. The threat about her daughter may amount to undue influence or coercion — ask students to distinguish them. Allow 10 minutes in groups and 15 minutes of plenary discussion.`;

async function main() {
  // Brand kit (an administrator sets it once)
  await A('stSaveBrand', { name: 'Global Business University', footer: 'Department of Commerce', primary: '#1f3a6e', accent: '#c8952c', dark: '#1b1b1f', light: '#f5f4ef', muted: '#5f6470', fontHead: 'serif', fontBody: 'sans' });
  if (hod) await A('stSaveSettings', { grants: { academicAdmins: [admin.id], reviewers: [hod.id] } });

  // Courses, outcomes and units
  const made = {};
  for (const c of COURSES) {
    let course = store.rows('Courses').find((x) => x.deleted !== 'Y' && x.shortname === c.shortname);
    if (!course) { const r = await T('saveCourse', { fullname: c.fullname, shortname: c.shortname, category: c.category, summary: c.summary, color: c.color, visible: true, sections: c.units.length }); course = store.findById('Courses', r.id); }
    const secs = store.rows('Sections').filter((x) => x.courseId === course.id && x.deleted !== 'Y').sort((a, b) => a.position - b.position);
    for (let i = 0; i < c.units.length && i + 1 < secs.length; i++) await T('saveSection', { courseId: course.id, id: secs[i + 1].id, title: c.units[i][0], summary: 'Topics: ' + c.units[i][1].join(', ') + '.' });
    const code = (pre, list) => list.map((text, i) => ({ code: pre + (i + 1), text }));
    const r = await T('stSaveOutcomes', { courseId: course.id, programme: c.programme, semester: c.semester, department: c.department, co: code('CO', c.co), po: code('PO', c.po), pso: code('PSO', c.pso), units: c.units.map((u) => ({ title: u[0], topics: u[1] })) });
    if (students.length) await T('enrolUsers', { courseId: course.id, userIds: students.map((u) => u.id) });
    made[c.shortname] = { course, units: r.units, sections: store.rows('Sections').filter((x) => x.courseId === course.id && x.deleted !== 'Y').sort((a, b) => a.position - b.position) };
  }
  if (meena) store.append('Enrolments', { id: 'E' + Date.now().toString(36) + 'mm', courseId: made.MM201.course.id, userId: meena.id, role: 'teacher', createdAt: Date.now() });
  console.log('Courses with outcomes: ' + Object.keys(made).join(', '));

  // The demo workflow: one request → a linked set of learning objects
  const L = made['BCS-LAB'], unit1 = L.units[0], sec1 = L.sections[1];
  const pack = await T('stPack', { courseId: L.course.id, unitId: unit1.id, topic: 'Essentials of a valid contract', prompt: 'Create a 15-slide interactive lecture on essentials of a valid contract.', slides: 15, count: 10, level: 'II B.Com Corporate Secretaryship', sourceText: SOURCE,
    kinds: ['presentation', 'infographic', 'case', 'quiz', 'discussion', 'assignment', 'flashcards'] });
  const D = studio._db;
  const item = (kind) => D.items.find((x) => x.familyId === pack.familyId && x.kind === kind);
  // The faculty member edits the drafts: a reviewed question set and a fuller case (what the demo shows after "review").
  const qz = item('quiz'), cs = item('case');
  if (qz) await T('stSave', { id: qz.id, rev: qz.rev, title: 'Quiz: Essentials of a valid contract', questions: MCQS.map((q, i) => ({ id: 'q' + (i + 1), type: 'mcq', text: q[0], options: q[1], correct: q[2], explanation: q[3], marks: 1, bloom: q[4], difficulty: q[5], co: q[6] })) });
  if (cs) await T('stSave', { id: cs.id, rev: cs.rev, title: 'Case study: The festival stall agreement', doc: CASE });
  for (const x of pack.items) {
    const it = D.items.find((y) => y.id === x.id);
    await T('stMeta', { id: it.id, meta: Object.assign({}, it.meta, { courseId: L.course.id, unitId: unit1.id, topic: 'Essentials of a valid contract', co: it.kind === 'case' || it.kind === 'assignment' ? ['CO1', 'CO2'] : ['CO1'], po: ['PO1', 'PO2'], pso: [], bloom: ['Understand', 'Apply'], difficulty: 'Moderate', tags: ['contract act', 'unit 1'], folder: 'Legal Aspects — Unit I' }) });
    await T('stAiReviewed', { id: it.id, reviewed: true });
  }
  const pub = async (kind, as, extra) => { const it = item(kind); if (!it) return null; const r = await T('stPublish', Object.assign({ id: it.id, courseId: L.course.id, sectionId: sec1.id, as, visible: true }, extra || {})); return r; };
  const pubPres = await pub('presentation', 'studio');
  await pub('notes', 'studio');
  await pub('infographic', 'studio');
  await pub('case', 'studio');
  await pub('flashcards', 'studio');
  const pubQuiz = await pub('quiz', 'quiz', { durationMin: 15 });
  await pub('discussion', 'forum');
  await pub('assignment', 'assignment', { maxGrade: 20, dueAt: Date.now() + 10 * DAY });
  console.log('Learning objects: ' + pack.items.length + ' created and published to ' + L.course.shortname + (pubQuiz ? ' (quiz in the gradebook)' : ''));

  // Students open the lecture and the notes; a live check during class
  const pres = item('presentation'), quiz = item('quiz');
  for (const st of students) {
    const S = as(st);
    if (pubPres) await S('stView', { id: pres.id, moduleId: pubPres.moduleId });
  }
  const live = await T('stLiveStart', { id: quiz.id, courseId: L.course.id });
  for (let i = 0; i < students.length; i++) { const S = as(students[i]); const q = quiz.questions[0]; await S('stLiveAnswer', { id: live.id, answer: q.type === 'short' ? 'consideration' : (i % 4 === 3 ? (Number(q.correct) + 1) % q.options.length : Number(q.correct)) }); }
  await T('stLiveControl', { id: live.id, action: 'reveal' });
  await T('stLiveControl', { id: live.id, action: 'close' });

  // A colleague's infographic waiting for HOD review
  if (meena) {
    const mm = made.MM201;
    const r = await M('stGenerate', { kind: 'infographic', topic: 'The 4 Ps of the marketing mix', courseId: mm.course.id, unitId: mm.units[2].id,
      sourceText: 'The marketing mix\nProduct is the good or service offered to meet customer needs, including its features, quality, brand and packaging. Price is the amount customers pay, set with costs, competition and perceived value in mind. Place covers the channels that make the product available where and when customers want it. Promotion is how the firm communicates with customers through advertising, sales promotion, personal selling and public relations. The four elements must be consistent with the chosen positioning.' });
    await M('stMeta', { id: r.id, meta: { courseId: mm.course.id, unitId: mm.units[2].id, topic: 'Marketing mix', co: ['CO3'], po: ['PO1'], bloom: ['Understand'], difficulty: 'Easy', tags: ['marketing mix'] } });
    await M('stAiReviewed', { id: r.id, reviewed: true });
    await M('stSubmitReview', { id: r.id, note: 'Please check before I publish it to MM201.' });
    await M('stComment', { id: r.id, text: 'Added an example for each P on page 1.' });
  }

  // A resource in the university library
  const fm = made.FM301;
  const cm = await T('stGenerate', { kind: 'conceptmap', topic: 'Capital budgeting techniques', courseId: fm.course.id, unitId: fm.units[1].id,
    sourceText: 'Capital budgeting\nCapital budgeting is the process of evaluating long-term investment proposals. The payback period is the time needed to recover the initial investment. Net present value is the present value of cash inflows minus the present value of cash outflows. The internal rate of return is the discount rate at which net present value is zero. Profitability index is the ratio of the present value of inflows to the initial investment.' });
  await T('stAiReviewed', { id: cm.id, reviewed: true });
  await T('stShare', { id: cm.id, library: true, department: true });
  await A('stLibrary', { id: cm.id, approve: true });

  // A student's own work
  if (students[0]) {
    const S = as(students[0]);
    const tpl = (await S('stTemplates')).builtin.find((x) => x.kind === 'poster');
    const r = await S('stCreate', tpl ? { kind: 'poster', templateId: tpl.id } : { kind: 'poster', blank: true });
    const it = D.items.find((x) => x.id === r.id);
    await S('stSave', { id: it.id, rev: it.rev, title: 'Consumer rights in India — awareness poster', pages: it.pages, size: it.size });
  }

  D.settings.demoData = true;
  studio._flush();
  console.log('Studio demo ready: sign in as demo.teacher → Content Studio.');
}
main().then(() => setTimeout(() => process.exit(0), 600)).catch((e) => { console.error('Studio demo failed: ' + (e && e.message)); studio._flush(); setTimeout(() => process.exit(1), 600); });
