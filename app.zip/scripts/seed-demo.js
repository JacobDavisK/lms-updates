/**
 * Fills the site with demo courses, users and activity so you can explore
 * every feature. Runs through the real API (the same calls the browser makes).
 *
 *   npm run seed                                  (uses ./data)
 *   LMS_DATA_DIR=/some/other/dir npm run seed     (uses another database)
 */
'use strict';
process.env.LMS_ALERTS_OFF = '1'; // demo data must not send real emails / SMS
process.env.LMS_DEMO = '1';       // seeding makes a demo installation (demo sign-ins are only allowed there)
const store = require('../lib/store');
const crypto = require('../lib/crypto');
const lms = require('../lib/api');

const DAY = 86400000;
const now = Date.now();
const TEACHER_PW = 'Teach2026demo';
const STUDENT_PW = 'Learn2026demo';

if (store.rows('Courses').some((c) => c.shortname === 'BLAW201' && c.deleted !== 'Y')) {
  console.log('Demo content is already installed (course BLAW201 exists). Nothing to do.');
  process.exit(0);
}
lms.bootstrap();

// The seeder signs in as the demo teacher and students through the real API.
// If the site requires emailed sign-in codes for staff, pause that for this run
// only, and put the setting back however the run ends.
const otpSetting = store.getSetting('requireOtpStaff', 'N');
if (otpSetting === 'Y') store.setSetting('requireOtpStaff', 'N');
process.on('exit', () => { if (otpSetting === 'Y') store.setSetting('requireOtpStaff', 'Y'); });

function ensureUser(username, name, role, batch, email, password) {
  let u = store.rows('Users').find((x) => x.username === username);
  if (u) return u;
  const salt = crypto.newSalt();
  u = {
    id: crypto.newId('U'), username, name, role, batch, email, salt, hash: crypto.hashPw(password, salt, 1000),
    status: 'active', failed: 0, lockedUntil: 0, mustChange: 'N', createdAt: now - 30 * DAY, lastLogin: 0
  };
  store.append('Users', u);
  return u;
}
function as(username, password) {
  const r = lms.login(username, password);
  if (!r.token) throw new Error('Could not sign in as ' + username + ' (the site asked for a sign-in code).');
  return (action, payload) => lms.api(r.token, action, payload || {});
}

ensureUser('demo.teacher', 'Priya Sharma', 'teacher', '', 'priya.sharma@example.edu', TEACHER_PW);
const students = [
  ['demo.anitha', 'Anitha Raman'], ['demo.bharath', 'Bharath Kumar'], ['demo.chitra', 'Chitra Menon'],
  ['demo.dev', 'Dev Patel'], ['demo.esha', 'Esha Nair'], ['demo.farhan', 'Farhan Ali']
].map(([u, n]) => ensureUser(u, n, 'student', 'II BCom CS A', u.replace('demo.', '') + '@example.edu', STUDENT_PW));

// Parents: one guardian per family, linked to their child's student account.
const family = require('../lib/family');
const PARENT_PW = 'Family2026demo';
[['demo.raman', 'Raman K', 'demo.anitha', '+919800000001'], ['demo.patel', 'Kiran Patel', 'demo.dev', '+919800000002']].forEach(([un, name, child, phone]) => {
  const p = ensureUser(un, name, 'parent', '', un.replace('demo.', '') + '.parent@example.edu', PARENT_PW);
  if (!p.phone) store.update('Users', p.id, { phone });
  family.link(p, store.rows('Users').find((x) => x.username === child), 'seed');
});
// Demo admin + one-click Admin / Faculty / Student / Parent tiles on the sign-in page.
require('../lib/demo').ensureAccounts();

const T = as('demo.teacher', TEACHER_PW);

/* ---------------- Course 1: Business Law ---------------- */
const blaw = T('saveCourse', {
  fullname: 'Business Law', shortname: 'BLAW201', category: 'Commerce', color: 'violet',
  summary: 'The legal framework of business in India: contracts, bailment and pledge, agency and more.',
  startDate: now - 21 * DAY, endDate: now + 100 * DAY, visible: true, selfEnrol: false, enrolKey: '', sections: 3
}).id;
let secs = T('getCourse', { courseId: blaw }).sections;
T('saveSection', { courseId: blaw, id: secs[1].id, title: 'Indian Contract Act — essentials', summary: 'Offer, acceptance, consideration and capacity. Read the notes **before** Monday’s lecture.' });
T('saveSection', { courseId: blaw, id: secs[2].id, title: 'Bailment and pledge', summary: '' });
T('saveSection', { courseId: blaw, id: secs[3].id, title: 'Law of agency', summary: '' });

T('saveModule', { courseId: blaw, sectionId: secs[0].id, type: 'label', visible: true,
  description: '### Welcome to Business Law!\nThis course runs for one semester. Check the **timeline** on your dashboard for deadlines, and use the Q&A forum for questions.' });
const qa = T('saveModule', { courseId: blaw, sectionId: secs[0].id, type: 'forum', title: 'Course Q&A forum', visible: true,
  description: 'Ask questions about lectures, readings and assignments. Your classmates and I will answer.' }).id;
T('saveModule', { courseId: blaw, sectionId: secs[0].id, type: 'url', title: 'Indian Contract Act, 1872 — full text', visible: true,
  url: 'https://www.indiacode.nic.in/', description: 'The official text on India Code.' });

const notes = T('saveModule', { courseId: blaw, sectionId: secs[1].id, type: 'page', title: 'Lecture notes: offer and acceptance', visible: true,
  description: 'Key definitions and landmark cases.',
  content: '## What is an offer?\nUnder **Section 2(a)**, a person makes a *proposal* when they signify to another their willingness to do or abstain from doing anything, with a view to obtaining the assent of that other.\n\n' +
    '## Essentials of a valid offer\n1. It must be intended to create legal relations\n2. The terms must be certain\n3. It must be communicated to the offeree\n4. It may be specific or general\n\n' +
    '> A general offer can be accepted by anyone who performs its conditions — see *Carlill v Carbolic Smoke Ball Co* (1893).\n\n' +
    '## Acceptance\nAcceptance must be **absolute and unqualified** (Section 7). A counter-offer destroys the original offer.\n\n---\nFurther reading: [India Code](https://www.indiacode.nic.in/)' }).id;
const brief = T('saveModule', { courseId: blaw, sectionId: secs[1].id, type: 'assignment', title: 'Case brief: Carlill v Carbolic Smoke Ball Co', visible: true,
  description: 'Write a one-page case brief covering:\n- the facts\n- the legal issue\n- the decision and its reasoning\n- why the case matters for general offers\n\nSubmit as online text or upload a PDF.',
  dueAt: now + 5 * DAY, cutoffAt: now + 12 * DAY, maxGrade: 20, subText: true, subFile: true }).id;
const quiz1 = T('saveQuiz', { courseId: blaw, sectionId: secs[1].id, title: 'Quiz 1: Contract basics', description: 'Six questions on offer, acceptance and consideration. 15 minutes.',
  openAt: now - 2 * DAY, closeAt: now + 7 * DAY, durationMin: 15, maxAttempts: 2, questionsPerAttempt: 0, negativeMark: 0, passPercent: 50,
  violationLimit: 0, accessCode: '', reviewMode: 'immediate', shuffleQuestions: true, shuffleOptions: true, published: true,
  proctoring: 'off' }).id; // the seeded students below take it without a camera
T('importQuestions', { quizId: quiz1, mode: 'append', text: [
  'Which section of the Indian Contract Act defines a proposal? | Section 2(a) | Section 2(b) | Section 10 | Section 25 | A | 1 | Section 2(a) defines proposal (offer).',
  'Acceptance must be… | Conditional | Absolute and unqualified | Implied only | In writing | B | 1 | Section 7 requires acceptance to be absolute and unqualified.',
  'A counter-offer… | Accepts the original offer | Rejects the original offer | Is invalid | Needs registration | B | 1 | A counter-offer amounts to rejection of the original offer.',
  'Carlill v Carbolic Smoke Ball Co is a leading case on… | Agency | General offers | Bailment | Minors | B | 1 | It established that a general offer can be accepted by performance.',
  'An agreement without consideration is generally… | Valid | Void | Voidable | Illegal | B | 1 | Section 25: an agreement without consideration is void, with exceptions.',
  'Which of these can make a valid contract? | A minor | A person of unsound mind | A major of sound mind | A disqualified person | C | 1 | Section 11: competent persons are majors of sound mind not disqualified by law.'
].join('\n') });

// A proctored exam nobody has taken yet, so the demo can show the camera check-in and live monitor.
const quiz3 = T('saveQuiz', { courseId: blaw, sectionId: secs[1].id, title: 'Proctored test: Contract law', description: 'Five questions, 10 minutes. Camera and microphone are required.',
  openAt: now - DAY, closeAt: now + 14 * DAY, durationMin: 10, maxAttempts: 1, questionsPerAttempt: 0, negativeMark: 0, passPercent: 50,
  violationLimit: 0, accessCode: '', reviewMode: 'score', shuffleQuestions: true, shuffleOptions: true, published: true,
  proctoring: 'standard' }).id;
T('importQuestions', { quizId: quiz3, mode: 'append', text: [
  'Section 10 of the Indian Contract Act deals with… | Agents | What agreements are contracts | Bailment | Quasi-contracts | B | 1',
  'Consideration may move from… | Only the promisee | The promisee or any other person | Only the promisor | Only a third party | B | 1',
  'An agreement enforceable at the option of one party only is… | Void | Voidable | Valid | Illegal | B | 1',
  'Acceptance of a proposal by post is complete against the proposer when… | The letter is posted | The letter is received | The letter is read | The proposer replies | A | 1',
  'Which of these is an example of a general offer? | A job offer to one person | A reward advertised to the public | A counter-offer | An invitation to tender | B | 1'
].join('\n') });

T('saveModule', { courseId: blaw, sectionId: secs[2].id, type: 'page', title: 'Bailment explained', visible: true,
  content: '## Bailment (Section 148)\nThe delivery of goods by one person to another for some purpose, upon a contract that they shall be returned when the purpose is accomplished.\n\n- The person delivering is the **bailor**\n- The person receiving is the **bailee**\n\n## Pledge (Section 172)\nBailment of goods as **security for payment of a debt** or performance of a promise.' });
const essay = T('saveModule', { courseId: blaw, sectionId: secs[2].id, type: 'assignment', title: 'Essay: rights and duties of a bailee', visible: true,
  description: 'In 800–1000 words, explain the rights and duties of a bailee with at least two illustrations.', dueAt: now - 2 * DAY, cutoffAt: now + 5 * DAY, maxGrade: 50, subText: true, subFile: true }).id;
T('saveModule', { courseId: blaw, sectionId: secs[3].id, type: 'label', visible: true, description: 'Materials for this topic will be released after the mid-term.' });

/* ---------------- Course 2: Financial Accounting ---------------- */
const facc = T('saveCourse', {
  fullname: 'Financial Accounting', shortname: 'FACC101', category: 'Commerce', color: 'emerald',
  summary: 'Double-entry bookkeeping, journals, ledgers and final accounts.', startDate: now - 14 * DAY, endDate: now + 120 * DAY,
  visible: true, selfEnrol: false, enrolKey: '', sections: 2
}).id;
secs = T('getCourse', { courseId: facc }).sections;
T('saveSection', { courseId: facc, id: secs[1].id, title: 'Journal and ledger', summary: '' });
T('saveSection', { courseId: facc, id: secs[2].id, title: 'Trial balance', summary: '' });
T('saveModule', { courseId: facc, sectionId: secs[1].id, type: 'page', title: 'The golden rules of accounting', visible: true,
  content: 'Every transaction affects at least two accounts. Classify each account first, then apply its rule:\n\n- **Personal**: debit the receiver, credit the giver\n- **Real**: debit what comes in, credit what goes out\n- **Nominal**: debit expenses and losses, credit incomes and gains' });
const quiz2 = T('saveQuiz', { courseId: facc, sectionId: secs[1].id, title: 'Quick check: journal entries', description: '',
  openAt: 0, closeAt: now + 3 * DAY, durationMin: 10, maxAttempts: 0, questionsPerAttempt: 0, negativeMark: 0.25, passPercent: 40,
  violationLimit: 5, accessCode: '', reviewMode: 'score', shuffleQuestions: true, shuffleOptions: true, published: true,
  proctoring: 'off' }).id;
T('importQuestions', { quizId: quiz2, mode: 'append', text: [
  'Rent paid in cash is debited to… | Cash account | Rent account | Capital account | Bank account | B | 1',
  'Goods sold on credit to Ravi: Ravi’s account is… | Debited | Credited | Not affected | Closed | A | 1',
  'Which account is a nominal account? | Machinery | Salary | Ravi | Cash | B | 1'
].join('\n') });
T('saveModule', { courseId: facc, sectionId: secs[2].id, type: 'assignment', title: 'Prepare a trial balance', visible: true,
  description: 'Use the ledger balances in the attached worksheet and prepare a trial balance.', dueAt: now + 10 * DAY, cutoffAt: 0, maxGrade: 25, subText: false, subFile: true });

/* ---------------- Course 3: open for self-enrolment ---------------- */
const dmkt = T('saveCourse', {
  fullname: 'Digital Marketing Fundamentals', shortname: 'DMKT110', category: 'Management', color: 'rose',
  summary: 'SEO, social media, content strategy and analytics — an open elective anyone can join.',
  startDate: now + 7 * DAY, endDate: now + 90 * DAY, visible: true, selfEnrol: true, enrolKey: '', sections: 4
}).id;
secs = T('getCourse', { courseId: dmkt }).sections;
T('saveModule', { courseId: dmkt, sectionId: secs[0].id, type: 'page', title: 'Course outline', visible: true,
  content: '## What you will learn\n- Search engine optimisation\n- Social media strategy\n- Content marketing\n- Measuring results with analytics' });

/* ---------------- Enrolment, announcements, forum ---------------- */
T('enrolUsers', { courseId: blaw, batch: 'II BCom CS A' });
T('enrolUsers', { courseId: facc, userIds: students.slice(0, 4).map((u) => u.id) });
T('postAnnouncement', { courseId: blaw, title: 'Mid-term schedule', body: 'The mid-term test is on **Friday of week 8**, covering Topics 1 and 2. Quiz 1 is good practice — you get two attempts.' });
T('postAnnouncement', { courseId: facc, title: 'Welcome to Financial Accounting', body: 'Please bring a calculator to every class. Our first quick-check quiz is open now.' });
store.append('Announcements', {
  id: crypto.newId('W'), courseId: '', userId: store.rows('Users').find((u) => u.role === 'admin').id,
  title: 'Welcome to the new learning platform', body: 'Courses, assignments, forums, quizzes and grades now live in one place. Use the **Calendar** to see every deadline.',
  createdAt: now - 3 * DAY, deleted: 'N'
});
const disc = T('postDiscussion', { moduleId: qa, subject: 'Introduce yourself!', message: 'Tell the class your name and one thing you hope to learn in this course.' }).id;

/* ---------------- Student activity ---------------- */
const A = as('demo.anitha', STUDENT_PW);
A('postReply', { discussionId: disc, message: 'Hi everyone, I’m Anitha. I want to understand how contracts work in e-commerce.' });
A('toggleCompletion', { moduleId: notes });
A('submitAssignment', { moduleId: brief, text: '**Facts:** The company offered £100 to anyone who caught influenza after using its smoke ball as directed...\n\n**Issue:** Was there a binding contract?\n\n**Decision:** Yes — a general offer accepted by performance.' });
const B = as('demo.bharath', STUDENT_PW);
B('postReply', { discussionId: disc, message: 'Bharath here — interested in company law and startups.' });
B('submitAssignment', { moduleId: brief, text: 'Carlill v Carbolic Smoke Ball Co (1893): unilateral contract, acceptance by performance, advertisement was not mere puffery.' });
const C = as('demo.chitra', STUDENT_PW);
C('submitAssignment', { moduleId: essay, text: 'A bailee must take reasonable care of the goods (Section 151), must not make unauthorised use (Section 154)...' });

function takeQuiz(api, quizId) {
  const { attemptId } = api('startAttempt', { quizId, accessCode: '' });
  api('getAttempt', { attemptId }).questions.forEach((q) => {
    api('saveAnswer', { attemptId, qid: q.qid, choice: Math.floor(Math.random() * q.options.length) });
  });
  api('submitAttempt', { attemptId });
}
takeQuiz(A, quiz1);
takeQuiz(B, quiz1);
takeQuiz(C, quiz1);
takeQuiz(A, quiz2);

T('gradeSubmission', { moduleId: brief, userId: students[0].id, grade: 17, feedback: 'Clear and well structured. Add one more sentence on **why** the advertisement was not a mere puff.' });

/* ---------------- Messages: a short conversation in #general and one direct message ---------------- */
const general = T('chatBootstrap').channels.find((c) => c.general && /BLAW201/.test(c.topic));
if (general) {
  const welcome = T('chatSend', { ch: general.id, text: 'Welcome to **#general** for Business Law! Ask questions here any time — someone usually answers within the hour.' }).message;
  A('chatReact', { ch: general.id, id: welcome.id, emoji: '👍' });
  const q = B('chatSend', { ch: general.id, text: 'Is Quiz 1 open book?' }).message;
  T('chatSend', { ch: general.id, parent: q.id, text: 'No — but the reading on offer and acceptance covers everything in it.' });
  A('chatSend', { ch: general.id, text: '@[Priya Sharma](' + T('chatBootstrap').me.id + ') could we get one more practice question on counter-offers?' });
}
const dm = C('chatOpenDM', { uids: [T('chatBootstrap').me.id] }).channel;
C('chatSend', { ch: dm.id, text: 'Ma’am, can I submit the bailment essay a day late? I was unwell this week.' });

/* ---------------- Attendance: 5 periods a day (55 min each), Mon–Sat, last four weeks ---------------- */
{
  // Chance of missing a whole day, and of missing a single period on a day they came.
  const awayDay = { 'demo.anitha': 0.03, 'demo.bharath': 0.06, 'demo.chitra': 0.1, 'demo.dev': 0.3, 'demo.esha': 0.15, 'demo.farhan': 0.12 };
  const skipPeriod = { 'demo.anitha': 0.02, 'demo.bharath': 0.05, 'demo.chitra': 0.06, 'demo.dev': 0.15, 'demo.esha': 0.1, 'demo.farhan': 0.08 };
  const topics = { [blaw]: ['Offer and acceptance', 'Consideration', 'Capacity to contract', 'Free consent', 'Bailment', 'Pledge', 'Agency'], [facc]: ['Journal entries', 'Ledger posting', 'Trial balance', 'Bank reconciliation', 'Depreciation'] };
  let seedR = 7, n = 0;
  const rand = () => { seedR = (seedR * 9301 + 49297) % 233280; return seedR / 233280; };
  for (let back = 27; back >= 1; back--) {
    const day = new Date(now - back * DAY);
    if (day.getDay() === 0) continue;
    const date = day.getFullYear() + '-' + String(day.getMonth() + 1).padStart(2, '0') + '-' + String(day.getDate()).padStart(2, '0');
    const away = {};
    students.forEach((u) => { away[u.id] = rand() < awayDay[u.username]; });
    for (let period = 1; period <= 5; period++) {
      const cid = period % 2 ? blaw : facc;          // odd periods Business Law, even periods Financial Accounting
      const list = cid === blaw ? students : students.slice(0, 4);
      const marks = {};
      list.forEach((u) => { marks[u.id] = away[u.id] || rand() < skipPeriod[u.username] ? 'A' : 'P'; });
      T('attSave', { courseId: cid, date, period, topic: topics[cid][n++ % topics[cid].length], marks });
    }
  }
}

/* ---------------- Internal marks (LOCF): COMP.1 submitted, COMP 3a in draft ---------------- */
{
  const ymd = (t) => { const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  const byUser = (vals) => Object.fromEntries(students.map((u, i) => [u.id, vals[i] === 'A' ? { ab: true } : { p: vals[i] }]));
  T('mkMeta', { courseId: blaw, semester: '3', credits: '4', department: 'Commerce', kind: 'Theory', teacher: 'Dr. Priya Sharma', programme: '' });
  // K1&K2 /10, K3&K4 /20, K5&K6 /20 → converted to 30
  T('mkSave', { courseId: blaw, comp: 'COMP.1', date: ymd(now - 12 * DAY), marks: byUser([[9, 17, 15], [8, 14, 13.5], [7, 12, 11], [4, 7, 5], 'A', [7, 13, 12]]) });
  T('mkSubmit', { courseId: blaw, comp: 'COMP.1', force: true });
  T('mkSave', { courseId: blaw, comp: 'COMP 3a', date: ymd(now - 4 * DAY), marks: byUser([[18], [16], [15], [9], [12], [14]]) });
}

/* ---------------- 30 days of usage history for the analytics dashboards ---------------- */
const analytics = require('../lib/analytics');
const engagement = { 'demo.anitha': 0.95, 'demo.bharath': 0.7, 'demo.chitra': 0.5, 'demo.dev': 0.35, 'demo.esha': 0.15, 'demo.farhan': 0 };
const quietFor = { 'demo.dev': 9 }; // Dev stopped visiting 9 days ago
const hours = [9, 10, 11, 14, 15, 16, 19, 20, 21, 22];
const rnd = (a, b) => a + Math.random() * (b - a);
[[blaw, students], [facc, students.slice(0, 4)]].forEach(([cid, list]) => {
  const mods = store.rows('Modules').filter((m) => m.courseId === cid && m.deleted !== 'Y' && m.type !== 'label');
  list.forEach((u) => {
    const e = engagement[u.username] || 0;
    if (!e) return;
    for (let i = 29; i >= (quietFor[u.username] || 1); i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const weekend = d.getDay() === 0 || d.getDay() === 6;
      if (Math.random() > e * 0.85 + 0.05 || (weekend && Math.random() < 0.6)) continue;
      d.setHours(hours[Math.floor(Math.random() * hours.length)], Math.floor(Math.random() * 60), 0, 0);
      const minutes = Math.round(rnd(8, 70) * e + 4);
      analytics.seedDay(u.id, cid, d.getTime(), minutes, Math.round(rnd(2, 12) * e + 1), Math.random() < 0.15 ? 1 : 0, Math.random() < 0.15 ? { download: 1 } : {});
      mods.forEach((m) => { if (Math.random() < e * 0.3) analytics.seedModuleView(u.id, m.id, m.type, d.getTime(), 1); });
    }
  });
});
analytics.flush();

/* ---------------- Staff leave & movements (Attendance → Leave / Movements / Leave desk) ---------------- */
const leaveMod = require('../lib/leave');
const hod = ensureUser('demo.hod', 'Dr. Ramesh Iyer', 'teacher', '', 'ramesh.iyer@example.edu', TEACHER_PW);
ensureUser('demo.meena', 'Meena Krishnan', 'teacher', '', 'meena.k@example.edu', TEACHER_PW);
const AD = as('demo.admin', 'Admin2026demo');
lms.asSystemAdmin('leaveSaveSettings', {
  total: 12, yearStart: 6, excludeSundays: true, counted: { CL: true, OD: false, ML: true }, movementsPerMonth: 2, movementMaxMinutes: 120,
  leavePath: [{ name: 'Head of Department', approvers: [hod.id] }, { name: 'Principal', approvers: [] }],
  movementPath: [{ name: 'Head of Department', approvers: [hod.id] }]
});
const HOD = as('demo.hod', TEACHER_PW);
const M = as('demo.meena', TEACHER_PW);
const dayStr = (n) => { const d = new Date(now + n * DAY); if (d.getDay() === 0) d.setDate(d.getDate() + 1); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const backdate = (ref, daysAgo) => { // make the history look like it happened over the past weeks
  const r = leaveMod._db.requests.find((x) => x.id === ref);
  r.trail.forEach((t, i) => { t.at = now - daysAgo * DAY + i * 5 * 3600000; });
  r.createdAt = r.trail[0].at; r.updatedAt = r.trail[r.trail.length - 1].at;
};
const lv = (fn, p) => fn(p.kind === 'movement' ? 'movementApply' : 'leaveApply', p).request.id;
// Priya (demo.teacher): two approved leaves, one with the Principal, one with an open HOD query, one approved movement.
const p1 = lv(T, { type: 'CL', from: dayStr(-52), to: dayStr(-51), reason: 'Family function at Madurai — sister’s engagement.' });
HOD('leaveAct', { id: p1, action: 'approve', note: 'Classes arranged with Dr. Meena.' }); AD('leaveAct', { id: p1, action: 'approve' }); backdate(p1, 60);
const p2 = lv(T, { type: 'ML', from: dayStr(-24), to: dayStr(-22), reason: 'Viral fever; doctor advised three days’ rest. Certificate submitted to the office.' });
HOD('leaveAct', { id: p2, action: 'query', note: 'Please submit the medical certificate to the office.' });
T('leaveAct', { id: p2, action: 'reply', note: 'Submitted to the office on the day I returned.' });
HOD('leaveAct', { id: p2, action: 'approve' }); AD('leaveAct', { id: p2, action: 'approve', note: 'Get well soon.' }); backdate(p2, 26);
const p3 = lv(T, { type: 'OD', from: dayStr(6), to: dayStr(7), reason: 'Resource person for the FDP on GST at Loyola College, Chennai.' });
HOD('leaveAct', { id: p3, action: 'approve', note: 'Recommended.' }); backdate(p3, 2);
const p4 = lv(T, { type: 'CL', from: dayStr(13), to: dayStr(13), reason: 'Personal work at the bank and registrar office.' });
HOD('leaveAct', { id: p4, action: 'query', note: 'Internal tests start that week — who will take your BLAW201 hour?' });
const m1 = lv(T, { kind: 'movement', date: dayStr(-3), fromTime: '14:00', toTime: '15:15', reason: 'Collecting passport at the Passport Seva Kendra.' });
HOD('leaveAct', { id: m1, action: 'approve' }); backdate(m1, 4);
// Meena: waiting at HOD, plus a movement.
lv(M, { type: 'CL', from: dayStr(3), to: dayStr(3), half: true, reason: 'Parent–teacher meeting at my son’s school.' });
lv(M, { kind: 'movement', date: dayStr(1), fromTime: '11:30', toTime: '12:30', reason: 'Bank visit for salary account KYC.' });
leaveMod._flush();

/* ---------------- A parent–teacher conversation (Messages) ---------------- */
{
  const R = as('demo.raman', PARENT_PW);
  const priya = store.rows('Users').find((u) => u.username === 'demo.teacher');
  const ch = R('chatOpenDM', { uids: [priya.id] }).channel;
  R('chatSend', { ch: ch.id, text: 'Good evening Ma’am, this is Raman, Anitha’s father. How is she doing in Business Law? She mentioned the internal test next week.' });
  T('chatSend', { ch: ch.id, text: 'Good evening Sir. Anitha is doing well — she is regular to class and did well in COMP.1. For the internal test, revising bailment and pledge will help.' });
  R('chatSend', { ch: ch.id, text: 'Thank you Ma’am, that is reassuring. 🙏' });
}


/* ---------------- Student OD / ML requests (Class faculty → HOD → Vice Principal) ---------------- */
{
  const find = (u) => store.rows('Users').find((x) => x.username === u);
  lms.asSystemAdmin('stuLeaveSettings', { classFaculty: { 'ii bcom cs a': [find('demo.teacher').id] }, hod: {}, hodDefault: [hod.id], vp: [find('demo.admin').id], mlCountsPresent: true });
  const AN = as('demo.anitha', STUDENT_PW);
  const absentDays = AN('attMine').students[0].days.recent.filter((d) => d.status !== 'present').map((d) => d.date);
  // 1. Fully approved OD on a day Anitha was marked absent — her attendance now shows OD there.
  const odDay = absentDays[absentDays.length - 1];
  if (odDay) {
    const r1 = AN('stuLeaveApply', { type: 'OD', from: odDay, to: odDay, reason: 'Represented the college at the inter-collegiate debate at Madras Christian College.' }).request.id;
    T('leaveAct', { id: r1, action: 'approve', note: 'Verified with the debate club coordinator.' });
    HOD('leaveAct', { id: r1, action: 'approve' });
    AD('leaveAct', { id: r1, action: 'approve', note: 'Well done!' });
    backdate(r1, 3);
  }
  // 2. ML waiting at the HOD.
  const mlDay = absentDays.length > 1 ? absentDays[absentDays.length - 2] : dayStr(-2);
  const r2 = AN('stuLeaveApply', { type: 'ML', from: mlDay, to: mlDay, reason: 'High fever; consulted Dr. Suresh at Apollo Clinic, Nungambakkam. Certificate available.' }).request.id;
  T('leaveAct', { id: r2, action: 'approve' });
  backdate(r2, 1);
  // 3. Dev: the class faculty has asked for the medical certificate.
  const DV = as('demo.dev', STUDENT_PW);
  const r3 = DV('stuLeaveApply', { type: 'ML', from: dayStr(-6), to: dayStr(-5), reason: 'Viral infection, advised rest for two days.' }).request.id;
  T('leaveAct', { id: r3, action: 'query', note: 'Please submit the medical certificate to the class office and reply here once done.' });
  leaveMod._flush();
}

console.log('');
console.log('Demo content installed. The sign-in page shows one-click Admin / Faculty / Student / Parent demo accounts.');
console.log('  Admin   : demo.admin / Admin2026demo');
console.log('  Teacher : demo.teacher / ' + TEACHER_PW);
console.log('  Students: demo.anitha, demo.bharath, demo.chitra, demo.dev, demo.esha, demo.farhan / ' + STUDENT_PW);
console.log('  Parents : demo.raman (Anitha\'s parent), demo.patel (Dev\'s parent) / ' + PARENT_PW);
console.log('');
