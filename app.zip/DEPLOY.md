# Running the LMS for real (not a demo)

The site holds personal data about students and parents. Before anyone other than you can
reach it, set it up like this.

## 1. Run it behind HTTPS

Out of the box the server listens on **this computer only** (`127.0.0.1:3000`). Put an HTTPS
reverse proxy in front of it. [Caddy](https://caddyserver.com) gets and renews certificates
automatically:

```
# /etc/caddy/Caddyfile
lms.yourcollege.edu {
    reverse_proxy 127.0.0.1:3000
}
```

Then start the LMS with:

| Variable | Value | Why |
|---|---|---|
| `NODE_ENV` | `production` | Sign-in codes are never printed to the console, and staff codes can't be switched on without email |
| `TRUST_PROXY` | `1` | Real client IPs for the sign-in limits; HTTPS detection turns on HSTS |
| `HOST` | `127.0.0.1` | The default: only the proxy can reach Node. Use `0.0.0.0` only if the proxy is on another machine |
| `LMS_PEPPER` | the `PEPPER` value from `data/properties.json` | Keeps the password pepper out of the data folder. Copy the existing value **exactly**, then remove it from `properties.json`. A different value makes every password stop working |
| `SMTP_HOST`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM` | your mail server | Sign-in codes and alerts. Secrets stay out of `data/` |
| `TWILIO_SID`, `TWILIO_TOKEN`, `TWILIO_FROM` (or `SMS_WEBHOOK_URL`, `SMS_WEBHOOK_TOKEN`) | your SMS provider | Enables the **texted code at first sign-in** |
| `ANTHROPIC_API_KEY` | optional | The AI guide |

**Never set `LMS_DEMO=1` on a real site.** Without it, demo sign-ins can't be switched on and
the `demo.*` accounts can't sign in.

## 2. Accounts

- In **Admin → Settings**, turn on *Require an emailed sign-in code for teachers and admins*.
  Email must be set up first.
- Keep the number of administrators small, and give each person their own account.
- First-time passwords (mobile number / child's college ID) expire after the number of days set
  in Settings (14 by default). With SMS set up, the first sign-in also needs a texted code.

## 3. Back up every night

```
LMS_BACKUP_KEY="a long passphrase you keep somewhere safe" npm run backup
```

This writes an encrypted file to `backups/` and keeps the latest 14; the folder is never
uploaded to GitHub. Copy the backups to another machine or drive. To check one, restore it into
a new folder; restoring never touches the live data:

```
LMS_BACKUP_KEY="…" npm run restore -- backups/lms-data-20260925-0200.lmsbak restored-data
```

Schedule the backup with cron (Linux) or Task Scheduler (Windows) to run every night.

## 4. Keep it checked

`npm run test:security` runs the security regression tests against a throwaway demo copy. On
GitHub they also run on every push (`.github/workflows/security.yml`), along with `npm audit`.
