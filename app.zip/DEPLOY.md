# Running the LMS for real (not a demo)

The site holds personal data about students and parents. Before anyone other than you can
reach it, set it up like this.

## Hosting on Render

`render.yaml` describes the whole setup: one Node web service in Singapore with a 5 GB disk at
`/var/data` (data in `/var/data/lms`, backups in `/var/data/backups`), HTTPS on a
`*.onrender.com` address, and a generated `LMS_PEPPER`. It needs a paid plan: the free plan has no
disk. Render charges for the instance plus the disk.

When the LMS sees it is on Render (`RENDER=true`), it fills in the rest itself: production mode,
listening on all interfaces, port 10000, trusting Render's proxy, reading the visitor's address
from `cf-connecting-ip`, and using the service's address in email links. Anything you set
yourself wins. Without a data folder on a disk (`LMS_DATA_DIR`) it refuses to start, because
Render erases everything else on each deploy.

1. Sign in at [render.com](https://render.com) and connect your GitHub account.
2. **New → Blueprint** (not "Web Service"), choose the `lms` repository, and confirm. The first
   deploy takes a few minutes.
3. Open the service's **Logs**. On the first start the LMS prints a one-time admin password
   (username `admin`). Sign in at the service's address and set a new password straight away.
4. Copy the `LMS_PEPPER` value (service → **Environment**) to somewhere safe. Without it, a
   restored backup has no working passwords.
5. **Automatic deploys after each release:** service → **Settings → Deploy Hook**, copy the URL,
   then on GitHub add it as the repository secret `RENDER_DEPLOY_HOOK`
   (repo → Settings → Secrets and variables → Actions). From then on, raising the version and
   pushing deploys the site once the tests pass. Auto-save pushes don't redeploy it. To deploy
   by hand: service → **Manual Deploy**.
6. **Check the sign-in limits see real addresses:** sign in, then open the audit log. Your
   `LOGIN` entry should show your own internet address. If the log says
   `requests arrive without a "cf-connecting-ip" header`, the forwarded address is used instead,
   which also works.
7. Then follow sections 2 and 3 below: email, staff sign-in codes, and backups. Render also
   keeps daily snapshots of the disk for 7 days (service → **Disks**).

**Created a plain Web Service instead of a Blueprint?** It works too: add a disk (service →
**Disks**, mount path `/var/data`), then set `LMS_DATA_DIR=/var/data/lms`, `LMS_PEPPER` (a long
random value) and `NODE_VERSION=24` under **Environment**. Build command `npm ci --omit=dev`,
start command `node server.js`.

**Moving an existing site's data here** (only once the college has approved storing student
records with Render):

1. On the current computer: `LMS_BACKUP_KEY="…" npm run backup`.
2. Copy the `.lmsbak` file to the disk (service → **Shell**, or `scp` over Render's SSH), then
   in the Shell: `LMS_BACKUP_KEY="…" npm run restore -- /var/data/<file>.lmsbak /var/data/restored`.
3. Under **Environment**, change both at once, then save and deploy: `LMS_PEPPER` to the old
   site's `PEPPER` value (from `data/properties.json`, or the `LMS_PEPPER` it ran with), and
   `LMS_DATA_DIR` to `/var/data/restored`. Changing only one of them stops the site from starting,
   because the pepper must match the data folder.
4. The starter data stays in `/var/data/lms` untouched in case you need to go back.

The phone apps (see MOBILE.md) use this site's `https://` address as `LMS_SERVER_URL`.

## Deploy with Docker (any Linux server)

The quickest way onto a server, such as a college server, a VPS (DigitalOcean, Hetzner, AWS
Lightsail…) or any host that runs Docker with a permanent disk. `docker-compose.yml` runs the LMS
together with [Caddy](https://caddyserver.com), which gets and renews the HTTPS certificate by
itself. All of section 1 below is already set up for you.

**You need:** a Linux server with [Docker](https://docs.docker.com/engine/install/) (1 GB RAM is
plenty), ports 80 and 443 open, and a domain name whose DNS **A record** points at the server.

```
git clone https://github.com/JacobDavisK/lms.git
cd lms
cp .env.example .env
nano .env                      # set LMS_DOMAIN and LMS_PEPPER (openssl rand -hex 32), email if you have it
docker compose up -d --build
docker compose logs lms        # shows the one-time admin password on the first start
```

Open `https://<LMS_DOMAIN>`, sign in as `admin` with that password and set a new one. The
Android/iOS apps (MOBILE.md) use this address as `LMS_SERVER_URL`.

- **Records** live in the Docker volume `lms-data`, never in the image or in git.
- **The pepper:** keep a copy of `LMS_PEPPER` somewhere safe and never change it. If it's lost or
  mistyped, the LMS refuses to start (instead of every password silently failing). Put the right
  value back in `.env` and run `docker compose up -d`.
- **Updates:** `git pull && docker compose up -d --build`. The site restarts for a few seconds.
- **Backups:** `docker compose exec lms npm run backup` writes an encrypted file into the
  `lms-backups` volume (set `LMS_BACKUP_KEY` in `.env`). Copy them off the server with
  `docker compose cp lms:/backups ./backups`. To back up every night at 2 am, add this to the
  server's crontab: `0 2 * * * cd /path/to/lms && docker compose exec -T lms npm run backup`.
- **Locked out of admin:** `docker compose exec lms npm run reset-admin`.
- **Moving an existing site:** set `LMS_PEPPER` to the old site's `PEPPER` (from
  `data/properties.json`) and start once. Then stop it with `docker compose stop lms`, copy the old
  `data` folder into the volume with `docker compose cp ./data/. lms:/data/`, hand the files to the
  LMS user with `docker compose run --rm -u root lms chown -R node:node /data`, and run
  `docker compose start lms`. Only move real records once the college has approved where they
  will be stored.
- **Question papers as PDF** need a LaTeX engine, which the image doesn't include. Teachers can
  still download the LaTeX project.

Every push to GitHub builds the image and checks that it starts, stores records in the volume, runs
as a non-root user, stops cleanly, and refuses a wrong pepper.

When `NODE_ENV=production`, the LMS prints a `WARNING:` line at start-up for risky settings:
demo mode on, no `LMS_PEPPER`, email/SMS switched off, or an open `HOST` without `TRUST_PROXY`.

## 1. Run it behind HTTPS

Out of the box the server listens on **this computer only** (`127.0.0.1:3000`). Put an HTTPS
reverse proxy in front of it. [Caddy](https://caddyserver.com) gets and renews certificates
automatically:

```
# /etc/caddy/Caddyfile
lms.yourcollege.edu {
    reverse_proxy 127.0.0.1:3000
}
```

Then start the LMS with:

| Variable | Value | Why |
|---|---|---|
| `NODE_ENV` | `production` | Sign-in codes are never printed to the console, and staff codes can't be switched on without email |
| `TRUST_PROXY` | `1` | Real client IPs for the sign-in limits; HTTPS detection turns on HSTS |
| `HOST` | `127.0.0.1` | The default: only the proxy can reach Node. Use `0.0.0.0` only if the proxy is on another machine |
| `LMS_PEPPER` | the `PEPPER` value from `data/properties.json` | Keeps the password pepper out of the data folder. Copy the existing value **exactly**, then remove it from `properties.json`. A different value makes every password stop working |
| `SMTP_HOST`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM` | your mail server | Sign-in codes and alerts. Secrets stay out of `data/` |
| `TWILIO_SID`, `TWILIO_TOKEN`, `TWILIO_FROM` (or `SMS_WEBHOOK_URL`, `SMS_WEBHOOK_TOKEN`) | your SMS provider | Enables the **texted code at first sign-in** |
| `ANTHROPIC_API_KEY` | optional | The AI guide |

**Never set `LMS_DEMO=1` on a real site.** Without it, demo sign-ins can't be switched on and
the `demo.*` accounts can't sign in.

## 2. Accounts

- In **Admin → Settings**, turn on *Require an emailed sign-in code for teachers and admins*.
  Email must be set up first.
- Keep the number of administrators small, and give each person their own account.
- First-time passwords (mobile number / child's college ID) expire after the number of days set
  in Settings (14 by default). With SMS set up, the first sign-in also needs a texted code.

## 3. Back up every night

```
LMS_BACKUP_KEY="a long passphrase you keep somewhere safe" npm run backup
```

This writes an encrypted file to `backups/` and keeps the latest 14; the folder is never
uploaded to GitHub. Copy the backups to another machine or drive. To check one, restore it into
a new folder; restoring never touches the live data:

```
LMS_BACKUP_KEY="…" npm run restore -- backups/lms-data-20260925-0200.lmsbak restored-data
```

Schedule the backup with cron (Linux) or Task Scheduler (Windows) to run every night.

## 4. Keep it checked

`npm run test:security` runs the security regression tests against a throwaway demo copy. On
GitHub they also run on every push (`.github/workflows/security.yml`), along with `npm audit`.
