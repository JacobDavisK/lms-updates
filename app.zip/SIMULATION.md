# Business Simulation Studio

**Create a business → define the market → create the scenario → make decisions → simulate consequences →
compete → analyse performance → learn.**

Business simulations are built into the LMS (sidebar: **Business simulations**). Faculty design simulations
without programming, run them with a class (a course) in teams, and analyse and grade the results. Students run
a company round by round. One engine runs every simulation: a new simulation is data, not code.

## Quick start (demo installation)

Sign in with the **Faculty** tile and open **Business simulations**. The demo has:

- the five demo simulations, published v1.0:
  - **Evolution Motors** (EV market entry, India)
  - **BrewCraft Cafés** (expansion)
  - **NeoVault Bank** (growth vs risk)
  - **FreshLeaf Foods** (pricing war)
  - **CloudNest** (funding and scaling)
- **Evolution Motors — Section A**, a run with three teams. Rounds 1–3 have been played with different
  strategies and round 4 (Government Incentive) is open.
- **BrewCraft Cafés — Pilot**, a completed run with analytics, a debrief and a reflection.

The **Student** tile is in Team Ampere (CEO) and can play round 4 straight away. The **Parent** tile has no
simulations. Demo data: `LMS_DEMO=1 npm run seed:simulation`. It refuses to run on a real database.

## The acceptance workflow

| Who | Steps |
|---|---|
| Faculty | Business simulations → **New simulation** → *Market Entry — Evolution Motors (EV)* → Builder steps: basic information (6 rounds), business environment, customer segments, companies, competitors, decisions, financial model, formulas, scenarios & events, rounds, KPIs, scoring, gameplay & assessment → **Simulation health** → **Preview as student** (plays every round, shows the calculations) → **Publish v1.0** → **Run with a class** (course, random teams or manual) → **Launch** |
| Student | Business simulations → the run → **Overview** (company, round brief, news) → **Market** (segments, competitors, economy) → **Decisions** (sliders, what-if, reasoning) → **Submit** → results arrive when the round runs (notification) → **Results** (score explanation, KPIs, income statement, cash flow, balance sheet) → next round … → **Debrief** (final score, what happened, why, which decisions mattered, strategies, what to do differently, learning points) → **Reflection** |
| Faculty | Run console: **Live** (submissions, run the round, deadlines, announcements) → **Analytics** (team and individual performance, decision patterns, mistakes, KPI trends, rankings, learning outcomes, team debriefs) → **Assessment** (grade reflections, send grades to the gradebook) → **Report** (Excel, CSV, PDF) |

`tests/simulation.test.js` runs this whole workflow through the API on every CI build.

## Architecture

| Layer | Files | Responsibility |
|---|---|---|
| Presentation | `public/js/simulation.js`, `public/js/sim-play.js`, `public/css/simulation.css`, `public/js/charts.js` (multi-line chart) | Faculty dashboard, library, Builder, run console, analytics, report; student game. No business logic. |
| Application | `lib/simulation.js` | Storage, roles and permissions, versions, runs, teams, rounds, deadlines, decisions and approvals, journal, analytics, debrief, assessment, gradebook, reports, audit |
| Domain | `lib/simengine.js`, `lib/simformula.js`, `lib/simtemplates.js` | The simulation engine (pure, deterministic), the safe formula language, templates |
| Data | `data/simulation/simulation.json` (+ LMS gradebook and notifications) | Persistence |
| Integration | `lib/api.js` (`sm*` routes), LMS courses, enrolments, gradebook, notifications | LMS integration |

### The engine (`lib/simengine.js`)

Each round, for every customer segment:

1. **Attractiveness** of every offer (teams and competitors) = exp( price term + quality + brand +
   sustainability + distribution + promotion + custom ). Each term is weighted by that segment's
   sensitivities. Pricing above the segment's purchasing power is penalised.
2. **Category demand** = potential × Σ attractiveness ÷ (Σ attractiveness + outside option). Some customers buy
   nothing when offers are poor.
3. **Choice share** is each offer's attractiveness divided by the total, blended with last round's *sales* share
   by the segment's switching probability (loyalty). Customers lost to a stock-out go to rivals.
4. **Competitors** react to last round's team decisions:
   - *static*: no reaction
   - *follower*: matches price cuts and marketing
   - *aggressive*: undercuts the lowest price
   - *premium*: moves up-market
   - *scripted*: follows faculty-set prices or marketing per round
5. **Operations:**
   - production is limited by capacity and staffing (productivity × employee satisfaction)
   - unit cost includes the inflation index, events, the learning curve, quality and technology
   - sales are capped by inventory plus production
   - make-to-order businesses (services) carry no stock
6. **Finance:**
   - income statement: revenue, COGS, gross profit, operating expenses, EBITDA, depreciation, EBIT, interest,
     tax, net profit
   - cash flow: collections and payments with receivable and payable days, investing, financing
   - balance sheet: cash, receivables, inventory, plant, payables, debt, share capital, retained earnings
   - the balance sheet always balances, and is checked in every test
   - lenders cap debt at a debt-to-equity limit, and interest rises with leverage
   - dividends are paid only from retained earnings
   - running out of cash triggers an emergency loan at a penalty rate
7. **Capabilities:** technology (R&D), quality, brand (marketing, with decay), distribution reach, sustainability,
   employee satisfaction (pay, training, layoffs) and customer satisfaction (quality, value, stock-outs).
8. **KPIs:** about 40 standard metrics, plus faculty formulas.
9. **Score:**
   - each KPI scores 0 at its floor and 100 at its target
   - optionally blended with the team's position in the class (relative share)
   - categories are weighted averages of their KPIs, and the overall score uses the faculty's category weights
   - the final score is the average, the last round, or weighted towards later rounds
   - every score carries a plain-language explanation
10. **Mistakes**, used for decision quality: stock-outs, excess inventory, pricing below cost, emergency loans,
    idle capacity, low employee satisfaction and over-leverage.

**Reproducibility:** demand noise and probability-based events come from a seeded generator, and every run has
its own seed. The same seed and decisions always give the same results, which is tested. Each round's inputs and
outputs are stored with the run.

**Events** have these properties:

- **Trigger:** scheduled rounds, random (a probability, optionally within a window of rounds), or a condition (a
  formula on each team's previous round, applying to that team only).
- **Duration, severity and "only once".**
- **Impacts** on demand, price sensitivity, sustainability sensitivity, unit cost, capacity, fixed costs, salary,
  interest, tax, marketing effectiveness, a buyer subsidy, competitor prices and marketing, productivity and
  holding cost. One-off impacts change brand, satisfaction, morale, quality or cash.

A round's events are drawn and announced to students when the round opens, before they decide, and are exactly
the ones the engine applies.

### Formula language (`lib/simformula.js`)

- **Operators:** numbers, `+ − * / % ^`, comparisons, `&& || !` and `a ? b : c`.
- **Functions:** `min`, `max`, `abs`, `round`, `floor`, `ceil`, `sqrt`, `log`, `log1p`, `exp`, `pow`, `clamp`,
  `if`, `sign` and `avg`.
- **Names:** `metric.revenue`, `state.brand`, `state.custom.battery`, `formula.otherKey`, `value` (the decision)
  and `round`.

It is a tokenizer, parser and tree-walker:

- There is no `eval`, `Function` or property access beyond plain data.
- `__proto__`, `prototype` and `constructor` are blocked.
- Length, depth and node count are limited.
- Results must be finite numbers.
- Validation checks names, finds circular references between formulas, and orders formulas by dependency.

### Extending without code

- **Decisions** bind to standard drivers: price (overall or per segment), production, capacity, marketing, R&D,
  quality, hiring, training, salary, distribution, sustainability, borrowing, repayment, equity, dividend, and
  segment entry.
- **Custom** decisions use a cost formula and effects. Effects apply either *before the market* (demand, unit
  cost, attractiveness) or *after the round* (any company attribute, or a new `custom.<name>` attribute that
  persists). Examples in the templates:
  - battery technology (cumulative investment lowers cost and adds range)
  - credit-risk appetite with collections, where credit-loss events trigger when net risk is high
  - legal and compliance programmes that avoid fines
  - trade promotions
- **Efficiency multipliers** let one decision mean "new outlets × 45,000 cups of capacity".

## Data model

`data/simulation/simulation.json`:

| Entity | Fields (main) |
|---|---|
| `settings` | grants (institution admins, observers), demo flag |
| `sims[]` (Simulation) | id, ownerId, title, status (draft/published/archived), `config`, rev (edit conflicts), `versions[]` (SimulationVersion: v, at, by, note, frozen config), dirty, shared.library, previewRunId, timestamps, deletedAt |
| `config` | basics (incl. learning objectives), market (incl. economy), segments[] (CustomerSegment), companies[] (Company), competitors[] (Competitor), decisions[] (DecisionVariable incl. effects), finance, formulas[], events[] (Event/Scenario incl. modifiers), rounds[] (SimulationRound), kpis[] (KPI), scoring (categories and weights), settings (gameplay, debrief, assessment) |
| `runs[]` (SimulationRun / season) | id, simId, version, frozen config, courseId, ownerId, status (setup/running/paused/completed), preview, seed, mode, `teams[]` (Team: id, name, company, colour, `members[]` = TeamMember uid + role), round, roundOpen, deadline, roundHours, autoRun, observers, announcements, `states{}` (company state per team), competitors, eventHistory, roundEvents, `decisions{team:{round: DecisionSubmission}}` (values, status, approvals, history, rationale), `rounds[]` (round results: events, market, per-team values, metrics, statements = FinancialStatement, KPIs, Score, mistakes, trace), `journal[]` (DecisionJournal), `reflections{}` (Reflection incl. grade), gradeModuleId |
| `log[]` (AuditLog) | at, uid, name, role, action, id, title, extra (also written to the LMS audit log) |

Users, roles, courses, enrolments, grades and notifications are the LMS's own tables. Departments come from
Mentoring.

## API

Every call goes through `POST /rpc` (`api(token, action, payload)`). Roles are checked per route, and object
permissions inside each function.

| Area | Routes |
|---|---|
| Simulations | `smHome smList smTemplates smCreate smGet smSave smValidate smPublish smRestoreVersion smDuplicate smDelete smShare smExport smPreview` |
| Runs | `smRunCreate smRunTeams smRunGet smRound smLaunch smControl` (run, pause, resume, deadline, autorun, undo, complete, observers) `smAnnounce smRunDelete` |
| Playing | `smJoinTeam smSetRoles smDecide smApprove smSubmit smWhatIf smJournal smReflect` |
| Analysis | `smAnalytics smDebrief smAssessment smGradeReflection smPushGrades smReport` |
| Administration | `smSettings smSaveSettings smAudit` |

Errors come back as `{ error }` with a readable message. Lists are bounded, and imports are size-limited.

## Roles

| Role | In this LMS | Can |
|---|---|---|
| Super admin | LMS administrator | Everything; grants; settings; full audit |
| Institution admin | grant (Simulation settings) | See and manage every simulation and run; institution library |
| Faculty / designer | teacher | Create, edit, preview, publish, version, import/export simulations; run them in courses they teach; teams; analytics; assessment |
| Student | student | Play in runs of courses they are enrolled in (own team only; role permissions if switched on) |
| Observer | grant, or added per run | Read-only results, analytics and reports |

## Security

- **Server-side authorisation on every call:**
  - simulation owner, institution admin, or library (published, staff only)
  - runs: course teachers manage, enrolled students play, observers read
  - previews are visible only to their designer
  - denials are audited
- **Students see only their own team's details:**
  - no console and no calculation trace
  - rivals' decisions are never shown
  - other teams stay anonymous in the debrief
  - the leaderboard follows the configured visibility
  - what-if assumes rivals repeat last round, so nobody learns a rival's current plan
- **Input validation:** every config is normalised (known fields only, numbers clamped, strings length-limited),
  decisions are clamped to their ranges, and imports are parsed and normalised.
- **Formulas** are parsed, never executed as code, as described above.
- **Concurrency:** Builder saves carry a revision number, so a stale save is refused. Decisions lock on
  submission. Runs freeze their simulation version.
- **Audit:** create, modify, publish, export, launch, rounds, decisions, re-opened decisions, grades, permissions
  and deletion. Shown per run and site-wide.
- **Other protections:** rate limits on saves, decisions and what-if. Demo accounts cannot change simulation
  settings. The demo seed refuses real data. No secrets are involved, and no external AI is called by this
  module.

## Tests

`npm run test:simulation` runs 176 checks on a throwaway copy of the demo data:

- **Unit tests:**
  - the formula engine, including unsafe-formula rejection, dependency order and cycle detection
  - demand and price sensitivity
  - financial identities (revenue, gross and net profit, cash reconciliation, the balanced balance sheet)
  - shares adding up to 100%
  - supply limits
  - event scheduling and probability (≈20% over 400 seeds), determinism
  - KPI scoring and configurable weights, final-score modes
  - decision clamping, and validation of broken configs
  - all 31 templates valid
- **Integration and end-to-end:** the full faculty → student → faculty workflow above, preview, publishing and
  versions, teams, role-based approvals, what-if (state unchanged), deadlines with auto-run, rollback, replay
  reproducibility, import/export, analytics, assessment, gradebook (8 students graded) and Excel/CSV reports.
- **Security:** cross-teacher and cross-course access, students vs analytics and grades, observers read-only,
  stale saves, unsafe formulas, out-of-range grades, audit entries, and seed refusal.

It runs in CI with the other suites.

## Known limitations

- Single institution (the LMS): "institution admin" is a grant, and departments come from Mentoring.
  Multi-tenant institutions and subscriptions are not in scope.
- Teams see results when the teacher runs the round, or at the deadline. Decision drafts sync through saves, not
  live cursors.
- The engine models one product per company, with per-segment prices. Multi-product portfolios and
  international markets are not modelled yet.
- What-if is an estimate: rivals repeat last round and random demand is excluded.
- Storage is a JSON file, which suits a college. A large multi-campus deployment should move runs to a database.
  The application layer is the only module that touches storage.
- The PDF report uses the browser's print dialog.

## MVP status

Complete:

- authentication and RBAC (LMS)
- faculty and student dashboards
- the Simulation Builder (14 steps)
- 31 templates
- companies, customer segments, competitors (5 behaviours)
- a no-code decision builder with custom formulas
- scenario, random and condition events
- the round engine, financial engine, KPI engine and configurable scoring with explanations
- teams with roles and approvals
- leaderboard (4 visibility levels)
- gameplay with what-if
- faculty analytics, decision journal, post-simulation debrief and reflection
- the assessment engine with gradebook export
- the Evolution Motors demo, plus 4 more demos
- preview, JSON import/export, versioning, the validation engine, audit logs, notifications, deadlines and
  auto-run, reports (Excel/CSV/PDF), observers, and mobile layout

## Phase 2 and 3

AI simulation generation (Generate → Review → Edit → Preview → Publish, using the LMS AI provider layer
`lib/ai.js`). Case-study → simulation conversion (the Content Studio importers can supply the text). LTI 1.3
with OAuth 2.0/OIDC, REST and webhooks for external LMSs. Advanced competitor AI. Multi-product and
international markets. Real-time multiplayer. Marketplace and cross-institution sharing. Voice and immersive
modes. External economic data feeds.
