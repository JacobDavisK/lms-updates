# Mentoring & Student Success

A native LMS module that turns mentoring into a continuous, documented, outcome-oriented process:

**Allocation → Student 360° → Goals → Sessions → Academic monitoring → Support indicators → Interventions → Follow-ups → Outcomes → Analytics**

It reuses the LMS's sign-in and roles, notifications and email queue, calendar, file store, ERP attendance and internal marks, course gradebook and activity data, Excel export, audit log and AI configuration. No new dependencies.

---

## A. What is included

| Area | What it does |
|---|---|
| **Mentor dashboard** | KPIs for total mentees, on track, needs attention, priority intervention, no recent interaction, pending/overdue follow-ups, goals in progress and open concerns. Lists students needing attention, upcoming meetings, overdue follow-ups, new indicators, open concerns and goals. Includes a global mentoring search. |
| **Student 360°** | Identity; a **Student Success Snapshot** with 8 tiles: academic, attendance, engagement, goals, mentoring, concerns, interventions, career. Tabs: Overview (the **Student Success Timeline** plus open items and academic record), Academic (attendance by course with a 12-week trend, internal marks, gradebook, missed deadlines), Sessions, Goals, Concerns, Interventions, Follow-ups, Parents, Career, AI assistant, History (allocation history and anonymous feedback). |
| **My mentees → Add mentees** | A mentor adds students to their own list the same way students are enrolled in a course: search and tick, or add a whole class. Only students with no mentor can be added (moving a student between mentors stays with HODs and coordinators), the maximum applies, and each addition is kept in the allocation history. A mentor can also remove their own mentee with a reason. Administrators can switch this off under Configuration → General. |
| **Allocation** | Seven KPIs. Manual and bulk assign/reassign/unassign with a reason. **Rule-based allocation** filters by department, programme, batch, section, semester and category, then shares students evenly up to the maximum, with a preview first. **Excel/CSV import** has a template and a preview. Shows mentor workload (overloaded/inactive) and a full allocation history; nothing is overwritten. |
| **Sessions** | Schedule, reschedule, cancel, mark missed, record, and decline student requests. Supports one-to-one, group and parent sessions; online (https link) or in person; recurring weekly, fortnightly or monthly (up to 12). **Templates** (Academic / Career / Development, editable). Fields: concern, observation, summary shared with the student, private note, outcome, action plan, follow-up date, attachments and confidentiality level. Sessions appear in the LMS **calendar**. |
| **Goals** | Students and mentors create goals with category, dates, priority, success criteria, progress % and status (Not Started / In Progress / At Risk / Completed / Deferred / Cancelled). Progress history and mentor comments are kept. |
| **Concerns** | A student "Raise a concern" button, and staff can log concerns too. Ten categories and priorities. Status runs Open → Assigned → In Progress → Awaiting Student → Resolved / Closed. The trail can hold shared or internal notes. Students can reply, a follow-up date can be set, and a concern can be turned into an intervention. |
| **Interventions & action plans** | Problem, plan, action items (who does what by when), follow-up date, evidence attachments, and an outcome of Improved / Partially improved / Not improved. |
| **Follow-ups** | Every action item has a target date and/or follow-up date, reminders, a responsible person, status and outcome. The board has Overdue, Today, Tomorrow, This week and Later columns, plus recently completed items. |
| **Early warning** | A configurable rule engine (see I) creates **support indicator** events. Mentors review or dismiss them (a reason is required to dismiss) or plan an action. Priority rules escalate to the HOD. It runs hourly and on demand. |
| **Career & development** | Career goal, industry, role, location, higher education, placement status, entrepreneurship, skills, certifications (with evidence files), internships and projects. Mentors add recommendations (skill gap → activity → target), which students mark done with evidence. |
| **Parents** | The parent's Mentoring page shows their child's mentor, meetings they are invited to, goals (configurable) and notes the mentor chose to share. Mentors log meetings, calls and online interactions. |
| **Student feedback** | Optional feedback after each session: a 1–5 rating, what helped, what else is needed, and whether they want another session. Shown only in aggregate once a minimum number of responses exists. |
| **Analytics & reports** | Three levels: mentor, department (HOD) and institution (coordinator / principal / admin). Filters: cycle, department, programme, batch, section, semester, mentor and date range. Charts cover activity over time, students by support status, sessions by category, concern categories, intervention outcomes, goal completion and feedback. Mentor workload is shown alphabetically, not ranked. **Excel** mentor, department and institutional reports; **CSV** export; a **printable student report** (browser → Save as PDF). |
| **AI assistant** | Five tasks: student summary, meeting preparation, progress since last session, suggested actions and follow-up summary. Built-in summaries work with no external AI. Claude is used only if an administrator allows pseudonymised data to be sent. See the safety notes in H. |
| **Cycles** | Academic-year cycles: plan → start → close → archive. New records are stamped with the active cycle, and archived cycles are read-only. |
| **Configuration & audit** | Everything is institution-configurable (see I). A dedicated mentoring audit log shows who, what, which record and which fields changed. |

## B. Architecture

- **Backend:** `lib/mentoring.js`. It has a `ROUTES` table merged into the single `/rpc` router in `lib/api.js`, the same pattern as Leave and ERP. Every handler checks role, grant and object on the server.
- **Storage:** `data/mentoring/mentoring.json`, following the same pattern as `data/erp/leave.json`. Writes are debounced, atomic (write then rename) and flushed on exit. Covered by `npm run backup`.
- **Academic data:** read, never duplicated.
  - `erp.studentAcademics()` provides attendance and published internal marks.
  - `insights.courseReport()` provides gradebook, completion, missed deadlines and last activity.
  - Results are cached for 10 minutes per student and per course.
- **Frontend:** `public/js/mentoring.js` and `public/css/mentoring.css`, using the existing components and design tokens. Routes live in `public/js/main.js`; navigation in `public/js/shell.js` is role-aware.
- **Hooks added to existing code:**
  - `lms.registerCalendarSource()` puts sessions into the calendar.
  - The `mentoring` file-access context covers attachments.
  - `/me` gains mentoring navigation flags.
  - `erp.studentAcademics()`.
  - `assistant` exports its Claude client.
  - `userimport.readRows()` is shared for imports.
  - `errorState()` now shows a proper *permission denied* state.
- **Notifications:** in-app through `notifyMany`. Email is optional (a Mentoring setting) and goes through the existing messaging queue, only when email is configured.
- **Scheduler:** every 15 minutes it sends session reminders, follow-ups due tomorrow or overdue, and goal deadlines, de-duplicated so each goes once. Every hour it runs the early-warning check.

## C. Data (entities in `mentoring.json`)

| Entity | Main fields |
|---|---|
| `settings` | labels, limits, lists, templates, departments, grants, notifications, parents, feedback, AI, retention, rules |
| `cycles` | name, year, term, start, end, objectives, status (planned / active / closed / archived) |
| `allocations` | studentId, mentorId, cycleId, at, by, reason, active, endedAt, endedBy, endReason, previousMentorId |
| `profiles[studentId]` | `identity` (department, programme, semester, section, category, CGPA, arrears, results) and `career` (goals, skills, certifications, internships, projects, recommendations) |
| `sessions` | ref, studentIds, parentIds, mentorId, type, mode, category, at, duration, location, link, agenda, status, template answers, concern, observation, summary, privateNote, outcome, level, attachments, seriesId, cycleId |
| `goals` | studentId, title, category, description, start, target, priority, criteria, progress, status, comments, updates |
| `concerns` | ref, studentId, mentorId, category, description, priority, status, level, trail (shared / internal), resolution, followUp, attachments |
| `interventions` | ref, studentId, problem, plan, source (indicator / concern / session), status, outcome, outcomeNote, followUp, level, attachments |
| `actions` | studentId, title, detail, owner, due, followUp, status, outcome, parentType/parentId (session / intervention / concern / interaction), level |
| `interactions` | parent/guardian log: parentIds, mode, topic, purpose, discussion, sharedSummary, action, followUp, outcome, shared, level |
| `feedback` | sessionId, studentId, mentorId, rating, useful, helpful, needs, another |
| `events` | support indicators: studentId, ruleId, severity, value, text, status (open / reviewed / dismissed / cleared), note |
| `ai` | generated assistant outputs (kind, mode, text, who, when) |
| `log` | mentoring audit trail: who, role, action, entity, entityId, studentId, changed fields, timestamp |

Students, staff and parents stay in the existing `Users` and `Guardians` collections. Attachments stay in `Files`, with context `mentoring`.

## D. Pages (`#/…`)

| Route | Who |
|---|---|
| `/mentoring` | Everyone. Staff get the dashboard, students get *My mentoring*, parents get their child's mentoring. |
| `/mentoring/mentees`, `/mentoring/student/:id`, `/mentoring/report/:id` | Staff with access to the student |
| `/mentoring/sessions`, `/followups`, `/concerns`, `/goals`, `/interventions`, `/indicators`, `/search` | Staff; students also get sessions, goals and concerns |
| `/mentoring/allocation` | Coordinators, administrators, HODs |
| `/mentoring/analytics` | Staff; the department and institution levels need the grant |
| `/mentoring/settings` (tabs: general, rules, lists, departments & roles, cycles, notifications & privacy, audit) | Administrators |
| `/mentoring/development` | Students |

## E. API (`POST /rpc {fn:'api', args:[token, action, payload]}`)

- **Read:** `mtHome`, `mtOptions`, `mtMentees`, `mtStudent`, `mtSearch`, `mtPeople`, `mtSessions`, `mtGoals`, `mtConcerns`, `mtInterventions`, `mtActions`, `mtFollowups`, `mtEvents`, `mtAnalytics`, `mtCycles`, `mtConfig`, `mtAudit`, `mtAllocHome`, `mtAllocTemplate`.
- **Write:**
  - `mtProfileSave`, `mtCareerSave`
  - `mtAllocAssign`, `mtAllocUnassign`, `mtAllocAuto`, `mtAllocImport`
  - `mtMenteeSearch`, `mtMenteeAdd`, `mtMenteeRemove`
  - `mtCycleSave`
  - `mtSessionSave`, `mtSessionRecord`, `mtSessionStatus`, `mtSessionRequest`
  - `mtGoalSave`, `mtGoalComment`
  - `mtConcernSubmit`, `mtConcernAct`
  - `mtInterventionSave`, `mtInterventionOutcome`
  - `mtActionSave`, `mtActionUpdate`
  - `mtGuardianLog`, `mtFeedback`, `mtEventAct`, `mtRunCheck`
  - `mtReport`, `mtAi`, `mtSaveConfig`

## F. Permissions

The LMS has four account roles: admin, teacher, student and parent. Mentoring roles are **grants** set under Mentoring configuration → Departments & roles:

| Role | Scope | Can |
|---|---|---|
| Administrator (super admin) | every student | Everything, including configuration, rules, grants and the audit log. Level-3 records only with the Restricted grant. |
| Coordinator (grant) | every student | Allocation, cycles, reports, monitoring interventions (levels 1–2) |
| Principal / Director (grant) | institution | Institution and department dashboards and summary export. **No individual records.** |
| HOD (grant, per department) | students of their departments | Allocation within the department, monitoring, department dashboard and report (levels 1–2) |
| Mentor (any faculty with mentees) | **only their current mentees** | Sessions, notes, goals, interventions, follow-ups, parent log, AI assistant, mentor report |
| Student | self | Mentor, schedule, goals, own action items, requests and concerns, development profile, Level-1 records, feedback |
| Parent | linked children | Mentor, meetings they are invited to, notes explicitly shared, goals (optional). **Never** concerns, interventions or mentor notes. |

**Confidentiality levels** apply to every record:
- **1 — Student visible:** the student sees it.
- **2 — Mentor only:** mentor, HOD and coordinators/admins.
- **3 — Restricted:** the author, plus staff holding the Restricted grant who already have the student in scope. Every view is logged.

`privateNote` fields are never sent to students or parents at any level.

## G. Testing

`npm run test:mentoring` runs **128 checks** against a throwaway seeded copy of the demo data, and also runs in GitHub Actions. They cover:
- configuration and grants
- allocation: limits, HOD scope, reassignment history, CSV import, rules
- object-level access for mentor, other mentor, HOD, coordinator, principal, unrelated faculty, other student and parent
- session confidentiality and parent visibility
- Level-3 restriction and view logging
- concerns: shared vs internal trail, student reply, cross-student access
- goals, action items, interventions and the parent log
- file attachment access and file-type refusal
- early-warning rules: missing data never triggers, priority, escalation
- analytics scope, reports, CSV, search scope and the calendar
- cycles and archive read-only
- the AI assistant and its access control
- the audit log, including that private text is not copied into it
- rate limiting

`npm run test:security` (32 checks) still passes.

Browser-checked as faculty, student, parent, HOD and administrator on desktop and at 375 px phone width (no horizontal scroll), with no console errors.

## H. Security review

| Check | Result |
|---|---|
| Server-side authorization | Every route has role checks. Every record read or write re-checks the student scope (`staffCan`) and record level (`staffSees`). Front-end hiding is cosmetic only. |
| Cross-student / cross-mentor / privilege escalation | Tested. Students' `studentId` parameters are ignored. Asking for `scope=all` never widens a mentor's view. Grants can only be changed by administrators. Demo accounts cannot change configuration. |
| Confidential data to students/parents | Separate output shapes for students and parents. Private notes, Level-2/3 records, internal concern notes, interventions and concerns (for parents) are never serialised to them. Tested by searching the raw JSON. |
| Input validation | Lengths, enums, dates and timestamps are bounded. Meeting links must be `https://`. IDs are validated. Configuration lists are sanitised. |
| XSS | All output is escaped (`esc()`); markdown is rendered only through the existing safe subset. CSV exports neutralise formula injection. |
| Files | Uses the existing upload path (10 MB, per-role quota, rate limit). Attach only files you uploaded yourself. Extension allow-list: PDF, images, Office, CSV and text. Downloads are served as attachments with `nosniff`. Access is decided per record and audited. **No malware scanner is available on this server**; add one at the reverse proxy if required. |
| Rate limiting | Global API limit, plus limits on concerns (10/h), mentoring requests (6/h), imports, reports and AI (30/h). |
| Audit | The mentoring log records assignments, sessions, concerns, goals, interventions, restricted views, exports, AI use and configuration. It stores changed field names, not the confidential text. Entries are mirrored to the append-only `data/audit.log`. |
| AI | Off by default for external use. When on, it sends pseudonymised facts only: no name, ID, contact or Level-3 records. The system prompt forbids diagnosis, sensitive inferences and labelling. Output is labelled advisory, stored and audited. |
| Sessions / CSRF | Uses the existing bearer-token `/rpc` (no cookies, so no CSRF surface), idle and 12-hour caps, CSP with nonce. |
| Known limits | JSON storage keeps data in memory and is suited to one institution with thousands of students, not multi-campus scale. The CGPA and results feed is manual because the LMS has no results system. There is no virus scanning. |

## I. Configuration (Site administration → Mentoring settings)

- **General:**
  - maximum mentees per mentor (default 30)
  - minimum mentoring frequency (30 days)
  - default follow-up period (14 days)
  - how many "needs attention" indicators make a priority intervention (3)
  - status wording (neutral by default)
  - retention period (records are never deleted automatically)
- **Support indicator rules:**
  - Each rule has a name, metric, operator, threshold, time period, severity (reminder / needs attention / priority), enabled flag and HOD escalation.
  - Metrics: overall attendance, attendance in the period, attendance fall vs the previous period, internal assessment average, gradebook average, missed deadlines, days since LMS activity, days since last session, concerns in the period, open concerns, overdue action items, goals at risk.
  - Ten starting rules are provided (e.g. attendance < 75%, internal < 50%, no session for 30 days = reminder, two or more overdue items = priority).
  - Missing data never triggers a rule.
- **Lists & templates:** session types, discussion categories, goal and concern categories, session templates and their prompts.
- **Departments & roles:** departments (name, code, classes) and their HODs, coordinators, principal/director, Restricted-record access.
- **Cycles:** create, start, close, archive or reopen.
- **Notifications & privacy:** email copies, HOD escalation, reminder timing, what parents see, the student feedback switch and anonymity threshold, and permission to use external AI.

**First steps on the real site:**
1. Add departments with their classes and HODs.
2. Grant coordinators (and the principal).
3. Start a cycle.
4. Allocate mentors from **Mentoring → Allocation**, using Import or Rule-based allocation for a whole batch.

## J. Future enhancements (intentionally not in this release)

- Google / Microsoft calendar sync. The LMS has no calendar integration to reuse; sessions appear in the LMS calendar only.
- Push notifications. The LMS has in-app, email and SMS but no push channel.
- A university results / CGPA feed. It is entered manually today.
- Malware scanning of attachments.
- Background generation of very large institutional reports. They are generated on request today, and are fine for thousands of students.
- Predictive analytics beyond configurable rules. This was deliberately not built, because the system flags indicators and does not predict or diagnose.
- Database migration (SQL) for multi-campus scale.

## Demo data

`npm run seed:mentoring` (with `LMS_DEMO=1`, after `npm run seed`) installs a fictional cohort. It refuses to run on a database with real students. The cohort is:
- 5 departments and 10 mentors (`mdemo.f01`–`f10`), with f01, f03, f05, f07 and f09 as HODs
- a principal (`mdemo.principal`)
- 100 students (`mdemo.s001`–`s100`) in "(demo)" classes, with six weeks of attendance
- about 340 sessions, goals, concerns, interventions, follow-ups, feedback and career profiles, and support indicators

The demo tiles connect to it: the Faculty tile mentors the demo students and the Parent tile sees shared notes. Passwords: staff `Teach2026demo`, students `Learn2026demo`. Everything is marked as demo data. The demo launchers run it on first start.
