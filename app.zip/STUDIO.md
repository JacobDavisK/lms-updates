# Academic Content Studio — "Create once. Teach everywhere."

A Canva-style design and teaching studio inside the LMS. Faculty turn a topic, a syllabus unit or their own
notes into linked learning objects (lecture slides, notes, infographics, cases, quizzes, discussions,
assignments, flashcards …), map them to course outcomes and Bloom levels, review them, and publish them into
a course in one step. Students create presentations, posters, infographics, concept maps and portfolios, and
submit them to assignments.

Sidebar: **Content Studio** (faculty, administrators and students — not parents).

## What is in this release (MVP)

| Area | Status |
|---|---|
| Dashboard: Copilot prompt, start from syllabus, import, format tiles, recent work, live sessions, review queue | Done |
| Canvas editor: templates, shapes, text, images (upload), charts, tables, icons, diagrams, brand kit, layers; drag, resize, snapping guides, multi-select, group, align, z-order, zoom, page strip, undo/redo, keyboard shortcuts, autosave with conflict detection | Done |
| Document editor (Markdown with live preview, outline, toolbar), quiz editor (MCQ, multiple response, true/false, short answer; Bloom, difficulty, CO and marks per question), flashcard editor | Done |
| Templates: lecture, seminar, project, startup pitch, infographic, concept map, mind map, timeline, flowchart, business model canvas, certificate, worksheet, digital portfolio, 7 research poster types; institutional templates | Done |
| Academic Copilot: generate, improve (simplify, expand, academic, student-friendly, structure, grammar, examples, applications, summarise), transform between formats, content packs from one request, prompt library (13 disciplines) | Done |
| Outcome mapping: course CO/PO/PSO and units per course, Bloom and difficulty, suggestions with reasons | Done |
| Content families: every object made from the same source shares a family; derived objects are flagged when the source's text changes | Done |
| Workflow: draft → review (peer, HOD) → approved → published → archived; comments with @mentions and suggestions; version history, compare, restore, copy any version | Done |
| Sharing: people (view/edit), department, university library (approved by an academic administrator) | Done |
| Publishing to a course: Studio activity (viewer), native LMS quiz (graded, in the gradebook), assignment, forum | Done |
| Students: own designs, submit a version to an assignment, formative AI feedback (never a grade) | Done |
| Live activities: MCQ / poll / word cloud during class, teacher console, reveal and pacing | Done |
| Exports: PDF (print), PNG/JPG (per page or all), PowerPoint (.pptx), Word (.docx), CSV (quiz, flashcards), JSON | Done |
| Imports: PDF (text), Word, PowerPoint, Excel/CSV, text/Markdown, public web pages | Done |
| Accessibility checker (contrast, alt text, small text, headings, dense slides, link text) | Done |
| Analytics: me / department / institution — creation, publishing, views, live responses, AI use and cost, outcome coverage, adoption; per-item learning insights | Done |
| AI provider abstraction: Anthropic, OpenAI, Google, local (Ollama-compatible); offline built-in generator when none is configured | Done |
| Business simulation engine, real-time co-editing cursors, animation timeline, video/audio editing | Phase 2 |

## Demo workflow

On a demo installation (`start-demo.cmd`, or `LMS_DEMO=1 npm run seed:studio` after the other demo seeds), sign
in with the **Faculty** tile (Priya Sharma) and open **Content Studio**:

1. **Start from syllabus** → *Legal Aspects of Business* (B.Com Corporate Secretaryship) → *Unit I: Indian
   Contract Act* → *Essentials of a valid contract*.
2. Request: "Create a 15-slide interactive lecture on essentials of a valid contract."
3. The Copilot creates the master lecture notes and, from them, a 15-slide lecture (objectives, content, quick
   checks, summary, think–pair–share), an infographic, a case, 10 MCQs, discussion questions, an assignment and
   flashcards — one content family.
4. Each object is mapped to CO1, PO1, PO2 and Bloom *Understand* / *Apply* (Details panel → *Suggest mappings*).
5. Review (tick *I have reviewed and verified this content*), then **Publish to course**. The quiz becomes a
   graded LMS quiz; the assignment and forum are native activities.
6. Students see the content in the course; the teacher can run a live check and see learning insights.

The demo seed already did all of this once, so every page has content. It also leaves a colleague's
infographic waiting for HOD review, a concept map in the university library and a student poster.

## Files

New

| File | Purpose |
|---|---|
| `lib/studio.js` | Storage, permissions, workflow, versions, sharing, publishing, live activities, analytics, settings, routes (`st*`) |
| `lib/studiogen.js` | Content types, templates, layouts, built-in generator, AI prompts and validation, Bloom/outcome suggestions, accessibility, rubric analysis |
| `lib/ai.js` | Provider layer: Anthropic / OpenAI / Google / local; retries, timeouts, rate limits, logging, token and cost tracking, PII redaction, prompt fencing |
| `lib/ooxml.js` | PowerPoint and Word writers (no dependencies) |
| `lib/studioimport.js` | Importers (PDF, DOCX, PPTX, XLSX/CSV, text, URL with SSRF protection) |
| `public/js/studio.js` | Dashboard, library, Copilot flows, viewer, present mode, print/PNG/JPG export, live, analytics, outcomes, settings |
| `public/js/studio-editor.js` | Canvas, document, quiz and flashcard editors |
| `public/css/studio.css` | Studio styles (tokens, dark mode, mobile) |
| `scripts/seed-studio.js` | Demo data (demo installations only) |
| `tests/studio.test.js` | 109 functional and security checks |

Changed: `lib/api.js` (routes, `me.studio`, Studio bound to course tools), `lib/lms.js` (`studio` activity type,
`addStudioModule`, file access hook), `lib/assistant.js` / `lib/erp.js` / `lib/userimport.js` (exports),
`public/index.html`, `public/js/main.js` (routes), `public/js/shell.js` (navigation), `public/js/activities.js`
(Studio activity), `public/js/icons.js`, `installer/setup.js`, `start-demo.cmd`, `scripts/build-release.js`,
`package.json`, `.github/workflows/security.yml`.

## Data

`data/studio/studio.json` (created on first use; backed up with the rest of `data/`):

- `settings` — provider, policies, limits, quiz defaults, grants (academic administrators, reviewers), brand kit
- `courses` — per course: programme, semester, department, CO/PO/PSO, units and topics
- `items` — content: kind, format (`canvas` pages and elements / `doc` Markdown / `quiz` questions / `cards`),
  metadata (course, unit, topic, outcomes, Bloom, difficulty, tags, folder), sharing, comments, workflow,
  family/source links, AI provenance, publications, submissions
- `versions` — snapshots per item (named versions kept; the latest 25 autosaves kept)
- `templates`, `prompts`, `live`, `events` (views, checks, AI calls — capped), `log`, `favorites`

The LMS database gains a module type `studio` (field `studioId`). Uploaded images use the existing file store
with `context: 'studio'`. No other schema changes.

## API

All through `POST /rpc` (`api(token, action, payload)`), checked on the server per role and per item.

Content: `stHome stList stCreate stGet stView stCheck stSave stMeta stFavorite stDuplicate stDelete stArchive`
Versions: `stVersions stCompare stRestore` · Collaboration: `stComment stShare stPeople stLibrary`
Workflow: `stSubmitReview stReview stAiReviewed stSourceOk` · Publishing: `stPublish stSubmit stAssignments`
Curriculum: `stCourses stSaveOutcomes` · AI: `stGenerate stPack stTransform stImprove stSuggest stFeedback`
Files: `stImport stExport stAsset stAssets` · Live: `stLiveStart stLiveState stLiveAnswer stLiveControl stLiveList`
Insight: `stAnalytics stLearning stAudit` · Administration: `stTemplates stSaveTemplate stPrompts stSavePrompt stBrand stSaveBrand stSettings stSaveSettings`

## AI providers (environment variables)

Keys stay on the server and are never sent to browsers. With none set, the Studio uses its built-in generator:
source-based content when you paste or import material, otherwise a structured outline with
`[bracketed]` parts to complete.

| Variable | Use |
|---|---|
| `ANTHROPIC_API_KEY` (or the key under Site administration → Settings → AI guide) | Anthropic Claude |
| `STUDIO_ANTHROPIC_MODEL` | Optional model override for the Studio |
| `OPENAI_API_KEY`, `OPENAI_MODEL`, `OPENAI_BASE_URL` | OpenAI or an OpenAI-compatible endpoint |
| `GEMINI_API_KEY`, `GEMINI_MODEL` | Google Gemini |
| `LOCAL_AI_URL`, `LOCAL_AI_MODEL` | A local model server (e.g. Ollama at `http://127.0.0.1:11434`) |

Choose the provider under **Content Studio → Settings** (automatic picks the first connected one). Requests
are retried on rate limits and server errors, rate-limited per person, logged (provider, model, purpose, tokens,
estimated cost — never the text) and shown in Settings and Analytics.

No new npm dependencies.

## Security

- **Server-side permissions on every call.** Items are visible to the owner, people it is shared with, the
  department (if shared), faculty (approved library items), reviewers at the current stage, and course members
  only through a *Studio activity* publication. Edit rights are separate. Denials are audited.
- **Students never receive answer keys, speaker notes, comments or workflow** of faculty content. A quiz
  published as a graded LMS quiz does not open its Studio copy to students; self-check answers are marked one
  question at a time on the server. Versions, exports, copies and AI use of faculty items need more than course
  access.
- **AI safety:** source text is wrapped in a random, unguessable fence with an instruction never to follow
  instructions inside it; AI output is validated against a schema and sanitised like user input; emails, phone
  numbers and student IDs are removed before text goes to an external provider (configurable); per-person daily
  limits; AI content is marked and must be confirmed as reviewed before it can be published; AI feedback is
  advisory and never a grade.
- **Uploads:** images only (PNG, JPEG, GIF, WebP) checked by magic bytes; SVG refused; only your own uploads or
  the brand logo can be placed; files are served only to people who can see an item that uses them.
- **Imports:** size limits; URL import is https-only, resolves DNS and refuses private, loopback, link-local,
  carrier-grade NAT and metadata addresses, follows no redirects, and accepts only HTML/text.
- **Canvas content is sanitised** (element types, numbers, colours, fonts, lengths); text is always escaped.
- Concurrent edits use revision numbers: a stale save is refused, never silently overwritten.
- Demo seed refuses to run without `LMS_DEMO=1` or on a database with real students. Studio settings and brand
  changes are blocked for demo tile accounts.

## Tests

`npm run test:studio` — 109 checks on a throwaway copy of the demo data (no external AI calls): role access,
privilege escalation, IDOR across departments and students, sharing, conflicts and versions, malicious uploads
(script-as-PNG, SVG, claiming others' files, CSS injection), SSRF (private, metadata, loopback, http, file),
imports, export well-formedness, workflow and approval, publishing to native quiz/assignment, redaction for
students, answer-key protection, submissions, AI feedback limits, live activities, library approval, audit and
seed safety. Runs in CI with the other suites.

## Known limitations

- Collaboration is near-real-time (autosave every few seconds, remote changes loaded every 15 s, conflicts
  refused), not simultaneous cursors.
- PDF import extracts text only (no layout or images); scanned PDFs need OCR first.
- PowerPoint export draws charts as shapes and uses standard fonts; PDF export uses the browser's print dialog.
- The built-in generator restructures and quizzes your own material; it does not add facts. Without source
  material or an AI provider it produces outlines.
- Learning insights compare students who opened a resource with those who did not: an association, not proof
  that the resource caused the difference (shown only with at least five students in each group).

## Phase 2 recommendations

Business simulation engine (decision rounds, market model, team dashboards); real-time co-editing with presence
and cursors; slide animations and transitions; audio narration and video export; LTI/SCORM packages; question
bank sharing across departments with item statistics; rubric-linked peer review; AI image generation with
licence tracking; OCR for scanned PDFs; offline editing; deeper analytics (item difficulty, outcome attainment
from Studio quizzes).
