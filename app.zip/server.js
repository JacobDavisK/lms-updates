'use strict';
const path = require('path');
const fs = require('fs');
const nodeCrypto = require('crypto');
const express = require('express');
const store = require('./lib/store');
const lms = require('./lib/api');
const demo = require('./lib/demo');

const PORT = process.env.PORT || 3000;
// Listen on this computer only unless HOST says otherwise (e.g. HOST=0.0.0.0 behind a reverse proxy,
// or to share on the local network) — audit C1 / Info 1.
const HOST = process.env.HOST || '127.0.0.1';
const PUBLIC = path.join(__dirname, 'public');
const INDEX_TEMPLATE = fs.readFileSync(path.join(PUBLIC, 'index.html'), 'utf8');
const VERSION = require('./package.json').version;
let lastActivity = Date.now(); // last real use of the site (background polling doesn't count) — updates wait for a quiet moment

lms.bootstrap();
require('./lib/messaging').start(); // email/SMS delivery queue
require('./lib/alerts').start();    // due-date reminders & weekly progress reports
require('./lib/proctor').start();   // deletes proctoring recordings after the retention period
// Save buffered usage analytics on Ctrl+C / service stop ('exit' handles normal shutdown).
['SIGINT', 'SIGTERM', 'SIGHUP'].forEach((sig) => process.on(sig, () => process.exit(0))); // SIGHUP: the console window was closed

const app = express();
app.disable('x-powered-by');
// Behind an HTTPS reverse proxy set TRUST_PROXY=1 so req.ip / req.secure come from X-Forwarded-* (audit M4 / Info 1).
if (process.env.TRUST_PROXY) app.set('trust proxy', Number(process.env.TRUST_PROXY) || process.env.TRUST_PROXY);
// Security headers (audit L2). The two inline scripts in index.html carry a per-response nonce.
const CDN = 'https://cdn.jsdelivr.net', MODELS = 'https://storage.googleapis.com'; // proctoring AI models only
function csp(nonce) {
  return [
    "default-src 'self'",
    "script-src 'self' 'nonce-" + nonce + "' " + CDN + " 'wasm-unsafe-eval'",
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob:",
    "media-src 'self' blob:",
    "font-src 'self' data:",
    "connect-src 'self' " + CDN + ' ' + MODELS,
    "worker-src 'self' blob:",
    'frame-src https://www.youtube-nocookie.com https://player.vimeo.com',
    "frame-ancestors 'none'", "base-uri 'none'", "form-action 'self'", "object-src 'none'"
  ].join('; ');
}
app.use((req, res, next) => {
  res.locals.nonce = nodeCrypto.randomBytes(16).toString('base64');
  res.set('Content-Security-Policy', csp(res.locals.nonce));
  res.set('X-Frame-Options', 'DENY');
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('Referrer-Policy', 'same-origin');
  res.set('Permissions-Policy', 'camera=(self), microphone=(self), display-capture=(self), fullscreen=(self), geolocation=(), payment=(), usb=()');
  res.set('Cross-Origin-Opener-Policy', 'same-origin');
  if (req.secure) res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});
app.use(express.json({ limit: '16mb' }));
app.use('/css', express.static(path.join(PUBLIC, 'css')));
app.use('/js', express.static(path.join(PUBLIC, 'js')));
// KaTeX (equation typesetting for the question-paper editor), served locally so it works offline.
app.use('/vendor/katex', express.static(path.join(__dirname, 'node_modules', 'katex', 'dist'), { maxAge: '7d' }));

app.get('/', (req, res) => {
  const siteName = store.getSetting('siteName', 'Jacob Davis LMS');
  const html = INDEX_TEMPLATE
    .replace('{{SITE_NAME}}', escapeHtml(siteName))
    .replace('{{SITE_JSON}}', JSON.stringify(siteName).replace(/</g, '\\u003c'))
    .replace('{{DEMO_JSON}}', JSON.stringify(demo.publicList()).replace(/</g, '\\u003c'))
    .split('{{NONCE}}').join(res.locals.nonce);
  res.set('Cache-Control', 'no-store'); // the demo sign-ins appear / disappear with the admin setting
  res.type('html').send(html);
});

// Privacy policy (the Play Store and App Store link to it): public, no sign-in needed.
const PRIVACY_TEMPLATE = fs.readFileSync(path.join(PUBLIC, 'privacy.html'), 'utf8');
app.get('/privacy', (req, res) => {
  const siteName = store.getSetting('siteName', 'Jacob Davis LMS');
  res.type('html').send(PRIVACY_TEMPLATE.split('{{SITE_NAME}}').join(escapeHtml(siteName)).replace('{{UPDATED}}', '2 October 2026'));
});

/** Single RPC endpoint, same shape as google.script.run: {fn, args}. */
app.post('/rpc', (req, res) => {
  res.set('Cache-Control', 'no-store'); // API responses carry personal data (audit L2)
  const { fn, args } = req.body || {};
  const a = Array.isArray(args) ? args : [];
  if (!(fn === 'api' && a[1] === 'notifications')) lastActivity = Date.now();
  // The client's address is added here, never taken from the request body (per-client sign-in limits — audit M4).
  const handlers = { login: () => lms.login(a[0], a[1], req.ip), verifyOtp: () => lms.verifyOtp(a[0], a[1], req.ip), api: () => lms.api(a[0], a[1], a[2]) };
  const handler = Object.prototype.hasOwnProperty.call(handlers, fn) ? handlers[fn] : null;
  if (!handler) { res.status(400).json({ error: 'Unknown function.' }); return; }
  try {
    const out = handler();
    if (out && typeof out.then === 'function') {
      out.then((result) => res.json({ result }), (e) => res.json({ error: (e && e.message) || 'Something went wrong.' }));
    } else {
      res.json({ result: out });
    }
  } catch (e) {
    res.json({ error: e.message || 'Something went wrong.' });
  }
});

/** Which version is running, and for how long nobody has used it. The installed launcher (installer/launcher/run.js)
 *  reads this to apply updates only when the site is idle. */
app.get('/version', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ app: 'jd-lms', version: VERSION, idleSec: Math.floor((Date.now() - lastActivity) / 1000) });
});
/** Clean stop for the installed launcher (so buffered data is written before an update or when the user stops the LMS).
 *  Only exists when the launcher started us with a one-time token, and only answers this computer. */
app.post('/_ctl/shutdown', (req, res) => {
  const want = process.env.LMS_CTL_TOKEN || '';
  const got = String(req.get('x-ctl-token') || '');
  const loopback = ['127.0.0.1', '::1', '::ffff:127.0.0.1'].indexOf(req.socket.remoteAddress) >= 0;
  if (!want || !loopback || got.length !== want.length || !nodeCrypto.timingSafeEqual(Buffer.from(got), Buffer.from(want))) { res.status(404).json({ error: 'Not found.' }); return; }
  res.json({ ok: true });
  setTimeout(() => process.exit(0), 250);
});

/** Authenticated file download. The session token travels in the
 *  Authorization header, never in the URL. Always served as an attachment. */
app.get('/file/:id', (req, res) => {
  const auth = String(req.get('authorization') || '');
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  const f = lms.fileForDownload(token, req.params.id);
  if (!f) { res.status(404).json({ error: 'File not found.' }); return; }
  const ascii = f.name.replace(/[^\x20-\x7e]/g, '_').replace(/["\\]/g, '_');
  res.set('Content-Type', 'application/octet-stream');
  res.set('Content-Disposition', 'attachment; filename="' + ascii + '"; filename*=UTF-8\'\'' + encodeURIComponent(f.name));
  res.set('Cache-Control', 'private, no-store');
  res.sendFile(f.path);
});

/** Proctoring snapshots for staff (same header-token rule; shown inline as images). */
app.get('/proctor-img/:a/:b', (req, res) => {
  const auth = String(req.get('authorization') || '');
  const img = lms.proctorImage(auth.startsWith('Bearer ') ? auth.slice(7) : '', req.params.a, req.params.b);
  if (!img) { res.status(404).json({ error: 'Image not found.' }); return; }
  res.set('Content-Type', img.mime);
  res.set('Cache-Control', 'private, max-age=3600');
  res.sendFile(img.path);
});

function escapeHtml(v) {
  return String(v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

app.listen(PORT, HOST, () => {
  console.log('Jacob Davis LMS running at http://' + (HOST === '0.0.0.0' ? 'localhost' : HOST) + ':' + PORT + (HOST === '127.0.0.1' ? ' (this computer only — set HOST=0.0.0.0 to share)' : ''));
});
