'use strict';
const COURSE_COLORS = ['indigo', 'violet', 'fuchsia', 'rose', 'orange', 'amber', 'emerald', 'teal', 'cyan', 'sky', 'slate'];
const DAY = 864e5;

/* =====================================================================
   SHARED CARDS
   ===================================================================== */
function courseCard(c, opts) {
  opts = opts || {};
  const href = opts.href === undefined ? '#/course/' + c.id : opts.href;
  const foot = opts.foot !== undefined ? opts.foot
    : c.progress ? '<div class="ccard-progress">' + progressBar(c.progress.percent) + '<span><b>' + c.progress.percent + '%</b></span></div>'
      : c.students != null ? '<div class="ccard-progress">' + icon('users', 'i-sm') + '<span>' + plural(c.students, 'student') + '</span></div>' : '';
  const tag = href ? 'a' : 'div';
  const teachers = c.teachers || [];
  return '<' + tag + ' class="card ccard cc-' + esc(c.color) + '"' + (href ? ' href="' + href + '"' : '') + '>' +
    '<div class="ccard-banner banner-bg"><span class="chip">' + esc(c.shortname) + '</span>' +
    (!c.visible ? '<span class="chip">' + icon('eyeOff', 'i-sm') + ' Hidden</span>' : '') +
    '<span class="glyph">' + icon('cap') + '</span></div>' +
    '<div class="ccard-body"><div class="ccard-cat">' + esc(c.category || 'Course') + '</div><div class="ccard-title">' + esc(c.fullname) + '</div>' +
    (teachers.length ? '<div class="ccard-teachers"><span class="avatars">' + teachers.slice(0, 3).map((n) => avatar(n, 'sm')).join('') + '</span>' +
      esc(teachers.slice(0, 2).join(', ')) + (teachers.length > 2 ? ' +' + (teachers.length - 2) : '') + '</div>' : '') +
    '<div class="ccard-foot">' + foot + '</div></div></' + tag + '>';
}
function courseState(c, now) {
  if (c.startDate && c.startDate > now) return 'future';
  if (c.endDate && c.endDate < now) return 'past';
  return 'inprogress';
}
let fieldSeq = 0;
function field(label, control, hint) {
  const id = 'fld' + (++fieldSeq);
  let tagged = false;
  control = control.replace(/<(input|textarea|select)(?![^>]*\bid=)(?![^>]*type="(?:hidden|radio|checkbox|file)")/, (m) => { tagged = true; return m + ' id="' + id + '"'; });
  return '<div class="field"><label class="label"' + (tagged ? ' for="' + id + '"' : '') + '>' + label + (hint ? '<span class="hint">' + hint + '</span>' : '') + '</label>' + control + '</div>';
}
function check(name, label, checked, hint) {
  return '<label class="check"><input type="checkbox" name="' + name + '"' + (checked ? ' checked' : '') + '><span>' + label + (hint ? '<span class="hint">' + hint + '</span>' : '') + '</span></label>';
}
function durationText(ms) {
  ms = Math.abs(ms);
  const d = Math.floor(ms / DAY), h = Math.floor(ms % DAY / 36e5), m = Math.floor(ms % 36e5 / 6e4);
  if (d) return plural(d, 'day') + (h ? ' ' + plural(h, 'hour') : '');
  if (h) return plural(h, 'hour') + (m ? ' ' + plural(m, 'min', 'mins') : '');
  return plural(Math.max(1, m), 'min', 'mins');
}

/* =====================================================================
   DASHBOARD
   ===================================================================== */
function eventRow(e) {
  const d = new Date(e.at);
  const href = e.href ? '#' + e.href : e.moduleId ? '#/mod/' + e.moduleId : '#/course/' + e.courseId;
  return '<a class="event-row cc-' + esc(e.color) + '" href="' + href + '"><span class="event-date"><small>' + esc(d.toLocaleDateString(undefined, { month: 'short' })) + '</small><b>' + d.getDate() + '</b></span>' +
    '<span style="min-width:0"><b class="small" style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(e.title) + '</b>' +
    '<span class="xs muted">' + esc(e.label) + ' · ' + esc(fmtTime(e.at)) + ' · ' + esc(e.course) + '</span></span></a>';
}
function newsItem(a) {
  return '<div class="news"><div class="news-meta">' + badge(a.course, a.courseId ? 'primary' : 'info', a.courseId ? '' : 'megaphone') + '<span>' + esc(rel(a.createdAt)) + '</span></div>' +
    '<h4>' + esc(a.title) + '</h4><div class="prose">' + md(a.body) + '</div><div class="xs muted" style="margin-top:.35rem">' + esc(a.author) + '</div></div>';
}

async function viewDashboard() {
  if (S.me.role === 'parent') { go('/family'); return null; }
  const [d, ins, att] = await Promise.all([call('dashboard'), call('myInsights').catch((e) => { if (isExpired(e)) throw e; return null; }),
    S.me.role === 'student' ? call('attSummary').catch(() => null) : null]);
  updateUnread(d.unread);
  const me = S.me;
  const student = me.role === 'student';
  const st = d.stats;
  const h = new Date().getHours();
  const greet = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  const line = student
    ? (st.overdue ? 'You have ' + plural(st.overdue, 'overdue activity', 'overdue activities') + '. Let’s get back on track.'
      : st.dueSoon ? plural(st.dueSoon, 'activity is', 'activities are') + ' due in the next 7 days.' : 'Nothing urgent right now — a great time to get ahead.')
    : (st.toGrade ? plural(st.toGrade, 'submission is', 'submissions are') + ' waiting for your feedback.' : 'Everything is graded. Nice work.');
  const greeting = '<header class="greet"><div class="greet-date">' + esc(new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' })) + '</div>' +
    '<h1>' + greet + ', ' + esc(firstName(me.name)) + '</h1><p>' + esc(line) + '</p></header>';
  const courses = d.courses;
  const shelf = '<section class="dash-section"><div class="dash-h"><h2>' + (student ? 'Your courses' : 'Courses you teach') + '</h2><span class="spacer"></span><a href="#/courses">View all</a></div>' +
    (courses.length ? '<div class="shelf">' + courses.map((c) => courseCard(c)).join('') + '</div>'
      : emptyState('book', student ? 'No courses yet' : 'Create your first course',
        student ? 'Browse the catalogue to enrol, or ask your teacher to add you.' : 'Courses hold your lessons, activities, quizzes and gradebook.',
        student ? '<a class="btn btn-primary" href="#/catalog">Browse courses</a>' : '<button class="btn btn-primary" data-act="newCourse">' + icon('plus') + 'Create course</button>', false));
  const left = '<section class="dash-section"><div class="dash-h"><h2>Upcoming</h2><span class="spacer"></span><a href="#/calendar">Calendar</a></div>' + upcomingHtml(d.timeline, student) + '</section>' +
    '<section class="dash-section"><div class="dash-h"><h2>Recent activity</h2></div>' + recentHtml(d.recent, student) + '</section>';
  const right = (student ? attendancePanel(att) + progressPanel(d, ins) : teachingPanel(d, st) + dashboardInsights(ins)) +
    (d.announcements.length ? '<div class="panel"><h3>Announcements</h3>' + d.announcements.slice(0, 3).map(newsItem).join('') + '</div>' : '');
  return {
    title: 'Dashboard',
    html: greeting + (student ? focusLearn(d.resume) : focusTeach(d.resume, d.timeline)) +
      '<div class="dash"><div>' + left + '</div><aside>' + right + '</aside></div>' + shelf
  };
}

/* ---------- the one primary action ---------- */
function focusLearn(r) {
  if (!r) {
    return '<a class="focus" href="#/catalog"><div><div class="focus-eyebrow">Get started</div><h2>Find your first course</h2>' +
      '<div class="focus-sub">Browse the catalogue to enrol, or ask your teacher to add you.</div></div><div class="focus-cta"><span class="btn btn-primary btn-lg">Browse courses ' + icon('arrowRight') + '</span></div></a>';
  }
  const p = r.progress;
  const bar = p ? '<div class="focus-progress">' + progressBar(p.percent) + '<span class="tnum">' + p.percent + '% complete</span></div>' : '';
  if (!r.next) {
    return '<a class="focus cc-' + esc(r.color) + '" href="#/course/' + esc(r.courseId) + '"><div><div class="focus-eyebrow"><span class="dotc"></span>' + esc(r.shortname) + '</div>' +
      '<h2>You’re all caught up</h2><div class="focus-sub">' + esc(r.course) + '</div>' + bar + '</div>' +
      '<div class="focus-cta"><span class="btn btn-primary btn-lg">Open course ' + icon('arrowRight') + '</span></div></a>';
  }
  const n = r.next, meta = MOD[n.type] || MOD.page;
  return '<a class="focus cc-' + esc(r.color) + '" href="#/mod/' + esc(n.id) + '" aria-label="Continue learning: ' + esc(n.title) + '">' +
    '<div><div class="focus-eyebrow"><span class="dotc"></span>Continue learning · ' + esc(r.shortname) + '</div>' +
    '<h2>' + esc(n.title) + '</h2><div class="focus-sub"><span>' + esc(meta.label) + '</span><span class="dot-sep"></span><span>' + esc(r.course) + '</span>' +
    (n.section ? '<span class="dot-sep"></span><span>' + esc(n.section) + '</span>' : '') +
    (n.dueAt ? '<span class="dot-sep"></span><span>Due ' + esc(rel(n.dueAt)) + '</span>' : '') + '</div>' + bar + '</div>' +
    '<div class="focus-cta"><span class="btn btn-primary btn-lg">' + icon('play') + (r.lastAccess ? 'Resume' : 'Start') + '</span>' +
    '<span class="xs muted">Step ' + n.index + ' of ' + n.total + '</span></div></a>';
}
function focusTeach(r, timeline) {
  if (!r) {
    return '<div class="focus"><div><div class="focus-eyebrow">Get started</div><h2>Create your first course</h2><div class="focus-sub">Add lessons, assignments and quizzes, then enrol your students.</div></div>' +
      '<div class="focus-cta"><button class="btn btn-primary btn-lg" data-act="newCourse">' + icon('plus') + 'Create course</button></div></div>';
  }
  const grading = timeline.find((i) => i.kind === 'grading' && i.courseId === r.courseId) || timeline.find((i) => i.kind === 'grading');
  const href = grading ? '#/mod/' + grading.moduleId : '#/course/' + r.courseId;
  return '<a class="focus cc-' + esc(r.color) + '" href="' + href + '"><div><div class="focus-eyebrow"><span class="dotc"></span>Continue teaching · ' + esc(r.shortname) + '</div>' +
    '<h2>' + esc(grading ? grading.title : r.course) + '</h2><div class="focus-sub">' +
    (grading ? '<span>' + plural(grading.count, 'submission') + ' waiting for feedback</span><span class="dot-sep"></span><span>' + esc(grading.course) + '</span>'
      : '<span>' + plural(r.students, 'student') + '</span><span class="dot-sep"></span><span>Everything is graded</span>') + '</div></div>' +
    '<div class="focus-cta"><span class="btn btn-primary btn-lg">' + (grading ? icon('assignment') + 'Start grading' : 'Open course ' + icon('arrowRight')) + '</span></div></a>';
}

/* ---------- upcoming: a timeline grouped by urgency ---------- */
function upcomingHtml(items, student) {
  if (!items.length) return emptyState('checkCircle', 'Nothing due', 'You’re all caught up for the next few weeks.', '', false);
  const t0 = new Date(); t0.setHours(0, 0, 0, 0);
  const s = t0.getTime();
  const groups = [
    ['Needs grading', (i) => i.kind === 'grading'],
    ['Overdue', (i) => i.kind !== 'grading' && i.overdue],
    ['Today', (i) => i.kind !== 'grading' && !i.overdue && i.at < s + DAY],
    ['This week', (i) => i.kind !== 'grading' && !i.overdue && i.at >= s + DAY && i.at < s + 8 * DAY],
    ['Later', (i) => i.kind !== 'grading' && !i.overdue && i.at >= s + 8 * DAY]
  ];
  const row = (i) => {
    const what = i.kind === 'grading' ? plural(i.count, 'submission') + ' to grade' : i.kind === 'quiz' ? 'Quiz closes' : 'Assignment due';
    const when = i.kind === 'grading' ? '<b>' + i.count + '</b>to grade' : '<b>' + esc(fmtTime(i.at)) + '</b>' + esc(new Date(i.at).toLocaleDateString(undefined, { day: 'numeric', month: 'short' }));
    return '<li class="up-item cc-' + esc(i.color || 'indigo') + (i.overdue ? ' overdue' : '') + '"><span class="up-when">' + when + '</span><span class="up-dot" aria-hidden="true"></span>' +
      '<a class="up-main" href="#/mod/' + esc(i.moduleId) + '"><span class="up-text"><b>' + esc(i.title) + '</b><span>' + esc(i.course) + ' · ' + esc(what) +
      (i.kind !== 'grading' ? ' · ' + esc(rel(i.at)) : '') + '</span></span>' + icon('right', 'i-sm') + '</a></li>';
  };
  return '<ol class="upcoming">' + groups.map(([label, test]) => {
    const list = items.filter(test).slice(0, 6);
    return list.length ? '<li class="up-group">' + label + '</li>' + list.map(row).join('') : '';
  }).join('') + '</ol>';
}

/* ---------- recent activity ---------- */
function recentHtml(items, student) {
  if (!items || !items.length) return '<p class="small muted">' + (student ? 'Your submissions, quiz results and completed lessons will appear here.' : 'Your students’ submissions and quiz attempts will appear here.') + '</p>';
  const text = (i) => {
    const t = '<a href="#/mod/' + esc(i.moduleId) + '"><b>' + esc(i.title) + '</b></a>';
    const by = i.who ? '<b>' + esc(i.who) + '</b> ' : 'You ';
    if (i.kind === 'submitted') return by + 'submitted ' + t;
    if (i.kind === 'graded') return t + ' was graded · <b>' + i.grade + (i.max ? ' / ' + i.max : '') + '</b>';
    if (i.kind === 'quiz') return by + 'finished ' + t + ' · <b>' + i.score + ' / ' + i.max + '</b>';
    return by + 'completed ' + t;
  };
  const ico = { submitted: 'send', graded: 'award', quiz: 'quiz', completed: 'check' };
  return '<ul class="feedlist">' + items.map((i) => '<li><span class="fl-ico' + (i.kind === 'graded' || i.kind === 'completed' ? ' good' : '') + '">' + icon(ico[i.kind] || 'activity') + '</span>' +
    '<span class="fl-main">' + text(i) + '<br><span class="xs muted">' + esc(i.course) + '</span></span><time datetime="' + new Date(i.at).toISOString() + '">' + esc(rel(i.at)) + '</time></li>').join('') + '</ul>';
}

/* ---------- attendance (learners) ---------- */
function attendancePanel(a) {
  if (!a || a.none) return '';
  const tone = a.overall == null ? '' : a.below ? 'bad' : a.overall < a.threshold + 5 ? 'warn' : 'ok';
  const word = { present: 'Present all day', partial: 'Partly present', absent: 'Absent' };
  return '<a class="panel att-panel" href="#/attendance"><h3>Attendance</h3><div class="prog-hero">' + (a.overall == null ? '<span class="erp-noring">—</span>' : ring(a.overall, 76)) +
    '<div><div class="big">' + a.workingDays + '<small> days</small></div><div class="xs muted">working days · ' + a.presentDays + ' present' + (a.absentDays ? ' · ' + a.absentDays + ' absent' : '') + '</div></div></div>' +
    (a.recent.length ? '<div class="att-mini" role="img" aria-label="Last ' + a.recent.length + ' working days">' + a.recent.map((x) => '<i class="' + x.status + '" title="' + esc(new Date(x.date + 'T00:00').toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' }) + ': ' + word[x.status] + ' (' + x.attended + '/' + x.held + ')') + '"></i>').join('') + '</div>' : '') +
    '<div class="att-panel-foot ' + tone + '">' + (a.overall == null ? 'No classes recorded yet.' : a.below ? 'Below ' + a.threshold + '% — attend the next ' + plural(a.need, 'period') + ' to recover.' : a.canMiss ? 'On track · ' + plural(a.canMiss, 'period') + ' to spare above ' + a.threshold + '%' : 'On track — don’t miss the next class.') + '</div></a>';
}
/* ---------- progress (learners) ---------- */
function progressPanel(d, ins) {
  const st = d.stats;
  const withP = d.courses.filter((c) => c.progress);
  let html = '<div class="panel"><h3>Your progress</h3><div class="prog-hero">' + ring(st.progress || 0, 76) +
    '<div><div class="big">' + (st.average != null ? Math.round(st.average) + '<small>%</small>' : '—') + '</div><div class="xs muted">average grade</div></div></div>' +
    (withP.length ? '<div class="prog-list">' + withP.map((c) => '<a class="prog-row cc-' + esc(c.color) + '" href="#/course/' + esc(c.id) + '"><span>' + esc(c.fullname) + '</span><span>' +
      c.progress.done + '/' + c.progress.total + '</span>' + progressBar(c.progress.percent) + '</a>').join('') + '</div>' : '<p class="small muted">Progress appears once your courses have activities.</p>') + '</div>';
  if (ins && ins.series && ins.series.length) {
    const max = Math.max(...ins.series.map((x) => x.minutes));
    const lvl = (m) => (!m ? '' : m < Math.max(10, max * .34) ? 'l1' : m < Math.max(30, max * .67) ? 'l2' : 'l3');
    const streak = (() => { let n = 0; for (let i = ins.series.length - 1; i >= 0 && ins.series[i].minutes > 0; i--) n++; return n; })();
    html += '<div class="panel"><h3>Study rhythm</h3><div class="row" style="justify-content:space-between;align-items:baseline"><span class="small"><b>' + esc(hoursFmt(ins.week)) + '</b> <span class="muted">this week</span></span>' +
      '<span class="xs muted">' + (streak ? plural(streak, 'day') + ' in a row' : 'Start a streak today') + '</span></div>' +
      '<div class="streak" role="img" aria-label="Study time over the last 14 days">' + ins.series.map((x, i) => '<i class="' + lvl(x.minutes) + (i === ins.series.length - 1 ? ' today' : '') + '" title="' + esc(longDay(x.day) + ': ' + hoursFmt(x.minutes)) + '"></i>').join('') + '</div>' +
      '<div class="streak-legend"><span>2 weeks ago</span><span>Today</span></div></div>';
  }
  return html;
}
/* ---------- at a glance (teachers) ---------- */
function teachingPanel(d, st) {
  const row = (label, v, href) => '<a class="prog-row" href="' + href + '" style="grid-template-columns:1fr auto"><span>' + label + '</span><span class="strong" style="color:var(--foreground)">' + v + '</span></a>';
  return '<div class="panel"><h3>At a glance</h3><div class="prog-list">' + row('Submissions to grade', st.toGrade, '#/grades') + row('Students', st.students, '#/insights') +
    row('Courses', st.courses, '#/courses') + row('Activities', st.activities, '#/courses') + '</div></div>';
}

/* =====================================================================
   MY COURSES & CATALOGUE
   ===================================================================== */
async function viewMyCourses(params) {
  const list = await call('myCourses');
  const staff = S.me.role !== 'student';
  const f = params.get('f') || 'all';
  const now = Date.now();
  const shown = list.filter((c) => f === 'all' || courseState(c, now) === f);
  const tabs = [['all', 'All'], ['inprogress', 'In progress'], ['future', 'Future'], ['past', 'Past']];
  return {
    title: 'My courses',
    html: pageHead('My courses', {
      sub: plural(list.length, 'course') + (staff ? ' you teach or are enrolled in' : ' you are enrolled in'),
      actions: (staff ? '<button class="btn btn-primary" data-act="newCourse">' + icon('plus') + 'Create course</button>' : '') +
        '<a class="btn" href="#/catalog">' + icon('compass') + 'Course catalogue</a>'
    }) +
      '<div class="row-wrap" style="margin-bottom:1.25rem"><div class="pills">' + tabs.map(([k, l]) => '<a class="pill' + (f === k ? ' active' : '') + '" href="#/courses?f=' + k + '">' + l + '</a>').join('') + '</div>' +
      '<div class="spacer"></div><div class="search-box" style="width:min(280px,100%)">' + icon('search') + '<input type="search" placeholder="Filter by name" data-input="filterCards" data-delay="60" aria-label="Filter courses"></div></div>' +
      (shown.length
        ? '<div class="course-grid" id="cardGrid">' + shown.map((c) => '<div class="cwrap" data-text="' + esc((c.fullname + ' ' + c.shortname + ' ' + c.category).toLowerCase()) + '">' + courseCard(c) + '</div>').join('') + '</div>'
        : emptyState('book', 'No courses here', f === 'all' ? (staff ? 'Create a course to get started.' : 'Enrol from the catalogue, or ask your teacher to add you.') : 'No courses match this filter.',
          f === 'all' ? (staff ? '<button class="btn btn-primary" data-act="newCourse">' + icon('plus') + 'Create course</button>' : '<a class="btn btn-primary" href="#/catalog">Browse courses</a>') : ''))
  };
}
INPUTS.filterCards = (el) => {
  const q = el.value.trim().toLowerCase();
  $$('#cardGrid > [data-text]').forEach((x) => x.classList.toggle('hidden', !!q && x.dataset.text.indexOf(q) < 0));
};

async function viewCatalog() {
  const list = await call('catalog');
  const cards = list.map((c) => {
    let foot;
    if (c.enrolled) foot = badge('Enrolled', 'success', 'check');
    else if (c.canEnrol) foot = '<button class="btn btn-sm btn-primary" data-act="enrolMe" data-id="' + esc(c.id) + '" data-key="' + (c.needsKey ? '1' : '') + '" data-name="' + esc(c.fullname) + '">' + icon(c.needsKey ? 'key' : 'userPlus') + 'Enrol me</button>';
    else if (c.canView) foot = badge('You can manage this course', 'primary', 'settings');
    else foot = '<span class="xs muted">' + icon('lock', 'i-sm') + ' Enrolment by your teacher</span>';
    const summary = c.summary ? '<p class="small muted" style="margin:-.3rem 0 .8rem;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">' + esc(c.summary.replace(/[#*_`>]/g, '')) + '</p>' : '';
    const card = courseCard(c, { href: c.canView ? '#/course/' + c.id : '', foot: summary + foot });
    return '<div class="cwrap" data-text="' + esc((c.fullname + ' ' + c.shortname + ' ' + c.category + ' ' + c.summary).toLowerCase()) + '">' + card + '</div>';
  });
  return {
    title: 'Course catalogue',
    html: pageHead('Course catalogue', { sub: 'Browse every course available on ' + esc(SITE) + '.' }) +
      '<div class="search-box" style="max-width:420px;margin-bottom:1.25rem">' + icon('search') + '<input type="search" placeholder="Search the catalogue" data-input="filterCards" data-delay="60" aria-label="Search the catalogue"></div>' +
      (list.length ? '<div class="course-grid" id="cardGrid">' + cards.join('') + '</div>' : emptyState('compass', 'The catalogue is empty', 'No courses have been published yet.'))
  };
}
ACT.enrolMe = (d, btn) => {
  if (d.key) {
    formModal('Enrol in ' + d.name, 'This course needs an enrolment key. Your teacher will give it to you.', 'enrolKey',
      '<input type="hidden" name="id" value="' + esc(d.id) + '">' + field('Enrolment key', '<input type="text" name="key" maxlength="50" autocomplete="off" autofocus>'), 'Enrol me', 'narrow');
    return;
  }
  busy(btn, async () => { await call('selfEnrol', { courseId: d.id }); toast('You are enrolled. Welcome!'); go('/course/' + d.id); });
};
FORMS.enrolKey = (f, btn) => busy(btn, async () => {
  await call('selfEnrol', { courseId: f.elements.id.value, key: f.elements.key.value });
  closeModal(); toast('You are enrolled. Welcome!'); go('/course/' + f.elements.id.value);
});

/* =====================================================================
   CALENDAR
   ===================================================================== */
async function viewCalendar(params) {
  const now = new Date();
  let y = now.getFullYear(), mo = now.getMonth();
  const m = /^(\d{4})-(\d{2})$/.exec(params.get('m') || '');
  if (m) { y = Number(m[1]); mo = Math.min(11, Math.max(0, Number(m[2]) - 1)); }
  const first = new Date(y, mo, 1);
  const lead = (first.getDay() + 6) % 7; // weeks start on Monday
  const days = new Date(y, mo + 1, 0).getDate();
  const cellsN = Math.ceil((lead + days) / 7) * 7;
  const start = new Date(y, mo, 1 - lead);
  const end = new Date(y, mo, 1 - lead + cellsN);
  const events = await call('calendar', { from: start.getTime(), to: end.getTime() });
  const byDay = {};
  events.forEach((e) => { const k = new Date(e.at).toDateString(); (byDay[k] = byDay[k] || []).push(e); });
  const key = (d) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
  const prev = new Date(y, mo - 1, 1), next = new Date(y, mo + 1, 1);
  const chip = (e) => '<a class="cal-ev cc-' + esc(e.color) + '" href="' + (e.href ? '#' + esc(e.href) : e.moduleId ? '#/mod/' + esc(e.moduleId) : '#/course/' + esc(e.courseId)) + '" title="' +
    esc(e.label + ': ' + e.title + ' (' + e.course + ') ' + fmtTime(e.at)) + '">' + esc(fmtTime(e.at) + ' ' + e.title) + '</a>';
  let cells = '';
  for (let i = 0; i < cellsN; i++) {
    const d = new Date(start.getFullYear(), start.getMonth(), start.getDate() + i);
    const evs = byDay[d.toDateString()] || [];
    cells += '<div class="cal-day' + (d.getMonth() !== mo ? ' out' : '') + (d.toDateString() === now.toDateString() ? ' today' : '') + '">' +
      '<span class="dnum">' + d.getDate() + '</span>' + evs.slice(0, 3).map(chip).join('') +
      (evs.length > 3 ? '<span class="cal-more">+' + (evs.length - 3) + ' more</span>' : '') + '</div>';
  }
  const dows = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((x) => '<div class="cal-dow">' + x + '</div>').join('');
  const upcoming = events.filter((e) => e.at >= Date.now());
  return {
    title: 'Calendar',
    html: pageHead('Calendar', { sub: 'Due dates, quiz windows and course dates from all your courses.' }) +
      '<div class="split"><div class="card"><div class="cal-head"><h2>' + esc(first.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })) + '</h2>' +
      '<div class="spacer"></div><a class="btn btn-sm" href="#/calendar?m=' + key(now) + '">Today</a>' +
      '<a class="btn-icon" href="#/calendar?m=' + key(prev) + '" aria-label="Previous month">' + icon('left') + '</a>' +
      '<a class="btn-icon" href="#/calendar?m=' + key(next) + '" aria-label="Next month">' + icon('right') + '</a></div>' +
      '<div class="cal-grid">' + dows + cells + '</div></div>' +
      '<div><div class="card"><div class="card-head"><span class="i-tile sm tone-amber">' + icon('clock') + '</span><h2>Coming up this view</h2></div>' +
      (upcoming.length ? '<div style="padding:.35rem 0">' + upcoming.slice(0, 12).map(eventRow).join('') + '</div>' : '<div class="card-body small muted">No upcoming events in this month.</div>') +
      '</div><div class="card card-pad small muted" style="line-height:1.9">' +
      '<b style="color:var(--text)">Event types</b><br>' + icon('assignment', 'i-sm') + ' Assignment due dates<br>' + icon('quiz', 'i-sm') + ' Quiz opening and closing times<br>' + icon('cap', 'i-sm') + ' Course start and end dates<br>' + icon('compass', 'i-sm') + ' Mentoring sessions</div></div></div>'
  };
}

/* =====================================================================
   GRADES OVERVIEW
   ===================================================================== */
async function viewGradesOverview() {
  const rows = await call('gradesOverview');
  const learning = rows.filter((r) => r.role === 'student');
  const teaching = rows.filter((r) => r.role !== 'student');
  let html = pageHead('Grades', { sub: 'Your results across every course. Open a course to see item-by-item detail.' });
  if (!rows.length) html += emptyState('chart', 'No grades yet', 'Grades appear here once you are enrolled in a course with graded activities.');
  if (learning.length) {
    html += '<div class="card"><div class="card-head"><span class="i-tile sm tone-green">' + icon('award') + '</span><h2>Courses I am taking</h2></div><div class="table-wrap"><table class="table"><thead><tr><th>Course</th><th class="num">Graded items</th><th class="num">Course total</th><th></th></tr></thead><tbody>' +
      learning.map((r) => '<tr><td><a class="strong" href="#/course/' + esc(r.courseId) + '/grades">' + esc(r.fullname) + '</a><div class="xs muted">' + esc(r.shortname) + '</div></td><td class="num">' + r.items + '</td>' +
        '<td class="num">' + (r.total ? '<span class="grade-pill ' + gradeClass(r.total.percent) + '">' + r.total.percent + '%</span><div class="xs muted">' + r.total.score + ' / ' + r.total.max + '</div>' : '<span class="muted">—</span>') + '</td>' +
        '<td class="actions"><a class="btn btn-sm btn-ghost" href="#/course/' + esc(r.courseId) + '/grades">Details ' + icon('right', 'i-sm') + '</a></td></tr>').join('') +
      '</tbody></table></div></div>';
  }
  if (teaching.length) {
    html += '<div class="card"><div class="card-head"><span class="i-tile sm tone-indigo">' + icon('chart') + '</span><h2>Courses I teach</h2></div><div class="table-wrap"><table class="table"><thead><tr><th>Course</th><th class="num">Students</th><th class="num">Graded items</th><th class="num">Class average</th><th></th></tr></thead><tbody>' +
      teaching.map((r) => '<tr><td><a class="strong" href="#/course/' + esc(r.courseId) + '/grades">' + esc(r.fullname) + '</a><div class="xs muted">' + esc(r.shortname) + '</div></td><td class="num">' + r.students + '</td><td class="num">' + r.items + '</td>' +
        '<td class="num">' + (r.average != null ? '<span class="grade-pill ' + gradeClass(r.average) + '">' + r.average + '%</span>' : '<span class="muted">—</span>') + '</td>' +
        '<td class="actions"><a class="btn btn-sm btn-soft" href="#/course/' + esc(r.courseId) + '/grades">' + icon('grid', 'i-sm') + 'Gradebook</a></td></tr>').join('') +
      '</tbody></table></div></div>';
  }
  return { title: 'Grades', html };
}

/* =====================================================================
   NOTIFICATIONS, PROFILE, SEARCH
   ===================================================================== */
async function viewNotifications() {
  const r = await call('notifications');
  updateUnread(r.unread);
  return {
    title: 'Notifications',
    html: pageHead('Notifications', { sub: r.unread ? plural(r.unread, 'unread notification') : 'You are up to date.', actions: r.unread ? '<button class="btn" data-act="readAll">' + icon('check') + 'Mark all as read</button>' : '' }) +
      (r.items.length ? '<div class="card" style="overflow:hidden">' + r.items.map(notifItem).join('') + '</div>' : emptyState('inbox', 'No notifications yet', 'You will be notified about grades, announcements, enrolments and forum replies.'))
  };
}

const ALERT_CATS = [
  ['tests', 'Tests', 'New tests, tests opening, tests closing soon'],
  ['assignments', 'Assignments', 'New assignments, due-date reminders, overdue work, teacher reminders'],
  ['scores', 'Scores', 'Graded assignments and test results'],
  ['progress', 'Progress reports', 'Weekly progress report and reports sent by teachers']
];
function alertsCard(a, parent) {
  const sw = (ch, cat) => '<label class="switch" style="justify-content:center"><input type="checkbox" name="' + ch + '.' + cat + '"' + (a.prefs[ch][cat] ? ' checked' : '') + '><span class="track"></span><span class="sr">' + ch + ' ' + cat + '</span></label>';
  const off = [!a.emailReady ? 'email' : '', !a.smsReady ? 'SMS' : ''].filter(Boolean);
  return '<div class="card"><div class="card-head"><span class="i-tile sm tone-amber">' + icon('bell') + '</span><div><h2>Alerts & contact</h2>' +
    '<div class="xs muted">' + (parent ? 'Get alerts about your children’s tests, assignments, scores and progress.' : 'Choose how we tell you about tests, assignments, scores and progress.') + '</div></div></div>' +
    '<div class="card-body"><form data-form="myAlerts" novalidate>' +
    (off.length ? notice('Your school hasn’t switched on ' + off.join(' or ') + ' alerts yet. Your choices will apply once they do. In-app notifications always work.', '', 'info') : '') +
    '<div class="form-grid">' +
    field('Email', '<input type="email" name="email" maxlength="200" value="' + esc(a.email) + '"' + (a.canEditEmail ? '' : ' disabled') + '>', a.canEditEmail ? '' : 'Ask an administrator to change it.') +
    field('Mobile number', '<input type="tel" name="phone" maxlength="20" value="' + esc(a.phone) + '" placeholder="' + esc(a.countryCode) + ' 98765 43210">', (S.me.role === 'parent' ? 'This is also how you sign in — use it in place of a username. ' : '') + 'For SMS alerts. Numbers without a code use ' + esc(a.countryCode) + '.') + '</div>' +
    '<div class="table-wrap" style="border:1px solid var(--border);border-radius:12px;margin-bottom:1rem"><table class="table"><thead><tr><th>Alert</th><th style="text-align:center">Email</th><th style="text-align:center">SMS</th></tr></thead><tbody>' +
    ALERT_CATS.map(([k, l, d]) => '<tr><td><b class="small">' + l + '</b><div class="xs muted">' + d + '</div></td><td style="text-align:center">' + sw('email', k) + '</td><td style="text-align:center">' + sw('sms', k) + '</td></tr>').join('') +
    '</tbody></table></div><div class="row"><span class="xs muted">SMS messages are short summaries; emails include full details and a link.</span><div class="spacer"></div><button class="btn btn-primary" type="submit">Save alert settings</button></div></form></div></div>';
}
FORMS.myAlerts = (f, btn) => busy(btn, async () => {
  const prefs = { email: {}, sms: {} };
  ALERT_CATS.forEach(([k]) => { prefs.email[k] = f.elements['email.' + k].checked; prefs.sms[k] = f.elements['sms.' + k].checked; });
  await call('saveMyAlerts', { email: f.elements.email.disabled ? undefined : f.elements.email.value, phone: f.elements.phone.value, prefs });
  toast('Alert settings saved.');
  await refresh();
});

async function viewProfile() {
  const [r, alertCfg] = await Promise.all([call('profile'), call('myAlerts')]);
  const me = r.me;
  const st = r.stats;
  const parent = me.role === 'parent';
  return {
    title: 'Profile',
    html: '<section class="course-hero banner-bg cc-indigo" style="padding-bottom:28px"><div class="course-hero-top"><div class="row" style="gap:1.2rem;align-items:center">' + avatar(me.name, 'xl') +
      '<div><span class="chip">' + esc(me.role) + '</span><h1 style="margin:.4rem 0 .2rem">' + esc(me.name) + '</h1><div class="meta"><span>@' + esc(me.username) + '</span>' +
      (me.batch ? '<span>' + icon('users', 'i-sm') + ' ' + esc(me.batch) + '</span>' : '') + (me.email ? '<span>' + icon('mail', 'i-sm') + ' ' + esc(me.email) + '</span>' : '') + '</div></div></div></div></section>' +
      (parent ? '' : '<div class="stats">' + statCard('book', 'indigo', r.courses.length, 'Courses') + statCard('assignment', 'pink', st.submissions, 'Assignments submitted') +
      statCard('quiz', 'violet', st.attempts, 'Quiz attempts') + statCard('forum', 'green', st.posts, 'Forum posts') + '</div>') +
      '<div class="split"><div class="stack">' + alertsCard(alertCfg, parent) +
      (parent ? '<a class="card card-pad row" href="#/family" style="text-decoration:none;color:var(--text)"><span class="i-tile tone-indigo">' + icon('users') + '</span><div><b>My family</b><div class="small muted">See your children’s grades, progress and deadlines.</div></div><div class="spacer"></div>' + icon('right') + '</a>'
        : '<div><div class="section-title"><h2>My courses</h2></div>' +
      (r.courses.length ? '<div class="course-grid">' + r.courses.map((c) => courseCard(c)).join('') + '</div>' : emptyState('book', 'No courses yet', 'Courses you join or teach appear here.')) + '</div>') + '</div>' +
      '<div><div class="card"><div class="card-head"><span class="i-tile sm tone-indigo">' + icon('shield') + '</span><h2>Account & security</h2></div>' +
      '<table class="kv"><tr><th>Member since</th><td>' + esc(fmtDate(me.createdAt)) + '</td></tr><tr><th>Last sign-in</th><td>' + esc(fmt(me.lastLogin)) + '</td></tr></table>' +
      '<div class="card-foot"><button class="btn btn-block" data-act="chpw">' + icon('key') + 'Change password</button></div></div>' +
      '<div class="card card-pad"><h3>Appearance</h3><p class="small muted">Choose light or dark mode. Saved on this device.</p>' +
      '<label class="switch"><input type="checkbox" data-change="theme"' + (theme() === 'dark' ? ' checked' : '') + '><span class="track"></span>Dark mode</label></div></div></div>'
  };
}

async function viewSearch(params) {
  const q = (params.get('q') || '').trim();
  const box = $('#globalSearch'); if (box) box.value = q;
  const r = await call('search', { q });
  const acts = r.activities.map((a) => '<a class="disc-row tone-' + MOD[a.type].tone + '" href="#/mod/' + esc(a.id) + '">' + modTile(a.type, 'sm') +
    '<div class="dr-main"><div class="dr-title">' + esc(a.title) + '</div><div class="dr-meta">' + esc(MOD[a.type].label) + ' · ' + esc(a.course) + '</div></div>' + icon('right') + '</a>').join('');
  return {
    title: 'Search',
    html: pageHead('Search results', { sub: 'Results for “' + esc(q) + '”' }) +
      (!r.courses.length && !r.activities.length ? emptyState('search', 'No results', 'Try a different word, a course short name, or an activity title.') : '') +
      (r.courses.length ? '<div class="section-title" style="margin-top:0"><h2>Courses</h2>' + badge(String(r.courses.length)) + '</div><div class="course-grid">' +
        r.courses.map((c) => courseCard(c, { href: c.canView ? '#/course/' + c.id : '', foot: c.enrolled ? badge('Enrolled', 'success') : c.canEnrol ? '<a class="btn btn-sm btn-soft" href="#/catalog">Enrol from the catalogue</a>' : '' })).join('') + '</div>' : '') +
      (r.activities.length ? '<div class="section-title"><h2>Activities & resources</h2>' + badge(String(r.activities.length)) + '</div><div class="card" style="overflow:hidden">' + acts + '</div>' : '')
  };
}
