'use strict';
/* =====================================================================
   ONLINE PROCTORING — student side
   /assessment              proctored exams, face enrolment, my sessions
   /assessment/check        system check & AI diagnostics (anyone)
   /assessment/checkin/:id  guided check-in → starts the exam with monitoring
   The in-exam monitor (PM) runs next to the quiz engine in quiz.js.
   ===================================================================== */
const SENS = {
  low: { yaw: 38, pitch: 32, gaze: 0.72, noFace: 8000, away: 8000, multi: 3000, voice: 5000, obj: 0.62, dark: 25, cool: 30000 },
  medium: { yaw: 30, pitch: 26, gaze: 0.62, noFace: 5000, away: 5000, multi: 2000, voice: 3500, obj: 0.5, dark: 30, cool: 20000 },
  high: { yaw: 24, pitch: 21, gaze: 0.52, noFace: 3000, away: 3000, multi: 1000, voice: 2500, obj: 0.42, dark: 35, cool: 15000 }
};
const NUDGE = {
  no_face: 'We can’t see you — stay in front of the camera.', multiple_faces: 'Only you should be in the camera view.',
  multiple_people: 'Another person was detected. You must be alone.', looking_away: 'Please keep your eyes on the exam.',
  gaze_away: 'Please keep your eyes on the exam.', phone: 'A phone was detected — put it away.', book: 'Books and notes aren’t allowed.',
  extra_device: 'Another screen or laptop was detected.', voice: 'Please don’t talk during the exam.', background_voice: 'We can hear voices — make sure you are alone.',
  camera_covered: 'Your camera looks covered or too dark.', multi_monitor: 'Disconnect any extra monitors.', window_resized: 'Keep the exam full screen.',
  virtual_camera: 'Virtual camera software isn’t allowed.'
};
const REQ = [['webcam', 'video', 'Webcam'], ['microphone', 'mic', 'Microphone'], ['screen', 'monitor', 'Screen share'], ['identity', 'scan', 'Face ID'],
  ['liveness', 'activity', 'Liveness'], ['idCard', 'id', 'ID card'], ['roomScan', 'rotate', 'Room scan']];

function reqChips(p) {
  const ai = [p.aiFaces && 'faces', p.aiGaze && 'gaze', p.aiObjects && 'objects', p.aiAudio && 'audio'].filter(Boolean);
  return '<div class="req-chips">' + REQ.filter(([k]) => p[k]).map(([, ico, l]) => '<span class="req">' + icon(ico, 'i-sm') + esc(l) + '</span>').join('') +
    (ai.length ? '<span class="req ai">' + icon('sparkle', 'i-sm') + 'AI: ' + esc(ai.join(', ')) + '</span>' : '') + '</div>';
}
function stopStream(s) { if (s) s.getTracks().forEach((t) => { try { t.stop(); } catch (e) { /* already stopped */ } }); }
function mediaOk() { return !!(window.isSecureContext && navigator.mediaDevices && navigator.mediaDevices.getUserMedia); }
function mediaError(e, what) {
  const n = e && e.name;
  if (n === 'NotAllowedError' || n === 'SecurityError') return 'Access to the ' + what + ' was blocked. Click the camera icon in the address bar, allow it, then try again.';
  if (n === 'NotFoundError' || n === 'OverconstrainedError') return 'No ' + what + ' was found. Connect one and try again.';
  if (n === 'NotReadableError') return 'The ' + what + ' is being used by another app (Zoom, Teams, WhatsApp…). Close it and try again.';
  return (e && e.message) || 'The ' + what + ' could not be started.';
}
const getCamera = () => navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' }, audio: false });
const getMic = () => navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: false, autoGainControl: false }, video: false });
async function getScreen() {
  if (!navigator.mediaDevices.getDisplayMedia) throw new Error('This browser cannot share the screen. Use Chrome or Edge on a laptop or desktop.');
  const s = await navigator.mediaDevices.getDisplayMedia({ video: { displaySurface: 'monitor', frameRate: 5 }, audio: false, monitorTypeSurfaces: 'include', selfBrowserSurface: 'exclude', surfaceSwitching: 'exclude' });
  const set = s.getVideoTracks()[0].getSettings();
  if (set.displaySurface && set.displaySurface !== 'monitor') { stopStream(s); throw new Error('Share your entire screen — not a window or a tab.'); }
  return s;
}
function playInto(el, stream) { if (!el) return; el.srcObject = stream; el.muted = true; el.playsInline = true; const p = el.play(); if (p) p.catch(() => {}); }
function gpuName() {
  try {
    const gl = document.createElement('canvas').getContext('webgl');
    const x = gl && gl.getExtension('WEBGL_debug_renderer_info');
    return x ? String(gl.getParameter(x.UNMASKED_RENDERER_WEBGL)).slice(0, 110) : '';
  } catch (e) { return ''; }
}
/** Brightness of the face when there is exactly one, otherwise of the whole frame. */
function faceLight(v, f) { return f && f.faces === 1 && f.box ? PAI.light(v, f.box) : PAI.light(v); }
function median(a) { const b = a.slice().sort((x, y) => x - y); return b.length ? b[Math.floor(b.length / 2)] : 0; }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function descriptorsFrom(video, n) {
  const out = [];
  for (let i = 0; i < n * 3 && out.length < n; i++) {
    const d = await PAI.descriptor(video);
    if (d) out.push(d.d);
    await sleep(220);
  }
  return out;
}

/* =====================================================================
   STUDENT HUB
   ===================================================================== */
async function viewAssessment() {
  if (S.me.role !== 'student') return viewProctorHub();
  const r = await call('proctorHome');
  const now = Date.now() + (r.serverNow - Date.now());
  const exams = r.exams.map((q) => {
    const state = q.openAt && now < q.openAt ? 'upcoming' : q.closeAt && now > q.closeAt ? 'closed' : 'open';
    const left = q.maxAttempts ? q.maxAttempts - q.used : 1;
    let action;
    if (q.inProgressId) action = '<a class="btn btn-grad" href="#/assessment/checkin/' + esc(q.id) + '">' + icon('play') + 'Check in & continue</a>';
    else if (state === 'open' && left > 0) action = '<a class="btn btn-grad" href="#/assessment/checkin/' + esc(q.id) + '">' + icon('shield') + 'Begin check-in</a>';
    else action = badge(state === 'upcoming' ? 'Opens ' + rel(q.openAt) : state === 'closed' ? 'Closed' : 'No attempts left', state === 'upcoming' ? 'info' : '');
    return '<div class="card exam-card"><div class="exam-card-top"><span class="i-tile tone-violet">' + icon('shield') + '</span><div style="min-width:0;flex:1"><h3>' + esc(q.title) + '</h3>' +
      '<div class="xs muted">' + (q.openAt ? 'Opens ' + esc(fmt(q.openAt)) + ' · ' : '') + (q.closeAt ? 'Closes ' + esc(fmt(q.closeAt)) + ' · ' : '') + (q.durationMin ? q.durationMin + ' min' : 'No time limit') + '</div></div>' + action + '</div>' +
      reqChips(q.policy) + '</div>';
  }).join('');
  const REVIEW = { pending: ['Awaiting review', ''], cleared: ['Cleared', 'success'], suspicious: ['Under review', 'warning'], misconduct: ['Misconduct recorded', 'danger'] };
  const sessions = r.sessions.map((x) => '<tr><td><b>' + esc(x.quiz) + '</b></td><td class="small">' + esc(fmt(x.startedAt)) + '</td>' +
    '<td>' + badge(x.status === 'terminated' ? 'Ended by proctoring' : x.status === 'active' ? 'In progress' : 'Completed', x.status === 'terminated' ? 'danger' : x.status === 'active' ? 'warning' : 'success') + '</td>' +
    '<td>' + badge(REVIEW[x.review][0], REVIEW[x.review][1]) + '</td></tr>').join('');
  return {
    title: 'Proctored exams',
    html: pageHead('Proctored exams', { crumbs: [['Assessment'], ['Proctored exams']], sub: 'Exams that are supervised by your camera and on-device AI', actions: '<a class="btn" href="#/assessment/check">' + icon('activity') + 'System check</a>' }) +
      '<div class="proctor-hero card"><div><span class="eyebrow">' + icon('sparkle', 'i-sm') + ' AI-proctored assessment</span><h2>Take exams from anywhere — fairly.</h2>' +
      '<p>Before each exam you complete a short check-in: a system check, a face and liveness check, and anything else your teacher asks for. During the exam, AI running on <b>your own device</b> looks for things like another person, a phone or talking. Your teacher reviews anything it flags. The AI only ends an exam by itself if your teacher has set a limit, and you’ll see that limit before you start.</p>' +
      '<div class="row-wrap"><a class="btn btn-primary" href="#/assessment/check">' + icon('activity') + 'Run the system check</a></div></div>' +
      '<div class="hero-face">' + (r.profile.enrolled ? '<span class="i-tile lg tone-green">' + icon('scan') + '</span><b>Face enrolled</b><span class="xs muted">since ' + esc(fmtDate(r.profile.enrolledAt)) + '</span>'
        : '<span class="i-tile lg tone-amber">' + icon('scan') + '</span><b>Face not enrolled yet</b><span class="xs muted">It happens at your first check-in, or now in the system check.</span>') + '</div></div>' +
      '<div class="section-title"><h2>Your proctored exams</h2></div>' +
      (exams ? '<div class="exam-grid">' + exams + '</div>' : emptyState('shield', 'No proctored exams right now', 'When a teacher sets a proctored exam for you, it appears here.')) +
      (sessions ? '<div class="card" style="margin-top:1.25rem"><div class="card-head"><span class="i-tile sm tone-blue">' + icon('history') + '</span><h2>My proctoring record</h2></div><div class="table-wrap"><table class="table"><thead><tr><th>Exam</th><th>Started</th><th>Status</th><th>Integrity review</th></tr></thead><tbody>' + sessions + '</tbody></table></div></div>' : '') +
      privacyCard()
  };
}
function privacyCard() {
  return '<div class="card" style="margin-top:1.25rem"><div class="card-head"><span class="i-tile sm tone-slate">' + icon('lock') + '</span><h2>Your privacy</h2></div><div class="card-body"><ul class="small muted" style="margin:0;padding-left:1.1rem;line-height:1.8">' +
    '<li>Video and audio are analysed on your device and are <b>never streamed or recorded continuously</b>.</li>' +
    '<li>Only small snapshots (at intervals and when something is flagged), event times and a numeric face signature are sent to the college server.</li>' +
    '<li>Recordings are visible only to the teachers of the exam and are deleted automatically after the retention period.</li>' +
    '<li>Flags are for a human reviewer. You are never penalised automatically unless your teacher has set a limit, which is shown before you start.</li></ul></div></div>';
}

/* =====================================================================
   SYSTEM CHECK & AI DIAGNOSTICS
   ===================================================================== */
async function viewSystemCheck() {
  const student = S.me.role === 'student';
  const home = student ? await call('proctorHome') : null;
  return {
    title: 'System check',
    html: pageHead('System check', { crumbs: [['Assessment', '/assessment'], ['System check']], sub: 'Test your camera, microphone and the proctoring AI before exam day' }) +
      '<div class="split"><div class="stack"><div class="card"><div class="ci-stage" id="diagStage"><video id="diagVideo" class="mirror" autoplay muted playsinline></video><canvas id="diagOverlay" class="ci-overlay mirror"></canvas>' +
      '<div class="ci-guide" id="diagGuide">Press “Start” to turn on your camera</div></div>' +
      '<div class="card-body row-wrap"><button class="btn btn-primary" data-act="diagStart" id="diagBtn">' + icon('video') + 'Start</button>' +
      '<div class="meter" title="Microphone level"><i id="diagMic"></i></div><span class="xs muted" id="diagMicTxt">Microphone off</span></div></div>' +
      (student ? '<div class="card"><div class="card-head"><span class="i-tile sm tone-green">' + icon('scan') + '</span><div><h2>Face ID</h2><div class="xs muted">Your face signature is used to confirm it’s you at every proctored exam</div></div></div><div class="card-body" id="faceCard">' +
        (home.profile.enrolled ? '<p class="small">' + badge('Enrolled', 'success', 'check') + ' on ' + esc(fmtDate(home.profile.enrolledAt)) + ' (' + esc(home.profile.source) + ').</p><button class="btn" data-act="diagTestFace">' + icon('scan') + 'Test face match</button>'
          : '<p class="small muted">Not enrolled yet. Start the camera, face it in good light, then enrol. You can also enrol at your first exam check-in.</p><button class="btn btn-primary" data-act="diagEnrol">' + icon('scan') + 'Enrol my face</button>') +
        '<div id="faceOut" style="margin-top:.75rem"></div></div></div>' : '') + '</div>' +
      '<div class="stack"><div class="card"><div class="card-head"><span class="i-tile sm tone-violet">' + icon('sparkle') + '</span><div><h2>Checks</h2><div class="xs muted">All green means you’re ready</div></div></div><div class="card-body"><ul class="checklist" id="diagChecks">' +
      diagChecks({}) + '</ul></div></div>' +
      '<div class="card"><div class="card-head"><span class="i-tile sm tone-blue">' + icon('activity') + '</span><div><h2>Live AI readout</h2><div class="xs muted">What the proctoring AI sees right now</div></div></div><div class="card-body"><div class="ai-readout" id="diagReadout"><span class="muted small">Start the camera to see the live readout.</span></div></div></div></div></div>',
    after() { S.onLeave = diagStop; }
  };
}
function checkItem(state, title, text) {
  const ico = { ok: 'checkCircle', fail: 'alert', warn: 'alert', run: 'refresh', wait: 'circle' }[state] || 'circle';
  return '<li class="ck ' + state + '">' + icon(ico) + '<div><b>' + esc(title) + '</b>' + (text ? '<span>' + text + '</span>' : '') + '</div></li>';
}
function diagChecks(c) {
  const ext = window.screen.isExtended;
  return checkItem(mediaOk() ? 'ok' : 'fail', 'Browser & secure connection', mediaOk() ? esc(browserName()) : 'Open the site over https:// in Chrome, Edge or Firefox.') +
    checkItem(c.cam || 'wait', 'Camera', esc(c.camTxt || '')) + checkItem(c.mic || 'wait', 'Microphone', esc(c.micTxt || 'Say something to test it.')) +
    checkItem(ext ? 'warn' : 'ok', 'Single display', ext ? 'A second monitor is connected. Disconnect it before a proctored exam.' : 'Only one screen detected.') +
    checkItem(c.ai || 'wait', 'Proctoring AI', esc(c.aiTxt || 'Loads the face, object and identity models (≈25 MB the first time, then cached).')) +
    checkItem(c.net || 'wait', 'Connection to the server', esc(c.netTxt || ''));
}
function browserName() {
  const ua = navigator.userAgent;
  const m = /Edg\/(\d+)/.exec(ua) || /Chrome\/(\d+)/.exec(ua) || /Firefox\/(\d+)/.exec(ua) || /Version\/(\d+).*Safari/.exec(ua);
  const name = /Edg\//.test(ua) ? 'Edge' : /Chrome\//.test(ua) ? 'Chrome' : /Firefox\//.test(ua) ? 'Firefox' : /Safari/.test(ua) ? 'Safari' : 'Browser';
  return name + (m ? ' ' + m[1] : '') + (/Mobi|Android|iPhone|iPad/.test(ua) ? ' (mobile)' : '');
}
async function measureRtt() {
  const t = [];
  for (let i = 0; i < 3; i++) { const t0 = performance.now(); await call('proctorLabels'); t.push(performance.now() - t0); }
  return Math.round(median(t));
}

const DG = { cam: null, mic: null, meter: null, loop: null, c: {} };
function diagStop() {
  clearInterval(DG.loop); DG.loop = null;
  stopStream(DG.cam); stopStream(DG.mic); if (DG.meter) DG.meter.close();
  DG.cam = DG.mic = DG.meter = null;
}
function diagSet(k, state, txt) { DG.c[k] = state; DG.c[k + 'Txt'] = txt; const el = $('#diagChecks'); if (el) el.innerHTML = diagChecks(DG.c); }
ACT.diagStart = (d, btn) => busy(btn, async () => {
  diagStop();
  if (!mediaOk()) { toast('Camera access needs a secure (https) connection.', 'err'); return; }
  DG.c = {};
  diagSet('cam', 'run', 'Starting…');
  try { DG.cam = await getCamera(); } catch (e) { diagSet('cam', 'fail', mediaError(e, 'camera')); return; }
  const t = DG.cam.getVideoTracks()[0], set = t.getSettings();
  diagSet('cam', PAI.VIRTUAL.test(t.label) ? 'fail' : 'ok', (t.label || 'Camera') + (set.width ? ' · ' + set.width + '×' + set.height : '') + (PAI.VIRTUAL.test(t.label) ? ' — virtual cameras are not allowed' : ''));
  playInto($('#diagVideo'), DG.cam);
  try { DG.mic = await getMic(); DG.meter = PAI.audio(DG.mic); diagSet('mic', 'run', (DG.mic.getAudioTracks()[0].label || 'Microphone') + ' — say something'); } catch (e) { diagSet('mic', 'fail', mediaError(e, 'microphone')); }
  measureRtt().then((ms) => diagSet('net', ms < 800 ? 'ok' : 'warn', ms + ' ms round trip' + (ms >= 800 ? ' — slow; use a steadier connection' : ''))).catch(() => diagSet('net', 'fail', 'Could not reach the server'));
  diagSet('ai', 'run', 'Loading face model…');
  btn.innerHTML = icon('refresh') + 'Restart';
  try {
    await PAI.loadFace();
    diagSet('ai', 'run', 'Loading object & identity models…');
    await Promise.all([PAI.loadObjects(), PAI.loadIdentity()]);
    const r = PAI.ready();
    diagSet('ai', 'ok', 'Face, gaze, object and identity models ready (' + (r.delegate === 'GPU' ? 'GPU accelerated' : 'CPU') + ')');
  } catch (e) { diagSet('ai', 'fail', 'Could not load the AI models: ' + (e.message || e) + '. Check your internet connection and try again.'); }
  diagLoop();
});
function diagLoop() {
  let frames = 0, t0 = performance.now(), fps = 0, lastObj = 0, objs = [], micPeak = 0;
  const base = [];
  DG.loop = setInterval(() => {
    const v = $('#diagVideo');
    if (!v || !DG.cam) { diagStop(); return; }
    const f = PAI.ready().face ? PAI.face(v) : null;
    const L = faceLight(v, f);
    frames++;
    if (performance.now() - t0 > 1000) { fps = frames * 1000 / (performance.now() - t0); frames = 0; t0 = performance.now(); }
    if (PAI.ready().objects && Date.now() - lastObj > 1200) { lastObj = Date.now(); objs = PAI.objects(v).filter((o) => o.score >= 0.45); }
    const a = DG.meter ? DG.meter.read() : null;
    if (a) {
      const m = $('#diagMic'); if (m) m.style.width = Math.round(a.level * 100) + '%';
      const tx = $('#diagMicTxt'); if (tx) tx.textContent = a.voiced ? 'Voice detected' : 'Listening…';
      micPeak = Math.max(micPeak, a.voiced ? 1 : 0);
      if (micPeak && DG.c.mic === 'run') diagSet('mic', 'ok', (DG.mic.getAudioTracks()[0].label || 'Microphone') + ' — working');
    }
    let dy = null, dp = null;
    if (f && f.faces === 1 && f.yaw != null) {
      if (base.length < 12) base.push([f.yaw, f.pitch]);
      const by = median(base.map((b) => b[0])), bp = median(base.map((b) => b[1]));
      dy = PAI.wrap(f.yaw - by); dp = PAI.wrap(f.pitch - bp);
    }
    drawOverlay($('#diagOverlay'), v, f, objs);
    const g = $('#diagGuide');
    if (g) g.textContent = !f ? 'Loading AI…' : guideText(f, L, dy, dp);
    const ro = $('#diagReadout');
    if (ro) {
      const row = (k, v2, bad) => '<div class="ai-row' + (bad ? ' bad' : '') + '"><span>' + k + '</span><b>' + v2 + '</b></div>';
      ro.innerHTML = row('Faces', f ? f.faces : '—', f && f.faces !== 1) +
        row('Head turn / tilt', dy == null ? '—' : Math.round(dy) + '° / ' + Math.round(dp) + '°', dy != null && (Math.abs(dy) > 30 || Math.abs(dp) > 26)) +
        row('Eye gaze', f && f.faces ? (Math.abs(f.gazeH) > 0.6 ? 'Sideways' : 'On screen') : '—', f && Math.abs(f.gazeH) > 0.6) +
        row('Mouth / blink', f && f.faces ? Math.round(f.jaw * 100) + '% / ' + Math.round(f.blink * 100) + '%' : '—') +
        row('Lighting', L ? Math.round(L.mean) + (L.mean < 45 ? ' (too dark)' : '') : '—', L && L.mean < 45) +
        row('Objects', objs.length ? objs.map((o) => esc(o.label) + ' ' + Math.round(o.score * 100) + '%').join(', ') : 'none', objs.some((o) => o.label !== 'person')) +
        row('Voice', a ? (a.voiced ? 'speaking' : 'quiet') + ' · ' + Math.round(a.db) + ' dB' : '—', a && a.voiced) +
        row('Frame rate', fps ? fps.toFixed(1) + ' fps' : '—');
    }
  }, 160);
}
function guideText(f, L, dy, dp) {
  if (L && L.mean < 40) return 'Too dark — face a window or a lamp';
  if (!f.faces) return 'We can’t see a face';
  if (f.faces > 1) return 'Only one person should be in view';
  if (f.box && f.box.w < 0.17) return 'Move a little closer';
  if (f.box && Math.abs(f.box.x + f.box.w / 2 - 0.5) > 0.2) return 'Centre your face in the frame';
  if (dy != null && (Math.abs(dy) > 30 || Math.abs(dp) > 26)) return 'Look at the screen';
  return 'Looking good';
}
function drawOverlay(cv, v, f, objs) {
  if (!cv || !v || !v.videoWidth) return;
  const w = cv.clientWidth, h = cv.clientHeight;
  if (cv.width !== w) cv.width = w;
  if (cv.height !== h) cv.height = h;
  const g = cv.getContext('2d');
  g.clearRect(0, 0, w, h);
  // object-fit: cover mapping
  const sc = Math.max(w / v.videoWidth, h / v.videoHeight), ox = (w - v.videoWidth * sc) / 2, oy = (h - v.videoHeight * sc) / 2;
  if (f && f.box) {
    g.strokeStyle = f.faces === 1 ? '#22c55e' : '#ef4444'; g.lineWidth = 2.5;
    g.strokeRect(ox + f.box.x * v.videoWidth * sc, oy + f.box.y * v.videoHeight * sc, f.box.w * v.videoWidth * sc, f.box.h * v.videoHeight * sc);
  }
  (objs || []).forEach((o) => {
    if (!o.box) return;
    const bad = o.label !== 'person';
    g.strokeStyle = bad ? '#f59e0b' : 'rgba(255,255,255,.55)'; g.lineWidth = 2;
    g.strokeRect(ox + o.box.originX * sc, oy + o.box.originY * sc, o.box.width * sc, o.box.height * sc);
  });
}
ACT.diagEnrol = (d, btn) => busy(btn, async () => {
  const v = $('#diagVideo');
  if (!DG.cam || !v) { toast('Start the camera first.', 'err'); return; }
  await PAI.loadIdentity();
  $('#faceOut').innerHTML = '<span class="small muted">Hold still and look at the camera…</span>';
  const ds = await descriptorsFrom(v, 3);
  if (ds.length < 2) { $('#faceOut').innerHTML = notice('We couldn’t see your face clearly. Face the camera in good light and try again.', 'warn'); return; }
  await call('enrolFace', { descriptors: ds, img: PAI.grab(v, 480, 0.8) });
  $('#faceCard').innerHTML = notice('Your face is enrolled. It will be used to confirm your identity at every proctored exam.', 'ok');
});
ACT.diagTestFace = (d, btn) => busy(btn, async () => {
  const v = $('#diagVideo');
  if (!DG.cam || !v) { toast('Start the camera first.', 'err'); return; }
  await PAI.loadIdentity();
  const x = await PAI.descriptor(v);
  if (!x) { $('#faceOut').innerHTML = notice('No face found. Look at the camera and try again.', 'warn'); return; }
  const r = await call('testFace', { descriptor: x.d });
  $('#faceOut').innerHTML = r.match ? notice('It’s a match — the camera recognises you (distance ' + r.distance + ').', 'ok') : notice('This doesn’t match your enrolled face (distance ' + r.distance + '). Better, even lighting usually helps.', 'warn');
});

/* =====================================================================
   CHECK-IN
   ===================================================================== */
const CI = { st: null };
function ciSteps(p) {
  return [['rules', 'Rules & consent', 'file'], ['system', 'System check', 'activity'], p.identity && ['identity', p.liveness ? 'Face & liveness' : 'Face check', 'scan'],
    p.idCard && ['idcard', 'ID card', 'id'], p.roomScan && ['room', 'Room scan', 'rotate'], ['start', 'Start exam', 'play']].filter(Boolean);
}
async function viewCheckin(quizId) {
  ciStop();
  const r = await call('proctorBegin', { quizId });
  CI.st = { sid: r.sid, policy: r.policy, quiz: r.quiz, resume: r.resume, profile: r.profile, step: 'rules', done: {}, cam: null, mic: null, screen: null, meter: null, loop: null, base: null, handed: false, sysOk: {} };
  return {
    title: 'Check-in · ' + r.quiz.title,
    html: pageHead(r.quiz.title, { crumbs: [['Assessment', '/assessment'], ['Exam check-in']], sub: (r.resume ? 'Check in again to continue your attempt' : 'Proctored exam check-in') + ' · ' + (r.quiz.durationMin ? r.quiz.durationMin + ' minutes' : 'no time limit') }) +
      '<div class="ci"><aside class="ci-steps card" id="ciSteps"></aside><section class="card ci-main" id="ciMain"></section></div>',
    after() { S.onLeave = () => { if (!CI.st || !CI.st.handed) ciStop(); }; ciGo('rules'); }
  };
}
function ciStop() {
  const c = CI.st; if (!c) return;
  clearInterval(c.loop); c.loop = null;
  if (!c.handed) { stopStream(c.cam); stopStream(c.mic); stopStream(c.screen); if (c.meter) c.meter.close(); }
  CI.st = null;
}
function ciGo(step) {
  const c = CI.st; if (!c) return;
  clearInterval(c.loop); c.loop = null;
  c.step = step;
  const steps = ciSteps(c.policy);
  const idx = steps.findIndex((s) => s[0] === step);
  $('#ciSteps').innerHTML = '<div class="subhead" style="padding:0 var(--sp-2)">Check-in</div>' + steps.map(([k, l, ico], i) =>
    '<div class="ci-step' + (k === step ? ' on' : '') + (i < idx || c.done[k] ? ' done' : '') + '"><span class="n">' + (i < idx || c.done[k] ? icon('check', 'i-sm') : i + 1) + '</span>' + icon(ico, 'i-sm') + '<span>' + esc(l) + '</span></div>').join('') +
    '<div class="ci-foot">' + reqChips(c.policy) + '</div>';
  const main = $('#ciMain');
  main.innerHTML = CI_VIEWS[step]();
  const v = $('#ciVideo');
  if (v && c.cam) playInto(v, c.cam);
  if (CI_AFTER[step]) CI_AFTER[step]();
}
function ciNext() {
  const steps = ciSteps(CI.st.policy).map((s) => s[0]);
  CI.st.done[CI.st.step] = true;
  ciGo(steps[steps.indexOf(CI.st.step) + 1]);
}
ACT.ciBack = () => { const steps = ciSteps(CI.st.policy).map((s) => s[0]); ciGo(steps[Math.max(0, steps.indexOf(CI.st.step) - 1)]); };
ACT.ciNext = () => ciNext();
function ciActions(nextLabel, enabled, id) {
  return '<div class="form-actions"><button class="btn" type="button" data-act="ciBack"' + (CI.st.step === 'rules' ? ' disabled' : '') + '>' + icon('arrowLeft') + 'Back</button>' +
    '<button class="btn btn-primary" type="button" data-act="ciNext" id="' + (id || 'ciNextBtn') + '"' + (enabled ? '' : ' disabled') + '>' + esc(nextLabel || 'Continue') + icon('right') + '</button></div>';
}
function stage(extra) {
  return '<div class="ci-stage"><video id="ciVideo" class="mirror" autoplay muted playsinline></video><canvas id="ciOverlay" class="ci-overlay mirror"></canvas>' + (extra || '') + '<div class="ci-guide" id="ciGuide"></div></div>';
}

const CI_VIEWS = {
  rules() {
    const p = CI.st.policy, q = CI.st.quiz;
    const watch = [p.webcam && 'your webcam (you, your face and the room around you)', p.microphone && 'your microphone (talking and other voices)', p.screen && 'your entire screen',
      'the exam window (tab switches, leaving full screen, copy/paste and shortcuts)'].filter(Boolean);
    const ai = [p.aiFaces && 'no face / more than one face', p.aiGaze && 'looking away from the screen', p.aiObjects && 'phones, books, other screens and other people',
      p.aiAudio && 'talking and background voices', p.identity && 'whether the person matches your verified face'].filter(Boolean);
    return '<h2 class="ci-title">' + icon('file') + ' Rules & consent</h2>' +
      '<p class="muted">This exam is proctored. Please read this before continuing.</p>' +
      '<div class="grid-2" style="margin:1rem 0"><div class="ci-box"><h4>' + icon('eye', 'i-sm') + ' What is monitored</h4><ul>' + watch.map((x) => '<li>' + esc(x) + '</li>').join('') + '</ul></div>' +
      '<div class="ci-box"><h4>' + icon('sparkle', 'i-sm') + ' What the AI looks for</h4><ul>' + ai.map((x) => '<li>' + esc(x) + '</li>').join('') + '</ul></div></div>' +
      '<div class="ci-box"><h4>' + icon('shield', 'i-sm') + ' Exam rules</h4><ul>' +
      '<li>Be alone in a quiet, well-lit room. Keep your face visible and centred.</li><li>No phones, books, notes, smart watches, earphones or second screens.</li>' +
      '<li>Stay in full screen; don’t switch tabs or apps.</li>' + (q.durationMin ? '<li>You have <b>' + q.durationMin + ' minutes</b>. The timer keeps running if you disconnect.</li>' : '') +
      (p.strikes ? '<li><b>After ' + p.strikes + ' serious flags your exam is submitted automatically.</b></li>' : '') + (q.violationLimit ? '<li>After ' + q.violationLimit + ' browser warnings your exam is submitted automatically.</li>' : '') +
      '</ul></div>' +
      '<p class="xs muted" style="margin-top:.8rem">Analysis runs on your device. Snapshots and events are seen only by the teachers of this exam and deleted automatically after the retention period.</p>' +
      '<label class="check" style="margin-top:.8rem"><input type="checkbox" id="ciAgree" data-change="ciAgree"> I agree to be proctored and I will follow these rules.</label>' + ciActions('Continue', false);
  },
  system() {
    return '<h2 class="ci-title">' + icon('activity') + ' System check</h2><p class="muted">We’re checking your device. Allow camera' + (CI.st.policy.microphone ? ' and microphone' : '') + ' access when your browser asks.</p>' +
      '<div class="split-2">' + stage() + '<ul class="checklist" id="ciChecks"></ul></div>' +
      '<div class="row-wrap" style="margin-top:.8rem"><button class="btn" type="button" data-act="ciRecheck">' + icon('refresh') + 'Run again</button>' +
      (CI.st.policy.screen ? '<button class="btn btn-soft" type="button" data-act="ciShare" id="ciShareBtn">' + icon('monitor') + 'Share entire screen</button>' : '') +
      '<div class="meter" title="Microphone level"><i id="ciMic"></i></div></div>' + ciActions('Continue', false);
  },
  identity() {
    return '<h2 class="ci-title">' + icon('scan') + ' ' + (CI.st.policy.liveness ? 'Face & liveness check' : 'Face check') + '</h2>' +
      '<p class="muted">' + (CI.st.profile.enrolled ? 'We’ll compare you with your enrolled face.' : 'This is your first proctored exam, so this photo becomes your reference face.') +
      (CI.st.policy.liveness ? ' Follow the prompts so we know it’s really you and not a photo.' : '') + '</p>' +
      '<div class="split-2">' + stage('<div class="ci-oval"></div>') + '<div><ul class="checklist" id="ciLive"></ul><div id="ciIdOut" style="margin-top:.75rem"></div></div></div>' + ciActions('Continue', false);
  },
  idcard() {
    return '<h2 class="ci-title">' + icon('id') + ' Photo ID</h2><p class="muted">Hold your college ID card close to the camera with your photo facing it, inside the frame, then capture. (The preview is mirrored; the photo won’t be.)</p>' +
      '<div class="split-2">' + stage('<div class="ci-card"></div>') + '<div><div id="ciIdcardOut" class="small muted">No photo yet.</div>' +
      '<div class="row-wrap" style="margin-top:.8rem"><button class="btn btn-primary" type="button" data-act="ciIdCapture">' + icon('camera') + 'Capture ID</button></div></div></div>' + ciActions('Continue', !!CI.st.done.idcard);
  },
  room() {
    const shots = CI.st.room || [];
    return '<h2 class="ci-title">' + icon('rotate') + ' Room scan</h2><p class="muted">Slowly show your surroundings. Tilt or turn your laptop (or camera) for each view and capture it.</p>' +
      '<div class="split-2">' + stage() + '<div><div class="room-grid" id="ciRoom">' + ROOM_VIEWS.map((l, i) => '<div class="room-shot' + (shots[i] ? ' done' : '') + '">' + (shots[i] ? '<img alt="" src="data:image/jpeg;base64,' + shots[i] + '">' : icon('camera')) + '<span>' + esc(l) + '</span></div>').join('') + '</div>' +
      '<div class="row-wrap" style="margin-top:.8rem"><button class="btn btn-primary" type="button" data-act="ciRoomCapture" id="ciRoomBtn"' + (shots.length >= 4 ? ' disabled' : '') + '>' + icon('camera') + (shots.length >= 4 ? 'All views captured' : 'Capture: ' + esc(ROOM_VIEWS[shots.length])) + '</button></div></div></div>' +
      ciActions('Continue', shots.length >= 4);
  },
  start() {
    const c = CI.st, p = c.policy;
    const items = [['System check passed', true], p.identity && ['Identity verified' + (c.idNote ? ' — ' + c.idNote : ''), true], p.idCard && ['ID card captured', true], p.roomScan && ['Room scanned', true],
      p.screen && ['Screen shared', !!c.screen]].filter(Boolean);
    return '<h2 class="ci-title">' + icon('play') + ' Ready to ' + (c.resume ? 'continue' : 'start') + '</h2>' +
      '<ul class="checklist">' + items.map(([t, ok]) => checkItem(ok ? 'ok' : 'fail', t, '')).join('') + '</ul>' +
      notice('The exam opens in full screen and monitoring starts immediately. A small camera preview stays in the corner. ' + (p.liveChat ? 'Use “Message proctor” there if you need help.' : ''), '', 'info') +
      '<form data-form="ciStart" novalidate style="margin-top:1rem">' + (c.quiz.needsCode ? field('Access code', '<input type="text" name="code" maxlength="50" autocomplete="off">', 'Your teacher gives you this code.') : '') +
      '<div class="form-actions"><button class="btn" type="button" data-act="ciBack">' + icon('arrowLeft') + 'Back</button><button class="btn btn-grad btn-lg" type="submit">' + icon('play') + (c.resume ? 'Continue the exam' : 'Start the exam') + '</button></div></form>';
  }
};
const ROOM_VIEWS = ['Your desk', 'Left side', 'Right side', 'Behind you'];

const CI_AFTER = {
  system() { ciRunSystem(); },
  identity() { ciIdentityLoop(); },
  idcard() { ciPreviewLoop(); },
  room() { ciPreviewLoop(); }
};
ACT.ciAgree = (d, el) => { const b = $('#ciNextBtn'); if (b) b.disabled = !el.checked; };

/* ---------- system ---------- */
function ciSetCheck(k, state, title, text) {
  const c = CI.st; if (!c) return;
  c.sysOk[k] = { state, title, text };
  const order = ['browser', 'cam', 'mic', 'screen', 'display', 'ai', 'net'];
  const el = $('#ciChecks');
  if (el) el.innerHTML = order.filter((x) => c.sysOk[x]).map((x) => checkItem(c.sysOk[x].state, c.sysOk[x].title, esc(c.sysOk[x].text || ''))).join('');
  const need = order.filter((x) => c.sysOk[x]);
  const ok = need.length >= 5 && need.every((x) => c.sysOk[x].state === 'ok' || c.sysOk[x].state === 'warn');
  const b = $('#ciNextBtn'); if (b) b.disabled = !ok;
}
ACT.ciRecheck = () => ciRunSystem();
async function ciRunSystem() {
  const c = CI.st, p = c.policy;
  c.sysOk = {};
  ciSetCheck('browser', mediaOk() ? 'ok' : 'fail', 'Browser & secure connection', mediaOk() ? browserName() : 'Open the site over https:// in Chrome, Edge or Firefox.');
  if (!mediaOk()) return;
  ciSetCheck('cam', 'run', 'Camera', 'Starting…');
  if (!c.cam || c.cam.getVideoTracks()[0].readyState !== 'live') {
    try { c.cam = await getCamera(); } catch (e) { ciSetCheck('cam', 'fail', 'Camera', mediaError(e, 'camera')); return; }
  }
  if (!CI.st) return;
  playInto($('#ciVideo'), c.cam);
  const t = c.cam.getVideoTracks()[0], set = t.getSettings();
  if (PAI.VIRTUAL.test(t.label)) { ciSetCheck('cam', 'fail', 'Camera', t.label + ' is virtual-camera software. Choose your real webcam in the browser’s camera settings.'); stopStream(c.cam); c.cam = null; return; }
  ciSetCheck('cam', 'ok', 'Camera', (t.label || 'Camera') + (set.width ? ' · ' + set.width + '×' + set.height : ''));
  if (p.microphone) {
    if (!c.mic || c.mic.getAudioTracks()[0].readyState !== 'live') {
      try { c.mic = await getMic(); } catch (e) { ciSetCheck('mic', 'fail', 'Microphone', mediaError(e, 'microphone')); }
    }
    if (c.mic) {
      if (!c.meter) c.meter = PAI.audio(c.mic);
      ciSetCheck('mic', 'run', 'Microphone', 'Say “hello” to test it');
    }
  }
  const ext = window.screen.isExtended;
  ciSetCheck('display', ext ? 'fail' : 'ok', 'Single display', ext ? 'A second monitor is connected. Disconnect it, then press “Run again”.' : 'One screen');
  if (p.screen) ciSetCheck('screen', c.screen ? 'ok' : 'fail', 'Screen sharing', c.screen ? 'Entire screen shared' : 'Press “Share entire screen” and choose your whole screen.');
  ciSetCheck('net', 'run', 'Connection', 'Measuring…');
  measureRtt().then((ms) => ciSetCheck('net', ms < 1500 ? 'ok' : 'warn', 'Connection', ms + ' ms round trip' + (ms >= 1500 ? ' — slow; move closer to your Wi-Fi' : ''))).catch(() => ciSetCheck('net', 'fail', 'Connection', 'Could not reach the server.'));
  ciSetCheck('ai', 'run', 'Proctoring AI', 'Loading models (first time ≈25 MB)…');
  try {
    await PAI.loadFace();
    const extra = [];
    if (p.aiObjects) extra.push(PAI.loadObjects());
    if (p.identity) extra.push(PAI.loadIdentity());
    await Promise.all(extra);
    ciSetCheck('ai', 'ok', 'Proctoring AI', 'Ready · ' + (PAI.ready().delegate === 'GPU' ? 'GPU accelerated' : 'running on CPU'));
  } catch (e) { ciSetCheck('ai', 'fail', 'Proctoring AI', 'Could not load the AI models (' + (e.message || e) + '). Check your internet and press “Run again”.'); }
  // live mic meter + preview overlay
  clearInterval(c.loop);
  c.loop = setInterval(() => {
    if (!CI.st) return;
    const v = $('#ciVideo');
    const f = PAI.ready().face && v ? PAI.face(v) : null;
    const L = v ? faceLight(v, f) : null;
    const g = $('#ciGuide'); if (g && f) g.textContent = guideText(f, L, null, null);
    drawOverlay($('#ciOverlay'), v, f, null);
    if (c.meter) {
      const a = c.meter.read();
      const m = $('#ciMic'); if (m) m.style.width = Math.round(a.level * 100) + '%';
      if (a.voiced && c.sysOk.mic && c.sysOk.mic.state === 'run') ciSetCheck('mic', 'ok', 'Microphone', (c.mic.getAudioTracks()[0].label || 'Microphone') + ' — working');
    }
  }, 150);
}
ACT.ciShare = (d, btn) => busy(btn, async () => {
  const c = CI.st;
  try { stopStream(c.screen); c.screen = await getScreen(); } catch (e) { ciSetCheck('screen', 'fail', 'Screen sharing', e.name === 'NotAllowedError' ? 'Screen sharing was cancelled. Try again and choose “Entire screen”.' : e.message); return; }
  c.screen.getVideoTracks()[0].addEventListener('ended', () => { if (CI.st && !CI.st.handed) { CI.st.screen = null; ciSetCheck('screen', 'fail', 'Screen sharing', 'Sharing stopped. Share again.'); } });
  ciSetCheck('screen', 'ok', 'Screen sharing', 'Entire screen shared');
});
// Leaving the system step: report the environment.
const ciNextBase = ACT.ciNext;
ACT.ciNext = (d, btn) => {
  const c = CI.st;
  if (c && c.step === 'system') {
    busy(btn, async () => {
      const t = c.cam.getVideoTracks()[0], set = t.getSettings();
      await call('proctorVerify', {
        sid: c.sid, step: 'system', env: {
          ua: navigator.userAgent, platform: (navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform, mobile: /Mobi|Android|iPhone|iPad/.test(navigator.userAgent),
          screen: window.screen.width + '×' + window.screen.height, displays: window.screen.isExtended ? 'multiple' : 'single', camera: t.label, cameraRes: set.width ? set.width + '×' + set.height : '',
          mic: c.mic ? c.mic.getAudioTracks()[0].label : '', screenShare: c.screen ? 'entire screen' : 'not required', ai: 'face ' + (PAI.ready().face ? 'on' : 'off') + ', objects ' + (PAI.ready().objects ? 'on' : 'off') + ', identity ' + (PAI.ready().identity ? 'on' : 'off') + ' · ' + PAI.ready().delegate,
          gpu: gpuName(), rttMs: 0, phoneCamera: PAI.PHONECAM.test(t.label)
        }
      });
      ciNext();
    });
    return;
  }
  ciNextBase(d, btn);
};

/* ---------- identity + liveness ---------- */
function ciIdentityLoop() {
  const c = CI.st, p = c.policy;
  const L = c.live = { phase: 'align', good: 0, base: [], sign: 0, blinkOpen: false, tries: c.live ? c.live.tries : 0 };
  const steps = () => {
    const items = [['align', 'Face centred and well lit'], p.liveness && ['turn1', 'Turn your head to one side'], p.liveness && ['turn2', 'Now turn to the other side'], p.liveness && ['blink', 'Blink your eyes'], ['capture', 'Look at the camera for the photo']].filter(Boolean);
    const order = items.map((x) => x[0]);
    const cur = order.indexOf(L.phase === 'verifying' || L.phase === 'done' ? 'zz' : L.phase);
    const el = $('#ciLive');
    if (el) el.innerHTML = items.map(([k, t], i) => checkItem(L.phase === 'done' || L.phase === 'verifying' || i < cur ? 'ok' : i === cur ? 'run' : 'wait', t, '')).join('');
  };
  L.render = steps;
  steps();
  c.loop = setInterval(async () => {
    if (!CI.st || CI.st.step !== 'identity' || L.busy) return;
    const v = $('#ciVideo');
    const f = PAI.face(v);
    const lt = faceLight(v, f);
    drawOverlay($('#ciOverlay'), v, f, null);
    const g = $('#ciGuide');
    if (!f) return;
    let dy = null, dp = null;
    if (c.base && f.faces === 1 && f.yaw != null) { dy = PAI.wrap(f.yaw - c.base[0]); dp = PAI.wrap(f.pitch - c.base[1]); }
    const okFrame = f.faces === 1 && f.box && f.box.w >= 0.17 && Math.abs(f.box.x + f.box.w / 2 - 0.5) < 0.2 && !(lt && lt.mean < 40);
    if (L.phase === 'align') {
      if (g) g.textContent = okFrame ? 'Hold still…' : guideText(f, lt, null, null);
      if (okFrame) { L.base.push([f.yaw, f.pitch]); if (L.base.length >= 10) { c.base = [median(L.base.map((b) => b[0])), median(L.base.map((b) => b[1]))]; L.phase = p.liveness ? 'turn1' : 'capture'; steps(); } } else L.base = [];
      return;
    }
    if (f.faces !== 1) { if (g) g.textContent = guideText(f, lt, null, null); return; }
    if (L.phase === 'turn1') {
      if (g) g.textContent = 'Slowly turn your head to one side';
      if (Math.abs(dy) > 20) { L.sign = Math.sign(dy); L.phase = 'turn2'; steps(); }
    } else if (L.phase === 'turn2') {
      if (g) g.textContent = 'Now turn to the other side';
      if (Math.sign(dy) === -L.sign && Math.abs(dy) > 20) { L.phase = 'blink'; steps(); }
    } else if (L.phase === 'blink') {
      if (g) g.textContent = 'Look at the screen and blink';
      if (f.blink < 0.25 && Math.abs(dy) < 15) L.blinkOpen = true;
      if (L.blinkOpen && f.blink > 0.5) { L.phase = 'capture'; L.liveness = true; steps(); }
    } else if (L.phase === 'capture') {
      if (g) g.textContent = 'Look straight at the camera…';
      if (okFrame && Math.abs(dy) < 12 && Math.abs(dp) < 14) { L.busy = true; await ciCaptureSelfie(v, !!L.liveness || !p.liveness); L.busy = false; }
    }
  }, 120);
}
async function ciCaptureSelfie(v, liveness, accept) {
  const c = CI.st, L = c.live;
  L.phase = 'verifying';
  L.render();
  const g = $('#ciGuide'); if (g) g.textContent = 'Verifying…';
  const out = $('#ciIdOut');
  if (out) out.innerHTML = '<span class="small muted">' + icon('refresh', 'i-sm') + ' Checking your identity…</span>';
  const img = PAI.grab(v, 640, 0.82);
  const ds = await descriptorsFrom(v, 3);
  if (!CI.st) return;
  let r;
  try { r = await call('proctorVerify', { sid: c.sid, step: 'selfie', img, descriptors: ds, liveness, accept: !!accept }); } catch (e) {
    L.phase = 'capture'; L.render(); if (out) out.innerHTML = notice(esc(e.message), 'warn'); return;
  }
  L.tries = r.tries;
  if (r.match || r.accepted) {
    L.phase = 'done';
    c.idNote = r.enrolled ? 'reference face enrolled' : r.match ? 'matches your enrolled face' : 'flagged for teacher review';
    if (out) out.innerHTML = r.enrolled ? notice('<b>Face enrolled.</b> This photo is now your reference for proctored exams.', 'ok')
      : r.match ? notice('<b>Identity verified.</b> You match your enrolled face.', 'ok') : notice('Your photo still doesn’t match your enrolled face. You can continue — your teacher will review it.', 'warn');
    if (g) g.textContent = r.match ? 'Verified' : 'Continuing with review';
    const b = $('#ciNextBtn'); if (b) b.disabled = false;
  } else {
    if (out) out.innerHTML = notice('<b>That didn’t match your enrolled face.</b> Face a light source, remove caps or masks, and try again (' + r.tries + ' of 3).', 'warn') +
      '<div class="row-wrap" style="margin-top:.6rem"><button class="btn" type="button" data-act="ciRetryFace">' + icon('refresh') + 'Try again</button></div>';
  }
}
ACT.ciRetryFace = () => { if (CI.st) { CI.st.live.phase = 'capture'; CI.st.live.render(); $('#ciIdOut').innerHTML = ''; } };

/* ---------- ID card & room scan ---------- */
function ciPreviewLoop() {
  const c = CI.st;
  c.loop = setInterval(() => {
    if (!CI.st) return;
    const v = $('#ciVideo');
    const g = $('#ciGuide');
    if (g) g.textContent = c.step === 'idcard' ? 'Hold the ID inside the frame' : 'Show: ' + (ROOM_VIEWS[(c.room || []).length] || 'done');
  }, 500);
}
ACT.ciIdCapture = (d, btn) => busy(btn, async () => {
  const c = CI.st, v = $('#ciVideo');
  const img = PAI.grab(v, 960, 0.85);
  const cv = document.createElement('canvas');
  cv.width = v.videoWidth; cv.height = v.videoHeight; cv.getContext('2d').drawImage(v, 0, 0);
  // The student's own face is also in frame; the ID photo is the smaller face.
  let desc = null;
  try { await PAI.loadIdentity(); desc = await idCardDescriptor(cv); } catch (e) { desc = null; }
  c.idImg = img; c.idDesc = desc;
  const r = await call('proctorVerify', { sid: c.sid, step: 'idcard', img, descriptor: desc ? desc.d : null });
  const out = $('#ciIdcardOut');
  const preview = '<img class="id-preview" alt="Captured ID" src="data:image/jpeg;base64,' + img + '">';
  if (r.match) { c.done.idcard = true; out.innerHTML = preview + notice('<b>ID matched</b> your face.', 'ok'); $('#ciNextBtn').disabled = false; }
  else {
    out.innerHTML = preview + notice(desc ? 'The photo on the card doesn’t look like your selfie. Hold it closer and steadier, then retake.' : 'We couldn’t read the photo on your card. Hold it closer, avoid glare, then retake.', 'warn') +
      '<div class="row-wrap" style="margin-top:.5rem"><button class="btn btn-ghost" type="button" data-act="ciIdAccept">Use this photo anyway</button></div>';
  }
});
async function idCardDescriptor(cv) {
  // Crop the centre region where the card frame is, so the ID face dominates.
  const w = cv.width, h = cv.height;
  const crop = document.createElement('canvas');
  crop.width = Math.round(w * 0.6); crop.height = Math.round(h * 0.6);
  crop.getContext('2d').drawImage(cv, w * 0.2, h * 0.2, w * 0.6, h * 0.6, 0, 0, crop.width, crop.height);
  const up = document.createElement('canvas');
  up.width = crop.width * 2; up.height = crop.height * 2;
  const g = up.getContext('2d'); g.imageSmoothingQuality = 'high'; g.drawImage(crop, 0, 0, up.width, up.height);
  return PAI.descriptor(up, true);
}
ACT.ciIdAccept = (d, btn) => busy(btn, async () => {
  const c = CI.st;
  await call('proctorVerify', { sid: c.sid, step: 'idcard', img: c.idImg, descriptor: c.idDesc ? c.idDesc.d : null, final: true });
  c.done.idcard = true;
  $('#ciNextBtn').disabled = false;
  toast('ID photo saved for your teacher to check.');
});
ACT.ciRoomCapture = (d, btn) => busy(btn, async () => {
  const c = CI.st; c.room = c.room || [];
  const img = PAI.grab($('#ciVideo'), 640, 0.75);
  await call('proctorVerify', { sid: c.sid, step: 'room', img, label: ROOM_VIEWS[c.room.length] });
  c.room.push(img);
  ciGo('room');
});

/* ---------- start ---------- */
FORMS.ciStart = (f, btn) => {
  const c = CI.st;
  if (!c) return;
  enterFullscreen(); // must run inside the click
  busy(btn, async () => {
    await call('proctorReady', { sid: c.sid });
    const r = await call('startAttempt', { quizId: c.quiz.id, accessCode: f.elements.code ? f.elements.code.value : '', proctorSession: c.sid });
    c.handed = true;
    clearInterval(c.loop); c.loop = null;
    const hand = { sid: c.sid, policy: c.policy, quizId: c.quiz.id, cam: c.cam, mic: c.mic, screen: c.screen, meter: c.meter, base: c.base };
    CI.st = null;
    await openAttempt(r.attemptId);
    if (S.attempt) pmStart(hand);
    else { stopStream(hand.cam); stopStream(hand.mic); stopStream(hand.screen); if (hand.meter) hand.meter.close(); }
  }).then(() => { if (!S.attempt && document.fullscreenElement) exitFullscreen(); });
};

/* =====================================================================
   IN-EXAM MONITOR
   ===================================================================== */
const PM = { m: null };
function pmStart(o) {
  pmStop();
  const p = o.policy;
  const M = PM.m = {
    sid: o.sid, policy: p, quizId: o.quizId, sens: SENS[p.sensitivity] || SENS.medium, cam: o.cam, mic: o.mic, screen: o.screen, meter: o.meter || (o.mic ? PAI.audio(o.mic) : null),
    base: o.base, baseSamples: [], cond: {}, last: {}, hits: {}, voice: [], jaw: [], queue: [], sending: false, stats: {}, listeners: [], timers: [],
    snapAt: Date.now(), screenAt: Date.now(), idAt: Date.now() + 15000, beatMs: 10000, thumb: '', frames: 0, fpsT: performance.now(), fps: 0, offlineAt: 0
  };
  const pip = document.createElement('div');
  pip.className = 'pm-pip'; pip.id = 'pmPip';
  pip.innerHTML = '<div class="pm-video"><video id="pmVideo" class="mirror" autoplay muted playsinline></video><span class="pm-rec"><i></i>Proctored</span></div>' +
    '<div class="pm-status" id="pmStatus"></div><div class="pm-nudge" id="pmNudge" role="status" aria-live="polite"></div>' +
    '<div class="pm-actions">' + (p.liveChat ? '<button type="button" class="btn btn-sm btn-ghost" data-act="pmChat">' + icon('message', 'i-sm') + 'Message proctor</button>' : '') +
    '<button type="button" class="btn-icon sm" data-act="pmMin" title="Minimise">' + icon('minus') + '</button></div>';
  document.body.appendChild(pip);
  M.video = $('#pmVideo');
  playInto(M.video, M.cam);
  if (M.screen) { M.svideo = document.createElement('video'); playInto(M.svideo, M.screen); }
  const listen = (t, ty, fn) => { t.addEventListener(ty, fn); M.listeners.push([t, ty, fn]); };
  const camTrack = M.cam.getVideoTracks()[0];
  listen(camTrack, 'ended', () => { fire('camera_off', 1, 'camera stopped'); pmReconnect('camera'); });
  listen(camTrack, 'mute', () => { M.camMutedAt = Date.now(); });
  listen(camTrack, 'unmute', () => { M.camMutedAt = 0; });
  if (M.mic) listen(M.mic.getAudioTracks()[0], 'ended', () => fire('mic_off', 1, 'microphone stopped', ''));
  if (M.screen) listen(M.screen.getVideoTracks()[0], 'ended', () => { fire('screen_share_stopped', 1, '', ''); pmReconnect('screen'); });
  if (PAI.VIRTUAL.test(camTrack.label)) fire('virtual_camera', 1, camTrack.label);
  if (window.screen.isExtended) fire('multi_monitor', 1, 'extended display', '');
  if (window.screen.addEventListener) listen(window.screen, 'change', () => { if (window.screen.isExtended) fire('multi_monitor', 1, 'monitor connected', ''); });
  listen(window, 'resize', () => {
    if (window.innerWidth < window.screen.availWidth * 0.75 || window.innerHeight < window.screen.availHeight * 0.6) fire('window_resized', 0.8, window.innerWidth + '×' + window.innerHeight, '');
  });
  listen(window, 'offline', () => { M.offlineAt = Date.now(); });
  listen(window, 'online', () => { if (M.offlineAt) { fire('offline', 1, Math.round((Date.now() - M.offlineAt) / 1000) + ' s offline', ''); M.offlineAt = 0; } });
  M.timers.push(setInterval(pmTick, 300));
  if (p.aiObjects) M.timers.push(setInterval(pmObjects, 1500));
  if (p.identity) M.timers.push(setInterval(pmIdentity, 5000));
  M.beatTimer = setTimeout(pmBeat, 1500);
  pmStatus();
}
function pmStop() {
  const M = PM.m; if (!M) return;
  PM.m = null;
  M.timers.forEach(clearInterval); clearTimeout(M.beatTimer);
  M.listeners.forEach(([t, ty, fn]) => t.removeEventListener(ty, fn));
  stopStream(M.cam); stopStream(M.mic); stopStream(M.screen); if (M.meter) M.meter.close();
  const pip = $('#pmPip'); if (pip) pip.remove();
  if (M.queue.length) call('proctorEvents', { sid: M.sid, events: M.queue.splice(0, 20) }).catch(() => {});
}
function cond(type, on, hold, conf, detail) {
  const M = PM.m; if (!M) return;
  if (!on) { delete M.cond[type]; return; }
  const now = Date.now();
  if (!M.cond[type]) M.cond[type] = now;
  if (now - M.cond[type] >= (hold || 0)) { fire(type, conf, detail); M.cond[type] = now; }
}
function fire(type, conf, detail, img) {
  const M = PM.m; if (!M) return;
  const now = Date.now();
  if (M.last[type] && now - M.last[type] < M.sens.cool) return;
  M.last[type] = now;
  M.queue.push({ type, conf, detail: detail || '', img: img === undefined ? PAI.grab(M.video, 480, 0.7) : img });
  if (NUDGE[type]) pmNudge(NUDGE[type]);
  pmFlush();
}
function pmNudge(text) {
  const el = $('#pmNudge'); if (!el) return;
  el.textContent = text; el.classList.add('on');
  const pip = $('#pmPip'); if (pip) { pip.classList.remove('min'); pip.classList.add('alert'); }
  clearTimeout(PM.nudgeT);
  PM.nudgeT = setTimeout(() => { el.classList.remove('on'); if (pip) pip.classList.remove('alert'); }, 5000);
}
async function pmFlush() {
  const M = PM.m; if (!M || M.sending || !M.queue.length) return;
  M.sending = true;
  const batch = M.queue.splice(0, 10);
  try {
    const r = await call('proctorEvents', { sid: M.sid, events: batch });
    if (r.terminated || (r.status && r.status !== 'active')) { pmEnded(r.status || 'terminated'); return; }
  } catch (e) { if (PM.m === M) M.queue.unshift(...batch.filter((x) => x.type !== 'snapshot').slice(0, 30)); }
  M.sending = false;
  if (PM.m === M && M.queue.length) setTimeout(pmFlush, 500);
}
function pmTick() {
  const M = PM.m; if (!M || !M.video) return;
  const p = M.policy, now = Date.now(), v = M.video;
  const camTrack = M.cam.getVideoTracks()[0];
  const camAlive = camTrack && camTrack.readyState === 'live';
  M.frames++;
  if (performance.now() - M.fpsT > 2000) { M.fps = Math.round(M.frames * 10000 / (performance.now() - M.fpsT)) / 10; M.frames = 0; M.fpsT = performance.now(); }
  const L = camAlive ? PAI.light(v) : null;
  cond('camera_covered', !!L && (L.mean < M.sens.dark || (L.sd < 6 && L.mean < 70)), 3000, 0.9, L ? 'brightness ' + Math.round(L.mean) : '');
  if (M.camMutedAt && now - M.camMutedAt > 4000) { fire('camera_off', 1, 'camera blocked by the system'); M.camMutedAt = now; }
  let f = null;
  if (camAlive && p.aiFaces && PAI.ready().face) { try { f = PAI.face(v); } catch (e) { f = null; } }
  M.stats.light = L ? Math.round(L.mean) : null;
  if (f) {
    M.stats.faces = f.faces;
    M.lastFaces = f.faces;
    cond('no_face', f.faces === 0 && !(L && L.mean < M.sens.dark), M.sens.noFace, 0.9);
    cond('multiple_faces', f.faces > 1, M.sens.multi, 0.85, f.faces + ' faces');
    if (f.faces >= 1 && f.yaw != null) {
      if (!M.base) {
        M.baseSamples.push([f.yaw, f.pitch]);
        if (M.baseSamples.length >= 20) M.base = [median(M.baseSamples.map((b) => b[0])), median(M.baseSamples.map((b) => b[1]))];
      } else {
        const dy = PAI.wrap(f.yaw - M.base[0]), dp = PAI.wrap(f.pitch - M.base[1]);
        const away = Math.abs(dy) > M.sens.yaw || Math.abs(dp) > M.sens.pitch;
        const gaze = !away && Math.abs(f.gazeH) > M.sens.gaze;
        M.stats.away = away; M.stats.gaze = gaze;
        if (p.aiGaze) {
          cond('looking_away', away, M.sens.away, 0.8, 'turn ' + Math.round(dy) + '°, tilt ' + Math.round(dp) + '°');
          cond('gaze_away', gaze, M.sens.away + 1500, 0.7, 'gaze ' + (f.gazeH > 0 ? 'right' : 'left'));
        }
      }
      M.jaw.push([now, f.jaw]);
    } else { cond('looking_away', false); cond('gaze_away', false); M.stats.away = false; M.stats.gaze = false; }
  }
  if (M.meter && p.aiAudio) {
    const a = M.meter.read();
    M.stats.voice = Math.round(a.level * 100) / 100;
    M.voice.push([now, a.voiced]);
    while (M.voice.length && now - M.voice[0][0] > 6000) M.voice.shift();
    while (M.jaw.length && now - M.jaw[0][0] > 6000) M.jaw.shift();
    const voicedMs = M.voice.filter((x) => x[1]).length * 300;
    if (voicedMs >= M.sens.voice) {
      const j = M.jaw.map((x) => x[1]);
      const mean = j.length ? j.reduce((s, x) => s + x, 0) / j.length : 0;
      const sd = j.length ? Math.sqrt(j.reduce((s, x) => s + (x - mean) * (x - mean), 0) / j.length) : 0;
      const mouth = j.length > 5 && (sd > 0.045 || Math.max(...j) > 0.3);
      fire(mouth ? 'voice' : 'background_voice', Math.min(1, voicedMs / 6000 + 0.3), Math.round(voicedMs / 100) / 10 + ' s of speech' + (mouth ? ', mouth moving' : ', mouth still'));
      M.voice = [];
    }
  }
  if (camAlive && now - M.snapAt >= p.snapshotSec * 1000) { M.snapAt = now; M.queue.push({ type: 'snapshot', kind: 'cam', img: PAI.grab(v, 480, 0.65) }); pmFlush(); }
  if (M.svideo && M.screen && M.screen.getVideoTracks()[0].readyState === 'live' && now - M.screenAt >= p.snapshotSec * 2000) {
    M.screenAt = now; M.queue.push({ type: 'snapshot', kind: 'screen', img: PAI.grab(M.svideo, 1024, 0.55) }); pmFlush();
  }
  M.stats.cam = camAlive; M.stats.mic = !!M.mic && M.mic.getAudioTracks()[0].readyState === 'live';
  M.stats.screen = !!M.screen && M.screen.getVideoTracks()[0].readyState === 'live';
  M.stats.fs = !!document.fullscreenElement; M.stats.focus = document.hasFocus(); M.stats.fps = M.fps;
  if (M.frames % 3 === 0) pmStatus();
}
function pmObjects() {
  const M = PM.m; if (!M || !PAI.ready().objects) return;
  let dets = [];
  try { dets = PAI.objects(M.video); } catch (e) { return; }
  const thr = M.sens.obj;
  const top = (labels, s) => dets.filter((d) => labels.indexOf(d.label) >= 0 && d.score >= s).reduce((b, d) => (!b || d.score > b.score ? d : b), null);
  const phone = top(['cell phone', 'remote'], thr);
  hit('phone', phone, phone && phone.score >= 0.75);
  hit('book', top(['book'], thr + 0.05));
  hit('extra_device', top(['laptop', 'tv'], thr + 0.05));
  const people = dets.filter((d) => d.label === 'person' && d.score >= thr + 0.1).length;
  hit('multiple_people', people >= 2 ? { score: 0.8, label: people + ' people' } : null);
}
function hit(type, d, instant) {
  const M = PM.m;
  const arr = M.hits[type] || (M.hits[type] = []);
  const now = Date.now();
  while (arr.length && now - arr[0] > 6000) arr.shift();
  if (!d) return;
  arr.push(now);
  if (instant || arr.length >= 2) { fire(type, d.score, d.label + ' ' + Math.round(d.score * 100) + '%'); arr.length = 0; }
}
async function pmIdentity() {
  const M = PM.m; if (!M || M.pendingId || Date.now() < M.idAt || !PAI.ready().identity || M.lastFaces !== 1) return;
  M.idAt = Date.now() + 45000 + Math.random() * 20000; // irregular, so it can't be timed
  try {
    const d = await PAI.descriptor(M.video);
    if (d && PM.m === M) M.pendingId = { d: d.d, img: PAI.grab(M.video, 480, 0.7) };
  } catch (e) { /* next time */ }
}
async function pmBeat() {
  const M = PM.m; if (!M) return;
  const a = S.attempt;
  const stats = Object.assign({}, M.stats, {
    ai: PAI.ready().face ? (PAI.ready().delegate || 'on') : 'off', answered: a ? Object.keys(a.answers).length : 0, total: a ? a.questions.length : 0, remainingMs: a ? Math.max(0, a.deadline - Date.now()) : 0
  });
  const body = { sid: M.sid, stats };
  if (M.pendingId) body.identity = M.pendingId;
  if (M.thumb) body.thumb = PAI.grab(M.video, M.thumb === 'large' ? 480 : 220, 0.6);
  try {
    const r = await call('proctorBeat', body);
    if (PM.m !== M) return;
    M.pendingId = null;
    // A proctor just started watching: send a picture right away rather than at the next beat.
    M.beatMs = r.thumb && !body.thumb ? 700 : r.beatMs || 10000;
    M.thumb = r.thumb || '';
    (r.commands || []).forEach(pmCommand);
    if (r.status && r.status !== 'active') { pmEnded(r.status); return; }
  } catch (e) { if (/PROCTOR_CHECKIN/.test(e.message)) { pmCheckinAgain(); return; } }
  pmFlush();
  if (PM.m === M) M.beatTimer = setTimeout(pmBeat, M.beatMs);
}
function pmCommand(c) {
  if (c.type === 'terminate') { pmEnded('terminated', c.text); return; }
  if (c.type === 'message' || c.type === 'warn') {
    openModal('<div class="modal-body" style="padding-top:1.5rem"><div class="confirm-icon' + (c.type === 'warn' ? ' danger' : '') + '">' + icon(c.type === 'warn' ? 'alert' : 'message') + '</div>' +
      '<h2 style="font-size:1.15rem">' + (c.type === 'warn' ? 'Warning from your proctor' : 'Message from your proctor') + '</h2><p style="white-space:pre-wrap">' + esc(c.text) + '</p>' +
      '<p class="xs muted">' + esc(c.from || '') + '</p><div class="form-actions"><button class="btn btn-primary" data-act="backToQuiz">Back to the exam</button></div></div>', 'narrow');
  }
}
function pmEnded(status, text) {
  const a = S.attempt;
  pmStop();
  if (!a) return;
  const id = a.id;
  stopExam();
  restoreApp('/review/' + id, status === 'terminated'
    ? { text: 'Your exam was ended by proctoring' + (text ? ': ' + text : '') + '. Your answers so far were submitted.', kind: 'err' }
    : { text: 'This attempt has been closed.', kind: 'warn' });
}
/** Proctoring lost contact (reload, camera gone for long, server restarted): go back through check-in. */
function pmCheckinAgain() {
  const M = PM.m;
  const quizId = (M && M.quizId) || (S.attempt && S.attempt.quizId);
  pmStop();
  if (S.attempt) stopExam();
  restoreApp('/assessment/checkin/' + quizId, { text: 'Proctoring was interrupted. Check in again to continue — your saved answers and the timer are kept.', kind: 'warn' });
}
function pmStatus() {
  const M = PM.m, el = $('#pmStatus'); if (!M || !el) return;
  const s = M.stats;
  const dot = (ok, ico, title) => '<span class="pm-dot ' + (ok ? 'ok' : 'bad') + '" title="' + esc(title) + '">' + icon(ico, 'i-sm') + '</span>';
  el.innerHTML = dot(s.cam, 'video', s.cam ? 'Camera on' : 'Camera off') + dot(s.faces === 1, 'user', s.faces === 1 ? 'Face in view' : s.faces ? 'More than one face' : 'No face') +
    dot(!s.away && !s.gaze, 'eye', s.away || s.gaze ? 'Looking away' : 'Eyes on screen') +
    (M.mic ? dot(s.mic, 'mic', s.mic ? 'Microphone on' : 'Microphone off') + '<span class="meter sm"><i style="width:' + Math.round((s.voice || 0) * 100) + '%"></i></span>' : '') +
    (M.policy.screen ? dot(s.screen, 'monitor', s.screen ? 'Screen shared' : 'Screen not shared') : '') +
    '<span class="pm-ai" title="On-device AI">' + icon('sparkle', 'i-sm') + (PAI.ready().face ? 'AI' : 'AI off') + '</span>';
}
function pmReconnect(what) {
  if (!PM.m) return;
  openModal('<div class="modal-body" style="padding-top:1.5rem"><div class="confirm-icon danger">' + icon(what === 'screen' ? 'monitor' : 'video') + '</div>' +
    '<h2 style="font-size:1.15rem">' + (what === 'screen' ? 'Screen sharing stopped' : 'Your camera stopped') + '</h2><p class="muted">This has been recorded. Reconnect to continue the exam under proctoring.</p>' +
    '<div class="form-actions"><button class="btn btn-primary" data-act="pmReconnect" data-what="' + what + '">' + icon('refresh') + (what === 'screen' ? 'Share entire screen' : 'Turn the camera back on') + '</button></div></div>', 'narrow');
}
ACT.pmReconnect = (d, btn) => busy(btn, async () => {
  const M = PM.m; if (!M) return;
  if (d.what === 'screen') {
    const s = await getScreen();
    M.screen = s; if (!M.svideo) M.svideo = document.createElement('video'); playInto(M.svideo, s);
    s.getVideoTracks()[0].addEventListener('ended', () => { fire('screen_share_stopped', 1, '', ''); pmReconnect('screen'); });
  } else {
    let s;
    try { s = await getCamera(); } catch (e) { toast(mediaError(e, 'camera'), 'err'); return; }
    stopStream(M.cam); M.cam = s; playInto(M.video, s);
    s.getVideoTracks()[0].addEventListener('ended', () => { fire('camera_off', 1, 'camera stopped'); pmReconnect('camera'); });
  }
  closeModal();
  if (!document.fullscreenElement) enterFullscreen();
});
ACT.pmMin = () => { const p = $('#pmPip'); if (p) p.classList.toggle('min'); };
ACT.pmChat = () => {
  openModal(modalHead('Message your proctor', 'They see it right away in the live monitor.') + '<div class="modal-body"><form data-form="pmSay" novalidate>' +
    '<textarea name="text" maxlength="500" style="min-height:100px" placeholder="e.g. My internet disconnected for a moment." autofocus></textarea>' +
    '<div class="form-actions"><button class="btn" type="button" data-act="backToQuiz">Cancel</button><button class="btn btn-primary" type="submit">' + icon('send') + 'Send</button></div></form></div>', 'narrow');
};
FORMS.pmSay = (f, btn) => busy(btn, async () => {
  const M = PM.m; if (!M) return;
  await call('proctorSay', { sid: M.sid, text: f.elements.text.value });
  closeModal(); toast('Sent to your proctor.');
  if (!document.fullscreenElement) enterFullscreen();
});
