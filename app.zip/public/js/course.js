'use strict';
/* =====================================================================
   COURSE PAGE
   ===================================================================== */
function editMode() { return !!(S.course && S.course.editor && prefs.get('editMode', false)); }

async function viewCourse(id, tab, params) {
  tab = tab || 'content';
  const data = await call('getCourse', { courseId: id });
  S.course = data;
  S.ctx = { courseId: id };
  const c = data.course;
  const tabs = ['content', 'participants', 'grades', 'announcements'].concat(data.editor ? ['analytics', 'settings'] : []);
  if (tabs.indexOf(tab) < 0) tab = 'content';
  let body, after;
  if (tab === 'content') body = courseContent(data);
  else if (tab === 'participants') body = await courseParticipants(c, data.editor);
  else if (tab === 'grades') body = await courseGrades(c, data.editor);
  else if (tab === 'announcements') body = await courseAnnouncements(c);
  else if (tab === 'analytics') { const a = await courseAnalyticsTab(c, params); body = a.html; after = a.after; }
  else body = courseSettings(c);
  return { title: c.shortname + (tab === 'analytics' ? ' · Analytics' : ''), html: courseHero(data) + courseTabs(c, tab, data.editor) + body, after };
}

/** The learner's next unfinished activity, in course order. */
function nextUp(data) {
  for (const s of data.sections) {
    const m = s.modules.find((x) => x.type !== 'label' && x.tracked && !x.done && x.visible);
    if (m) return { m, section: s };
  }
  return null;
}
function courseHero(data) {
  const c = data.course;
  const p = c.progress;
  const next = !data.editor ? nextUp(data) : null;
  const dates = c.startDate || c.endDate ? '<span>' + icon('calendar', 'i-sm') + ' ' + esc(fmtDate(c.startDate)) + ' – ' + esc(c.endDate ? fmtDate(c.endDate) : 'ongoing') + '</span>' : '';
  return '<section class="course-hero cc-' + esc(c.color) + '"><div class="course-hero-top"><div>' +
    crumbs([['My courses', '/courses'], [c.category || 'Course']]) +
    '<div class="row-wrap"><span class="chip">' + esc(c.shortname) + '</span>' + (!c.visible ? badge('Hidden from students', 'warning', 'eyeOff') : '') + '</div>' +
    '<h1>' + esc(c.fullname) + '</h1><div class="meta">' +
    (c.teachers.length ? '<span>' + icon('user', 'i-sm') + ' ' + esc(c.teachers.join(', ')) + '</span>' : '') + dates +
    (c.students != null ? '<span>' + icon('users', 'i-sm') + ' ' + plural(c.students, 'student') + '</span>' : '') +
    (data.editor ? '<span>' + icon('shield', 'i-sm') + ' ' + (data.role === 'admin' ? 'Administrator' : 'You teach this course') + '</span>' : '') + '</div></div>' +
    (p ? '<div class="hero-ring">' + ring(p.percent, 58) + '<div><small>Your progress</small><strong>' + p.done + ' of ' + p.total + ' complete</strong>' +
      '<small>' + (p.total - p.done ? plural(p.total - p.done, 'activity', 'activities') + ' to go' : 'Course complete') + '</small></div></div>' : '') +
    '</div>' +
    (next ? '<div class="course-next"><div class="cn-text"><small>Up next · ' + esc(next.section.title) + '</small><b>' + esc(next.m.title) + '</b></div>' +
      '<a class="btn btn-primary" href="#/mod/' + esc(next.m.id) + '">' + icon('play') + (p && p.done ? 'Continue' : 'Start') + '</a></div>' : '') +
    (data.editor ? '<div class="course-hero-actions"><label class="switch"><input type="checkbox" data-change="toggleEdit"' + (editMode() ? ' checked' : '') + '><span class="track"></span>Edit mode</label>' +
      '<div class="spacer"></div><button class="btn btn-sm" data-act="addSection">' + icon('plus') + 'Add section</button>' +
      '<a class="btn btn-sm" href="#/course/' + esc(c.id) + '/participants">' + icon('userPlus') + 'Enrol users</a></div>' : '') +
    '</section>';
}
function courseTabs(c, tab, editor) {
  const t = [['content', 'Course', 'book'], ['participants', 'Participants', 'users'], ['grades', 'Grades', 'chart'], ['announcements', 'Announcements', 'megaphone']];
  if (editor) t.push(['analytics', 'Analytics', 'trending'], ['settings', 'Settings', 'settings']);
  return '<nav class="tabs">' + t.map(([k, l, ico]) => '<a class="tab' + (tab === k ? ' active' : '') + '" href="#/course/' + esc(c.id) + (k === 'content' ? '' : '/' + k) + '">' + icon(ico, 'i-sm') + l + '</a>').join('') + '</nav>';
}

function courseContent(data) {
  const em = editMode();
  const sections = data.sections.filter((s) => em || s.modules.length || s.summary || data.editor);
  const total = data.sections.reduce((a, s) => a + s.modules.length, 0);
  const index = '<aside class="card course-index"><h4>Course index</h4>' + data.sections.map((s) =>
    '<a class="ci-link" role="button" tabindex="0" data-act="jumpSection" data-id="sec-' + esc(s.id) + '">' + icon('folder', 'i-sm') + '<span style="min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(s.title) + '</span><span class="n">' + s.modules.length + '</span></a>' +
    (s.modules.length ? '<div class="ci-sub">' + s.modules.filter((m) => m.type !== 'label').map((m) =>
      '<a class="ci-link" href="#/mod/' + esc(m.id) + '"><span class="dotc' + (m.done ? ' done' : '') + '"></span><span style="min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(m.title) + '</span></a>').join('') + '</div>' : '')).join('') + '</aside>';
  let main;
  if (!total && !data.editor) main = emptyState('layers', 'Nothing here yet', 'Your teacher has not added any activities to this course yet.');
  else {
    // Number activities through the whole course: 01, 02, 03…
    let n = 0;
    data.sections.forEach((s) => s.modules.forEach((m) => { if (m.type !== 'label') m.num = ++n; }));
    main = (data.editor && !total && !em ? notice('This course is empty. Turn on <b>Edit mode</b> to add activities and resources.', '', 'sparkles') : '') +
      sections.map((s) => sectionHtml(s, data, em)).join('');
  }
  return '<div class="course-layout">' + index + '<div>' + main + '</div></div>';
}

function sectionHtml(sec, data, em) {
  const general = Number(sec.position) === 0;
  const bar = em ? '<div class="edit-bar">' +
    (!general ? '<button class="btn-icon sm" title="Move up" data-act="moveSection" data-id="' + esc(sec.id) + '" data-dir="-1">' + icon('up') + '</button>' +
      '<button class="btn-icon sm" title="Move down" data-act="moveSection" data-id="' + esc(sec.id) + '" data-dir="1">' + icon('down') + '</button>' : '') +
    '<button class="btn-icon sm" title="Edit section" data-act="editSection" data-id="' + esc(sec.id) + '">' + icon('edit') + '</button>' +
    (!general ? '<button class="btn-icon sm danger" title="Delete section" data-act="delSection" data-id="' + esc(sec.id) + '">' + icon('trash') + '</button>' : '') + '</div>' : '';
  const list = sec.modules.length ? '<ul class="act-list">' + sec.modules.map((m) => actHtml(m, em)).join('') + '</ul>'
    : (em ? '' : '<p class="small muted" style="padding:0 1.25rem 1rem 3.2rem">No activities in this section yet.</p>');
  return '<section class="card csection" id="sec-' + esc(sec.id) + '"><div class="csection-head">' +
    '<button class="btn-icon sm collapse-btn" data-act="collapse" aria-label="Collapse section">' + icon('down') + '</button>' +
    '<h2>' + esc(sec.title) + '</h2><span class="count">' + plural(sec.modules.length, 'item') + '</span>' + bar + '</div>' +
    '<div class="csection-body">' + (sec.summary ? '<div class="csection-summary prose">' + md(sec.summary) + '</div>' : '') + list +
    (em ? '<button class="add-act" data-act="addActivity" data-section="' + esc(sec.id) + '">' + icon('plus') + 'Add an activity or resource</button>' : '') + '</div></section>';
}

function modEditBar(m) {
  return '<div class="edit-bar">' +
    '<button class="btn-icon sm" title="Move up" data-act="moveMod" data-id="' + esc(m.id) + '" data-dir="-1">' + icon('up') + '</button>' +
    '<button class="btn-icon sm" title="Move down" data-act="moveMod" data-id="' + esc(m.id) + '" data-dir="1">' + icon('down') + '</button>' +
    '<button class="btn-icon sm" title="' + (m.visible ? 'Hide from students' : 'Show to students') + '" data-act="toggleVis" data-id="' + esc(m.id) + '" data-visible="' + (m.visible ? '1' : '') + '">' + icon(m.visible ? 'eye' : 'eyeOff') + '</button>' +
    '<button class="btn-icon sm" title="Edit settings" data-act="editMod" data-id="' + esc(m.id) + '">' + icon('edit') + '</button>' +
    '<button class="btn-icon sm danger" title="Delete" data-act="delMod" data-id="' + esc(m.id) + '" data-title="' + esc(m.title) + '">' + icon('trash') + '</button></div>';
}
function completionControl(m) {
  if (!m.tracked) return '';
  if (m.manual) return '<button class="done-btn' + (m.done ? ' on' : '') + '" data-act="toggleDone" data-id="' + esc(m.id) + '">' + icon(m.done ? 'check' : 'circle', 'i-sm') + (m.done ? 'Done' : 'Mark as done') + '</button>';
  const how = { assignment: 'submit it', quiz: 'finish an attempt', forum: 'post in it' }[m.type] || 'complete it';
  return '<span class="done-auto' + (m.done ? ' on' : '') + '" title="Completed automatically when you ' + how + '">' + icon(m.done ? 'checkCircle' : 'circle', 'i-sm') + (m.done ? 'Done' : 'To do') + '</span>';
}
function actHtml(m, em) {
  const meta = MOD[m.type] || MOD.page;
  const now = Date.now();
  if (m.type === 'label') {
    return '<li class="act' + (m.visible ? '' : ' is-hidden') + '"><div class="act-label" style="flex:1"><div class="prose">' + md(m.description) + '</div>' +
      (!m.visible ? '<div style="margin-top:.4rem">' + badge('Hidden from students', 'warning', 'eyeOff') + '</div>' : '') + '</div>' +
      (em ? '<div class="act-side">' + modEditBar(m) + '</div>' : '') + '</li>';
  }
  const bits = [];
  if (m.type === 'assignment' && m.dueAt) {
    bits.push('<span>' + icon('clock') + ' Due ' + esc(fmt(m.dueAt)) + '</span>');
    if (m.tracked && !m.done && now > m.dueAt && (!m.cutoffAt || now < m.cutoffAt)) bits.push(badge('Overdue', 'danger'));
  }
  if (m.type === 'quiz') {
    if (m.openAt && m.openAt > now) bits.push('<span>' + icon('calendar') + ' Opens ' + esc(fmt(m.openAt)) + '</span>');
    if (m.closeAt) bits.push('<span>' + icon('clock') + ' ' + (m.closeAt < now ? 'Closed ' : 'Closes ') + esc(fmt(m.closeAt)) + '</span>');
    if (m.durationMin) bits.push('<span>' + icon('history') + ' ' + m.durationMin + ' min</span>');
  }
  if (m.toGrade) bits.push(badge(m.toGrade + ' to grade', 'warning', 'assignment'));
  if (!m.visible) bits.push(badge('Hidden from students', 'warning', 'eyeOff'));
  return '<li class="act tone-' + meta.tone + (m.visible ? '' : ' is-hidden') + (m.done ? ' is-done' : '') + '"><a class="act-link" href="#/mod/' + esc(m.id) + '">' + modTile(m.type) +
    '<span class="act-text"><span class="act-type">' + (m.num ? '<span class="tnum">' + String(m.num).padStart(2, '0') + '</span> · ' : '') + meta.label + '</span><span class="act-title">' + esc(m.title) + '</span>' +
    (bits.length ? '<span class="act-meta">' + bits.join('') + '</span>' : '') + '</span></a>' +
    '<div class="act-side">' + completionControl(m) + (em ? modEditBar(m) : '') + '</div></li>';
}

/* ---------- content actions ---------- */
ACT.collapse = (d, el) => el.closest('.csection').classList.toggle('collapsed');
ACT.jumpSection = (d) => { const el = document.getElementById(d.id); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); };
ACT.toggleEdit = (d, el) => { prefs.set('editMode', !!el.checked); refresh(); };
ACT.toggleDone = (d, btn) => busy(btn, async () => { const r = await call('toggleCompletion', { moduleId: d.id }); toast(r.done ? 'Marked as done.' : 'Marked as not done.'); await refresh(); });
ACT.moveSection = (d, btn) => busy(btn, async () => { await call('moveSection', { id: d.id, dir: Number(d.dir) }); await refresh(); });
ACT.moveMod = (d, btn) => busy(btn, async () => { await call('moveModule', { id: d.id, dir: Number(d.dir) }); await refresh(); });
ACT.toggleVis = (d, btn) => busy(btn, async () => {
  await call('setModuleVisible', { id: d.id, visible: !d.visible });
  toast(d.visible ? 'Hidden from students.' : 'Now visible to students.');
  await refresh();
});
ACT.delMod = async (d) => {
  if (!await confirmBox('Delete “' + d.title + '”?', '<p>The activity will be removed from the course. Submissions and attempts stay in the database.</p>', 'Delete', true)) return;
  busy(null, async () => {
    const onModule = /^\/mod\//.test(currentPath());
    await call('deleteModule', { id: d.id });
    toast('Deleted.');
    if (onModule && S.course) go('/course/' + S.course.course.id); else refresh();
  });
};
ACT.addSection = () => sectionForm({});
ACT.editSection = (d) => sectionForm(S.course.sections.find((s) => s.id === d.id));
function sectionForm(sec) {
  formModal(sec.id ? 'Edit section' : 'Add section', sec.id ? '' : 'Sections group your activities by topic or week.', 'section',
    '<input type="hidden" name="id" value="' + esc(sec.id || '') + '">' +
    field('Section name', '<input type="text" name="title" maxlength="200" value="' + esc(sec.title || '') + '" autofocus>') +
    field('Summary <span class="muted">(optional)</span>', '<textarea name="summary" maxlength="10000" style="min-height:100px">' + esc(sec.summary || '') + '</textarea>' + mdHelp()),
    'Save section');
}
FORMS.section = (f, btn) => busy(btn, async () => {
  await call('saveSection', { courseId: S.course.course.id, id: f.elements.id.value, title: f.elements.title.value, summary: f.elements.summary.value });
  closeModal(); toast('Section saved.');
  if (!editMode()) prefs.set('editMode', true);
  await refresh();
});
ACT.delSection = async (d) => {
  if (!await confirmBox('Delete this section?', '<p>The section and every activity in it will be removed.</p>', 'Delete section', true)) return;
  busy(null, async () => { await call('deleteSection', { id: d.id }); toast('Section deleted.'); await refresh(); });
};

/* ---------- activity chooser & forms ---------- */
ACT.addActivity = (d) => {
  const groups = ['Activities', 'Resources'];
  openModal(modalHead('Add an activity or resource', 'Choose what to add to this section.') + '<div class="modal-body">' +
    groups.map((g) => '<div class="chooser-group">' + g + '</div><div class="chooser" style="margin-bottom:1.25rem">' +
      Object.keys(MOD).filter((k) => MOD[k].group === g).map((k) =>
        '<button class="chooser-item tone-' + MOD[k].tone + '" data-act="chooseType" data-type="' + k + '" data-section="' + esc(d.section) + '">' + modTile(k) +
        '<b>' + MOD[k].label + '</b><span>' + MOD[k].desc + '</span></button>').join('') + '</div>').join('') + '</div>', 'wide');
};
ACT.chooseType = (d) => {
  if (d.type === 'quiz') {
    quizForm({ published: true, reviewMode: 'score', shuffleQuestions: true, shuffleOptions: true, maxAttempts: 1, durationMin: 30 },
      { courseId: S.course.course.id, sectionId: d.section });
  } else moduleForm(d.type, { sectionId: d.section, visible: true });
};
ACT.editMod = (d, btn) => busy(btn, async () => {
  const r = await call('getModule', { id: d.id });
  if (!S.course || S.course.course.id !== r.course.id) S.course = await call('getCourse', { courseId: r.course.id });
  if (r.module.type === 'quiz') {
    const q = await call('getQuestions', { quizId: r.module.quizId });
    quizForm(q.quiz, {});
  } else moduleForm(r.module.type, Object.assign({}, r.module, { file: r.file }));
});

function moduleForm(type, m) {
  const meta = MOD[type];
  const secs = S.course.sections;
  let f = '<input type="hidden" name="id" value="' + esc(m.id || '') + '"><input type="hidden" name="type" value="' + type + '">';
  if (type === 'label') {
    f += field('Text shown on the course page', '<textarea name="description" maxlength="20000" style="min-height:160px" autofocus>' + esc(m.description || '') + '</textarea>' + mdHelp());
  } else {
    f += field('Name', '<input type="text" name="title" maxlength="200" value="' + esc(m.title || '') + '" autofocus>');
    f += field(type === 'assignment' ? 'Instructions' : type === 'forum' ? 'Forum introduction <span class="muted">(optional)</span>' : 'Description <span class="muted">(optional)</span>',
      '<textarea name="description" maxlength="20000" style="min-height:' + (type === 'assignment' ? 150 : 90) + 'px">' + esc(m.description || '') + '</textarea>' + mdHelp());
  }
  if (type === 'page') f += field('Page content', '<textarea name="content" maxlength="200000" style="min-height:280px">' + esc(m.content || '') + '</textarea>' + mdHelp());
  if (type === 'url') f += field('External URL', '<input type="url" name="url" maxlength="2000" placeholder="https://" value="' + esc(m.url || '') + '">', 'Opens in a new tab.');
  if (type === 'file') {
    f += '<div class="field"><span class="label">File</span><input type="hidden" name="fileId" value="' + esc(m.file ? m.file.id : '') + '">' +
      '<div id="modFileBox" class="file-list">' + (m.file ? fileChip(m.file) : '') + '</div>' +
      '<label class="dropzone" style="margin-top:.6rem">' + icon('upload') + '<b>' + (m.file ? 'Replace the file' : 'Choose a file to upload') + '</b><span class="small">PDF, slides, documents, images — up to 10 MB</span>' +
      '<input type="file" data-change="modFile"></label></div>';
  }
  if (type === 'assignment') {
    f += '<fieldset class="fieldset"><legend>Availability</legend><div class="form-grid">' +
      field('Due date', '<input type="datetime-local" name="dueAt" value="' + toLocalInput(m.dueAt) + '">', 'Late submissions are marked late.') +
      field('Cut-off date', '<input type="datetime-local" name="cutoffAt" value="' + toLocalInput(m.cutoffAt) + '">', 'No submissions after this. Optional.') + '</div></fieldset>' +
      '<fieldset class="fieldset"><legend>Submissions & grading</legend>' +
      check('subText', 'Online text', m.subText !== false, 'Students type or paste their answer.') +
      check('subFile', 'File submissions', m.subFile !== false, 'Up to 5 files, 10 MB each.') +
      field('Maximum grade', '<input type="number" name="maxGrade" min="1" max="1000" step="any" value="' + (m.maxGrade || 100) + '" style="max-width:160px">') + '</fieldset>';
  }
  if (m.id) f += field('Section', '<select name="sectionId">' + secs.map((s) => '<option value="' + esc(s.id) + '"' + (s.id === m.sectionId ? ' selected' : '') + '>' + esc(s.title) + '</option>').join('') + '</select>');
  else f += '<input type="hidden" name="sectionId" value="' + esc(m.sectionId) + '">';
  f += check('visible', 'Visible to students', m.visible !== false);
  formModal((m.id ? 'Edit ' : 'Add ') + meta.label.toLowerCase(), meta.desc, 'module', f, m.id ? 'Save changes' : 'Add ' + meta.label.toLowerCase(), 'wide');
}
ACT.modFile = (d, input) => {
  const file = input.files[0];
  if (!file) return;
  const box = $('#modFileBox');
  const form = input.form || input.closest('form');
  box.innerHTML = '<span class="small muted">Uploading ' + esc(file.name) + '…</span>';
  uploadFile(file).then((r) => { form.elements.fileId.value = r.id; box.innerHTML = fileChip(r); })
    .catch((e) => { box.innerHTML = ''; toast(e.message, 'err'); });
  input.value = '';
};
FORMS.module = (f, btn) => busy(btn, async () => {
  const e = f.elements;
  const type = e.type.value;
  const p = {
    courseId: S.course.course.id, id: e.id.value, type, sectionId: e.sectionId.value,
    title: e.title ? e.title.value : '', description: e.description.value, visible: e.visible.checked
  };
  if (type === 'page') p.content = e.content.value;
  if (type === 'url') p.url = e.url.value.trim();
  if (type === 'file') { p.fileId = e.fileId.value; if (!p.fileId) throw new Error('Upload a file first.'); }
  if (type === 'assignment') {
    Object.assign(p, { dueAt: fromLocalInput(e.dueAt.value), cutoffAt: fromLocalInput(e.cutoffAt.value), maxGrade: e.maxGrade.value, subText: e.subText.checked, subFile: e.subFile.checked });
  }
  await call('saveModule', p);
  closeModal();
  toast(MOD[type].label + (p.id ? ' updated.' : ' added.'));
  await refresh();
});

/* =====================================================================
   COURSE CREATE / SETTINGS
   ===================================================================== */
function courseFields(c) {
  return '<input type="hidden" name="id" value="' + esc(c.id || '') + '">' +
    field('Course full name', '<input type="text" name="fullname" maxlength="200" value="' + esc(c.fullname || '') + '" placeholder="e.g. Business Law — Semester 3" autofocus>') +
    '<div class="form-grid">' + field('Short name', '<input type="text" name="shortname" maxlength="40" value="' + esc(c.shortname || '') + '" placeholder="e.g. BLAW301">', 'Shown on cards and in breadcrumbs.') +
    field('Category', '<input type="text" name="category" maxlength="100" value="' + esc(c.category || '') + '" placeholder="e.g. Commerce">') + '</div>' +
    field('Summary', '<textarea name="summary" maxlength="5000" style="min-height:90px">' + esc(c.summary || '') + '</textarea>' + mdHelp()) +
    '<div class="form-grid">' + field('Start date', '<input type="date" name="startDate" value="' + toDateInput(c.startDate) + '">') +
    field('End date', '<input type="date" name="endDate" value="' + toDateInput(c.endDate) + '">') + '</div>' +
    field('Course colour', '<div class="swatches">' + COURSE_COLORS.map((k) => '<label><input type="radio" name="color" value="' + k + '"' + (k === (c.color || 'indigo') ? ' checked' : '') + '><span class="cswatch cc-' + k + '" title="' + k + '"></span></label>').join('') + '</div>') +
    '<fieldset class="fieldset"><legend>Visibility & enrolment</legend>' +
    check('visible', 'Course visible to students', c.visible !== false) +
    check('selfEnrol', 'Allow students to enrol themselves from the catalogue', !!c.selfEnrol) +
    field('Enrolment key <span class="muted">(optional)</span>', '<input type="text" name="enrolKey" maxlength="50" autocomplete="off" value="' + esc(c.enrolKey || '') + '">', 'If set, students need this key to self-enrol.') + '</fieldset>' +
    (c.id ? '' : field('Number of topic sections', '<input type="number" name="sections" min="0" max="12" value="4" style="max-width:140px">', 'Plus a General section at the top. You can add more later.'));
}
function readCourseForm(f) {
  const e = f.elements;
  return {
    id: e.id.value, fullname: e.fullname.value, shortname: e.shortname.value, category: e.category.value, summary: e.summary.value,
    startDate: fromDateInput(e.startDate.value), endDate: fromDateInput(e.endDate.value),
    color: (f.querySelector('input[name=color]:checked') || {}).value || 'indigo',
    visible: e.visible.checked, selfEnrol: e.selfEnrol.checked, enrolKey: e.enrolKey.value, sections: e.sections ? e.sections.value : 0
  };
}
ACT.newCourse = () => formModal('Create a course', 'Set up the basics — you can change everything later.', 'course',
  courseFields({ color: COURSE_COLORS[Math.floor(Math.random() * COURSE_COLORS.length)], visible: true }), 'Create course', 'wide');
FORMS.course = (f, btn) => busy(btn, async () => {
  const p = readCourseForm(f);
  const r = await call('saveCourse', p);
  closeModal();
  if (p.id) { toast('Course settings saved.'); await refresh(); return; }
  prefs.set('editMode', true);
  toast('Course created. Add your first activities.');
  go('/course/' + r.id);
});
function courseSettings(c) {
  return '<div class="grid" style="max-width:860px"><div class="card"><div class="card-head"><span class="i-tile sm tone-indigo">' + icon('settings') + '</span><h2>Course settings</h2></div>' +
    '<div class="card-body"><form data-form="course" novalidate>' + courseFields(c) +
    '<div class="form-actions"><button class="btn btn-primary" type="submit">Save changes</button></div></form></div></div>' +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-red">' + icon('alert') + '</span><h2>Danger zone</h2></div>' +
    '<div class="card-body row-wrap"><div style="flex:1;min-width:220px"><b>Delete this course</b><p class="small muted" style="margin:0">Hides the course from everyone. Student work stays in the database.</p></div>' +
    '<button class="btn btn-danger" data-act="delCourse" data-id="' + esc(c.id) + '">' + icon('trash') + 'Delete course</button></div></div></div>';
}
ACT.delCourse = async (d) => {
  if (!await confirmBox('Delete this course?', '<p>It will disappear for everyone, including students. This can only be undone by editing the database.</p>', 'Delete course', true)) return;
  busy(null, async () => { await call('deleteCourse', { id: d.id }); toast('Course deleted.'); go('/courses'); });
};

/* =====================================================================
   PARTICIPANTS
   ===================================================================== */
async function courseParticipants(c, editor) {
  const r = await call('participants', { courseId: c.id });
  S.participants = r;
  const teachers = r.participants.filter((p) => p.role === 'teacher').length;
  const rows = r.participants.map((p) =>
    '<tr data-text="' + esc((p.name + ' ' + (p.username || '') + ' ' + p.batch).toLowerCase()) + '"><td><div class="cell-user">' + avatar(p.name) + '<div><b>' + esc(p.name) + '</b>' +
    (p.username ? '<span>@' + esc(p.username) + '</span>' : '') + '</div></div></td>' +
    '<td>' + (p.role === 'teacher' ? badge(p.owner ? 'Teacher · owner' : 'Teacher', 'primary', 'cap') : badge('Student', '', 'user')) + '</td>' +
    '<td>' + esc(p.batch || '—') + '</td>' +
    (editor ? '<td class="small">' + esc(p.email || '—') + '</td><td class="small muted">' + (p.lastLogin ? esc(rel(p.lastLogin)) : 'Never') + '</td>' +
      '<td class="actions">' + (!p.owner && (S.me.role === 'admin' || p.role === 'student') ? '<button class="btn btn-sm btn-ghost btn-danger" data-act="unenrol" data-id="' + esc(p.userId) + '" data-name="' + esc(p.name) + '">' + icon('x', 'i-sm') + 'Remove</button>' : '') + '</td>' : '') +
    '</tr>').join('');
  return '<div class="card"><div class="card-head"><span class="i-tile sm tone-blue">' + icon('users') + '</span><div><h2>Participants</h2><div class="xs muted">' +
    plural(r.participants.length - teachers, 'student') + ' · ' + plural(teachers, 'teacher') + '</div></div><div class="spacer"></div>' +
    '<div class="search-box" style="width:min(240px,40vw)">' + icon('search') + '<input type="search" placeholder="Filter" data-input="filterRows" data-target="#partTable" aria-label="Filter participants"></div>' +
    (editor ? '<button class="btn btn-primary btn-sm" data-act="enrolUsers">' + icon('userPlus') + 'Enrol users</button>' : '') + '</div>' +
    (r.participants.length ? '<div class="table-wrap"><table class="table" id="partTable"><thead><tr><th>Name</th><th>Role</th><th>Batch</th>' + (editor ? '<th>Email</th><th>Last access</th><th></th>' : '') + '</tr></thead><tbody>' + rows + '</tbody></table></div>'
      : '<div class="card-body">' + emptyState('users', 'No participants yet', 'Enrol students to give them access.', '', false) + '</div>') + '</div>';
}
INPUTS.filterRows = (el) => {
  const q = el.value.trim().toLowerCase();
  $$(el.dataset.target + ' tbody tr[data-text]').forEach((tr) => tr.classList.toggle('hidden', !!q && tr.dataset.text.indexOf(q) < 0));
};
ACT.enrolUsers = () => {
  S.enrolPick = new Set();
  const batches = (S.participants && S.participants.batches) || [];
  openModal(modalHead('Enrol users', 'Add people to ' + esc(S.course.course.fullname) + '.') + '<div class="modal-body">' +
    '<div class="search-box" style="margin-bottom:.75rem">' + icon('search') + '<input type="search" id="enrolQ" placeholder="Search by name, username or batch" data-input="enrolSearch" data-delay="200" autofocus></div>' +
    '<div id="enrolResults" class="card" style="max-height:320px;overflow-y:auto"><div class="card-pad small muted">Loading…</div></div>' +
    '<div class="form-actions" style="position:static;margin:1rem 0 0;padding:1rem 0 0;background:none;border-radius:0">' +
    '<span class="small muted" id="enrolCount" style="margin-right:auto">No one selected</span><button class="btn" data-act="close">Cancel</button>' +
    '<button class="btn btn-primary" data-act="enrolSelected" id="enrolBtn" disabled>' + icon('userPlus') + 'Enrol selected</button></div>' +
    (batches.length ? '<hr><form data-form="enrolBatch" class="row-wrap"><div style="flex:1;min-width:200px"><b class="small">Enrol a whole batch</b><div class="xs muted">Adds every active student in the batch.</div></div>' +
      '<select name="batch" style="width:auto;min-width:200px">' + batches.map((b) => '<option>' + esc(b) + '</option>').join('') + '</select>' +
      '<button class="btn btn-soft" type="submit">' + icon('users') + 'Enrol batch</button></form>' : '') +
    '</div>', 'wide');
  INPUTS.enrolSearch({ value: '' });
};
INPUTS.enrolSearch = async (el) => {
  const box = $('#enrolResults');
  if (!box) return;
  try {
    const list = await call('searchUsers', { courseId: S.course.course.id, q: el.value || '' });
    if (!$('#enrolResults')) return;
    box.innerHTML = list.length ? list.map((u) =>
      '<label class="disc-row" style="cursor:pointer"><input type="checkbox" data-change="enrolPick" data-id="' + esc(u.id) + '"' + (S.enrolPick.has(u.id) ? ' checked' : '') + ' style="width:16px;height:16px;accent-color:var(--primary)">' +
      avatar(u.name, 'sm') + '<div class="dr-main"><div class="dr-title">' + esc(u.name) + '</div><div class="dr-meta">@' + esc(u.username) + (u.batch ? ' · ' + esc(u.batch) : '') + '</div></div>' + badge(u.role, u.role === 'student' ? '' : 'primary') + '</label>').join('')
      : '<div class="card-pad small muted">No matching people who are not already enrolled.</div>';
  } catch (e) { if (!isExpired(e)) box.innerHTML = '<div class="card-pad small muted">' + esc(e.message) + '</div>'; }
};
ACT.enrolPick = (d, el) => {
  if (el.checked) S.enrolPick.add(d.id); else S.enrolPick.delete(d.id);
  const n = S.enrolPick.size;
  $('#enrolCount').textContent = n ? n + ' selected' : 'No one selected';
  $('#enrolBtn').disabled = !n;
};
ACT.enrolSelected = (d, btn) => busy(btn, async () => {
  const r = await call('enrolUsers', { courseId: S.course.course.id, userIds: Array.from(S.enrolPick) });
  closeModal(); toast(plural(r.added, 'person', 'people') + ' enrolled.'); await refresh();
});
FORMS.enrolBatch = (f, btn) => busy(btn, async () => {
  const r = await call('enrolUsers', { courseId: S.course.course.id, batch: f.elements.batch.value });
  closeModal(); toast(r.added ? plural(r.added, 'student') + ' enrolled from ' + f.elements.batch.value + '.' : 'Everyone in that batch is already enrolled.'); await refresh();
});
ACT.unenrol = async (d) => {
  if (!await confirmBox('Remove ' + d.name + '?', '<p>They will lose access to this course. Their grades and submissions are kept.</p>', 'Remove', true)) return;
  busy(null, async () => { await call('unenrolUser', { courseId: S.course.course.id, userId: d.id }); toast('Removed from the course.'); await refresh(); });
};

/* =====================================================================
   GRADEBOOK
   ===================================================================== */
function gradeCellHtml(c) {
  if (!c) return '<span class="grade-pill gp-none">—</span>';
  const p = pct(c.score, c.max);
  return '<span class="grade-pill ' + gradeClass(p) + '" title="' + p + '%">' + c.score + '<span style="opacity:.6"> / ' + c.max + '</span></span>';
}
async function courseGrades(c, editor) {
  const g = await call('courseGrades', { courseId: c.id });
  S.gradebook = g;
  if (!g.items.length) {
    return emptyState('chart', 'No graded activities yet', editor ? 'Add an assignment or a quiz — their grades will appear here automatically.' : 'Your teacher has not added graded activities yet.');
  }
  const itemHead = (it) => '<a href="#/mod/' + esc(it.moduleId) + '"><span class="th-type">' + MOD[it.type].label + '</span>' + esc(it.title) + '</a>';
  if (editor) {
    const totals = g.rows.map((r) => r.total).filter(Boolean);
    const avg = totals.length ? Math.round(totals.reduce((a, t) => a + t.percent, 0) / totals.length * 10) / 10 : null;
    return '<div class="stats" style="grid-template-columns:repeat(3,minmax(0,1fr))">' + statCard('users', 'blue', g.rows.length, 'Students') +
      statCard('layers', 'violet', g.items.length, 'Graded items') + statCard('trending', 'green', avg != null ? avg + '%' : '—', 'Class average') + '</div>' +
      '<div class="card"><div class="card-head"><span class="i-tile sm tone-green">' + icon('grid') + '</span><h2>Grader report</h2><div class="spacer"></div>' +
      '<button class="btn btn-sm" data-act="exportGrades">' + icon('download') + 'Export CSV</button></div>' +
      (g.rows.length ? '<div class="table-wrap"><table class="table grader"><thead><tr><th class="sticky">Student</th>' + g.items.map((it) => '<th>' + itemHead(it) + '</th>').join('') + '<th>Course total</th></tr></thead><tbody>' +
        g.rows.map((r) => '<tr><td class="sticky"><div class="cell-user">' + avatar(r.name, 'sm') + '<div><b>' + esc(r.name) + '</b><span>' + esc(r.batch || r.username) + '</span></div></div></td>' +
          r.cells.map((cell) => '<td>' + gradeCellHtml(cell) + '</td>').join('') + '<td>' + (r.total ? '<span class="grade-pill ' + gradeClass(r.total.percent) + '">' + r.total.percent + '%</span>' : '<span class="grade-pill gp-none">—</span>') + '</td></tr>').join('') +
        '</tbody></table></div>' : '<div class="card-body small muted">No students are enrolled yet.</div>') + '</div>';
  }
  return '<div class="card"><div class="card-head"><span class="i-tile sm tone-green">' + icon('award') + '</span><h2>My grades</h2><div class="spacer"></div>' +
    (g.total ? '<span class="grade-pill ' + gradeClass(g.total.percent) + '" style="font-size:.95rem">Course total: ' + g.total.percent + '%</span>' : '') + '</div>' +
    '<div class="table-wrap"><table class="table"><thead><tr><th>Grade item</th><th class="num">Grade</th><th class="num">Percentage</th><th>Feedback</th></tr></thead><tbody>' +
    g.items.map((it, i) => {
      const cell = g.cells[i];
      return '<tr><td><div class="row">' + modTile(it.type, 'sm') + '<a class="strong" href="#/mod/' + esc(it.moduleId) + '">' + esc(it.title) + '</a></div></td>' +
        '<td class="num">' + (cell ? cell.score + ' / ' + cell.max : '<span class="muted">Not graded</span>') + '</td>' +
        '<td class="num">' + (cell ? '<span class="grade-pill ' + gradeClass(pct(cell.score, cell.max)) + '">' + pct(cell.score, cell.max) + '%</span>' : '—') + '</td>' +
        '<td class="small">' + (cell && cell.feedback ? '<div class="prose">' + md(cell.feedback) + '</div>' : '<span class="muted">—</span>') + '</td></tr>';
    }).join('') +
    '<tr style="background:var(--surface-2)"><td><b>Course total</b></td><td class="num"><b>' + (g.total ? g.total.score + ' / ' + g.total.max : '—') + '</b></td>' +
    '<td class="num">' + (g.total ? '<span class="grade-pill ' + gradeClass(g.total.percent) + '">' + g.total.percent + '%</span>' : '—') + '</td><td></td></tr>' +
    '</tbody></table></div></div>';
}
ACT.exportGrades = () => {
  const g = S.gradebook;
  const head = ['Name', 'Username', 'Batch'].concat(g.items.map((it) => it.title + ' (' + MOD[it.type].label + ')')).concat(['Course total %']);
  const rows = g.rows.map((r) => [r.name, r.username, r.batch].concat(r.cells.map((c) => (c ? c.score + '/' + c.max : ''))).concat([r.total ? r.total.percent : '']));
  downloadText(g.course.shortname + '-grades.csv', csv([head].concat(rows)));
};

/* =====================================================================
   ANNOUNCEMENTS (course + site)
   ===================================================================== */
function announcementsHtml(r, courseId) {
  const composer = r.canPost ? '<div class="card"><div class="card-head"><span class="i-tile sm tone-pink">' + icon('megaphone') + '</span><h2>Post an announcement</h2></div>' +
    '<div class="card-body"><form data-form="announce" novalidate><input type="hidden" name="courseId" value="' + esc(courseId) + '">' +
    field('Subject', '<input type="text" name="title" maxlength="200">') +
    field('Message', '<textarea name="body" maxlength="20000" style="min-height:110px"></textarea>' + mdHelp()) +
    '<div class="row"><span class="small muted">' + icon('bell', 'i-sm') + ' ' + (courseId ? 'Everyone in the course' : 'Every user') + ' will get a notification.</span><div class="spacer"></div>' +
    '<button class="btn btn-primary" type="submit">' + icon('send') + 'Post</button></div></form></div></div>' : '';
  const list = r.items.length ? r.items.map((a) => '<article class="card"><div class="post">' + avatar(a.author) + '<div class="post-main"><div class="post-head"><b>' + esc(a.author) + '</b><time>' + esc(fmt(a.createdAt)) + '</time>' +
    (a.canDelete ? '<div class="spacer"></div><button class="btn-icon sm danger" title="Delete" data-act="delAnnouncement" data-id="' + esc(a.id) + '">' + icon('trash') + '</button>' : '') + '</div>' +
    '<h3 style="margin:.2rem 0 .5rem">' + esc(a.title) + '</h3><div class="prose">' + md(a.body) + '</div></div></div></article>').join('')
    : emptyState('megaphone', 'No announcements yet', r.canPost ? 'Post news and reminders — everyone gets notified.' : 'News from your teachers will appear here.');
  return '<div class="stack" style="max-width:860px">' + composer + list + '</div>';
}
async function courseAnnouncements(c) {
  return announcementsHtml(await call('announcements', { courseId: c.id }), c.id);
}
FORMS.announce = (f, btn) => busy(btn, async () => {
  await call('postAnnouncement', { courseId: f.elements.courseId.value, title: f.elements.title.value, body: f.elements.body.value });
  toast('Announcement posted.'); await refresh();
});
ACT.delAnnouncement = async (d) => {
  if (!await confirmBox('Delete this announcement?', '<p>It will be removed for everyone.</p>', 'Delete', true)) return;
  busy(null, async () => { await call('deleteAnnouncement', { id: d.id }); toast('Announcement deleted.'); await refresh(); });
};
