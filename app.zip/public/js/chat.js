'use strict';
/* =====================================================================
   COMMUNICATION — Slack-style messaging
   /chat, /chat/:channel   channels per course, DMs, threads, reactions,
   mentions, files, pins, search, typing, presence, unread badges.
   A long-poll loop runs for the whole session so badges and toasts are live
   on every page; the chat view itself updates in place (no page reloads).
   ===================================================================== */
const CH = {
  running: false, seq: 0, me: null, channels: new Map(), users: {}, msgs: {}, more: {}, lastRead: {},
  active: '', thread: null, pane: '', typing: {}, files: [], editing: '', mentions: {}, reactions: [], canCreate: false, studentDM: false, mounted: false
};
const EMOJI = ['😀', '😄', '😊', '🙂', '😉', '😍', '🤔', '😅', '😂', '🙌', '👏', '👍', '👎', '🙏', '💪', '👀', '🎉', '✨', '🔥', '💯', '✅', '❌', '⚠️', '❓',
  '💡', '📌', '📚', '📝', '📎', '📅', '⏰', '🎯', '❤️', '💙', '🤝', '😮', '😢', '😴', '🤓', '🥳', '☕', '🍀', '🚀', '⭐', '👋', '🙋', '🤷', '👌'];
const chatEsc = (s) => esc(s == null ? '' : s);

/* ---------- formatting ---------- */
function chatFormat(text) {
  const held = [];
  let t = String(text || '').replace(/@\[([^\]]{1,80})\]\((U[a-z0-9]{6,40})\)/gi, (m, name, id) => {
    held.push('<span class="mention' + (CH.me && id === CH.me.id ? ' me' : '') + '">@' + chatEsc(name) + '</span>');
    return '\u0002' + (held.length - 1) + '\u0002';
  });
  t = md(t);
  return t.replace(/\u0002(\d+)\u0002/g, (_, i) => held[i]);
}
function dayLabel(t) {
  const d = new Date(t), today = new Date(); today.setHours(0, 0, 0, 0);
  const diff = Math.round((new Date(d).setHours(0, 0, 0, 0) - today) / 864e5);
  if (diff === 0) return 'Today';
  if (diff === -1) return 'Yesterday';
  return d.toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long', year: d.getFullYear() !== today.getFullYear() ? 'numeric' : undefined });
}
function chName(c) { return c.kind === 'dm' ? c.name : '#' + c.name; }
function userOf(id) { return CH.users[id] || { id, name: 'Someone', role: '' }; }

/* =====================================================================
   SESSION-WIDE LIVE LOOP
   ===================================================================== */
async function chatBoot() {
  const r = await call('chatBootstrap');
  CH.me = r.me; CH.seq = r.seq; CH.reactions = r.reactions; CH.canCreate = r.canCreate; CH.studentDM = r.studentDM; CH.parent = !!r.parent;
  CH.channels = new Map(r.channels.map((c) => [c.id, c]));
  CH.users[r.me.id] = r.me;
  r.channels.forEach((c) => (c.people || []).forEach((p) => { CH.users[p.id] = p; }));
  chatBadge();
  return r;
}
async function chatLoop() {
  if (CH.running) return;
  CH.running = true;
  const me = S.me && S.me.id;
  try { await chatBoot(); } catch (e) { CH.running = false; return; }
  while (CH.running && S.token && S.me && S.me.id === me) {
    try {
      const r = await call('chatPoll', { since: CH.seq });
      if (!CH.running || !S.me || S.me.id !== me) break;
      if (r.reset) { await chatBoot(); if (CH.mounted) chatRenderAll(); continue; }
      CH.seq = r.seq;
      r.events.forEach(chatEvent);
    } catch (e) {
      if (isExpired(e) || !S.token) break;
      await new Promise((res) => setTimeout(res, 4000));
    }
  }
  CH.running = false;
}
// Start with the session; stop (and forget) when signed out. Parents get direct messages with their children's teachers.
setInterval(() => {
  if (S.me && S.token && !CH.running) chatLoop();
  if (!S.me && (CH.me || CH.channels.size)) { CH.running = false; CH.me = null; CH.channels = new Map(); CH.msgs = {}; CH.users = {}; }
}, 1500);

function chatEvent(e) {
  if (e.type === 'message') {
    const m = e.message;
    if (e.user) CH.users[e.user.id] = e.user;
    let c = CH.channels.get(e.ch);
    if (!c) { chatBoot().then(() => { if (CH.mounted) chatRenderList(); }); return; }
    const mine = CH.me && m.uid === CH.me.id;
    if (!m.parent) { c.lastAt = m.at; c.preview = firstName(userOf(m.uid).name) + ': ' + String(m.text || '').replace(/@\[([^\]]+)\]\([^)]+\)/g, '@$1').replace(/[*_`>#]/g, '').slice(0, 80); }
    const viewing = CH.mounted && CH.active === e.ch && document.visibilityState === 'visible';
    if (!mine && !viewing) {
      if (!m.parent) c.unread = (c.unread || 0) + 1;
      if ((m.mentions || []).indexOf(CH.me && CH.me.id) >= 0) c.mentions = (c.mentions || 0) + 1;
      if (c.kind === 'dm' || (m.mentions || []).indexOf(CH.me && CH.me.id) >= 0) chatNotify(c, m);
    }
    if (CH.msgs[e.ch]) {
      if (m.parent) {
        const root = CH.msgs[e.ch].find((x) => x.id === m.parent);
        if (root && e.parent) Object.assign(root, e.parent);
        if (root && CH.mounted && CH.active === e.ch) chatRenderMessage(root);
        if (CH.thread && CH.thread.root.id === m.parent) { CH.thread.replies.push(m); if (e.parent) CH.thread.root = e.parent; chatRenderThread(true); }
      } else if (!CH.msgs[e.ch].some((x) => x.id === m.id)) {
        CH.msgs[e.ch].push(m);
        if (CH.mounted && CH.active === e.ch) chatAppend(m);
      }
    }
    if (viewing && !m.parent) chatMarkRead();
    if (CH.typing[e.ch]) delete CH.typing[e.ch][m.uid];
    if (CH.mounted) { chatRenderList(); chatRenderTyping(); }
    chatBadge();
  } else if (e.type === 'update') {
    const m = e.message;
    const list = CH.msgs[e.ch];
    if (list) { const i = list.findIndex((x) => x.id === m.id); if (i >= 0) { list[i] = m; if (CH.mounted && CH.active === e.ch) chatRenderMessage(m); } }
    if (CH.thread) {
      if (CH.thread.root.id === m.id) { CH.thread.root = m; chatRenderThread(); }
      const j = CH.thread.replies.findIndex((x) => x.id === m.id);
      if (j >= 0) { CH.thread.replies[j] = m; chatRenderThread(); }
    }
  } else if (e.type === 'read') {
    const c = CH.channels.get(e.ch);
    if (c) { c.unread = 0; c.mentions = 0; c.lastRead = e.at; }
    if (CH.mounted) chatRenderList();
    chatBadge();
  } else if (e.type === 'typing') {
    (CH.typing[e.ch] = CH.typing[e.ch] || {})[e.uid] = { name: e.name, until: Date.now() + 6000, thread: e.thread };
    if (CH.mounted) chatRenderTyping();
    setTimeout(() => CH.mounted && chatRenderTyping(), 6200);
  } else if (e.type === 'channel') {
    const c = e.channel;
    CH.channels.set(c.id, Object.assign(CH.channels.get(c.id) || {}, c));
    (c.people || []).forEach((p) => { CH.users[p.id] = p; });
    if (CH.mounted) { chatRenderList(); if (CH.active === c.id) chatRenderHeader(); }
  }
}
function chatBadge() {
  let n = 0;
  CH.channels.forEach((c) => { n += c.kind === 'dm' ? (c.unread || 0) : (c.mentions || 0); });
  ['#navChat', '#tabChat'].forEach((sel) => { const el = $(sel); if (el) { el.textContent = n > 99 ? '99+' : String(n); el.classList.toggle('hidden', !n); } });
  document.title = document.title.replace(/^\(\d+\+?\) /, '');
  if (n) document.title = '(' + (n > 99 ? '99+' : n) + ') ' + document.title;
}
function chatNotify(c, m) {
  if (S.attempt) return;
  const who = userOf(m.uid).name;
  const text = String(m.text || (m.files && m.files.length ? 'sent a file' : '')).replace(/@\[([^\]]+)\]\([^)]+\)/g, '@$1').replace(/[*_`>#]/g, '').slice(0, 120);
  if (document.visibilityState === 'hidden' && 'Notification' in window && Notification.permission === 'granted') {
    try { const n = new Notification(who + (c.kind === 'dm' ? '' : ' in ' + chName(c)), { body: text, tag: c.id }); n.onclick = () => { window.focus(); go('/chat/' + c.id); n.close(); }; } catch (err) { /* not allowed */ }
  } else if (!(CH.mounted && CH.active === c.id)) toast(who + ': ' + text);
}

/* =====================================================================
   PAGE
   ===================================================================== */
async function viewChat(chId) {
  await (CH.me ? Promise.resolve() : chatBoot());
  if (!CH.running) chatLoop();
  const want = chId || prefs.get('chat.last', '') || '';
  return {
    title: 'Messages',
    html: '<div class="msgr" id="chat">' +
      '<aside class="chat-side" aria-label="Conversations"><div class="chat-side-head"><h1>Messages</h1><span class="spacer"></span>' +
      '<button class="btn-icon" data-act="chatNewDM" title="New message" aria-label="New message">' + icon('edit') + '</button></div>' +
      '<form class="search-box chat-search" data-form="chatSearch" role="search">' + icon('search') + '<input type="search" name="q" placeholder="Search messages" aria-label="Search messages"></form>' +
      '<nav class="chat-list" id="chatList"></nav>' +
      ('Notification' in window && Notification.permission === 'default' ? '<button class="chat-notif" data-act="chatNotifs">' + icon('bell', 'i-sm') + 'Turn on desktop notifications</button>' : '') + '</aside>' +
      '<section class="chat-main" id="chatMain" aria-live="off"></section>' +
      '<aside class="chat-pane" id="chatPane" hidden></aside></div>',
    after() {
      CH.mounted = true;
      $('#main').classList.add('content-flush');
      S.stay = (p) => /^\/chat(\/|$)/.test(p) && CH.mounted && (chatRoute(p), true);
      S.onLeave = () => { CH.mounted = false; CH.active = ''; CH.thread = null; S.stay = null; const m = $('#main'); if (m) m.classList.remove('content-flush'); };
      chatRenderList();
      const pick = CH.channels.has(want) ? want : '';
      if (pick) chatOpen(pick);
      else if (innerWidth >= 900) { const first = [...CH.channels.values()].sort((a, b) => b.lastAt - a.lastAt)[0]; if (first) chatOpen(first.id, true); else chatEmpty(); }
      else chatEmpty();
    }
  };
}
function chatRoute(p) {
  const id = (/^\/chat\/([A-Za-z0-9]+)/.exec(p) || [])[1] || '';
  if (id && id !== CH.active) chatOpen(id);
  if (!id) { $('#chat').classList.remove('in-channel'); }
}
function chatEmpty() {
  $('#chatMain').innerHTML = '<div class="chat-empty">' + emptyState('message', 'Your conversations', CH.parent ? 'Message your child’s subject teachers — ask about progress, attendance or anything else.' : 'Pick a channel on the left, or start a new message with your teacher.',
    '<button class="btn btn-primary" data-act="chatNewDM">' + icon('edit') + 'New message</button>', false) + '</div>';
}

/* ---------- sidebar ---------- */
function chatRenderList() {
  const el = $('#chatList'); if (!el) return;
  const all = [...CH.channels.values()];
  const dms = all.filter((c) => c.kind === 'dm').sort((a, b) => b.lastAt - a.lastAt);
  const byCourse = {};
  all.filter((c) => c.kind !== 'dm' && !c.archived).forEach((c) => { (byCourse[c.courseId] = byCourse[c.courseId] || { name: c.course, full: c.courseName, color: c.color, list: [], mod: false }).list.push(c); if (c.canModerate) byCourse[c.courseId].mod = true; });
  const item = (c) => {
    const unread = c.unread > 0, dot = c.kind === 'dm' && c.people && c.people.length === 1;
    const lead = c.kind === 'dm'
      ? (c.people && c.people.length > 1 ? '<span class="chat-ico group">' + c.people.length + '</span>' : '<span class="chat-av">' + avatar(c.name, 'sm') + (dot ? '<i class="pres' + (c.people[0].online ? ' on' : '') + '"></i>' : '') + '</span>')
      : '<span class="chat-ico">' + icon(c.private ? 'lock' : 'hash', 'i-sm') + '</span>';
    return '<a class="chat-item' + (c.id === CH.active ? ' active' : '') + (unread ? ' unread' : '') + '" href="#/chat/' + esc(c.id) + '"' + (c.id === CH.active ? ' aria-current="page"' : '') + '>' + lead +
      '<span class="chat-item-text"><span class="nm">' + chatEsc(c.kind === 'dm' ? c.name : c.name) + '</span>' + (c.kind === 'dm' && c.preview ? '<span class="pv">' + chatEsc(c.preview) + '</span>' : '') + '</span>' +
      (c.mentions ? '<span class="count">@' + c.mentions + '</span>' : c.kind === 'dm' && c.unread ? '<span class="count">' + c.unread + '</span>' : '') + '</a>';
  };
  el.innerHTML =
    '<div class="chat-group"><div class="chat-group-h">Direct messages<button class="btn-icon sm" data-act="chatNewDM" aria-label="New direct message">' + icon('plus', 'i-sm') + '</button></div>' +
    (dms.length ? dms.map(item).join('') : '<button class="chat-hint" data-act="chatNewDM">' + icon('message', 'i-sm') + (CH.parent ? 'Message a teacher' : 'Message your teacher') + '</button>') + '</div>' +
    Object.keys(byCourse).map((cid) => {
      const g = byCourse[cid];
      g.list.sort((a, b) => (b.general - a.general) || a.name.localeCompare(b.name));
      return '<div class="chat-group cc-' + chatEsc(g.color) + '"><div class="chat-group-h"><span class="cdot"></span><span title="' + chatEsc(g.full) + '">' + chatEsc(g.name) + '</span>' +
        (g.mod ? '<button class="btn-icon sm" data-act="chatNewChannel" data-course="' + esc(cid) + '" aria-label="Add a channel">' + icon('plus', 'i-sm') + '</button>' : '') + '</div>' + g.list.map(item).join('') + '</div>';
    }).join('') +
    (!all.length && !CH.parent ? '<p class="small muted" style="padding:var(--sp-3)">Channels appear when you are enrolled in a course.</p>' : '');
}

/* ---------- open a conversation ---------- */
async function chatOpen(id, quiet) {
  const c = CH.channels.get(id);
  if (!c) { chatEmpty(); return; }
  CH.active = id; CH.thread = null; CH.files = []; CH.editing = ''; CH.mentions = {};
  prefs.set('chat.last', id);
  if (!quiet && location.hash !== '#/chat/' + id) history.replaceState(null, '', '#/chat/' + id);
  $('#chat').classList.add('in-channel');
  chatClosePane();
  chatRenderList();
  const main = $('#chatMain');
  main.innerHTML = '<header class="chat-head" id="chatHead"></header><div class="chat-scroll" id="chatScroll"><div class="chat-msgs" id="chatMsgs"><div class="sk sk-line" style="width:40%;margin:var(--sp-6)"></div></div></div>' +
    '<div class="chat-typing" id="chatTyping" aria-live="polite"></div>' + composerHtml('main', c);
  chatRenderHeader();
  try {
    const r = await call('chatHistory', { ch: id });
    if (CH.active !== id) return;
    Object.assign(CH.users, r.users);
    CH.msgs[id] = r.messages; CH.more[id] = r.more; CH.lastRead[id] = r.lastRead;
    Object.assign(c, { members: r.members, pinned: r.pinned });
    chatRenderHeader();
    chatRenderMessages(true);
    chatMarkRead();
    const ta = $('#chatMain textarea'); if (ta && innerWidth >= 900) ta.focus();
  } catch (e) { $('#chatMsgs').innerHTML = notice(chatEsc(e.message), 'err'); }
}
function chatRenderHeader() {
  const c = CH.channels.get(CH.active), el = $('#chatHead'); if (!c || !el) return;
  const who = c.kind === 'dm' && c.people ? c.people : [];
  el.innerHTML = '<button class="btn-icon chat-back" data-act="chatBack" aria-label="Back to conversations">' + icon('arrowLeft') + '</button>' +
    '<div class="chat-head-t"><h2>' + (c.kind === 'dm' ? chatEsc(c.name) : icon(c.private ? 'lock' : 'hash', 'i-sm') + chatEsc(c.name)) + '</h2>' +
    '<span class="xs muted">' + (c.kind === 'dm'
      ? (who.length === 1 ? (who[0].online ? '<i class="pres on inline"></i>Active now' : 'Away') + ' · ' + chatEsc(who[0].role) + (who[0].note ? ' · ' + chatEsc(who[0].note) : who[0].batch ? ' · ' + chatEsc(who[0].batch) : '') : plural(who.length + 1, 'person', 'people'))
      : chatEsc(c.course) + (c.topic ? ' · ' + chatEsc(c.topic) : '')) + '</span></div>' +
    (c.kind !== 'dm' ? '<button class="btn btn-sm btn-ghost" data-act="chatMembers" title="Members">' + icon('users', 'i-sm') + (c.members || '') + '</button>' : '') +
    '<button class="btn-icon sm" data-act="chatPins" title="Pinned messages" aria-label="Pinned messages">' + icon('pin') + '</button>' +
    (c.canModerate && !c.general ? '<button class="btn-icon sm" data-act="chatSettings" title="Channel settings" aria-label="Channel settings">' + icon('settings') + '</button>'
      : c.canModerate ? '<button class="btn-icon sm" data-act="chatSettings" title="Edit topic" aria-label="Edit topic">' + icon('edit') + '</button>' : '');
}
ACT.chatBack = () => { $('#chat').classList.remove('in-channel'); CH.active = ''; history.replaceState(null, '', '#/chat'); chatRenderList(); };

/* ---------- messages ---------- */
function msgHtml(m, prev, opts) {
  opts = opts || {};
  const u = userOf(m.uid);
  const grouped = prev && !prev.deleted && prev.uid === m.uid && m.at - prev.at < 7 * 60000 && new Date(prev.at).toDateString() === new Date(m.at).toDateString() && !opts.thread;
  const mine = CH.me && m.uid === CH.me.id;
  const c = CH.channels.get(m.ch) || {};
  let body;
  if (m.deleted) body = '<div class="msg-deleted">' + icon('trash', 'i-sm') + 'This message was deleted.</div>';
  else {
    const text = CH.editing === m.id
      ? '<form class="msg-edit" data-form="chatEdit" data-id="' + esc(m.id) + '"><textarea name="t" rows="2">' + chatEsc(m.text) + '</textarea><div class="row" style="margin-top:6px"><button class="btn btn-sm" type="button" data-act="chatEditCancel">Cancel</button><button class="btn btn-sm btn-primary" type="submit">Save</button><span class="xs muted">Esc to cancel · Enter to save</span></div></form>'
      : (m.text ? '<div class="msg-text">' + chatFormat(m.text) + (m.editedAt ? '<span class="msg-edited" title="' + esc(fmt(m.editedAt)) + '">(edited)</span>' : '') + '</div>' : '');
    const files = m.files && m.files.length ? '<div class="msg-files">' + m.files.map((f) => (/^image\//.test(f.mime)
      ? '<button class="msg-img" data-act="chatImg" data-id="' + esc(f.id) + '" data-name="' + esc(f.name) + '"><img data-chatimg="' + esc(f.id) + '" alt="' + esc(f.name) + '"></button>'
      : fileChip(f))).join('') + '</div>' : '';
    const reacts = m.reactions && m.reactions.length ? '<div class="msg-reacts">' + m.reactions.map((r) => '<button class="react' + (r.mine ? ' mine' : '') + '" data-act="chatReact" data-id="' + esc(m.id) + '" data-e="' + esc(r.e) + '" title="' + esc(r.who.map((id) => userOf(id).name).join(', ')) + '">' + r.e + '<b>' + r.n + '</b></button>').join('') +
      '<button class="react add" data-act="chatReactPick" data-id="' + esc(m.id) + '" aria-label="Add reaction">' + icon('plus', 'i-sm') + '</button></div>' : '';
    const thread = !opts.thread && m.replies ? '<button class="msg-thread" data-act="chatThread" data-id="' + esc(m.id) + '"><span class="avatars">' + (m.replyUsers || []).map((id) => avatar(userOf(id).name, 'sm')).join('') + '</span><b>' + plural(m.replies, 'reply', 'replies') + '</b><span class="muted">Last reply ' + esc(rel(m.lastReplyAt)) + '</span>' + icon('right', 'i-sm') + '</button>' : '';
    body = text + files + reacts + thread;
  }
  const tools = m.deleted || CH.editing === m.id ? '' : '<div class="msg-tools" role="toolbar" aria-label="Message actions">' +
    '<button data-act="chatReactPick" data-id="' + esc(m.id) + '" title="Add reaction" aria-label="Add reaction">' + icon('smile') + '</button>' +
    (!opts.thread ? '<button data-act="chatThread" data-id="' + esc(m.id) + '" title="Reply in thread" aria-label="Reply in thread">' + icon('message') + '</button>' : '') +
    (c.kind === 'dm' || c.canModerate || mine ? '<button data-act="chatPin" data-id="' + esc(m.id) + '" title="' + (m.pinned ? 'Unpin' : 'Pin') + '" aria-label="' + (m.pinned ? 'Unpin' : 'Pin') + '">' + icon('pin') + '</button>' : '') +
    (mine ? '<button data-act="chatEditStart" data-id="' + esc(m.id) + '" title="Edit" aria-label="Edit">' + icon('edit') + '</button>' : '') +
    (mine || c.canModerate ? '<button data-act="chatDel" data-id="' + esc(m.id) + '" title="Delete" aria-label="Delete" class="danger">' + icon('trash') + '</button>' : '') + '</div>';
  return '<div class="msg' + (grouped ? ' grouped' : '') + (m.pinned ? ' pinned' : '') + ((m.mentions || []).indexOf(CH.me && CH.me.id) >= 0 ? ' mentioned' : '') + '" id="m-' + esc(m.id) + '" data-id="' + esc(m.id) + '">' +
    (grouped ? '<span class="msg-when-mini">' + esc(fmtTime(m.at)) + '</span>' : '<span class="msg-av">' + avatar(u.name) + '</span>') +
    '<div class="msg-body">' + (grouped ? '' : '<div class="msg-meta"><b>' + chatEsc(u.name) + '</b>' + (u.role && u.role !== 'student' ? '<span class="role">' + chatEsc(u.role) + '</span>' : '') + '<time datetime="' + new Date(m.at).toISOString() + '" title="' + esc(fmt(m.at)) + '">' + esc(fmtTime(m.at)) + '</time>' + (m.pinned ? '<span class="pinmark">' + icon('pin', 'i-sm') + 'Pinned</span>' : '') + '</div>') +
    body + '</div>' + tools + '</div>';
}
function chatRenderMessages(toBottom) {
  const el = $('#chatMsgs'); if (!el) return;
  const c = CH.channels.get(CH.active);
  const list = CH.msgs[CH.active] || [];
  const read = CH.lastRead[CH.active] || 0;
  let html = CH.more[CH.active] ? '<div class="chat-more"><button class="btn btn-sm" data-act="chatOlder">Load earlier messages</button></div>'
    : '<div class="chat-intro">' + (c.kind === 'dm' ? '<div class="avatars">' + (c.people || []).map((p) => avatar(p.name, 'lg')).join('') + '</div><h3>' + chatEsc(c.name) + '</h3><p>This is the beginning of your conversation' + (c.people && c.people.length === 1 ? ' with <b>' + chatEsc(c.people[0].name) + '</b>' : '') + '. Messages here are private to you' + (c.people && c.people.length > 1 ? ' all' : ' both') + '.</p>'
      : '<span class="chat-intro-ico">' + icon(c.private ? 'lock' : 'hash') + '</span><h3>' + (c.general ? 'Welcome to #general' : '#' + chatEsc(c.name)) + '</h3><p>' + (c.general ? 'Everyone in <b>' + chatEsc(c.courseName || c.course) + '</b> is here. Ask questions, help classmates and hear from your teachers.' : chatEsc(c.topic || 'The start of #' + c.name + '.')) + '</p>') + '</div>';
  let prev = null, day = '', newShown = false;
  list.forEach((m) => {
    const d = new Date(m.at).toDateString();
    if (d !== day) { day = d; html += '<div class="chat-day"><span>' + esc(dayLabel(m.at)) + '</span></div>'; prev = null; }
    if (!newShown && read && m.at > read && CH.me && m.uid !== CH.me.id) { newShown = true; html += '<div class="chat-new" id="chatNew"><span>New</span></div>'; prev = null; }
    html += msgHtml(m, prev);
    prev = m;
  });
  el.innerHTML = html;
  chatHydrate(el);
  const sc = $('#chatScroll');
  if (toBottom && sc) {
    const nw = $('#chatNew');
    if (nw && nw.offsetTop > sc.clientHeight * 0.6) sc.scrollTop = nw.offsetTop - 80; else sc.scrollTop = sc.scrollHeight;
  }
}
function chatAppend(m) {
  const el = $('#chatMsgs'), sc = $('#chatScroll'); if (!el || !sc) return;
  const near = sc.scrollHeight - sc.scrollTop - sc.clientHeight < 160 || (CH.me && m.uid === CH.me.id);
  const list = CH.msgs[CH.active];
  const prev = list[list.length - 2];
  const day = prev && new Date(prev.at).toDateString() !== new Date(m.at).toDateString();
  const wrap = document.createElement('div');
  wrap.innerHTML = (day || !prev ? '<div class="chat-day"><span>' + esc(dayLabel(m.at)) + '</span></div>' : '') + msgHtml(m, day ? null : prev);
  [...wrap.children].forEach((n) => { n.classList.add('msg-in'); el.appendChild(n); });
  chatHydrate(el);
  if (near) sc.scrollTo({ top: sc.scrollHeight, behavior: 'smooth' });
}
function chatRenderMessage(m) {
  const node = document.getElementById('m-' + m.id);
  if (!node) return;
  const list = CH.msgs[m.ch] || [];
  const i = list.findIndex((x) => x.id === m.id);
  const wrap = document.createElement('div');
  wrap.innerHTML = msgHtml(m, i > 0 ? list[i - 1] : null);
  node.replaceWith(wrap.firstChild);
  chatHydrate($('#chatMsgs'));
}
/** Image attachments load through the authenticated file route. */
function chatHydrate(root) {
  $$('img[data-chatimg]', root).forEach((img) => {
    const id = img.dataset.chatimg; img.removeAttribute('data-chatimg');
    fetchFileBlob({ id }).then((b) => { img.src = URL.createObjectURL(b); }).catch(() => { img.alt = 'Image unavailable'; });
  });
}
ACT.chatOlder = (d, btn) => busy(btn, async () => {
  const list = CH.msgs[CH.active] || [];
  const r = await call('chatHistory', { ch: CH.active, before: list.length ? list[0].at : Date.now() });
  Object.assign(CH.users, r.users);
  const sc = $('#chatScroll'), h = sc.scrollHeight;
  CH.msgs[CH.active] = r.messages.concat(list); CH.more[CH.active] = r.more;
  chatRenderMessages(false);
  sc.scrollTop = sc.scrollHeight - h;
});
let readT = 0;
function chatMarkRead() {
  const c = CH.channels.get(CH.active);
  if (!c || document.visibilityState !== 'visible') return;
  clearTimeout(readT);
  readT = setTimeout(() => {
    const had = c.unread || c.mentions;
    c.unread = 0; c.mentions = 0;
    call('chatRead', { ch: c.id }).catch(() => {});
    if (had) { chatRenderList(); chatBadge(); }
  }, 400);
}
document.addEventListener('visibilitychange', () => { if (CH.mounted && CH.active && document.visibilityState === 'visible') chatMarkRead(); });

/* ---------- typing ---------- */
function chatRenderTyping() {
  const now = Date.now();
  const t = CH.typing[CH.active] || {};
  const names = Object.keys(t).filter((uid) => t[uid].until > now && !t[uid].thread).map((uid) => t[uid].name);
  const el = $('#chatTyping');
  if (el) el.innerHTML = names.length ? '<span class="dots"><i></i><i></i><i></i></span>' + chatEsc(names.slice(0, 3).join(', ')) + (names.length === 1 ? ' is' : ' are') + ' typing…' : '';
}
let typingT = 0;
function chatTyped(ta) {
  const box = ta.closest('.composer'); if (!box) return;
  ta.style.height = 'auto'; ta.style.height = Math.min(220, ta.scrollHeight) + 'px';
  if (Date.now() - typingT > 3000 && ta.value.trim()) { typingT = Date.now(); call('chatTyping', { ch: CH.active, thread: box.dataset.where === 'thread' && CH.thread ? CH.thread.root.id : '' }).catch(() => {}); }
  chatMentionSuggest(ta);
}

/* ---------- composer ---------- */
function composerHtml(where, c) {
  const ph = where === 'thread' ? 'Reply…' : c.archived ? 'This channel is archived' : 'Message ' + (c.kind === 'dm' ? c.name : '#' + c.name);
  return '<form class="composer" data-form="chatSend" data-where="' + where + '" novalidate><div class="composer-box">' +
    '<div class="composer-files" id="cf-' + where + '"></div>' +
    '<textarea name="t" rows="1" placeholder="' + esc(ph) + '" aria-label="' + esc(ph) + '" data-input="chatTyping" data-delay="0"' + (c.archived ? ' disabled' : '') + '></textarea>' +
    '<div class="composer-bar"><label class="btn-icon sm" title="Attach files" aria-label="Attach files">' + icon('upload', 'i-sm') + '<input type="file" multiple hidden data-change="chatAttach" data-where="' + where + '"></label>' +
    '<button type="button" class="btn-icon sm" data-act="chatEmoji" data-where="' + where + '" title="Emoji" aria-label="Insert emoji">' + icon('smile', 'i-sm') + '</button>' +
    '<button type="button" class="btn-icon sm" data-act="chatAt" data-where="' + where + '" title="Mention someone" aria-label="Mention someone">@</button>' +
    '<span class="composer-hint xs muted">**bold** · *italic* · `code` · Shift+Enter for a new line</span><span class="spacer"></span>' +
    '<button class="btn-icon sm send" type="submit" aria-label="Send">' + icon('send', 'i-sm') + '</button></div></div>' +
    '<div class="mention-pop" hidden></div></form>';
}
INPUTS.chatTyping = (ta) => chatTyped(ta);
document.addEventListener('keydown', (e) => {
  const ta = e.target;
  if (!ta || ta.tagName !== 'TEXTAREA') return;
  const form = ta.closest('form');
  if (!form) return;
  const pop = form.querySelector('.mention-pop');
  if (form.dataset.form === 'chatSend') {
    if (pop && !pop.hidden && ['ArrowDown', 'ArrowUp', 'Enter', 'Tab', 'Escape'].indexOf(e.key) >= 0) {
      e.preventDefault();
      const items = $$('button', pop), cur = items.findIndex((b) => b.classList.contains('on'));
      if (e.key === 'Escape') { pop.hidden = true; return; }
      if (e.key === 'Enter' || e.key === 'Tab') { (items[cur] || items[0]).click(); return; }
      const next = (cur + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
      items.forEach((b, i) => b.classList.toggle('on', i === next));
      return;
    }
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); form.requestSubmit(); return; }
    if (e.key === 'ArrowUp' && !ta.value && form.dataset.where === 'main') {
      const last = (CH.msgs[CH.active] || []).slice().reverse().find((m) => CH.me && m.uid === CH.me.id && !m.deleted);
      if (last) { e.preventDefault(); ACT.chatEditStart({ id: last.id }); }
    }
  } else if (form.dataset.form === 'chatEdit') {
    if (e.key === 'Escape') { e.preventDefault(); ACT.chatEditCancel(); }
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); }
  }
}, true);

/** "@Name" typed in the composer becomes a real mention token when sent. */
function withMentionTokens(text) {
  Object.keys(CH.mentions).sort((a, b) => b.length - a.length).forEach((name) => {
    text = text.split('@' + name).join('@[' + name + '](' + CH.mentions[name] + ')');
  });
  return text;
}
FORMS.chatSend = (f, btn) => {
  const where = f.dataset.where;
  const ta = f.elements.t;
  const text = withMentionTokens(ta.value.trim());
  const files = CH.files.filter((x) => x.where === where && x.id);
  if (CH.files.some((x) => x.where === where && !x.id)) { toast('Wait for the attachment to finish uploading.', 'err'); return; }
  if (!text && !files.length) return;
  const ch = CH.active, parent = where === 'thread' && CH.thread ? CH.thread.root.id : '';
  ta.value = ''; ta.style.height = 'auto';
  CH.files = CH.files.filter((x) => x.where !== where); chatRenderFiles(where);
  busy(btn, async () => {
    try { await call('chatSend', { ch, text, parent, files: files.map((x) => x.id) }); }
    catch (e) { if (!ta.value) ta.value = text; throw e; }
  });
};
ACT.chatAttach = (d, el) => {
  const where = d.where;
  Array.from(el.files || []).slice(0, 6).forEach((file) => {
    const rec = { where, name: file.name, size: file.size, id: '' };
    CH.files.push(rec); chatRenderFiles(where);
    uploadFile(file).then((r) => { rec.id = r.id; rec.mime = r.mime; chatRenderFiles(where); })
      .catch((e) => { CH.files = CH.files.filter((x) => x !== rec); chatRenderFiles(where); toast(e.message, 'err'); });
  });
  if (el.value) el.value = '';
};
function chatRenderFiles(where) {
  const el = document.getElementById('cf-' + where); if (!el) return;
  el.innerHTML = CH.files.filter((x) => x.where === where).map((x, i) => '<span class="file-chip' + (x.id ? '' : ' loading') + '">' + icon(x.id ? 'file' : 'refresh', 'i-sm') + '<span class="fname">' + chatEsc(x.name) + '</span><span class="fsize">' + fileSize(x.size) + '</span>' +
    '<button type="button" class="btn-icon sm" data-act="chatUnattach" data-where="' + esc(where) + '" data-i="' + i + '" aria-label="Remove">' + icon('x', 'i-sm') + '</button></span>').join('');
}
ACT.chatUnattach = (d) => { const mine = CH.files.filter((x) => x.where === d.where); const rec = mine[Number(d.i)]; CH.files = CH.files.filter((x) => x !== rec); chatRenderFiles(d.where); };

/* emoji & reactions */
function chatPopover(anchor, html, cls) {
  $$('.chat-pop').forEach((p) => p.remove());
  const pop = document.createElement('div');
  pop.className = 'chat-pop ' + (cls || '');
  pop.innerHTML = html;
  document.body.appendChild(pop);
  const r = anchor.getBoundingClientRect();
  const w = pop.offsetWidth, h = pop.offsetHeight;
  pop.style.left = Math.max(8, Math.min(innerWidth - w - 8, r.right - w)) + 'px';
  pop.style.top = (r.top - h - 8 > 8 ? r.top - h - 8 : r.bottom + 8) + 'px';
  setTimeout(() => document.addEventListener('pointerdown', function off(ev) { if (!pop.contains(ev.target)) { pop.remove(); document.removeEventListener('pointerdown', off); } }), 0);
  return pop;
}
ACT.chatReactPick = (d, btn) => {
  chatPopover(btn, '<div class="emoji-grid">' + (CH.reactions.length ? CH.reactions : EMOJI).concat(EMOJI.filter((x) => CH.reactions.indexOf(x) < 0).slice(0, 12)).map((e) => '<button data-act="chatReact" data-id="' + esc(d.id) + '" data-e="' + e + '">' + e + '</button>').join('') + '</div>');
};
ACT.chatReact = (d) => {
  $$('.chat-pop').forEach((p) => p.remove());
  call('chatReact', { ch: CH.active, id: d.id, emoji: d.e }).catch((e) => toast(e.message, 'err'));
};
ACT.chatEmoji = (d, btn) => {
  chatPopover(btn, '<div class="emoji-grid wide">' + EMOJI.map((e) => '<button data-act="chatEmojiIns" data-where="' + esc(d.where) + '" data-e="' + e + '">' + e + '</button>').join('') + '</div>');
};
ACT.chatEmojiIns = (d) => {
  const ta = $('.composer[data-where="' + d.where + '"] textarea'); if (!ta) return;
  const p = ta.selectionStart || ta.value.length;
  ta.value = ta.value.slice(0, p) + d.e + ta.value.slice(p);
  ta.focus(); ta.selectionStart = ta.selectionEnd = p + d.e.length;
};

/* mentions */
let mentionT = 0;
ACT.chatAt = (d) => {
  const ta = $('.composer[data-where="' + d.where + '"] textarea'); if (!ta) return;
  const p = ta.selectionStart || ta.value.length;
  const pre = ta.value.slice(0, p);
  ta.value = pre + (pre && !/\s$/.test(pre) ? ' @' : '@') + ta.value.slice(p);
  ta.focus(); ta.selectionStart = ta.selectionEnd = p + (pre && !/\s$/.test(pre) ? 2 : 1);
  chatMentionSuggest(ta);
};
function chatMentionSuggest(ta) {
  const form = ta.closest('form'), pop = form && form.querySelector('.mention-pop'); if (!pop) return;
  const m = /(^|\s)@([^\s@]{0,30})$/.exec(ta.value.slice(0, ta.selectionStart));
  if (!m) { pop.hidden = true; return; }
  clearTimeout(mentionT);
  mentionT = setTimeout(async () => {
    try {
      const r = await call('chatPeople', { ch: CH.active, q: m[2] });
      if (!r.people.length) { pop.hidden = true; return; }
      pop.innerHTML = r.people.slice(0, 8).map((p, i) => '<button type="button" class="' + (i ? '' : 'on') + '" data-act="chatMentionPick" data-id="' + esc(p.id) + '" data-name="' + esc(p.name) + '">' +
        avatar(p.name, 'sm') + '<b>' + chatEsc(p.name) + '</b><span class="xs muted">' + chatEsc(p.role) + (p.online ? ' · active' : '') + '</span></button>').join('');
      pop.hidden = false;
    } catch (e) { pop.hidden = true; }
  }, 120);
}
ACT.chatMentionPick = (d, btn) => {
  const form = btn.closest('form'), ta = form.elements.t;
  const p = ta.selectionStart;
  const before = ta.value.slice(0, p).replace(/@([^\s@]{0,30})$/, '@' + d.name + ' ');
  ta.value = before + ta.value.slice(p);
  CH.mentions[d.name] = d.id;
  form.querySelector('.mention-pop').hidden = true;
  ta.focus(); ta.selectionStart = ta.selectionEnd = before.length;
};

/* edit / delete / pin */
ACT.chatEditStart = (d) => { CH.editing = d.id; const m = findChatMsg(d.id); if (m) { chatRenderMessage(m); if (CH.thread) chatRenderThread(); const ta = $('form[data-form="chatEdit"] textarea'); if (ta) { ta.focus(); ta.selectionStart = ta.value.length; } } };
ACT.chatEditCancel = () => { const id = CH.editing; CH.editing = ''; const m = findChatMsg(id); if (m) { chatRenderMessage(m); if (CH.thread) chatRenderThread(); } };
FORMS.chatEdit = (f, btn) => busy(btn, async () => {
  const id = f.dataset.id; CH.editing = '';
  await call('chatEdit', { ch: CH.active, id, text: withMentionTokens(f.elements.t.value) });
});
ACT.chatDel = async (d) => {
  if (!await confirmBox('Delete this message?', '<p>It will be removed for everyone in the conversation.</p>', 'Delete', true)) return;
  busy(null, () => call('chatDelete', { ch: CH.active, id: d.id }));
};
ACT.chatPin = (d) => busy(null, async () => { const r = await call('chatPin', { ch: CH.active, id: d.id }); toast(r.pinned ? 'Pinned to the conversation.' : 'Unpinned.'); });
function findChatMsg(id) {
  return (CH.msgs[CH.active] || []).find((m) => m.id === id) || (CH.thread && (CH.thread.root.id === id ? CH.thread.root : CH.thread.replies.find((m) => m.id === id)));
}
ACT.chatImg = (d) => busy(null, async () => {
  const b = await fetchFileBlob({ id: d.id });
  openModal(modalHead(d.name) + '<div class="modal-body"><img class="preview-img" alt="' + esc(d.name) + '" src="' + URL.createObjectURL(b) + '"></div>', 'wide');
});

/* ---------- side pane: thread, members, pins, search ---------- */
function chatOpenPane(kind, html) {
  const p = $('#chatPane'); if (!p) return;
  CH.pane = kind;
  p.hidden = false;
  p.innerHTML = html;
  $('#chat').classList.add('with-pane');
}
function chatClosePane() { const p = $('#chatPane'); if (p) { p.hidden = true; p.innerHTML = ''; } CH.pane = ''; CH.thread = null; const c = $('#chat'); if (c) c.classList.remove('with-pane'); }
ACT.chatPaneClose = () => chatClosePane();
const paneHead = (title, sub) => '<header class="chat-pane-h"><div><h3>' + title + '</h3>' + (sub ? '<span class="xs muted">' + sub + '</span>' : '') + '</div><button class="btn-icon sm" data-act="chatPaneClose" aria-label="Close">' + icon('x') + '</button></header>';

ACT.chatThread = (d) => busy(null, async () => {
  const r = await call('chatThread', { ch: CH.active, id: d.id });
  Object.assign(CH.users, r.users);
  CH.thread = { root: r.root, replies: r.replies };
  chatRenderThread(false, true);
});
function chatRenderThread(append, fresh) {
  if (!CH.thread) return;
  const c = CH.channels.get(CH.active) || {};
  if (fresh || CH.pane !== 'thread') {
    chatOpenPane('thread', paneHead('Thread', chatEsc(chName(c))) + '<div class="chat-scroll" id="threadScroll"><div class="chat-msgs thread" id="threadMsgs"></div></div>' + composerHtml('thread', c));
  }
  const el = $('#threadMsgs'); if (!el) return;
  const { root, replies } = CH.thread;
  el.innerHTML = msgHtml(root, null, { thread: true }) + '<div class="chat-day thread-count"><span>' + plural(replies.length, 'reply', 'replies') + '</span></div>' +
    replies.map((m, i) => msgHtml(m, replies[i - 1], { thread: true })).join('');
  chatHydrate(el);
  const sc = $('#threadScroll'); if (sc) sc.scrollTop = sc.scrollHeight;
  if (fresh) { const ta = $('.composer[data-where="thread"] textarea'); if (ta) ta.focus(); }
}
ACT.chatMembers = () => busy(null, async () => {
  const r = await call('chatMembers', { ch: CH.active });
  const c = CH.channels.get(CH.active);
  chatOpenPane('members', paneHead('Members', plural(r.members.length, 'person', 'people') + ' in ' + chatEsc(chName(c))) +
    '<div class="chat-scroll"><div class="member-list">' + r.members.map((u) => '<div class="member"><span class="chat-av">' + avatar(u.name, 'sm') + '<i class="pres' + (u.online ? ' on' : '') + '"></i></span><div><b>' + chatEsc(u.name) + '</b><span class="xs muted">' + chatEsc(u.role) + (u.note ? ' · ' + chatEsc(u.note) : u.batch ? ' · ' + chatEsc(u.batch) : '') + '</span></div>' +
      (CH.me && u.id !== CH.me.id && !CH.parent && (u.role !== 'student' || CH.me.role !== 'student' || CH.studentDM) ? '<button class="btn btn-sm btn-ghost" data-act="chatDMWith" data-id="' + esc(u.id) + '">Message</button>' : '') + '</div>').join('') + '</div></div>');
});
ACT.chatMessage = (d, btn) => busy(btn, async () => { const r = await call('chatOpenDM', { uids: [d.id] }); CH.channels.set(r.channel.id, r.channel); go('/chat/' + r.channel.id); });
ACT.chatDMWith = (d, btn) => busy(btn, async () => { const r = await call('chatOpenDM', { uids: [d.id] }); CH.channels.set(r.channel.id, r.channel); chatRenderList(); go('/chat/' + r.channel.id); });
ACT.chatPins = () => busy(null, async () => {
  const r = await call('chatPins', { ch: CH.active });
  Object.assign(CH.users, r.users);
  chatOpenPane('pins', paneHead('Pinned', chatEsc(chName(CH.channels.get(CH.active)))) + '<div class="chat-scroll"><div class="chat-msgs">' +
    (r.messages.length ? r.messages.map((m) => msgHtml(m, null, { thread: true })).join('') : '<p class="small muted" style="padding:var(--sp-5)">Nothing pinned yet. Pin a message to keep it handy for everyone.</p>') + '</div></div>');
});
FORMS.chatSearch = (f, btn) => busy(btn, async () => {
  const q = f.elements.q.value.trim();
  if (q.length < 2) { toast('Type at least 2 characters.', 'err'); return; }
  const r = await call('chatSearch', { q });
  Object.assign(CH.users, r.users);
  $('#chat').classList.add('in-channel');
  chatOpenPane('search', paneHead('Search', plural(r.results.length, 'result') + ' for “' + chatEsc(q) + '”') + '<div class="chat-scroll"><div class="search-results">' +
    (r.results.length ? r.results.map((m) => '<a class="search-hit" href="#/chat/' + esc(m.ch) + '" data-act="chatJump" data-ch="' + esc(m.ch) + '" data-id="' + esc(m.parent || m.id) + '"><span class="xs muted">' + chatEsc(m.channelKind === 'dm' ? m.channelName : '#' + m.channelName) + ' · ' + esc(fmt(m.at)) + '</span>' +
      '<b>' + chatEsc(userOf(m.uid).name) + '</b><div class="msg-text">' + chatFormat(m.text) + '</div></a>').join('') : '<p class="small muted" style="padding:var(--sp-5)">No messages match.</p>') + '</div></div>');
});
ACT.chatJump = async (d, el, e) => {
  if (e) e.preventDefault();
  if (CH.active !== d.ch) await chatOpen(d.ch);
  const n = document.getElementById('m-' + d.id);
  if (n) { n.scrollIntoView({ block: 'center', behavior: 'smooth' }); n.classList.add('flash'); setTimeout(() => n.classList.remove('flash'), 1800); }
};

/* ---------- new conversation / channel / settings ---------- */
ACT.chatNewDM = () => {
  CH.pick = new Map();
  openModal(modalHead('New message', CH.parent ? 'Message your child’s subject teachers.' : CH.me && CH.me.role === 'student' ? 'Message your teachers' + (CH.studentDM ? ' or classmates' : '') + '.' : 'Message anyone in your courses, or the parents of your students. Add several people for a group.') +
    '<div class="modal-body"><div class="pick-chips" id="pickChips"></div><div class="search-box">' + icon('search') + '<input type="search" placeholder="Search by name" data-input="chatPickSearch" data-delay="150" autofocus aria-label="Search people"></div>' +
    '<div class="pick-list" id="pickList"><div class="sk sk-line" style="margin-top:var(--sp-4)"></div></div>' +
    '<div class="form-actions"><button class="btn" data-act="close">Cancel</button><button class="btn btn-primary" data-act="chatStartDM" id="pickGo" disabled>Start conversation</button></div></div>', 'narrow');
  INPUTS.chatPickSearch({ value: '' });
};
INPUTS.chatPickSearch = async (el) => {
  const r = await call('chatPeople', { q: el.value || '' }).catch(() => ({ people: [] }));
  const list = $('#pickList'); if (!list) return;
  list.innerHTML = r.people.length ? r.people.map((p) => '<button type="button" class="pick' + (CH.pick.has(p.id) ? ' on' : '') + '" data-act="chatPickToggle" data-id="' + esc(p.id) + '" data-name="' + esc(p.name) + '">' +
    '<span class="chat-av">' + avatar(p.name, 'sm') + '<i class="pres' + (p.online ? ' on' : '') + '"></i></span><span><b>' + chatEsc(p.name) + '</b><span class="xs muted">' + chatEsc(p.role) + (p.note ? ' · ' + chatEsc(p.note) : p.batch ? ' · ' + chatEsc(p.batch) : '') + '</span></span>' + icon('check', 'i-sm') + '</button>').join('')
    : '<p class="small muted" style="padding:var(--sp-4) 0">' + (el.value ? 'Nobody by that name.' : CH.parent ? 'No teachers yet — they appear once your child is enrolled in a course.' : 'No one to message yet — you need to share a course with someone.') + '</p>';
};
ACT.chatPickToggle = (d, btn) => {
  if (CH.pick.has(d.id)) CH.pick.delete(d.id); else CH.pick.set(d.id, d.name);
  btn.classList.toggle('on', CH.pick.has(d.id));
  $('#pickChips').innerHTML = [...CH.pick].map(([id, n]) => '<span class="badge primary">' + chatEsc(n) + '</span>').join('');
  $('#pickGo').disabled = !CH.pick.size;
};
ACT.chatStartDM = (d, btn) => busy(btn, async () => {
  const r = await call('chatOpenDM', { uids: [...CH.pick.keys()] });
  CH.channels.set(r.channel.id, r.channel);
  (r.channel.people || []).forEach((p) => { CH.users[p.id] = p; });
  closeModal();
  if (CH.mounted) { chatRenderList(); chatOpen(r.channel.id); } else go('/chat/' + r.channel.id);
});
ACT.chatNewChannel = async (d) => {
  const general = [...CH.channels.values()].find((c) => c.courseId === d.course && c.general);
  CH.pick = new Map();
  formModal('New channel', 'In ' + chatEsc(general ? general.courseName || general.course : 'this course'), 'chatNewChannel',
    '<input type="hidden" name="course" value="' + esc(d.course) + '">' +
    field('Name', '<input type="text" name="name" maxlength="40" placeholder="e.g. project-team-a" autofocus>', 'Lower-case letters, numbers and dashes.') +
    field('Topic <span class="muted">(optional)</span>', '<input type="text" name="topic" maxlength="200" placeholder="What is this channel for?">') +
    '<label class="px-opt"><span class="switch"><input type="checkbox" name="priv" data-change="chatPrivToggle"><span class="track"></span></span><span><b>Private</b><span class="xs muted">Only people you add can see it. Otherwise everyone in the course can join in.</span></span></label>' +
    '<div id="privPick" class="hidden"><div class="small muted" style="margin-bottom:6px">Add members</div><div class="pick-list short" id="privList"><div class="sk sk-line"></div></div></div>', 'Create channel', 'narrow');
  if (general) {
    const r = await call('chatMembers', { ch: general.id }).catch(() => ({ members: [] }));
    const el = $('#privList'); if (el) el.innerHTML = r.members.filter((u) => !CH.me || u.id !== CH.me.id).map((u) => '<label class="pick"><input type="checkbox" name="m" value="' + esc(u.id) + '"><span class="chat-av">' + avatar(u.name, 'sm') + '</span><span><b>' + chatEsc(u.name) + '</b><span class="xs muted">' + chatEsc(u.role) + '</span></span></label>').join('');
  }
};
ACT.chatPrivToggle = (d, el) => { const p = $('#privPick'); if (p) p.classList.toggle('hidden', !el.checked); };
FORMS.chatNewChannel = (f, btn) => busy(btn, async () => {
  const e = f.elements;
  const members = $$('input[name=m]:checked', f).map((i) => i.value);
  const r = await call('chatCreateChannel', { courseId: e.course.value, name: e.name.value, topic: e.topic.value, private: e.priv.checked, members });
  CH.channels.set(r.channel.id, r.channel);
  closeModal(); chatRenderList(); chatOpen(r.channel.id);
  toast('#' + r.channel.name + ' is ready.');
});
ACT.chatSettings = () => {
  const c = CH.channels.get(CH.active); if (!c) return;
  formModal(c.general ? 'Edit topic' : 'Channel settings', '#' + chatEsc(c.name) + ' · ' + chatEsc(c.course), 'chatChannelSave',
    (c.general ? '' : field('Name', '<input type="text" name="name" maxlength="40" value="' + esc(c.name) + '">')) +
    field('Topic', '<input type="text" name="topic" maxlength="200" value="' + esc(c.topic) + '">') +
    (c.general ? '' : check('archived', 'Archive this channel (read-only, hidden from the list)', c.archived)), 'Save', 'narrow');
};
FORMS.chatChannelSave = (f, btn) => busy(btn, async () => {
  const e = f.elements;
  const r = await call('chatUpdateChannel', { ch: CH.active, topic: e.topic.value, name: e.name ? e.name.value : undefined, archived: e.archived ? e.archived.checked : undefined });
  CH.channels.set(r.channel.id, Object.assign(CH.channels.get(r.channel.id) || {}, r.channel));
  closeModal(); chatRenderList(); chatRenderHeader(); toast('Saved.');
});
ACT.chatNotifs = (d, btn) => { Notification.requestPermission().then((p) => { if (p === 'granted') { toast('Desktop notifications are on.'); btn.remove(); } }); };

// Touch screens have no hover: a tap on a message reveals its actions.
document.addEventListener('click', (e) => {
  if (!CH.mounted || !window.matchMedia || !matchMedia('(hover: none)').matches) return;
  const msg = e.target.closest && e.target.closest('.msg');
  if (!msg || e.target.closest('button, a, textarea')) return;
  const on = !msg.classList.contains('show-tools');
  $$('.msg.show-tools').forEach((x) => x.classList.remove('show-tools'));
  msg.classList.toggle('show-tools', on);
});

/** Full re-render after a reconnect. */
function chatRenderAll() { chatRenderList(); if (CH.active) chatOpen(CH.active, true); }
// Presence dots refresh every minute while the chat is open.
setInterval(() => {
  if (!CH.mounted) return;
  const ids = [...new Set([...CH.channels.values()].flatMap((c) => (c.people || []).map((p) => p.id)))];
  if (!ids.length) return;
  call('chatPresence', { uids: ids }).then((r) => {
    CH.channels.forEach((c) => (c.people || []).forEach((p) => { p.online = !!r.online[p.id]; }));
    chatRenderList(); chatRenderHeader();
  }).catch(() => {});
}, 60000);
