'use strict';
/* =====================================================================
   ANALYTICS VIEWS
   ===================================================================== */
const RANGES = [7, 14, 30, 90];
const RISK = {
  risk: { label: 'At risk', icon: 'alert', token: 'crit', order: 2 },
  watch: { label: 'Watch', icon: 'clock', token: 'warn', order: 1 },
  ok: { label: 'On track', icon: 'checkCircle', token: 'good', order: 0 }
};
function riskBadge(level) { const r = RISK[level]; return '<span class="risk ' + level + '">' + icon(r.icon) + r.label + '</span>'; }
function rangeDays(params) { const d = Number(params.get('days')); return RANGES.indexOf(d) >= 0 ? d : 30; }
function rangePills(base, days) {
  return '<span class="label-sm">Date range</span><div class="pills">' + RANGES.map((d) => '<a class="pill' + (d === days ? ' active' : '') + '" href="#' + base + '?days=' + d + '">' + d + ' days</a>').join('') + '</div>';
}
function kpi(label, value, sub, ico, hero) {
  return '<div class="card kpi' + (hero ? ' hero-kpi' : '') + '"><div class="kl">' + (ico ? icon(ico, 'i-sm') : '') + esc(label) + '</div><div class="kv">' + value + '</div>' + (sub ? '<div class="kd">' + sub + '</div>' : '') + '</div>';
}
function chartCard(title, sub, body, ico, tone) {
  return '<div class="card chart-card"><div class="card-head">' + (ico ? '<span class="i-tile sm tone-' + (tone || 'blue') + '">' + icon(ico) + '</span>' : '') +
    '<div><h2>' + esc(title) + '</h2>' + (sub ? '<div class="xs muted">' + sub + '</div>' : '') + '</div></div><div class="card-body">' + body + '</div></div>';
}
function lastSeen(t) { return t ? esc(rel(t)) : '<span class="muted">Never</span>'; }

/* =====================================================================
   COURSE ANALYTICS TAB
   ===================================================================== */
async function courseAnalyticsTab(c, params) {
  const days = rangeDays(params);
  const r = await call('courseAnalytics', { courseId: c.id, days, rules: prefs.get('riskRules', null) });
  S.analytics = r;
  S.anView = { filter: 'all', sort: 'risk', asc: false, sel: new Set() };
  const sm = r.summary;
  const base = '/course/' + c.id + '/analytics';
  const labels = r.daily.map((d) => d.day);
  const graded = r.students.filter((s) => s.grade != null);
  const avgHours = graded.length ? graded.reduce((a, s) => a + s.minutesAll, 0) / graded.length / 60 : null;
  const scatter = graded.length
    ? chartSlot('scatter', {
      points: graded.map((s) => ({ id: s.userId, name: s.name, x: Math.round(s.minutesAll / 6) / 10, y: s.grade, status: RISK[s.risk].token, statusLabel: RISK[s.risk].label })),
      xLabel: 'Hours in course (all time)', xFmt: (v) => v + ' h', xAvg: avgHours, yAvg: sm.avgGrade, label: 'Time in course versus grade'
    }) + '<div class="legend" style="margin:.6rem 0 0">' + ['risk', 'watch', 'ok'].map((k) => '<span><i class="k-' + RISK[k].token + '" style="border-radius:50%"></i>' + icon(RISK[k].icon) + RISK[k].label + '</span>').join('') + '</div>' +
      (r.students.length > graded.length ? '<p class="xs muted" style="margin:.4rem 0 0">' + plural(r.students.length - graded.length, 'student') + ' without a grade yet are not plotted.</p>' : '')
    : emptyState('chart', 'No grades yet', 'The chart appears once assignments or quizzes are graded.', '', false);

  const html =
    '<div class="filter-row">' + rangePills(base, days) + '<div class="spacer"></div>' +
    '<button class="btn btn-sm" data-act="progressReports" data-id="' + esc(c.id) + '">' + icon('send', 'i-sm') + 'Send progress reports</button>' +
    '<button class="btn btn-sm" data-act="riskRules">' + icon('settings', 'i-sm') + 'At-risk rules</button>' +
    '<button class="btn btn-sm" data-act="exportAnalytics">' + icon('download', 'i-sm') + 'Export CSV</button></div>' +
    '<div class="kpis">' +
    kpi('Active students', sm.active + '<small> / ' + sm.students + '</small>', deltaHtml(sm.active, sm.activePrev, 'vs previous ' + days + ' days'), 'users', true) +
    kpi('Avg time per student', esc(hoursFmt(sm.minutesPerStudent)), deltaHtml(sm.minutesPerStudent, sm.minutesPerStudentPrev, 'vs previous ' + days + ' days'), 'clock') +
    kpi('Average grade', sm.avgGrade != null ? sm.avgGrade + '<small>%</small>' : '—', 'Course total, graded students', 'award') +
    kpi('Average completion', sm.avgCompletion != null ? sm.avgCompletion + '<small>%</small>' : '—', 'Of visible activities', 'checkCircle') +
    kpi('Need attention', String(sm.atRisk + sm.watch), '<span class="risk risk">' + icon('alert') + sm.atRisk + ' at risk</span> <span class="risk watch">' + icon('clock') + sm.watch + ' watch</span>', 'target') +
    '</div>' +
    '<div class="grid-2" style="margin-bottom:1.25rem">' +
    chartCard('Daily active students', 'Students who opened anything in the course each day', chartSlot('columns', {
      labels, series: [{ name: 'Active students', values: r.daily.map((d) => d.active), token: '1' }], xFmt: shortDay, tipTitle: (i) => longDay(labels[i]), label: 'Daily active students'
    }) + tableView(['Day', 'Active students', 'Minutes', 'Page views'], r.daily.map((d) => [longDay(d.day), d.active, d.minutes, d.views])), 'users', 'blue') +
    chartCard('Time spent in the course', 'Total student time per day', chartSlot('area', {
      labels, values: r.daily.map((d) => d.minutes), name: 'Time in course', token: '1', xFmt: shortDay, tipTitle: (i) => longDay(labels[i]), yFmt: hoursFmt, valFmt: hoursFmt, unit: 60, label: 'Time spent in the course per day'
    }), 'clock', 'violet') + '</div>' +
    '<div class="grid-2" style="margin-bottom:1.25rem">' +
    chartCard('Time in course vs. grade', 'Each dot is a student. Click one for their report.', scatter, 'target', 'pink') +
    chartCard('When students are active', 'Active minutes by weekday and hour, all time', heatmapHtml(r.heat, 'Active minutes'), 'calendar', 'green') + '</div>' +
    '<div class="card" style="margin-bottom:1.25rem"><div class="card-head"><span class="i-tile sm tone-red">' + icon('target') + '</span><div><h2>Student performance</h2>' +
    '<div class="xs muted">Engagement, progress and grades in the last ' + days + ' days. At-risk rules: no access for ' + r.rules.inactiveDays + '+ days, grade below ' + r.rules.gradeBelow + '%, ' +
    r.rules.missed + '+ missed deadline, activity under ' + r.rules.activityPct + '% of the median.</div></div></div>' +
    '<div class="card-body row-wrap" style="padding-bottom:.75rem"><div class="pills" id="anFilter">' +
    [['all', 'All', r.students.length], ['risk', 'At risk', sm.atRisk], ['watch', 'Watch', sm.watch], ['ok', 'On track', r.students.length - sm.atRisk - sm.watch]].map(([k, l, n]) =>
      '<button class="pill' + (k === 'all' ? ' active' : '') + '" data-act="anFilter" data-f="' + k + '">' + l + ' <span class="muted">' + n + '</span></button>').join('') + '</div>' +
    '<div class="search-box" style="width:min(220px,40vw)">' + icon('search') + '<input type="search" placeholder="Find a student" data-input="anSearch" aria-label="Find a student"></div>' +
    '<div class="spacer"></div><span class="small muted" id="anSelCount"></span><button class="btn btn-sm btn-primary" data-act="nudge" id="anNudge" disabled>' + icon('send', 'i-sm') + 'Send reminder</button></div>' +
    (r.students.length ? '<div class="table-wrap"><table class="table sortable" id="anTable"><thead><tr><th style="width:36px"><input type="checkbox" data-change="anSelAll" aria-label="Select all shown" style="width:16px;height:16px;accent-color:var(--primary)"></th>' +
      [['name', 'Student'], ['risk', 'Status'], ['lastAccess', 'Last access'], ['minutes', 'Time'], ['activeDays', 'Active days'], ['views', 'Views'], ['completion', 'Completion'], ['grade', 'Grade'], ['missed', 'Missed'], ['posts', 'Posts']].map(([k, l]) =>
        '<th data-sort="' + k + '" data-act="anSort" data-k="' + k + '"' + (k === 'risk' ? ' class="sorted"' : '') + '>' + l + '</th>').join('') + '</tr></thead><tbody id="anBody"></tbody></table></div>'
      : '<div class="card-body">' + emptyState('users', 'No students enrolled', 'Enrol students to start collecting analytics.', '', false) + '</div>') + '</div>' +
    '<div class="card" style="margin-bottom:1.25rem"><div class="card-head"><span class="i-tile sm tone-amber">' + icon('layers') + '</span><div><h2>Content engagement</h2><div class="xs muted">How many students opened and completed each activity</div></div></div>' +
    contentTable(r) + '</div>' +
    '<div class="grid-2">' +
    chartCard('Grade distribution', 'Students by course-total band', chartSlot('columns', {
      labels: r.gradeDistribution.map((_, i) => i * 10 + (i === 9 ? '–100' : '–' + (i * 10 + 9))), series: [{ name: 'Students', values: r.gradeDistribution, token: '1' }], height: 200,
      tipTitle: (i) => 'Grade ' + (i * 10) + '–' + (i === 9 ? 100 : i * 10 + 9) + '%', label: 'Grade distribution'
    }) + tableView(['Grade band', 'Students'], r.gradeDistribution.map((n, i) => [(i * 10) + '–' + (i === 9 ? 100 : i * 10 + 9) + '%', n])), 'chart', 'green') +
    chartCard('Activity mix', 'Submissions, forum posts, quiz attempts and downloads per day', chartSlot('columns', {
      labels, xFmt: shortDay, tipTitle: (i) => longDay(labels[i]), height: 200, label: 'Activity mix per day',
      series: [{ name: 'Submissions', values: r.daily.map((d) => d.submit), token: '1' }, { name: 'Forum posts', values: r.daily.map((d) => d.post), token: '2' },
        { name: 'Quiz attempts', values: r.daily.map((d) => d.attempt), token: '3' }, { name: 'Downloads', values: r.daily.map((d) => d.download), token: '4' }]
    }) + tableView(['Day', 'Submissions', 'Forum posts', 'Quiz attempts', 'Downloads'], r.daily.map((d) => [longDay(d.day), d.submit, d.post, d.attempt, d.download])), 'activity', 'pink') +
    '</div><p class="xs muted" style="margin-top:1rem">Time is measured while a student has a course page open and is active (keyboard, mouse or scrolling within the last 5 minutes). Updated ' + esc(fmtTime(r.generatedAt)) + '.</p>';
  return { html, after: renderStudentRows };
}

function contentTable(r) {
  if (!r.content.length) return '<div class="card-body">' + emptyState('layers', 'No activities yet', 'Add activities to the course to see engagement.', '', false) + '</div>';
  const n = r.summary.students || 0;
  return '<div class="table-wrap"><table class="table"><thead><tr><th>Activity</th><th>Opened by</th><th class="num">Views</th><th>Completed</th><th class="num">Submitted</th><th class="num">Avg score</th><th>Last opened</th></tr></thead><tbody>' +
    r.content.map((m) => '<tr><td><div class="row">' + modTile(m.type, 'sm') + '<div style="min-width:0"><a class="strong" href="#/mod/' + esc(m.id) + '">' + esc(m.title) + '</a>' +
      '<div class="xs muted">' + esc(MOD[m.type].label) + ' · ' + esc(m.section) + (m.visible ? '' : ' · hidden') + '</div></div></div></td>' +
      '<td>' + meter(n ? Math.round(m.viewers / n * 100) : null) + '<div class="xs muted">' + m.viewers + ' of ' + n + '</div></td>' +
      '<td class="num">' + m.views + '</td><td>' + meter(n ? Math.round(m.completed / n * 100) : null) + '</td>' +
      '<td class="num">' + (m.submitted != null ? m.submitted : '<span class="muted">—</span>') + (m.lateCount ? '<div class="xs muted">' + m.lateCount + ' late</div>' : '') + '</td>' +
      '<td class="num">' + (m.avgScore != null ? '<span class="grade-pill ' + gradeClass(m.avgScore) + '">' + m.avgScore + '%</span>' : '<span class="muted">—</span>') + '</td>' +
      '<td class="small muted">' + (m.lastViewed ? esc(rel(m.lastViewed)) : 'Never') + '</td></tr>').join('') + '</tbody></table></div>';
}

/* ---------- student table: filter, search, sort, select ---------- */
function anRows() {
  const v = S.anView, list = S.analytics.students;
  const q = (v.q || '').toLowerCase();
  const key = v.sort;
  const val = (s) => (key === 'risk' ? RISK[s.risk].order * 100 + s.reasons.length : key === 'name' ? s.name.toLowerCase() : s[key] == null ? -1 : s[key]);
  return list.filter((s) => (v.filter === 'all' || s.risk === v.filter) && (!q || (s.name + ' ' + s.username + ' ' + s.batch).toLowerCase().indexOf(q) >= 0))
    .sort((a, b) => { const x = val(a), y = val(b); const c = x < y ? -1 : x > y ? 1 : 0; return (v.asc ? c : -c) || a.name.localeCompare(b.name); });
}
function renderStudentRows() {
  const body = $('#anBody');
  if (!body) return;
  const rows = anRows();
  body.innerHTML = rows.length ? rows.map((s) => '<tr><td><input type="checkbox" data-change="anSel" data-id="' + esc(s.userId) + '"' + (S.anView.sel.has(s.userId) ? ' checked' : '') + ' aria-label="Select ' + esc(s.name) + '" style="width:16px;height:16px;accent-color:var(--primary)"></td>' +
    '<td><div class="cell-user">' + avatar(s.name, 'sm') + '<div><b><button class="link strong" data-act="studentReport" data-id="' + esc(s.userId) + '">' + esc(s.name) + '</button></b><span>' + esc(s.batch || '@' + s.username) + '</span></div></div></td>' +
    '<td style="min-width:230px">' + riskBadge(s.risk) + (s.reasons.length ? '<div class="reasons">' + s.reasons.map((x) => '<span>' + esc(x.text) + '</span>').join('') + '</div>' : '') + '</td>' +
    '<td class="small">' + lastSeen(s.lastAccess) + '</td><td class="num">' + esc(hoursFmt(s.minutes)) + '</td><td class="num">' + s.activeDays + '</td><td class="num">' + s.views + '</td>' +
    '<td>' + meter(s.completion) + '</td><td class="num">' + (s.grade != null ? '<span class="grade-pill ' + gradeClass(s.grade) + '">' + s.grade + '%</span>' : '<span class="muted">—</span>') + '</td>' +
    '<td class="num">' + (s.missed ? '<b style="color:var(--danger)">' + s.missed + '</b>' : '0') + '</td><td class="num">' + s.posts + '</td></tr>').join('')
    : '<tr><td colspan="11" class="muted small" style="text-align:center;padding:1.5rem">No students match.</td></tr>';
  $$('#anTable th[data-sort]').forEach((th) => { th.classList.toggle('sorted', th.dataset.sort === S.anView.sort); th.classList.toggle('asc', th.dataset.sort === S.anView.sort && S.anView.asc); });
  updateSel();
}
function updateSel() {
  const n = S.anView.sel.size;
  const c = $('#anSelCount'), b = $('#anNudge');
  if (c) c.textContent = n ? n + ' selected' : '';
  if (b) b.disabled = !n;
}
ACT.anFilter = (d, btn) => { $$('#anFilter .pill').forEach((b) => b.classList.toggle('active', b === btn)); S.anView.filter = d.f; renderStudentRows(); };
INPUTS.anSearch = (el) => { S.anView.q = el.value.trim(); renderStudentRows(); };
ACT.anSort = (d) => { const v = S.anView; if (v.sort === d.k) v.asc = !v.asc; else { v.sort = d.k; v.asc = d.k === 'name'; } renderStudentRows(); };
ACT.anSel = (d, el) => { if (el.checked) S.anView.sel.add(d.id); else S.anView.sel.delete(d.id); updateSel(); };
ACT.anSelAll = (d, el) => { anRows().forEach((s) => { if (el.checked) S.anView.sel.add(s.userId); else S.anView.sel.delete(s.userId); }); renderStudentRows(); };
ACT.exportAnalytics = () => {
  const r = S.analytics;
  const head = ['Name', 'Username', 'Batch', 'Status', 'Reasons', 'Last access', 'Minutes (' + r.days + ' days)', 'Minutes (all time)', 'Active days', 'Views', 'Completion %', 'Grade %', 'Missed deadlines', 'Late submissions', 'Forum posts'];
  const rows = r.students.map((s) => [s.name, s.username, s.batch, RISK[s.risk].label, s.reasons.map((x) => x.text).join('; '), s.lastAccess ? fmt(s.lastAccess) : 'Never',
    s.minutes, s.minutesAll, s.activeDays, s.views, s.completion == null ? '' : s.completion, s.grade == null ? '' : s.grade, s.missed, s.late, s.posts]);
  downloadText(r.course.shortname + '-analytics-' + r.days + 'd.csv', csv([head].concat(rows)));
};

ACT.progressReports = async (d) => {
  if (!await confirmBox('Send progress reports?', '<p>Every student in this course, and their parents, will get a progress report covering grades, completion, overdue work and study time — in the app, and by email/SMS where those are switched on.</p>', 'Send reports')) return;
  busy(null, async () => {
    const r = await call('sendProgressReports', { courseId: d.id });
    toast('Progress reports sent for ' + plural(r.students, 'student') + (r.queued ? ' · ' + plural(r.queued, 'email/SMS', 'emails/SMS') + ' queued.' : '.'));
  });
};

/* ---------- at-risk rules ---------- */
ACT.riskRules = () => {
  const r = (S.analytics && S.analytics.rules) || { inactiveDays: 7, gradeBelow: 50, missed: 1, activityPct: 50 };
  formModal('At-risk rules', 'A student is flagged <b>Watch</b> when one rule matches and <b>At risk</b> when two or more do. Saved on this device for all your courses.', 'riskRules',
    '<div class="form-grid">' +
    field('No course access for (days)', '<input type="number" name="inactiveDays" min="1" max="90" value="' + r.inactiveDays + '">') +
    field('Course grade below (%)', '<input type="number" name="gradeBelow" min="1" max="100" value="' + r.gradeBelow + '">') +
    field('Missed deadlines (at least)', '<input type="number" name="missed" min="1" max="20" value="' + r.missed + '">') +
    field('Activity below % of class median', '<input type="number" name="activityPct" min="1" max="100" value="' + r.activityPct + '">') + '</div>' +
    '<button class="link small" type="button" data-act="resetRules">Reset to defaults</button>', 'Apply rules', 'narrow');
};
FORMS.riskRules = (f) => {
  const e = f.elements;
  prefs.set('riskRules', { inactiveDays: e.inactiveDays.value, gradeBelow: e.gradeBelow.value, missed: e.missed.value, activityPct: e.activityPct.value });
  closeModal(); toast('At-risk rules updated.'); refresh();
};
ACT.resetRules = () => { prefs.set('riskRules', null); closeModal(); toast('At-risk rules reset to the defaults.'); refresh(); };

/* ---------- reminders (Retention Center style) ---------- */
function nudgeModal(ids, courseName) {
  S.nudgeIds = ids;
  formModal('Send a reminder', 'To ' + plural(ids.length, 'student') + ' in ' + esc(courseName) + '. They always get an in-app notification that links to the course.', 'nudge',
    field('Message', '<textarea name="message" maxlength="500" style="min-height:120px">Hi! I noticed you haven’t been active in ' + esc(courseName) + ' recently. Please check the course page for upcoming deadlines, and let me know if you need any help.</textarea>') +
    '<fieldset class="fieldset"><legend>Also send</legend>' +
    check('email', 'By email', true) + check('sms', 'By SMS', false, 'Short text to the student’s mobile, if they have one.') +
    check('parents', 'A copy to their parents', false, 'Parents get the same message about their child, by the channels above.') +
    '<p class="xs muted" style="margin:.25rem 0 .5rem">Email and SMS only go out if they are switched on in Site settings and the person hasn’t opted out.</p></fieldset>',
    'Send reminder', 'narrow');
}
ACT.nudge = () => nudgeModal(Array.from(S.anView.sel), S.analytics.course.fullname);
ACT.nudgeOne = (d) => nudgeModal([d.id], d.course);
FORMS.nudge = (f, btn) => busy(btn, async () => {
  const courseId = (S.analytics && S.analytics.course.id) || (S.report && S.report.course.id);
  const e = f.elements;
  const r = await call('nudgeStudents', { courseId, userIds: S.nudgeIds, message: e.message.value, email: e.email.checked, sms: e.sms.checked, parents: e.parents.checked });
  closeModal(); toast('Reminder sent to ' + plural(r.sent, 'student') + '.');
  if (S.anView) { S.anView.sel.clear(); renderStudentRows(); }
});

/* ---------- individual student report ---------- */
ACT.studentReport = (d, el) => busy(el && el.tagName === 'BUTTON' ? el : null, async () => {
  const courseId = S.analytics ? S.analytics.course.id : S.course.course.id;
  const r = await call('studentReport', { courseId, userId: d.id, rules: prefs.get('riskRules', null) });
  S.report = r;
  const s = r.student;
  const labels = r.series.map((x) => x.day);
  const done = r.activities.filter((a) => a.done).length;
  openModal(modalHead(s.name, esc('@' + s.username + (s.batch ? ' · ' + s.batch : '') + (r.email ? ' · ' + r.email : '')) + ' · ' + esc(r.course.shortname)) +
    '<div class="modal-body"><div class="row-wrap" style="margin-bottom:1rem">' + riskBadge(s.risk) +
    (s.reasons.length ? s.reasons.map((x) => '<span class="badge">' + esc(x.text) + '</span>').join('') : '<span class="small muted">No at-risk rules match.</span>') + '</div>' +
    '<div class="kpis" style="grid-template-columns:repeat(auto-fit,minmax(130px,1fr))">' +
    kpi('Last access', s.lastAccess ? esc(rel(s.lastAccess)) : 'Never', '', 'history') +
    kpi('Time, last 30 days', esc(hoursFmt(s.minutes)), s.activeDays + ' active days', 'clock') +
    kpi('Course grade', s.grade != null ? s.grade + '<small>%</small>' : '—', '', 'award') +
    kpi('Completion', s.completion != null ? s.completion + '<small>%</small>' : '—', done + ' of ' + s.tracked + ' done', 'checkCircle') +
    kpi('Missed deadlines', String(s.missed), s.late ? s.late + ' late submissions' : '', 'alert') + '</div>' +
    chartCard('Daily time in course', 'Last 30 days', chartSlot('area', {
      labels, values: r.series.map((x) => x.minutes), name: 'Time in course', token: '1', xFmt: shortDay, tipTitle: (i) => longDay(labels[i]), yFmt: hoursFmt, valFmt: hoursFmt, unit: 60, height: 180, label: 'Daily time in course'
    }), 'activity', 'blue') +
    '<div class="grid-2" style="margin-top:1.25rem"><div class="card"><div class="card-head"><h3>Grades</h3></div>' +
    (r.grades.length ? '<table class="table"><tbody>' + r.grades.map((g) => '<tr><td><div class="row">' + modTile(g.type, 'sm') + '<span class="small strong">' + esc(g.title) + '</span></div></td><td class="num">' +
      (g.cell ? '<span class="grade-pill ' + gradeClass(pct(g.cell.score, g.cell.max)) + '">' + g.cell.score + ' / ' + g.cell.max + '</span>' : '<span class="muted small">Not graded</span>') + '</td></tr>').join('') + '</tbody></table>'
      : '<div class="card-body small muted">No graded activities.</div>') + '</div>' +
    '<div class="card"><div class="card-head"><h3>Activity</h3></div><table class="table"><tbody>' + r.activities.map((a) => '<tr><td><div class="row">' + modTile(a.type, 'sm') +
      '<span class="small">' + esc(a.title) + '</span></div></td><td class="small muted nowrap">' + (a.views ? plural(a.views, 'view') + ' · ' + esc(rel(a.lastViewed)) : 'Not opened') + '</td>' +
      '<td>' + (a.done ? badge('Done', 'success', 'check') : '') + '</td></tr>').join('') + '</tbody></table></div></div>' +
    '<div class="form-actions"><button class="btn" data-act="close">Close</button><button class="btn btn-primary" data-act="nudgeOne" data-id="' + esc(s.userId) + '" data-course="' + esc(r.course.fullname) + '">' + icon('send') + 'Send reminder</button></div></div>', 'xwide');
  mountCharts();
});

/* =====================================================================
   TEACHING INSIGHTS (all my courses)
   ===================================================================== */
async function viewInsights() {
  const r = await call('myInsights');
  if (r.role === 'student') { go('/dashboard'); return null; }
  const labels = r.series.map((x) => x.day);
  const totalStudents = r.courses.reduce((a, c) => a + c.students, 0);
  const html = pageHead('Teaching insights', { sub: 'Engagement and at-risk students across every course you teach.' + (S.me.role === 'admin' ? ' For the whole site, see <a href="#/admin/analytics">Site analytics</a>.' : '') }) +
    '<div class="kpis">' + kpi('Students need attention', String(r.atRiskTotal), 'Across your courses, last 7 days', 'target', true) +
    kpi('Courses', String(r.courses.length), plural(totalStudents, 'enrolment'), 'book') +
    kpi('Active students today', String(r.series.length ? r.series[r.series.length - 1].active : 0), deltaHtml(r.series.length ? r.series[r.series.length - 1].active : 0, r.series.length > 7 ? r.series[r.series.length - 8].active : null, 'vs a week ago'), 'users') + '</div>' +
    '<div class="split"><div>' + chartCard('Active students', 'Unique students active in your courses, last 14 days', chartSlot('columns', {
      labels, series: [{ name: 'Active students', values: r.series.map((x) => x.active), token: '1' }], xFmt: shortDay, tipTitle: (i) => longDay(labels[i]), label: 'Active students per day'
    }) + tableView(['Day', 'Active students'], r.series.map((x) => [longDay(x.day), x.active])), 'users', 'blue') +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-indigo">' + icon('book') + '</span><h2>Your courses</h2></div>' +
    (r.courses.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Course</th><th class="num">Students</th><th class="num">Active (7d)</th><th>Last 7 days</th><th>Attention</th><th class="num">Avg grade</th><th></th></tr></thead><tbody>' +
      r.courses.map((c) => '<tr><td><a class="strong" href="#/course/' + esc(c.course.id) + '">' + esc(c.course.fullname) + '</a><div class="xs muted">' + esc(c.course.shortname) + '</div></td>' +
        '<td class="num">' + c.students + '</td><td class="num">' + c.active + '</td><td>' + sparkline(c.spark) + '</td>' +
        '<td>' + (c.atRisk ? '<span class="risk risk">' + icon('alert') + c.atRisk + '</span> ' : '') + (c.watch ? '<span class="risk watch">' + icon('clock') + c.watch + '</span>' : '') + (!c.atRisk && !c.watch ? '<span class="risk ok">' + icon('checkCircle') + 'All on track</span>' : '') + '</td>' +
        '<td class="num">' + (c.avgGrade != null ? '<span class="grade-pill ' + gradeClass(c.avgGrade) + '">' + c.avgGrade + '%</span>' : '—') + '</td>' +
        '<td class="actions"><a class="btn btn-sm btn-soft" href="#/course/' + esc(c.course.id) + '/analytics">' + icon('trending', 'i-sm') + 'Analytics</a></td></tr>').join('') + '</tbody></table></div>'
      : '<div class="card-body">' + emptyState('book', 'No courses yet', 'Create a course to start seeing insights.', '', false) + '</div>') + '</div></div>' +
    '<div>' + attentionCard(r) + '</div></div>';
  return { title: 'Insights', html };
}
function attentionCard(r, limit) {
  const list = r.atRisk.slice(0, limit || 8);
  return '<div class="card"><div class="card-head"><span class="i-tile sm tone-red">' + icon('target') + '</span><div><h2>Students needing attention</h2><div class="xs muted">' + plural(r.atRiskTotal, 'student') + ' flagged</div></div></div>' +
    (list.length ? list.map((s) => '<a class="disc-row" href="#/course/' + esc(s.course.id) + '/analytics">' + avatar(s.name, 'sm') + '<div class="dr-main"><div class="dr-title">' + esc(s.name) + ' ' + riskBadge(s.risk) + '</div>' +
      '<div class="dr-meta">' + esc(s.course.shortname) + ' · ' + esc(s.reasons.map((x) => x.text).join(' · ')) + '</div></div>' + icon('right') + '</a>').join('')
      : '<div class="card-body">' + emptyState('checkCircle', 'Everyone is on track', 'No student matches the at-risk rules this week.', '', false) + '</div>') + '</div>';
}

/* =====================================================================
   SITE ANALYTICS (admin)
   ===================================================================== */
async function viewSiteAnalytics(params) {
  const days = rangeDays(params);
  const r = await call('siteAnalytics', { days });
  S.siteAnalytics = r;
  const k = r.kpis;
  const labels = r.daily.map((d) => d.day);
  const toolRows = Object.keys(r.tools).filter((t) => MOD[t]).map((t) => ({ label: MOD[t].label, value: r.tools[t], icon: '<span class="i-tile tone-' + MOD[t].tone + '" style="width:22px;height:22px;border-radius:6px">' + icon(MOD[t].icon, 'i-sm') + '</span>' })).sort((a, b) => b.value - a.value);
  const html = pageHead('Site analytics', { crumbs: [['Site administration'], ['Site analytics']], sub: 'Usage and engagement across the whole site.' }) +
    '<div class="filter-row">' + rangePills('/admin/analytics', days) + '<div class="spacer"></div><button class="btn btn-sm" data-act="exportSite">' + icon('download', 'i-sm') + 'Export CSV</button></div>' +
    '<div class="kpis">' + kpi('Active users', String(k.activeUsers), deltaHtml(k.activeUsers, k.activePrev, 'vs previous ' + days + ' days'), 'users', true) +
    kpi('Avg daily active', String(k.avgDailyActive), plural(k.uniqueLogins, 'person', 'people') + ' signed in', 'activity') +
    kpi('Time on site', k.hours + '<small> h</small>', plural(k.logins, 'sign-in'), 'clock') +
    kpi('Submissions', String(k.submissions), k.attempts + ' quiz attempts · ' + k.posts + ' posts', 'inbox') +
    kpi('Content', String(k.activities), k.visibleCourses + ' of ' + k.courses + ' courses visible · ' + fileSize(k.storageBytes) + ' files', 'layers') + '</div>' +
    '<div class="grid-2" style="margin-bottom:1.25rem">' +
    chartCard('Daily active users', 'People who used the site each day', chartSlot('area', {
      labels, values: r.daily.map((d) => d.active), name: 'Active users', token: '1', xFmt: shortDay, tipTitle: (i) => longDay(labels[i]), label: 'Daily active users'
    }) + tableView(['Day', 'Active users', 'People signed in', 'Minutes'], r.daily.map((d) => [longDay(d.day), d.active, d.logins, d.minutes])), 'users', 'blue') +
    chartCard('Sign-ins per day', 'Unique people signing in', chartSlot('columns', {
      labels, series: [{ name: 'People signed in', values: r.daily.map((d) => d.logins), token: '1' }], xFmt: shortDay, tipTitle: (i) => longDay(labels[i]), label: 'Sign-ins per day'
    }), 'key', 'violet') + '</div>' +
    '<div class="grid-3" style="margin-bottom:1.25rem;grid-template-columns:repeat(auto-fit,minmax(280px,1fr))">' +
    chartCard('Active users by role', 'Last ' + days + ' days, of all active accounts', hbars(['student', 'teacher', 'admin'].map((role) => ({ label: role.charAt(0).toUpperCase() + role.slice(1) + 's', value: k.activeByRole[role] || 0 })), String) +
      '<p class="xs muted" style="margin:.8rem 0 0">Accounts: ' + plural(k.users.student || 0, 'student') + ' · ' + plural(k.users.teacher || 0, 'teacher') + ' · ' + plural(k.users.admin || 0, 'admin') + '</p>', 'users', 'green') +
    chartCard('Tool usage', 'Page views by activity type', toolRows.length ? hbars(toolRows) : '<p class="small muted">No views yet.</p>', 'grid', 'amber') +
    chartCard('When the site is busiest', 'Active minutes by weekday and hour', heatmapHtml(r.heat, 'Active minutes'), 'calendar', 'pink') + '</div>' +
    '<div class="card" style="margin-bottom:1.25rem"><div class="card-head"><span class="i-tile sm tone-indigo">' + icon('trending') + '</span><div><h2>Most active courses</h2><div class="xs muted">By student time in the last ' + days + ' days</div></div></div>' +
    (r.topCourses.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Course</th><th>Active students</th><th class="num">Time</th><th class="num">Page views</th><th></th></tr></thead><tbody>' +
      r.topCourses.map((c) => '<tr><td><a class="strong" href="#/course/' + esc(c.id) + '">' + esc(c.fullname) + '</a><div class="xs muted">' + esc(c.shortname) + '</div></td>' +
        '<td>' + meter(c.enrolled ? Math.round(c.activeStudents / c.enrolled * 100) : null) + '<div class="xs muted">' + c.activeStudents + ' of ' + c.enrolled + ' enrolled</div></td>' +
        '<td class="num">' + esc(hoursFmt(c.minutes)) + '</td><td class="num">' + c.views + '</td>' +
        '<td class="actions"><a class="btn btn-sm btn-soft" href="#/course/' + esc(c.id) + '/analytics">' + icon('trending', 'i-sm') + 'Analytics</a></td></tr>').join('') + '</tbody></table></div>'
      : '<div class="card-body">' + emptyState('trending', 'No course activity yet', 'Course activity appears here as students use the site.', '', false) + '</div>') + '</div>' +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-red">' + icon('alert') + '</span><div><h2>Inactive students</h2><div class="xs muted">' + plural(r.inactive.count, 'student') + ' with no activity in 14+ days</div></div></div>' +
    (r.inactive.list.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Student</th><th>Batch</th><th>Last active</th></tr></thead><tbody>' +
      r.inactive.list.map((u) => '<tr><td><div class="cell-user">' + avatar(u.name, 'sm') + '<div><b>' + esc(u.name) + '</b><span>@' + esc(u.username) + '</span></div></div></td><td>' + esc(u.batch || '—') + '</td><td class="small">' + lastSeen(u.last) + '</td></tr>').join('') +
      '</tbody></table></div>' + (r.inactive.count > r.inactive.list.length ? '<div class="card-foot small muted">Showing the first ' + r.inactive.list.length + '.</div>' : '')
      : '<div class="card-body">' + emptyState('checkCircle', 'No inactive students', 'Every student has been active in the last two weeks.', '', false) + '</div>') + '</div>';
  return { title: 'Site analytics', html };
}
ACT.exportSite = () => {
  const r = S.siteAnalytics;
  downloadText('site-activity-' + r.days + 'd.csv', csv([['Day', 'Active users', 'People signed in', 'Active minutes']].concat(r.daily.map((d) => [d.day, d.active, d.logins, d.minutes]))));
};

/* =====================================================================
   DASHBOARD WIDGETS
   ===================================================================== */
function dashboardInsights(r) {
  if (!r) return '';
  const labels = r.series.map((x) => x.day);
  if (r.role === 'student') {
    const maxMin = Math.max(1, ...r.courses.map((c) => Math.max(c.mine, c.classAvg)));
    return '<div class="card"><div class="card-head"><span class="i-tile sm tone-blue">' + icon('activity') + '</span><div><h2>Your study time</h2>' +
      '<div class="xs muted">This week: <b style="color:var(--text)">' + esc(hoursFmt(r.week)) + '</b> ' + deltaHtml(r.week, r.prevWeek, 'vs last week') + '</div></div></div><div class="card-body">' +
      chartSlot('columns', { labels, series: [{ name: 'Study time', values: r.series.map((x) => x.minutes), token: '1' }], xFmt: shortDay, tipTitle: (i) => longDay(labels[i]), yFmt: hoursFmt, valFmt: hoursFmt, unit: 60, height: 170, label: 'Your study time per day' }) +
      (r.courses.length ? '<div class="legend" style="margin:1rem 0 .6rem"><span><i class="k-1"></i>You</span><span><i class="k-2"></i>Class average</span></div><div class="me-vs">' +
        r.courses.map((c) => '<div><div class="row-top"><span class="strong small">' + esc(c.shortname) + '</span><span class="xs muted">' + esc(hoursFmt(c.mine)) + ' vs ' + esc(hoursFmt(c.classAvg)) + ' · 7 days</span></div>' +
          '<div class="bars"><div class="k-1" style="width:' + (c.mine / maxMin * 100) + '%"></div><div class="k-2" style="width:' + (c.classAvg / maxMin * 100) + '%"></div></div></div>').join('') + '</div>' : '') +
      '</div></div>';
  }
  return attentionCard(r, 5) +
    '<div class="card">' + '<div class="card-head"><span class="i-tile sm tone-blue">' + icon('users') + '</span><div><h2>Student engagement</h2><div class="xs muted">Active students per day, last 14 days</div></div>' +
    '<div class="spacer"></div><a class="small" href="#/insights">Insights</a></div><div class="card-body">' +
    chartSlot('columns', { labels, series: [{ name: 'Active students', values: r.series.map((x) => x.active), token: '1' }], xFmt: shortDay, tipTitle: (i) => longDay(labels[i]), height: 160, label: 'Active students per day' }) + '</div></div>';
}
