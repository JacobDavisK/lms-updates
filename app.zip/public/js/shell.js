'use strict';
/* =====================================================================
   SIGN-IN
   ===================================================================== */
function authShell(inner) {
  return '<div class="auth"><section class="auth-hero">' +
    '<div class="brand"><span class="brand-mark">' + icon('logo') + '</span><span class="brand-name">' + esc(SITE) + '<span class="brand-sub">Learning management system</span></span></div>' +
    '<div class="auth-hero-body"><h1>Learn, teach and assess — <em>all in one place.</em></h1>' +
    '<p class="lead">Courses, assignments, discussions, secure timed quizzes and a live gradebook — built for real classrooms.</p>' +
    '<ul class="feature-list">' +
    '<li><span class="f-ico">' + icon('layers') + '</span>Structured courses with topics, resources and activities</li>' +
    '<li><span class="f-ico">' + icon('shield') + '</span>Timed quizzes with exam-mode integrity monitoring</li>' +
    '<li><span class="f-ico">' + icon('chart') + '</span>Gradebook, completion tracking and item analysis</li>' +
    '<li><span class="f-ico">' + icon('forum') + '</span>Forums, announcements and notifications</li>' +
    '<li><span class="f-ico">' + icon('users') + '</span>Parent portal with email &amp; SMS progress alerts</li></ul></div>' +
    '<div class="float-card fc-1">' + icon('checkCircle') + ' Assignment submitted<br><span style="opacity:.7">Graded with feedback</span></div>' +
    '<div class="float-card fc-2">' + icon('clock') + ' Quiz · 30 min<br><span style="opacity:.7">Auto-saved answers</span></div>' +
    '<div class="auth-foot">Open source · MIT licensed</div></section>' +
    '<section class="auth-panel"><div class="auth-card">' + inner + '</div></section></div>';
}

function viewLogin(msg) {
  stopPolling();
  document.title = SITE;
  app.innerHTML = authShell('<h2>Welcome back</h2><p class="sub">Sign in to continue to ' + esc(SITE) + '.</p>' +
    (msg ? notice(esc(msg), 'warn') : '') +
    '<form data-form="login" autocomplete="on" novalidate>' +
    '<div class="field"><label class="label" for="lu">College ID or mobile number</label><div class="input-ico">' + icon('user') +
    '<input id="lu" type="text" name="u" maxlength="64" autocomplete="username" autocapitalize="none" spellcheck="false" placeholder="e.g. 24-UBC-202 · parents: 98765 43210"></div></div>' +
    '<div class="field"><label class="label" for="lp">Password</label><div class="input-ico">' + icon('lock') +
    '<input id="lp" type="password" name="p" maxlength="128" autocomplete="current-password">' +
    '<button type="button" class="btn-icon sm pw-toggle" data-act="pwToggle" aria-label="Show password">' + icon('eye') + '</button></div></div>' +
    '<button class="btn btn-primary btn-lg btn-block" type="submit">Sign in ' + icon('arrowRight') + '</button></form>' +
    demoLoginsHtml() +
    '<details class="auth-first"><summary>' + icon('key', 'i-sm') + 'Signing in for the first time?</summary><dl>' +
    '<dt>Students &amp; teachers</dt><dd>College ID, and your registered <b>mobile number</b> as the password.</dd>' +
    '<dt>Parents</dt><dd>Your 10-digit <b>mobile number</b>, and your child’s <b>college ID</b> as the password.</dd></dl>' +
    '<p>We may text a one-time code to your registered mobile to confirm it’s you. You’ll then choose your own password. First-time passwords expire after two weeks — ask the college office if yours has.</p></details>' +
    '<div class="auth-help">' + icon('info') + '<span>Forgot your password? Ask your teacher or administrator to reset it. Accounts are created by your institution.</span></div>');
  const u = $('#lu'); if (u) u.focus();
}
/* One-click demo sign-ins (shown only while the admin setting "Show demo sign-ins" is on). */
const DEMO_ICON = { admin: ['shield', 'indigo'], teacher: ['book', 'blue'], student: ['cap', 'green'], parent: ['users', 'amber'] };
function demoLoginsHtml() {
  const list = (typeof DEMO_LOGINS !== 'undefined' && Array.isArray(DEMO_LOGINS)) ? DEMO_LOGINS : [];
  if (!list.length) return '';
  return '<div class="demo-logins"><div class="demo-sep"><span>or try a demo account</span></div><div class="demo-grid">' +
    list.map((a) => {
      const ic = DEMO_ICON[a.role] || ['user', 'indigo'];
      return '<button type="button" class="demo-tile" data-act="demoLogin" data-u="' + esc(a.username) + '" title="Sign in as the demo ' + esc(a.label.toLowerCase()) + '">' +
        '<span class="i-tile sm tone-' + ic[1] + '">' + icon(ic[0]) + '</span>' +
        '<span class="demo-body"><b>' + esc(a.label) + '</b><span class="demo-about">' + esc(a.about) + '</span>' +
        '<span class="demo-cred"><code>' + esc(a.username) + '</code><code>' + esc(a.password) + '</code></span></span>' +
        '<span class="demo-go">' + icon('arrowRight', 'i-sm') + '</span></button>';
    }).join('') + '</div></div>';
}
ACT.demoLogin = (d, btn) => {
  const a = DEMO_LOGINS.find((x) => x.username === d.u);
  if (!a) return;
  const f = document.querySelector('form[data-form="login"]');
  if (f) { f.elements.u.value = a.username; f.elements.p.value = a.password; }
  busy(btn, async () => {
    const r = await run('login', a.username, a.password);
    if (r.otp) { S.pending = r.pending; viewOtp(r.hint); } else afterLogin(r);
  });
};
ACT.pwToggle = (d, el) => {
  const i = el.parentElement.querySelector('input');
  i.type = i.type === 'password' ? 'text' : 'password';
  el.innerHTML = icon(i.type === 'password' ? 'eye' : 'eyeOff');
};
FORMS.login = (f, btn) => busy(btn, async () => {
  const u = f.elements.u.value.trim(), p = f.elements.p.value;
  if (!u || !p) throw new Error('Enter your college ID (parents: mobile number) and password.');
  const r = await run('login', u, p);
  if (r.otp) { S.pending = r.pending; viewOtp(r.hint); } else afterLogin(r);
});

function viewOtp(hint) {
  app.innerHTML = authShell('<h2>Enter your sign-in code</h2><p class="sub">We sent a 6-digit code to ' + esc(hint) + '. It expires in 5 minutes.</p>' +
    '<form data-form="otp" novalidate><div class="field"><label class="label" for="oc">Sign-in code</label><div class="input-ico">' + icon('key') +
    '<input id="oc" type="text" name="c" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" autofocus></div></div>' +
    '<button class="btn btn-primary btn-lg btn-block" type="submit">Verify and sign in</button></form>' +
    '<p class="small" style="margin-top:1.25rem"><button class="link" data-act="toLogin">' + icon('arrowLeft', 'i-sm') + ' Back to sign in</button></p>');
  const c = $('#oc'); if (c) c.focus();
}
FORMS.otp = (f, btn) => busy(btn, async () => { afterLogin(await run('verifyOtp', S.pending, f.elements.c.value)); });
ACT.toLogin = () => viewLogin();

function afterLogin(r) {
  S.token = r.token; S.me = r.me; S.pending = null;
  tokenStore.set(r.token);
  if (r.me.mustChange) viewChangePw(true); else startApp();
}

function pwFields(forced) {
  return '<div class="field"><label class="label">Current password' + (forced ? '<span class="hint">' + (S.me && S.me.role === 'parent' ? 'Your child’s college ID.' : S.me && (S.me.role === 'student' || S.me.role === 'teacher') ? 'Your mobile number (unless you were given a temporary password).' : 'The temporary password you were given.') + '</span>' : '') + '</label>' +
    '<input type="password" name="o" maxlength="128" autocomplete="current-password" autofocus></div>' +
    '<div class="field"><label class="label">New password<span class="hint">At least 8 characters, with a letter and a number. Must not contain your username.</span></label>' +
    '<input type="password" name="n" maxlength="128" autocomplete="new-password"></div>' +
    '<div class="field"><label class="label">Repeat new password</label><input type="password" name="n2" maxlength="128" autocomplete="new-password"></div>';
}
function viewChangePw(forced) {
  if (forced) {
    const first = S.me && S.me.role === 'parent' ? 'your child’s college ID' : S.me && (S.me.role === 'student' || S.me.role === 'teacher') ? 'your mobile number' : 'the temporary password you were given';
    app.innerHTML = authShell('<h2>Set your password</h2><p class="sub">Welcome! Choose your own password before you continue. Your current password is ' + first + ' — easy for others to guess.</p>' +
      '<form data-form="chpw" data-forced="1" novalidate>' + pwFields(true) + '<button class="btn btn-primary btn-lg btn-block" type="submit">Save password and continue</button></form>' +
      '<p class="small" style="margin-top:1.25rem"><button class="link" data-act="logout">Sign out</button></p>');
    const o = $('input[name=o]'); if (o) o.focus();
  } else {
    formModal('Change password', 'You will stay signed in on this device.', 'chpw', pwFields(false), 'Change password', 'narrow');
  }
}
ACT.chpw = () => viewChangePw(false);
FORMS.chpw = (f, btn) => busy(btn, async () => {
  const o = f.elements.o.value, n = f.elements.n.value, n2 = f.elements.n2.value;
  if (!o) throw new Error('Enter your current password.');
  if (n !== n2) throw new Error('The new passwords do not match.');
  if (n.length < 8 || !/[A-Za-z]/.test(n) || !/[0-9]/.test(n)) throw new Error('Use at least 8 characters with a letter and a number.');
  await call('changePassword', { oldPassword: o, newPassword: n });
  S.me.mustChange = false;
  closeModal();
  toast('Password changed.');
  if (f.dataset.forced) startApp();
});

ACT.logout = async () => {
  try { await call('logout'); } catch (e) { /* signing out anyway */ }
  endSession('You have signed out.');
};
function endSession(msg) {
  if (typeof stopExam === 'function' && S.attempt) stopExam();
  S.token = null; S.me = null;
  tokenStore.set(null);
  closeModal();
  viewLogin(msg);
}

/* =====================================================================
   APP FRAME
   ===================================================================== */
function navLink(href, ico, label, extra) {
  return '<a class="nav-item" href="#' + href + '" data-nav="' + href + '">' + icon(ico) + '<span>' + label + '</span>' + (extra || '') + '</a>';
}
/** Mobile: four primary destinations plus "More", which opens the full navigation as a sheet. */
function tabBar(parent) {
  const t = (href, ico, label, extra) => '<a class="tab-item" href="#' + href + '" data-nav="' + href + '">' + icon(ico) + '<span>' + label + '</span>' + (extra || '') + '</a>';
  const unread = '<span class="count hidden" id="tabUnread"></span>';
  const items = parent
    ? t('/family', 'users', 'Family') + t('/chat', 'message', 'Messages', '<span class="count hidden" id="tabChat"></span>') + t('/notifications', 'bell', 'Alerts', unread) + t('/profile', 'settings', 'Profile')
    : t('/dashboard', 'dashboard', 'Home') + t('/courses', 'book', 'Courses') + t('/chat', 'message', 'Messages', '<span class="count hidden" id="tabChat"></span>') + t('/notifications', 'bell', 'Alerts', unread);
  return '<nav class="tabbar" aria-label="Primary">' + items +
    '<button type="button" class="tab-item more" data-act="openNav" aria-label="More navigation">' + icon('menu') + '<span>More</span></button></nav>';
}
function homePath() { return S.me && S.me.role === 'parent' ? '/family' : '/dashboard'; }
function renderLayout() {
  const me = S.me;
  const parent = me.role === 'parent';
  const staff = me.role === 'teacher' || me.role === 'admin';
  const admin = me.role === 'admin';
  const unread = '<span class="count hidden" id="navUnread"></span>';
  let nav = parent
    ? '<div class="nav-group">' + navLink('/family', 'users', 'My family') + navLink('/attendance', 'calendar', 'Attendance') + navLink('/marks', 'chart', 'Marks') +
      navLink('/chat', 'message', 'Message teachers', '<span class="count hidden" id="navChat"></span>') + navLink('/mentoring', 'compass', 'Mentoring') +
      navLink('/notifications', 'bell', 'Notifications', unread) + navLink('/profile', 'settings', 'Alerts & profile') + '</div>'
    : '<div class="nav-group">' +
      navLink('/dashboard', 'dashboard', 'Dashboard') +
      navLink('/courses', 'book', 'My courses') +
      navLink('/catalog', 'compass', 'Course catalogue') +
      navLink('/calendar', 'calendar', 'Calendar') +
      navLink('/grades', 'chart', 'Grades') +
      navLink('/notifications', 'bell', 'Notifications', unread) + '</div>';
  if (!parent) {
    nav += '<div class="nav-group"><div class="nav-label">Assessment</div>' + (staff
      ? navLink('/assessment', 'shield', 'Proctoring') + navLink('/assessment/live', 'live', 'Live monitor') + navLink('/assessment/reviews', 'gavel', 'Integrity reviews')
      : navLink('/assessment', 'shield', 'Proctored exams')) + navLink('/assessment/check', 'activity', 'System check') + '</div>';
    nav += '<div class="nav-group"><div class="nav-label">Examinations</div>' + (staff
      ? navLink('/exams', 'exam', 'Question papers') + navLink('/exams/templates', 'template', 'QP templates') + navLink('/marks', 'edit', 'Mark entry')
      : navLink('/marks', 'chart', 'My marks')) + '</div>';
    nav += '<div class="nav-group"><div class="nav-label">Attendance</div>' + (staff
      ? navLink('/attendance', 'check', 'Take attendance') + navLink('/attendance/reports', 'download', 'Attendance reports') +
        navLink('/leave', 'calendar', 'Leave') + navLink('/movements', 'clock', 'Movements') +
        (me.leaveApprover ? navLink('/leave/desk', 'checkCircle', 'Leave desk', '<span class="count' + (me.leavePending ? '' : ' hidden') + '" id="navLeave">' + (me.leavePending || '') + '</span>') : '')
      : navLink('/attendance', 'calendar', 'My attendance') + navLink('/attendance/requests', 'send', 'OD / ML requests')) + '</div>';
    nav += '<div class="nav-group"><div class="nav-label">Communication</div>' +
      navLink('/chat', 'message', 'Messages', '<span class="count hidden" id="navChat"></span>') + '</div>';
    const mt = me.mentoring || {};
    nav += '<div class="nav-group"><div class="nav-label">Mentoring</div>' + (staff
      ? navLink('/mentoring', 'compass', 'Mentoring dashboard', mt.pending ? '<span class="count">' + mt.pending + '</span>' : '') + navLink('/mentoring/mentees', 'users', 'My mentees') +
        navLink('/mentoring/followups', 'clock', 'Follow-ups') + (mt.coordinator || mt.hod ? navLink('/mentoring/allocation', 'userPlus', 'Mentor allocation') : '') +
        navLink('/mentoring/analytics', 'trending', mt.coordinator || mt.principal ? 'Mentoring analytics' : mt.hod ? 'Department mentoring' : 'Mentoring analytics')
      : navLink('/mentoring', 'compass', 'My mentoring') + navLink('/mentoring/goals', 'target', 'My goals') + navLink('/mentoring/concerns', 'message', 'Support requests') + navLink('/mentoring/development', 'award', 'My development')) + '</div>';
  }
  if (!parent && me.studio) nav += '<div class="nav-group"><div class="nav-label">Content Studio</div>' + navLink('/studio', 'sparkle', staff ? 'Studio home' : 'My studio', me.studio.review ? '<span class="count">' + me.studio.review + '</span>' : '') + navLink('/studio/library', 'folder', staff ? 'Content library' : 'My work') +
    (staff ? navLink('/studio/live', 'live', 'Live activities') + navLink('/studio/outcomes', 'target', 'Outcomes & syllabus') + navLink('/studio/analytics', 'trending', 'Studio analytics') : '') + (me.studio.settings ? navLink('/studio/settings', 'settings', 'Studio settings') : '') + '</div>';
  if (!parent && me.sim) nav += '<div class="nav-group"><div class="nav-label">Business simulations</div>' + navLink('/sim', 'briefcase', staff ? 'Simulation dashboard' : 'My simulations', me.sim.pending ? '<span class="count">' + me.sim.pending + '</span>' : '') +
    (staff ? navLink('/sim/library', 'layers', 'Simulations') + navLink('/sim/new', 'template', 'Simulation templates') : '') + (me.sim.admin ? navLink('/sim/settings', 'settings', 'Simulation settings') : '') + '</div>';
  if (staff) nav += '<div class="nav-group"><div class="nav-label">Teaching</div>' + navLink('/insights', 'trending', 'Insights') + (admin ? '' : navLink('/admin/users', 'users', 'Students & parents')) + '</div>';
  if (admin) {
    nav += '<div class="nav-group"><div class="nav-label">Site administration</div>' +
      navLink('/admin/analytics', 'activity', 'Site analytics') +
      navLink('/admin/users', 'users', 'Users') + navLink('/admin/userdemo', 'userPlus', 'User demo') + navLink('/admin/courses', 'layers', 'Courses') +
      navLink('/admin/announcements', 'megaphone', 'Site news') + navLink('/admin/settings', 'settings', 'Settings') + navLink('/mentoring/settings', 'compass', 'Mentoring settings') +
      navLink('/admin/messages', 'send', 'Email & SMS log') +
      navLink('/admin/audit', 'shield', 'Audit log') + '</div>';
  }
  app.innerHTML = '<div class="shell">' +
    '<aside class="sidebar" id="sidebar" aria-label="Main navigation"><a class="brand" href="#' + homePath() + '"><span class="brand-mark">' + icon('logo') + '</span>' +
    '<span class="brand-name">' + esc(SITE) + '<span class="brand-sub">Learning platform</span></span></a>' + nav +
    '<div class="sidebar-foot"><a class="me-card" href="#/profile">' + avatar(me.name) + '<span class="who"><b>' + esc(me.name) + '</b><span>' + esc(me.role) + '</span></span></a></div></aside>' +
    '<div class="scrim" data-act="closeNav"></div>' + tabBar(parent) +
    '<div class="main-col"><header class="topbar">' +
    '<button class="btn-icon menu-toggle" data-act="openNav" aria-label="Open menu">' + icon('menu') + '</button>' +
    (parent ? '<div class="spacer"></div>' : '<form class="search-box" data-form="search" role="search">' + icon('search') +
      '<input id="globalSearch" type="search" name="q" placeholder="Search courses and activities…" autocomplete="off" aria-label="Search"><kbd>Ctrl K</kbd></form>') +
    '<div class="topbar-actions">' +
    '<button class="btn-icon theme-ico" data-act="theme" title="Toggle dark mode" aria-label="Toggle dark mode">' + icon(theme() === 'dark' ? 'sun' : 'moon') + '</button>' +
    '<div class="menu-wrap bell" data-onopen="loadNotifMenu"><button class="btn-icon" data-act="menu" aria-label="Notifications">' + icon('bell') + '<span class="dot hidden" id="bellDot"></span></button>' +
    '<div class="menu notif-menu" id="notifMenu"></div></div>' +
    '<div class="menu-wrap"><button class="btn-icon" data-act="menu" aria-label="Account menu" style="width:auto;padding:0 4px">' + avatar(me.name, 'sm') + '</button>' +
    '<div class="menu"><div class="menu-head"><b>' + esc(me.name) + '</b><div class="small muted">@' + esc(me.username) + ' · ' + esc(me.role) + '</div></div><div class="menu-sep"></div>' +
    '<a class="menu-item" href="#/profile">' + icon('user') + 'Profile</a>' +
    (parent ? '<a class="menu-item" href="#/family">' + icon('users') + 'My family</a>' : '<a class="menu-item" href="#/grades">' + icon('chart') + 'Grades</a>') +
    '<button class="menu-item" data-act="igSummon">' + icon('sparkle') + 'Talk to St. Ignatius</button>' +
    '<button class="menu-item" data-act="chpw">' + icon('key') + 'Change password</button>' +
    '<button class="menu-item" data-act="theme">' + icon('moon') + 'Toggle dark mode</button>' +
    '<div class="menu-sep"></div><button class="menu-item danger" data-act="logout">' + icon('logout') + 'Sign out</button></div></div>' +
    '</div></header><main class="content" id="main"></main></div></div>';
  updateUnread(S.unread);
}
function startApp() {
  renderLayout();
  const h = location.hash;
  if (!h || h === '#' || h === '#/' || (S.me.role === 'parent' && !/^#\/(family|child|notifications|profile|attendance|marks|chat|mentoring$)/.test(h))) history.replaceState(null, '', '#' + homePath());
  render();
  startPolling();
}
/** Brings the app frame back after exam mode (which takes over the whole page). */
function restoreApp(path, flash) {
  S.flash = flash || null;
  renderLayout();
  if (location.hash === '#' + path) render(); else location.hash = path;
}
function highlightNav(p) {
  let key = p;
  if (/^\/(course|mod|discussion|quiz|review)\//.test(p)) key = '/courses';
  if (/^\/child\//.test(p)) key = '/family';
  if (/^\/assessment\/(exam|session)\//.test(p)) key = S.me && S.me.role !== 'student' ? '/assessment' : key;
  if (/^\/assessment\/checkin\//.test(p)) key = '/assessment';
  if (/^\/mentoring\/(student|report)\//.test(p)) key = '/mentoring/mentees';
  if (/^\/studio\/(new|edit|view|print)/.test(p)) key = '/studio/library';
  if (/^\/sim\/build\//.test(p)) key = '/sim/library';
  if (/^\/sim\/(run|play|report)\//.test(p)) key = '/sim';
  // Most specific match wins, so /assessment/live doesn't also light up /assessment.
  let best = null;
  const items = $$('.nav-item, .tab-item[data-nav]');
  items.forEach((a) => { const n = a.dataset.nav; if ((key === n || key.indexOf(n + '/') === 0) && (!best || n.length > best.length)) best = n; });
  items.forEach((a) => { const on = a.dataset.nav === best; a.classList.toggle('active', on); if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
  // Anything not in the tab bar lives under "More".
  const more = $('.tab-item.more');
  if (more) more.classList.toggle('active', !$$('.tab-item[data-nav]').some((a) => a.dataset.nav === best));
}
ACT.openNav = () => document.body.classList.add('nav-open');
ACT.closeNav = () => document.body.classList.remove('nav-open');

FORMS.search = (f) => {
  const q = f.elements.q.value.trim();
  if (q.length < 2) { toast('Type at least 2 characters to search.', 'err'); return; }
  f.elements.q.blur();
  go('/search?q=' + encodeURIComponent(q));
};

/* ---------- notifications ---------- */
function safeLink(l) { return /^\/[A-Za-z0-9/_-]*$/.test(String(l || '')) ? l : '/notifications'; }
function updateUnread(n) {
  S.unread = n || 0;
  const dot = $('#bellDot'), c = $('#navUnread'), t = $('#tabUnread');
  if (dot) { dot.textContent = n > 9 ? '9+' : String(n); dot.classList.toggle('hidden', !n); }
  if (c) { c.textContent = String(n); c.classList.toggle('hidden', !n); }
  if (t) { t.textContent = n > 9 ? '9+' : String(n); t.classList.toggle('hidden', !n); }
}
async function pollUnread() {
  if (!S.token) return;
  try { const r = await run('api', S.token, 'notifications', {}); updateUnread(r.unread); } catch (e) { /* quiet */ }
}
function startPolling() {
  stopPolling();
  S.pollers.push(setInterval(pollUnread, 60000));
  S.pollers.push(setInterval(trackActivity, 60000));
  pollUnread();
}
/* Time-in-course tracking: one ping a minute while the tab is visible and the
   person has touched the keyboard, mouse or screen in the last five minutes. */
let inputThrottle = 0;
function markInput() { const t = Date.now(); if (t - inputThrottle > 5000) { inputThrottle = t; S.lastInput = t; } }
['pointerdown', 'pointermove', 'keydown', 'scroll', 'touchstart', 'wheel'].forEach((ev) => window.addEventListener(ev, markInput, { passive: true, capture: true }));
function trackActivity() {
  if (!S.token || document.visibilityState !== 'visible' || Date.now() - S.lastInput > 5 * 60000) return;
  run('api', S.token, 'track', { courseId: (S.ctx && S.ctx.courseId) || '' }).catch(() => {});
}
function stopPolling() { S.pollers.forEach(clearInterval); S.pollers = []; }
function notifItem(n) {
  const link = safeLink(n.link);
  return '<a class="notif' + (n.read ? ' read' : '') + '" href="#' + esc(link) + '" data-act="openNotif" data-id="' + esc(n.id) + '" data-link="' + esc(link) + '">' +
    '<span class="ndot"></span><span><span>' + esc(n.text) + '</span><br><span class="xs muted">' + esc(rel(n.createdAt)) + '</span></span></a>';
}
ACT.loadNotifMenu = async () => {
  const el = $('#notifMenu');
  el.innerHTML = '<div class="menu-headbar"><b>Notifications</b></div><div class="card-pad"><div class="sk sk-line"></div><div class="sk sk-line" style="width:70%"></div></div>';
  try {
    const r = await call('notifications');
    updateUnread(r.unread);
    el.innerHTML = '<div class="menu-headbar"><b>Notifications</b>' + (r.unread ? '<button class="link small" data-act="readAll">Mark all as read</button>' : '') + '</div>' +
      '<div class="notif-list">' + (r.items.length ? r.items.slice(0, 8).map(notifItem).join('') : '<div class="empty" style="padding:2rem 1rem"><div class="e-icon">' + icon('inbox') + '</div><p>You have no notifications yet.</p></div>') + '</div>' +
      '<a class="notif-foot" href="#/notifications">View all notifications</a>';
  } catch (e) { if (!isExpired(e)) el.innerHTML = '<div class="card-pad small muted">' + esc(e.message) + '</div>'; }
};
ACT.openNotif = (d) => {
  closeMenus();
  call('markNotificationsRead', { id: d.id }).then(pollUnread).catch(() => {});
  go(safeLink(d.link));
};
ACT.readAll = (d, btn) => busy(btn, async () => {
  await call('markNotificationsRead', {});
  updateUnread(0);
  if ($('.bell.open')) ACT.loadNotifMenu();
  if (currentPath() === '/notifications') refresh();
});
