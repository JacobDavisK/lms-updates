'use strict';
/* =====================================================================
   PARENT PORTAL
   ===================================================================== */
function resultRow(x) {
  return '<div class="tl-item">' + modTile(x.type, 'sm') + '<div class="tl-main"><span class="tl-title">' + esc(x.title) + '</span>' +
    '<div class="tl-meta">' + esc(x.course) + '<span class="dot-sep"></span>' + esc(rel(x.at)) + '</div></div>' +
    '<span class="grade-pill ' + gradeClass(x.percent) + '">' + x.score + ' / ' + x.max + '</span></div>';
}
function deadlineRow(x) {
  return '<div class="tl-item">' + modTile(x.type, 'sm') + '<div class="tl-main"><span class="tl-title">' + esc(x.title) + '</span>' +
    '<div class="tl-meta">' + (x.course ? esc(x.course) + '<span class="dot-sep"></span>' : '') + (x.type === 'quiz' ? 'Test closes' : 'Due') + ' ' + esc(fmt(x.at)) + '</div></div>' +
    (x.overdue ? badge('Overdue', 'danger', 'alert') : '<span class="xs muted nowrap">' + esc(rel(x.at)) + '</span>') + '</div>';
}

async function viewFamily() {
  if (S.me.role !== 'parent') { go('/dashboard'); return null; }
  const r = await call('family');
  const h = new Date().getHours();
  const greet = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  const names = r.children.map((c) => firstName(c.name));
  const hero = '<section class="hero"><div class="hero-date">' + esc(new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' })) + '</div>' +
    '<h1>' + greet + ', ' + esc(firstName(S.me.name)) + '</h1><p>' +
    (names.length ? 'Here is how ' + esc(names.length > 1 ? names.slice(0, -1).join(', ') + ' and ' + names[names.length - 1] + ' are' : names[0] + ' is') + ' doing.' : 'Welcome to the family portal.') +
    '</p><div class="hero-actions"><a class="btn" href="#/profile">' + icon('bell') + 'Alert settings</a></div></section>';
  if (!r.children.length) {
    return { title: 'Family', html: hero + emptyState('users', 'No students linked yet', 'Ask your school to link your child’s account to yours. Once linked, their grades and progress appear here.') };
  }
  const cards = r.children.map((c) => {
    const attention = c.overdue ? notice('<b>' + plural(c.overdue, 'overdue activity', 'overdue activities') + '.</b> ' + esc(firstName(c.name)) + ' may need a nudge.', 'warn') : '';
    return '<article class="card"><div class="card-head">' + avatar(c.name, 'lg') + '<div style="flex:1;min-width:0"><h2 style="font-size:1.15rem">' + esc(c.name) + '</h2>' +
      '<div class="xs muted">' + esc(c.batch || '@' + c.username) + ' · ' + plural(c.courses, 'course') + ' · last active ' + (c.lastActive ? esc(rel(c.lastActive)) : 'never') + '</div></div>' +
      '<a class="btn btn-primary btn-sm" href="#/child/' + esc(c.id) + '">Full report ' + icon('arrowRight', 'i-sm') + '</a></div>' +
      '<div class="card-body">' + attention +
      '<div class="kpis" style="grid-template-columns:repeat(auto-fit,minmax(130px,1fr));margin-bottom:1rem">' +
      kpi('Average grade', c.avgGrade != null ? c.avgGrade + '<small>%</small>' : '—', 'Across all courses', 'award') +
      kpi('Course progress', c.avgProgress != null ? c.avgProgress + '<small>%</small>' : '—', 'Activities completed', 'checkCircle') +
      kpi('Due this week', String(c.dueSoon), c.overdue ? '<span class="risk risk">' + icon('alert') + c.overdue + ' overdue</span>' : 'Nothing overdue', 'clock') +
      kpi('Study time', esc(hoursFmt(c.weekMinutes)), deltaHtml(c.weekMinutes, c.prevWeekMinutes, 'vs last week'), 'activity') + '</div>' +
      '<div class="grid-2"><div><h3 class="subhead">Recent results</h3>' +
      (c.recent.length ? '<div class="card" style="overflow:hidden">' + c.recent.slice(0, 4).map(resultRow).join('') + '</div>' : '<p class="small muted">No graded work yet.</p>') + '</div>' +
      '<div><h3 class="subhead">Coming up</h3>' +
      (c.upcoming.length ? '<div class="card" style="overflow:hidden">' + c.upcoming.slice(0, 4).map(deadlineRow).join('') + '</div>' : '<p class="small muted">Nothing due soon.</p>') + '</div></div>' +
      '</div></article>';
  }).join('');
  return { title: 'Family', html: hero + '<div class="stack">' + cards + '</div>' };
}

async function viewChild(id) {
  if (S.me.role !== 'parent') { go('/dashboard'); return null; }
  const r = await call('childReport', { id });
  const c = r.child;
  const labels = r.series.map((x) => x.day);
  const head = '<section class="course-hero banner-bg cc-indigo"><div class="course-hero-top"><div>' + crumbs([['Family', '/family'], [c.name]]) +
    '<div class="row" style="gap:1rem;margin-top:.4rem">' + avatar(c.name, 'xl') + '<div><h1 style="margin:0 0 .35rem">' + esc(c.name) + '</h1><div class="meta">' +
    (c.batch ? '<span>' + icon('users', 'i-sm') + ' ' + esc(c.batch) + '</span>' : '') + '<span>' + icon('book', 'i-sm') + ' ' + plural(c.courses, 'course') + '</span>' +
    '<span>' + icon('history', 'i-sm') + ' Last active ' + (c.lastActive ? esc(rel(c.lastActive)) : 'never') + '</span></div></div></div></div></div></section>';
  const kpis = '<div class="kpis">' +
    kpi('Average grade', c.avgGrade != null ? c.avgGrade + '<small>%</small>' : '—', 'Course totals, all courses', 'award', true) +
    kpi('Course progress', c.avgProgress != null ? c.avgProgress + '<small>%</small>' : '—', 'Activities completed', 'checkCircle') +
    kpi('Overdue', String(c.overdue), c.overdue ? 'Needs attention' : 'All caught up', 'alert') +
    kpi('Due in 7 days', String(c.dueSoon), 'Assignments and tests', 'clock') +
    kpi('Study time, 7 days', esc(hoursFmt(c.weekMinutes)), deltaHtml(c.weekMinutes, c.prevWeekMinutes, 'vs the week before'), 'activity') + '</div>';
  const study = chartCard('Study time', 'Minutes spent on the site each day, last 30 days', chartSlot('area', {
    labels, values: r.series.map((x) => x.minutes), name: 'Study time', token: '1', xFmt: shortDay, tipTitle: (i) => longDay(labels[i]), yFmt: hoursFmt, valFmt: hoursFmt, unit: 60, height: 190, label: 'Daily study time'
  }) + tableView(['Day', 'Minutes'], r.series.map((x) => [longDay(x.day), x.minutes])), 'activity', 'blue');
  const courses = r.courses.map((k) => {
    const maxMin = Math.max(1, k.minutesWeek, k.classAvgWeek);
    return '<article class="card"><div class="card-head"><span class="course-glyph cc-' + esc(k.color) + '" style="width:40px;height:40px">' + icon('cap', 'i-sm') + '</span>' +
      '<div style="flex:1;min-width:0"><h2>' + esc(k.fullname) + '</h2><div class="xs muted">' + esc(k.shortname) + (k.teachers.length ? ' · Teacher: ' + esc(k.teachers.join(', ')) : '') + '</div></div>' +
      (k.teacherList && k.teacherList.length ? k.teacherList.map((t) => '<button class="btn btn-sm" data-act="chatMessage" data-id="' + esc(t.id) + '" title="Message ' + esc(t.name) + '">' + icon('message', 'i-sm') + 'Message ' + esc(firstName(t.name)) + '</button>').join('') : '') +
      (k.total ? '<span class="grade-pill ' + gradeClass(k.total.percent) + '" style="font-size:.95rem">' + k.total.percent + '%</span>' : '<span class="small muted">No grades yet</span>') + '</div>' +
      '<div class="card-body"><div class="grid-2" style="margin-bottom:1rem"><div><div class="small muted" style="margin-bottom:.35rem">Progress</div>' + meter(k.progress ? k.progress.percent : null) +
      (k.progress ? '<div class="xs muted" style="margin-top:.25rem">' + k.progress.done + ' of ' + k.progress.total + ' activities completed</div>' : '') + '</div>' +
      '<div><div class="small muted" style="margin-bottom:.35rem">Time in this course, last 7 days</div><div class="me-vs"><div class="bars"><div class="k-1" style="width:' + (k.minutesWeek / maxMin * 100) + '%"></div><div class="k-2" style="width:' + (k.classAvgWeek / maxMin * 100) + '%"></div></div></div>' +
      '<div class="legend" style="margin:.35rem 0 0"><span><i class="k-1"></i>' + esc(firstName(c.name)) + ': ' + esc(hoursFmt(k.minutesWeek)) + '</span><span><i class="k-2"></i>Class average: ' + esc(hoursFmt(k.classAvgWeek)) + '</span></div></div></div>' +
      (k.items.length ? '<div class="table-wrap" style="border:1px solid var(--border);border-radius:12px"><table class="table"><thead><tr><th>Graded work</th><th class="num">Score</th><th>Teacher feedback</th></tr></thead><tbody>' +
        k.items.map((it) => '<tr><td><div class="row">' + modTile(it.type, 'sm') + '<span class="small strong">' + esc(it.title) + '</span></div></td>' +
          '<td class="num">' + (it.cell ? '<span class="grade-pill ' + gradeClass(pct(it.cell.score, it.cell.max)) + '">' + it.cell.score + ' / ' + it.cell.max + '</span>' : '<span class="muted small">Not graded yet</span>') + '</td>' +
          '<td class="small">' + (it.cell && it.cell.feedback ? '<div class="prose">' + md(it.cell.feedback) + '</div>' : '<span class="muted">—</span>') + '</td></tr>').join('') + '</tbody></table></div>'
        : '<p class="small muted">No graded work in this course yet.</p>') +
      (k.deadlines.length ? '<h3 class="subhead" style="margin-top:var(--sp-5)">Deadlines</h3><div class="card" style="overflow:hidden">' + k.deadlines.map(deadlineRow).join('') + '</div>' : '') +
      '</div></article>';
  }).join('');
  const side = '<div class="card"><div class="card-head"><span class="i-tile sm tone-green">' + icon('award') + '</span><h2>Latest results</h2></div>' +
    (r.results.length ? r.results.slice(0, 8).map(resultRow).join('') : '<div class="card-body small muted">No graded work yet.</div>') + '</div>' +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-pink">' + icon('megaphone') + '</span><h2>Course announcements</h2></div>' +
    (r.announcements.length ? r.announcements.map(newsItem).join('') : '<div class="card-body small muted">No announcements.</div>') + '</div>';
  return {
    title: c.name,
    html: head + kpis + '<div class="split"><div class="stack">' + study + (courses || emptyState('book', 'Not enrolled in any courses', 'Courses appear here once ' + esc(firstName(c.name)) + ' is enrolled.')) + '</div><div class="stack">' + side + '</div></div>'
  };
}
