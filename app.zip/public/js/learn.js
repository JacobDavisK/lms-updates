'use strict';
/* =====================================================================
   LEARNING PATHS — student side
   Overview across subjects, subject detail (path, skills, reviews, progress,
   class progress), lessons, practice and review sessions with the activity
   player, and learner settings. Everything is calculated on the server; this
   file only presents it. Answers wait on this device if the connection drops.
   The faculty side (authoring, analytics) is in learn-teach.js.
   ===================================================================== */
const LP = { q: {}, session: null, timer: null, prefs: null, lesson: null, seq: 0 };
const LP_STATUS = {
  not_started: ['Not started', '', 'circle'], developing: ['Developing', 'warning', 'trending'], practising: ['Practising', 'primary', 'target'],
  proficient: ['Proficient', 'success', 'checkCircle'], review: ['Due for review', 'info', 'refresh']
};
const LP_TYPES = { mcq: 'Multiple choice', multi: 'Select all that apply', fill: 'Fill in the blanks', match: 'Matching', order: 'Put in order', numeric: 'Numerical answer', short: 'Short answer', case: 'Case', reflection: 'Reflection' };
function lpStatus(st) { const x = LP_STATUS[st] || [st, '', 'circle']; return badge(x[0], x[1], x[2]); }
function lpReduced() { try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } }
/** A metric's definition, available to keyboard and screen-reader users (a native disclosure). */
function lpDef(text) { return text ? '<details class="lp-def"><summary aria-label="What does this mean?">' + icon('info') + '</summary><div class="lp-def-body">' + esc(text) + '</div></details>' : ''; }
function lpUpdated(ms) { return '<span class="faint small">Updated ' + esc(fmtTime(ms)) + '</span>'; }
function lpNav(active) {
  const items = [['/learn', 'Overview', 'dashboard'], ['/learn/review', 'Reviews', 'refresh'], ['/learn/settings', 'Settings', 'settings']];
  return '<nav class="tabs lp-tabs" aria-label="Learning">' + items.map((i) => '<a class="tab' + (i[0] === active ? ' active' : '') + '" href="#' + i[0] + '"' + (i[0] === active ? ' aria-current="page"' : '') + '>' + icon(i[2]) + i[1] + '</a>').join('') + '</nav>';
}
function lpDistBar(d, total) {
  const parts = ['proficient', 'review', 'practising', 'developing', 'not_started'].filter((k) => d[k]);
  if (!total) return '<p class="muted small">No skills set up yet.</p>';
  return '<div class="lp-dist" role="img" aria-label="' + esc(parts.map((k) => d[k] + ' ' + LP_STATUS[k][0].toLowerCase()).join(', ')) + '">' +
    parts.map((k) => '<i class="lp-d-' + k + '" style="flex:' + d[k] + '"></i>').join('') + '</div>' +
    '<ul class="lp-legend">' + parts.map((k) => '<li><span class="lp-key lp-d-' + k + '"></span>' + esc(LP_STATUS[k][0]) + ' <b>' + d[k] + '</b></li>').join('') + '</ul>';
}
function lpCompletion(c, def) {
  if (!c || !c.total) return '<div class="lp-metric"><div class="lp-metric-h">Required lessons' + lpDef(def) + '</div><p class="muted small">No required activities yet.</p></div>';
  return '<div class="lp-metric"><div class="lp-metric-h">Required lessons' + lpDef(def) + '</div>' + progressBar(c.percent) +
    '<div class="small"><b>' + c.done + '</b> of ' + c.total + ' completed · ' + c.percent + '%</div></div>';
}

/* =====================================================================
   OVERVIEW
   ===================================================================== */
async function viewLpHome() {
  if (S.me.role !== 'student') { go(S.me.role === 'parent' ? '/dashboard' : '/learn/teach'); return null; }
  await lpFlushPending(); // answers saved while offline count before the dashboard is calculated
  const d = await call('lpHome');
  const D = d.definitions;
  const H = d.habits;
  const g = d.features.gamification;
  const goalPct = g && H.dailyXp ? Math.min(100, Math.round(H.xpToday / H.dailyXp * 100)) : 0;
  const top = '<div class="lp-top">' +
    '<div class="card card-pad lp-today"><div class="lp-metric-h">Today' + lpDef(D.reviews) + '</div>' +
      (d.reviewsDue ? '<p><b class="lp-big">' + d.reviewsDue + '</b> review' + (d.reviewsDue === 1 ? '' : 's') + ' ready</p><a class="btn btn-primary" href="#/learn/review">' + icon('refresh') + 'Start reviews</a>' : '<p class="muted">No reviews due. Nice work.</p>') +
      (g && H.dailyXp ? '<div class="lp-goal">' + ring(goalPct, 56) + '<div><div class="small"><b>' + H.xpToday + '</b> / ' + H.dailyXp + ' XP today' + lpDef(D.xp) + '</div><div class="faint small">Daily goal' + (goalPct >= 100 ? ' — reached' : '') + '</div></div></div>' : '') + '</div>' +
    '<div class="card card-pad"><div class="lp-metric-h">Learning streak' + lpDef(D.streak + ' ' + D.activeDay) + '</div><p><b class="lp-big">' + H.streak.current + '</b> day' + (H.streak.current === 1 ? '' : 's') + '</p>' +
      '<div class="small muted">' + (H.streak.activeToday ? 'You have learned today.' : H.streak.current ? 'Learn today to keep it going.' : 'Any lesson, review or three questions starts a new streak.') + '</div><div class="faint small">Longest: ' + H.streak.longest + '</div></div>' +
    '<div class="card card-pad"><div class="lp-metric-h">This week' + lpDef(D.weeklyGoal) + '</div><p><b class="lp-big">' + H.week.activeDays + '</b> of ' + H.week.target + ' active days</p>' + progressBar(Math.min(100, H.week.activeDays / H.week.target * 100)) +
      '<div class="small muted">' + H.week.answers + ' answers · ' + H.week.lessons + ' lessons' + (g ? ' · ' + H.week.xp + ' XP' : '') + '</div></div>' +
    (g ? '<div class="card card-pad"><div class="lp-metric-h">Personal bests' + lpDef(D.xp) + '</div><ul class="lp-kv"><li><span>Longest streak</span><b>' + H.best.streak + ' days</b></li><li><span>Best week</span><b>' + H.best.weekXp + ' XP</b></li><li><span>Best day</span><b>' + H.best.dayXp + ' XP</b></li><li><span>Total</span><b>' + H.xpTotal + ' XP</b></li></ul></div>' : '') +
    '</div>';
  const actions = d.actions.length ? '<section class="card"><div class="card-head"><h2>Recommended next</h2></div><ul class="lp-actions">' + d.actions.map((a) =>
    '<li><a href="#' + esc(a.href) + '"><span class="i-tile tone-' + ({ review: 'blue', lesson: 'indigo', practice: 'amber', assigned: 'violet' }[a.kind] || 'slate') + '">' + icon({ review: 'refresh', lesson: 'book', practice: 'target', assigned: 'flag' }[a.kind] || 'right') + '</span><span><b>' + esc(a.title) + '</b><span class="muted small">' + esc(a.detail) + '</span></span>' + icon('right') + '</a></li>').join('') + '</ul></section>' : '';
  const subjects = d.subjects.length ? '<div class="lp-subjects">' + d.subjects.map((x) =>
    '<article class="card lp-subject cc-' + esc(x.color) + '"><div class="card-pad"><div class="lp-sub-head"><div><div class="faint small">' + esc(x.short) + '</div><h3><a href="#/learn/subject/' + esc(x.courseId) + '">' + esc(x.name) + '</a></h3></div>' +
      (x.reviewsDue ? badge(x.reviewsDue + ' due', 'info', 'refresh') : '') + '</div>' +
      lpCompletion(x.completion, D.completion) +
      '<div class="lp-metric"><div class="lp-metric-h">Skills (' + x.skills + ')' + lpDef(D.statuses + ' ' + D.evidence) + '</div>' + lpDistBar(x.distribution, x.skills) +
        (x.distribution.insufficient ? '<p class="faint small">' + x.distribution.insufficient + ' skill' + (x.distribution.insufficient === 1 ? ' does' : 's do') + ' not have enough evidence yet.</p>' : '') + '</div>' +
      '<div class="row-wrap lp-sub-actions">' + (x.next ? '<a class="btn btn-primary btn-sm" href="#/learn/lesson/' + esc(x.next.id) + '">' + icon('book') + 'Next: ' + esc(x.next.title) + '</a>' : '') +
        '<a class="btn btn-sm" href="#/learn/practice/' + esc(x.courseId) + '">' + icon('target') + 'Practise</a>' + (d.features.peers ? '<a class="btn btn-sm btn-ghost" href="#/learn/subject/' + esc(x.courseId) + '?tab=class">' + icon('users') + 'Class progress</a>' : '') + '</div>' +
    '</div></article>').join('') + '</div>' : emptyState('book', 'No learning paths yet', 'When your teachers switch on Learning Paths for a course, it appears here.');
  const upcoming = '<section class="card"><div class="card-head"><h2>Upcoming</h2></div>' + (d.upcoming.length ? '<ul class="lp-list">' + d.upcoming.map((u) =>
    '<li><span class="lp-when">' + esc(fmtDay(u.at)) + '</span><span><b>' + esc(u.title) + '</b><span class="muted small">' + esc(u.label) + ' · ' + esc(u.course || '') + (u.type === 'lesson' ? ' · lesson' : '') + '</span></span></li>').join('') + '</ul>' : '<p class="card-pad muted">Nothing due in the next two weeks.</p>') + '</section>';
  const recent = '<section class="card"><div class="card-head"><h2>Recent activity</h2></div>' + (d.recent.length ? '<ul class="lp-list">' + d.recent.map((r) =>
    '<li><span class="lp-when">' + esc(fmtDay(new Date(r.day + 'T12:00').getTime())) + '</span><span>' + (r.kind === 'lesson' ? 'Completed <b>' + esc(r.title) + '</b>' : (r.kind === 'review' ? 'Reviewed ' : 'Practised ') + plural(r.answers, 'question') + ' · ' + r.correct + ' correct') + '<span class="muted small"> · ' + esc(r.course) + '</span></span></li>').join('') + '</ul>' : '<p class="card-pad muted">Your learning activity will appear here.</p>') + '</section>';
  const badges = g ? '<section class="card"><div class="card-head"><h2>Achievements</h2></div><div class="lp-badges">' + d.badges.map((b) =>
    '<div class="lp-badge' + (b.earned ? ' earned' : '') + '"><span class="lp-badge-i">' + icon(b.earned ? b.icon : 'lock') + '</span><b>' + esc(b.name) + '</b><span class="small muted">' + esc(b.text) + '</span>' + (b.earned ? '<span class="sr">Earned</span>' : '<span class="sr">Not earned yet</span>') + '</div>').join('') + '</div></section>' : '';
  return {
    title: 'My learning',
    html: pageHead('My learning', { sub: 'Short lessons, practice with feedback, and reviews at the right time. ' + lpUpdated(d.updatedAt), actions: '<a class="btn" href="#/learn/settings">' + icon('settings') + 'Goals & privacy</a>' }) +
      lpNav('/learn') + top + actions + '<h2 class="section-title">Your subjects</h2>' + subjects + '<div class="grid-2 lp-lower">' + upcoming + recent + '</div>' + badges
  };
}

/* =====================================================================
   SUBJECT
   ===================================================================== */
async function viewLpSubject(courseId, params) {
  const tab = (params && params.get('tab')) || 'path';
  const d = await call('lpSubject', { courseId });
  if (d.editor) { go('/learn/teach/' + courseId); return null; }
  const D = d.definitions;
  const tabs = [['path', 'Learning path', 'route'], ['skills', 'Skills', 'target'], ['reviews', 'Reviews', 'refresh'], ['progress', 'My progress', 'chart']].concat(d.features.peers ? [['class', 'Class progress', 'users']] : []);
  const tabNav = '<nav class="tabs" aria-label="Subject sections">' + tabs.map((t) => '<a class="tab' + (t[0] === tab ? ' active' : '') + '" href="#/learn/subject/' + esc(courseId) + '?tab=' + t[0] + '"' + (t[0] === tab ? ' aria-current="page"' : '') + '>' + icon(t[2]) + t[1] + '</a>').join('') + '</nav>';
  let body = '';
  if (tab === 'path') {
    body = (d.assigned.length ? notice('<b>Practice from your teacher:</b> ' + d.assigned.map((g) => esc(g.skills.join(', ') + (g.note ? ' — ' + g.note : ''))).join('; ') + ' <a href="#/learn/practice/' + esc(courseId) + '">Start</a>', '', 'flag') : '') +
      (d.accommodated ? '<p class="faint small">Your suggested dates include extra time agreed with your teacher.</p>' : '') +
      (d.units.length ? d.units.map((u) => '<section class="card lp-unit"><div class="card-head"><h2>' + esc(u.name) + '</h2>' + (u.required.total ? '<span class="small muted">' + u.required.done + ' of ' + u.required.total + ' required</span>' : '') + '</div>' +
        u.topics.map((tp) => '<div class="lp-topic"><h3>' + esc(tp.name) + '</h3><ol class="lp-path">' + tp.lessons.map((l) => {
          const ico = { done: 'checkCircle', open: 'play', locked: 'lock', updated: 'refresh' }[l.state];
          const label = { done: 'Completed', open: 'Ready to start', locked: 'Finish the earlier lessons first', updated: 'Completed — content updated since' }[l.state];
          return '<li class="lp-step lp-' + l.state + '"><span class="lp-step-i" aria-hidden="true">' + icon(ico) + '</span><div class="lp-step-body"><b>' + esc(l.title) + '</b><span class="small muted">' + esc(label) + ' · about ' + l.minutes + ' min' + (l.required ? '' : ' · optional') +
            (l.dueAt ? ' · ' + (l.pastDue ? 'suggested by ' + esc(fmtDate(l.dueAt)) + ' — you can still do it' : 'suggested by ' + esc(fmtDate(l.dueAt))) : '') + '</span></div>' +
            (l.state !== 'locked' ? '<a class="btn btn-sm' + (l.state === 'open' ? ' btn-primary' : '') + '" href="#/learn/lesson/' + esc(l.id) + '">' + (l.state === 'open' ? 'Start' : 'Open') + '</a>' : '') + '</li>';
        }).join('') + '</ol></div>').join('') + '</section>').join('') : emptyState('book', 'No lessons published yet', 'Your teacher has not published lessons for this subject yet.'));
  } else if (tab === 'skills') {
    const all = [];
    d.units.forEach((u) => u.topics.forEach((tp) => tp.skills.forEach((k) => all.push(Object.assign({ unit: u.name, topic: tp.name }, k)))));
    body = '<p class="muted">' + esc(D.proficiency) + '</p>' + (all.length ? '<div class="table-wrap card"><table class="table"><caption class="sr">Your skills</caption><thead><tr><th scope="col">Skill</th><th scope="col">Status</th><th scope="col">Estimate</th><th scope="col">Reviews due</th><th scope="col"><span class="sr">Practise</span></th></tr></thead><tbody>' +
      all.map((k) => '<tr><td><b>' + esc(k.name) + '</b><div class="small muted">' + esc(k.topic) + '</div></td><td>' + lpStatus(k.status) + '</td><td>' +
        (k.status === 'not_started' ? '<span class="muted small">No answers yet</span>' : k.sufficient ? Math.round(k.estimate * 100) + '%' : '<span class="small muted">Not enough evidence yet (' + k.evidence + ' of 3 questions)</span>') +
        (k.updatedAt ? '<div class="faint small">Updated ' + esc(fmtDate(k.updatedAt)) + '</div>' : '') + '</td><td>' + (k.due || '—') + '</td><td><a class="btn btn-sm" href="#/learn/skill/' + esc(courseId) + '/' + esc(k.id) + '">Practise</a></td></tr>').join('') + '</tbody></table></div>' : emptyState('target', 'No skills yet', ''));
  } else if (tab === 'reviews') {
    const max = Math.max(1, ...d.reviews.schedule.map((x) => x.n));
    body = '<div class="grid-2"><div class="card card-pad"><div class="lp-metric-h">Due now' + lpDef(D.reviews) + '</div><p><b class="lp-big">' + d.reviews.dueNow + '</b></p>' +
      (d.reviews.overdue ? '<p class="small muted">Some have been waiting a while. Reviewing a few each day is plenty — there is no penalty.</p>' : '') +
      (d.reviews.dueNow ? '<a class="btn btn-primary" href="#/learn/review/' + esc(courseId) + '">' + icon('refresh') + 'Review this subject</a>' : '<p class="muted">Nothing due right now.</p>') + '</div>' +
      '<div class="card card-pad"><div class="lp-metric-h">Next two weeks</div>' + (d.reviews.schedule.length ? '<ul class="lp-sched">' + d.reviews.schedule.map((x) => '<li><span>' + (x.day === d.today ? 'Today' : esc(fmtDay(new Date(x.day + 'T12:00').getTime()))) + '</span><span class="lp-sched-bar"><i style="width:' + Math.round(x.n / max * 100) + '%"></i></span><b>' + x.n + '</b></li>').join('') + '</ul>' : '<p class="muted">Questions you answer will be scheduled here.</p>') + '</div></div>';
  } else if (tab === 'progress') {
    const labels = d.trend.map((w) => w.week);
    body = '<div class="card card-pad"><div class="lp-metric-h">Your last 8 weeks</div>' + chartSlot('columns', { labels, xFmt: (w) => fmtDate(new Date(w + 'T12:00').getTime()).replace(/ \d{4}$/, ''), label: 'Questions answered on your own and lessons completed per week', series: [{ name: 'Answered on your own', token: '1', values: d.trend.map((w) => w.independent) }, { name: 'Other answers', token: '3', values: d.trend.map((w) => Math.max(0, w.answers - w.independent)) }] }) +
      '<p class="small muted">Lessons completed: ' + d.trend.map((w) => w.lessons).reduce((a, b) => a + b, 0) + ' in 8 weeks' + (d.features.gamification ? ' · XP: ' + d.trend.map((w) => w.xp).reduce((a, b) => a + b, 0) : '') + '</p></div>' +
      (d.challenges.length ? '<section class="card"><div class="card-head"><h2>This week’s challenges</h2></div><ul class="lp-list">' + d.challenges.map((c) => '<li><span class="i-tile tone-' + (c.kind === 'class' ? 'violet' : 'amber') + '">' + icon(c.kind === 'class' ? 'users' : 'flag') + '</span><span style="flex:1"><b>' + esc(c.title) + '</b>' + progressBar(c.progress / c.target * 100) + '<span class="small muted">' + c.progress + ' / ' + c.target + (c.done ? ' · completed' : '') + (c.kind === 'class' ? ' · together with your class' : '') + '</span></span></li>').join('') + '</ul></section>' : '') +
      '<section class="card"><div class="card-head"><h2>Assessment results</h2>' + lpDef(D.grades) + '</div>' + (d.results.length ? '<div class="table-wrap"><table class="table"><thead><tr><th scope="col">Assessment</th><th scope="col">Result</th></tr></thead><tbody>' + d.results.map((r) => '<tr><td>' + esc(r.title) + '</td><td class="tnum">' + esc(r.cell.score) + ' / ' + esc(r.cell.max) + '</td></tr>').join('') + '</tbody></table></div>' : '<p class="card-pad muted">No released results yet.</p>') + '</section>';
  } else if (tab === 'class') {
    body = await lpClassHtml(courseId);
  }
  return {
    title: d.course.short + ' · Learning',
    html: pageHead(d.course.name, { crumbs: [['My learning', '/learn'], [d.course.short]], sub: lpUpdated(d.updatedAt), actions: (d.next ? '<a class="btn btn-primary" href="#/learn/lesson/' + esc(d.next.id) + '">' + icon('book') + 'Next lesson</a>' : '') + '<a class="btn" href="#/learn/practice/' + esc(courseId) + '">' + icon('target') + 'Practise</a>' }) +
      '<div class="grid-3 lp-sub-top"><div class="card card-pad">' + lpCompletion(d.completion, D.completion) + '</div><div class="card card-pad"><div class="lp-metric-h">Skills needing practice</div>' + (d.needsPractice.length ? '<ul class="lp-chips">' + d.needsPractice.slice(0, 6).map((k) => '<li><a href="#/learn/skill/' + esc(courseId) + '/' + esc(k.id) + '">' + esc(k.name) + '</a> ' + lpStatus(k.status) + '</li>').join('') + '</ul>' : '<p class="muted small">None right now.</p>') + '</div>' +
      '<div class="card card-pad"><div class="lp-metric-h">Remaining required lessons</div>' + (d.remaining.length ? '<ul class="lp-mini">' + d.remaining.slice(0, 5).map((l) => '<li>' + esc(l.title) + '</li>').join('') + (d.remaining.length > 5 ? '<li class="muted">and ' + (d.remaining.length - 5) + ' more</li>' : '') + '</ul>' : '<p class="muted small">' + (d.completion.total ? 'All required lessons done.' : 'No required activities yet.') + '</p>') + '</div></div>' +
      tabNav + body
  };
}
async function lpClassHtml(courseId) {
  const d = await call('lpPeers', { courseId });
  if (d.off) return emptyState('users', 'Class progress is switched off', 'Your institution has not switched on class progress.');
  const v = d.view;
  let list = '';
  if (!v.enough) list = notice('There are not enough classmates in your group to show progress without revealing individuals (at least ' + v.minCohort + ' are needed).', '', 'lock');
  else if (v.mode === 'aggregate' || !v.list.length) list = '<p class="muted">Your teacher shows class totals only.</p>';
  else list = '<div class="table-wrap card"><table class="table"><caption class="sr">Class progress</caption><thead><tr>' + (v.ranking ? '<th scope="col">Rank</th>' : '') + '<th scope="col">Classmate</th><th scope="col">Required lessons</th><th scope="col">Milestones</th><th scope="col">This week</th>' + (d.policy.showXp ? '<th scope="col">XP this week</th>' : '') + (d.policy.showBadges ? '<th scope="col">Badges</th>' : '') + '</tr></thead><tbody>' +
    v.list.map((r) => '<tr' + (r.me ? ' class="lp-me"' : '') + '>' + (v.ranking ? '<td>' + (r.rank || '—') + '</td>' : '') + '<td>' + avatar(r.name, 'sm') + ' ' + esc(r.name) + (r.me ? ' <span class="badge">You</span>' : '') + '</td><td>' + (r.completion == null ? '—' : progressBar(r.completion, 'sm') + '<span class="small">' + r.completion + '%</span>') + '</td><td>' + r.milestones + '</td><td>' + (r.activeThisWeek ? badge('Active', 'success', 'check') : '<span class="muted small">Not yet</span>') + '</td>' + (d.policy.showXp ? '<td class="tnum">' + (r.weekXp || 0) + '</td>' : '') + (d.policy.showBadges ? '<td>' + (r.badges || 0) + '</td>' : '') + '</tr>').join('') + '</tbody></table></div>';
  return '<div class="grid-3"><div class="card card-pad"><div class="lp-metric-h">Class median' + lpDef('The middle completion percentage of your class group. Shown only when the group is large enough to keep individuals private.') + '</div><p><b class="lp-big">' + (v.median == null ? '—' : v.median + '%') + '</b></p><p class="small muted">of required lessons completed</p></div>' +
    '<div class="card card-pad"><div class="lp-metric-h">Active this week</div><p><b class="lp-big">' + (v.activeThisWeek == null ? '—' : v.activeThisWeek) + '</b>' + (v.cohortSize ? ' of ' + v.cohortSize : '') + '</p></div>' +
    (d.challenges.length ? d.challenges.map((c) => '<div class="card card-pad"><div class="lp-metric-h">Class challenge</div><p><b>' + esc(c.title) + '</b></p>' + progressBar(c.progress / c.target * 100) + '<p class="small muted">' + c.progress + ' / ' + c.target + ' — everyone’s answers count</p></div>').join('') : '<div class="card card-pad"><div class="lp-metric-h">You appear as</div><p>' + esc({ default: 'Your teacher’s setting', alias: 'An alias', hidden: 'Hidden from the list' }[d.myChoice]) + '</p><a class="small" href="#/learn/settings">Change</a></div>') + '</div>' +
    list + '<details class="card card-pad lp-explain" open><summary><b>What can classmates see?</b></summary><p>' + esc(d.explain) + '</p><p class="small"><a href="#/learn/settings">Change how you appear</a></p></details>';
}

/* =====================================================================
   ACTIVITY PLAYER
   ===================================================================== */
function lpUid() {
  try { if (crypto.randomUUID) return crypto.randomUUID(); } catch (e) { /* not a secure context */ }
  const a = new Uint8Array(16); crypto.getRandomValues(a); return Array.from(a, (b) => b.toString(16).padStart(2, '0')).join('');
}
function lpPartHtml(type, prompt, data, name, label) {
  const n = esc(name);
  let ctl = '';
  switch (type) {
    case 'mcq': ctl = '<fieldset class="lp-opts"><legend class="sr">Choose one answer</legend>' + data.options.map((o) => '<label class="lp-opt"><input type="radio" name="' + n + '" value="' + esc(o.id) + '"><span>' + md(o.text) + '</span></label>').join('') + '</fieldset>'; break;
    case 'multi': ctl = '<fieldset class="lp-opts"><legend class="sr">Select all that apply</legend><p class="small muted">Select all that apply.</p>' + data.options.map((o) => '<label class="lp-opt"><input type="checkbox" name="' + n + '" value="' + esc(o.id) + '"><span>' + md(o.text) + '</span></label>').join('') + '</fieldset>'; break;
    case 'fill': {
      let k = 0;
      ctl = '<p class="lp-fill">' + esc(data.text).replace(/\{\{\d+\}\}/g, () => { k++; return '<input class="input lp-blank" name="' + n + '" aria-label="Blank ' + k + '" autocomplete="off" spellcheck="false">'; }) + '</p>';
      break;
    }
    case 'match': ctl = '<div class="lp-match">' + data.left.map((l) => {
      const id = 'lpm' + (++LP.seq);
      return '<div class="lp-match-row"><label for="' + id + '">' + esc(l.text) + '</label><select class="input" id="' + id + '" name="' + n + '" data-left="' + esc(l.id) + '"><option value="">Choose…</option>' + data.right.map((r) => '<option value="' + esc(r.id) + '">' + esc(r.text) + '</option>').join('') + '</select></div>';
    }).join('') + '</div>'; break;
    case 'order': ctl = '<ol class="lp-order" data-name="' + n + '">' + data.steps.map((s, i) => '<li data-id="' + esc(s.id) + '"><span>' + md(s.text) + '</span><span class="lp-order-btns"><button type="button" class="btn-icon sm" data-act="lpMove" data-dir="up" aria-label="Move up: ' + esc(s.text) + '"' + (i === 0 ? ' disabled' : '') + '>' + icon('up') + '</button><button type="button" class="btn-icon sm" data-act="lpMove" data-dir="down" aria-label="Move down: ' + esc(s.text) + '"' + (i === data.steps.length - 1 ? ' disabled' : '') + '>' + icon('down') + '</button></span></li>').join('') + '</ol>'; break;
    case 'numeric': { const id = 'lpn' + (++LP.seq); ctl = '<div class="row-wrap lp-num"><label class="sr" for="' + id + '">Your answer</label><input class="input" id="' + id + '" name="' + n + '" inputmode="decimal" autocomplete="off" placeholder="Your answer">' +
      (data.unit ? '<label class="lp-unitbox"><span class="sr">Unit</span><input class="input" name="' + n + 'u" value="' + (data.unitRequired ? '' : esc(data.unit)) + '" placeholder="Unit (' + esc(data.unit) + ')" autocomplete="off" aria-label="Unit"></label>' : '') + '</div>'; break; }
    case 'short': ctl = '<input class="input" name="' + n + '" autocomplete="off" aria-label="Your answer" placeholder="Your answer">'; break;
    case 'reflection': ctl = '<textarea class="input" name="' + n + '" rows="5" aria-label="Your reflection" data-input="lpWords" data-min="' + data.minWords + '"></textarea><div class="small muted lp-words" aria-live="polite">Write at least ' + data.minWords + ' words.</div>'; break;
    default: break;
  }
  return (prompt ? '<div class="lp-prompt prose">' + md(prompt) + '</div>' : '') + ctl;
}
function lpQuestionHtml(q, i, n) {
  const it = q.item;
  LP.q[q.pres] = { item: it, ev: null, active: 0, done: false, mode: q.mode };
  const meta = [LP_TYPES[it.type], { recognition: 'Recognise', recall: 'Recall', application: 'Apply' }[it.level], it.context === 'real-world' ? 'Real-world' : ''].filter(Boolean).join(' · ');
  const body = it.type === 'case'
    ? '<div class="lp-case prose">' + md(it.scenario) + '</div>' + (it.prompt ? '<div class="lp-prompt prose">' + md(it.prompt) + '</div>' : '') + it.parts.map((p, k) => '<div class="lp-part"><div class="lp-part-n">Question ' + (k + 1) + '</div>' + lpPartHtml(p.type, p.prompt, p.data, 'p' + k, p.prompt) + '</div>').join('')
    : lpPartHtml(it.type, it.prompt, it.data, 'a', it.prompt);
  return '<section class="card lp-q" id="q-' + esc(q.pres) + '" data-pres="' + esc(q.pres) + '" aria-labelledby="qh-' + esc(q.pres) + '">' +
    '<div class="lp-q-head"><h3 id="qh-' + esc(q.pres) + '">' + (n ? 'Question ' + (i + 1) + ' of ' + n : esc(it.title || 'Activity')) + '</h3><span class="small muted">' + esc(meta) + '</span></div>' +
    (q.reason ? '<p class="lp-why small">' + icon('info') + '<span><span class="sr">Why this question: </span>' + esc(q.reason) + '</span></p>' : '') +
    (it.imageId ? '' : '') +
    '<form data-form="lpAnswer" data-pres="' + esc(q.pres) + '" novalidate><div class="lp-q-body">' + body + '</div>' +
    '<div class="lp-q-actions"><button class="btn btn-primary" type="submit">' + (it.type === 'reflection' ? 'Save reflection' : 'Check answer') + '</button>' +
      (it.hints ? '<button class="btn" type="button" data-act="lpHint" data-pres="' + esc(q.pres) + '">' + icon('help') + 'Hint <span class="small">(' + it.hints + ')</span></button>' : '') + '</div></form>' +
    '<div class="lp-hints" aria-live="polite"></div><div class="lp-fb" role="status" aria-live="polite"></div></section>';
}
function lpCollect(form, item) {
  const one = (type, name) => {
    const fd = (sel) => $$(sel, form);
    switch (type) {
      case 'mcq': { const c = form.querySelector('input[name="' + name + '"]:checked'); return { choice: c ? c.value : '' }; }
      case 'multi': return { choices: fd('input[name="' + name + '"]:checked').map((x) => x.value) };
      case 'fill': return { blanks: fd('input[name="' + name + '"]').map((x) => x.value) };
      case 'match': { const m = {}; fd('select[name="' + name + '"]').forEach((s) => { m[s.dataset.left] = s.value; }); return { pairs: m }; }
      case 'order': { const ol = form.querySelector('ol[data-name="' + name + '"]'); return { order: ol ? $$('li', ol).map((li) => li.dataset.id) : [] }; }
      case 'numeric': { const v = form.querySelector('[name="' + name + '"]'); const u = form.querySelector('[name="' + name + 'u"]'); return { value: v ? v.value : '', unit: u ? u.value : '' }; }
      default: { const v = form.querySelector('[name="' + name + '"]'); return { text: v ? v.value : '' }; }
    }
  };
  if (item.type === 'case') return { parts: item.parts.map((p, k) => one(p.type, 'p' + k)) };
  return one(item.type, 'a');
}
function lpEmpty(item, ans) {
  const blank = (a) => !a || (a.choice === '' ) || (a.choices && !a.choices.length) || (a.value === '' ) || (a.text === '' && a.text !== undefined) || (a.blanks && a.blanks.every((x) => !String(x).trim())) || (a.pairs && Object.values(a.pairs).every((x) => !x));
  return item.type === 'case' ? ans.parts.some(blank) : item.type !== 'order' && blank(ans);
}
ACT.lpMove = (d, btn) => {
  const li = btn.closest('li'); const ol = li.parentElement;
  if (d.dir === 'up' && li.previousElementSibling) ol.insertBefore(li, li.previousElementSibling);
  else if (d.dir === 'down' && li.nextElementSibling) ol.insertBefore(li.nextElementSibling, li);
  $$('li', ol).forEach((x, i, all) => { const b = $$('button', x); b[0].disabled = i === 0; b[1].disabled = i === all.length - 1; });
  btn.focus();
};
INPUTS.lpWords = (t) => { const n = String(t.value).trim().split(/\s+/).filter(Boolean).length; const el = t.parentElement.querySelector('.lp-words'); if (el) el.textContent = n + ' word' + (n === 1 ? '' : 's') + ' (at least ' + t.dataset.min + ')'; };
ACT.lpHint = (d, btn) => busy(btn, async () => {
  const r = await call('lpHint', { pres: d.pres });
  const box = $('#q-' + d.pres + ' .lp-hints');
  box.insertAdjacentHTML('beforeend', '<p class="lp-hint">' + icon('help') + '<span><b>Hint ' + r.n + ':</b> ' + md(r.hint) + '</span></p>');
  if (!r.left) btn.remove(); else btn.querySelector('.small').textContent = '(' + r.left + ')';
});
/* ---------- answers that wait on this device while offline ---------- */
function lpPending() { return prefs.get('lp.pending', []); }
function lpSetPending(list) { prefs.set('lp.pending', list.slice(-50)); }
async function lpSend(entry) {
  try {
    const r = await call('lpAnswer', { pres: entry.pres, ev: entry.ev, answer: entry.answer, ms: entry.ms });
    lpSetPending(lpPending().filter((x) => x.ev !== entry.ev));
    return r;
  } catch (e) {
    // Keep it for later when the connection or the session dropped; drop it only when the server refused it.
    if (!/Cannot reach the server/.test(e.message) && !isExpired(e)) lpSetPending(lpPending().filter((x) => x.ev !== entry.ev));
    throw e;
  }
}
/** Sends answers saved on this device (only this person's — a shared computer never sends someone else's). */
async function lpFlushPending() {
  const me = S.me && S.me.username;
  const list = lpPending().filter((p) => p.user === me);
  for (const p of list) { try { await lpSend(p); } catch (e) { if (/Cannot reach the server/.test(e.message) || isExpired(e)) return; } }
}
window.addEventListener('online', () => { if (S.token) lpFlushPending(); });
FORMS.lpAnswer = async (form, btn) => {
  const pres = form.dataset.pres;
  const Q = LP.q[pres];
  if (!Q) return;
  const answer = lpCollect(form, Q.item);
  const fb = $('#q-' + pres + ' .lp-fb');
  if (lpEmpty(Q.item, answer)) { fb.innerHTML = notice('Answer every part first. If you are not sure, a hint can help.', 'warn'); return; }
  const entry = { pres, ev: lpUid(), answer, ms: Math.round(Q.active), at: Date.now(), user: S.me.username };
  lpSetPending(lpPending().concat([entry]));
  btn.disabled = true; btn.classList.add('is-busy');
  let r;
  try { r = await lpSend(entry); }
  catch (e) {
    btn.disabled = false; btn.classList.remove('is-busy');
    fb.innerHTML = /Cannot reach the server/.test(e.message)
      ? notice('You seem to be offline. Your answer is saved on this device and will be sent when the connection is back. <button class="btn btn-sm" type="button" data-act="lpRetry">Try again now</button>', 'warn')
      : notice(esc(e.message), 'err');
    return;
  }
  btn.disabled = false; btn.classList.remove('is-busy');
  if (r.duplicate) { fb.innerHTML = notice('This answer was already saved.', ''); return; }
  Q.tries = r.tries;
  if (r.correct === true || (r.correct === null && r.complete)) { Q.done = true; $$('input,select,textarea,button[data-act="lpMove"]', form).forEach((x) => { x.disabled = true; }); btn.remove(); const h = form.querySelector('[data-act="lpHint"]'); if (h) h.remove(); }
  fb.innerHTML = lpFeedbackHtml(r, Q, pres);
  if (LP.onAnswered) LP.onAnswered(pres, r);
};
ACT.lpRetry = (d, btn) => busy(btn, async () => { await lpFlushPending(); toast(lpPending().length ? 'Still offline — we will keep trying.' : 'Saved.'); if (!lpPending().length) refresh(); });
function lpFeedbackHtml(r, Q, pres) {
  const it = Q.item;
  const cel = LP.prefs ? LP.prefs.celebrate !== false : true;
  let head;
  if (r.correct === null) head = r.complete ? '<p class="lp-verdict ok">' + icon('checkCircle') + '<b>Reflection saved.</b> ' + r.words + ' words.</p>' : '<p class="lp-verdict">' + icon('edit') + 'Write at least a few more words (' + r.words + ' so far).</p>';
  else if (r.correct) head = '<p class="lp-verdict ok">' + icon('checkCircle') + '<b>Correct.</b> ' + (r.tries > 1 ? 'You worked it out.' : 'Well done.') + '</p>';
  else head = '<p class="lp-verdict no">' + icon('xCircle') + '<b>Not quite.</b> ' + (r.score > 0 && r.score < 1 ? 'Partly right (' + Math.round(r.score * 100) + '%).' : '') + '</p>';
  let h = '<div class="lp-fb-card ' + (r.correct === false ? 'no' : 'ok') + (cel && !lpReduced() && r.correct ? ' pop' : '') + '">' + head;
  if (r.parts) h += '<ul class="lp-parts">' + r.parts.map((p, k) => '<li>' + icon(p.correct ? 'check' : 'x') + 'Question ' + (k + 1) + ': ' + (p.correct ? 'correct' : 'not quite') + '</li>').join('') + '</ul>';
  if (r.misconception) h += '<p class="lp-misc">' + icon('alert') + '<span>' + esc(r.misconception) + '</span></p>';
  if (r.expected) h += '<div class="lp-answer"><b>Answer:</b> ' + esc(r.expected) + (r.explanation ? '<div class="prose small">' + md(r.explanation) + '</div>' : '') + '</div>';
  if (r.correct === false) h += '<div class="row-wrap"><button class="btn btn-sm" type="button" data-act="lpTryAgain" data-pres="' + esc(pres) + '">' + icon('refresh') + 'Try again</button>' + (r.expected ? '' : '<button class="btn btn-sm btn-ghost" type="button" data-act="lpReveal" data-pres="' + esc(pres) + '">Show the answer</button>') + (r.another ? '<button class="btn btn-sm btn-ghost" type="button" data-act="lpAnother" data-pres="' + esc(pres) + '">Try another example</button>' : '') + '</div>';
  else if (r.another && it.type !== 'reflection') h += '<button class="btn btn-sm btn-ghost" type="button" data-act="lpAnother" data-pres="' + esc(pres) + '">Try another example</button>';
  if (cel && (r.rewards || []).length) h += '<p class="lp-xp">' + icon('star') + r.rewards.map((x) => '+' + x.amount + ' XP · ' + esc(x.reason)).join(' · ') + '</p>';
  (r.skills || []).forEach((k) => { h += '<p class="lp-up">' + icon('trending') + '<span><b>' + esc(k.name) + ':</b> now ' + esc(LP_STATUS[k.to][0]) + '</span></p>'; });
  (r.badges || []).forEach((b) => { h += '<p class="lp-up">' + icon('award') + '<span>New badge: <b>' + esc(b.name) + '</b> — ' + esc(b.text) + '</span></p>'; });
  return h + '</div>';
}
ACT.lpTryAgain = (d) => {
  const form = $('#q-' + d.pres + ' form');
  $$('input,select,textarea,button', form).forEach((x) => { x.disabled = false; });
  $('#q-' + d.pres + ' .lp-fb').innerHTML = '';
  const f = form.querySelector('input:not([type=hidden]),select,textarea'); if (f) f.focus();
};
ACT.lpReveal = (d, btn) => busy(btn, async () => {
  const r = await call('lpReveal', { pres: d.pres });
  btn.insertAdjacentHTML('afterend', '<div class="lp-answer"><b>Answer:</b> ' + esc(r.expected) + (r.explanation ? '<div class="prose small">' + md(r.explanation) + '</div>' : '') + '</div>');
  btn.remove();
});
ACT.lpAnother = (d, btn) => busy(btn, async () => {
  const q = await call('lpAnother', { pres: d.pres });
  const sec = $('#q-' + d.pres);
  sec.insertAdjacentHTML('afterend', lpQuestionHtml(Object.assign(q, { reason: 'Another example of the same idea, with different details.' })));
  const nx = $('#q-' + q.pres); if (nx) { nx.scrollIntoView({ behavior: lpReduced() ? 'auto' : 'smooth', block: 'start' }); const f = nx.querySelector('input,select,textarea'); if (f) f.focus({ preventScroll: true }); }
});
/** Time actually spent answering: counted only while the page is visible and the learner has been active in the last minute. */
function lpStartTimer() {
  clearInterval(LP.timer);
  LP.timer = setInterval(() => {
    if (document.visibilityState !== 'visible' || Date.now() - (S.lastInput || 0) > 60000) return;
    const cur = Object.keys(LP.q).find((k) => !LP.q[k].done && $('#q-' + k));
    if (cur) LP.q[cur].active += 5000;
  }, 5000);
  S.onLeave = () => { clearInterval(LP.timer); LP.q = {}; LP.onAnswered = null; };
}
['keydown', 'pointerdown', 'input'].forEach((ev) => document.addEventListener(ev, () => { S.lastInput = Date.now(); }, { passive: true }));

/* =====================================================================
   LESSON
   ===================================================================== */
function lpBlockHtml(b) {
  if (b.kind === 'text') return '<div class="prose">' + md(b.text) + '</div>';
  if (b.kind === 'image') return '<figure class="lp-fig"><img src="' + esc(b.src) + '" alt="' + esc(b.alt || '') + '">' + (b.caption ? '<figcaption>' + esc(b.caption) + '</figcaption>' : '') + '</figure>';
  if (b.kind === 'video') {
    const src = b.provider === 'youtube' ? 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(b.vid) : 'https://player.vimeo.com/video/' + encodeURIComponent(b.vid);
    return '<figure class="lp-video"><div class="lp-video-frame"><iframe src="' + esc(src) + '" title="' + esc(b.title || 'Lesson video') + '" allow="fullscreen; picture-in-picture" loading="lazy"></iframe></div>' +
      (b.transcript ? '<details><summary>Transcript</summary><div class="prose small">' + md(b.transcript) + '</div></details>' : '') + '</figure>';
  }
  return '<div class="card card-pad lp-example"><div class="lp-ex-h">' + icon('lightbulb') + '<b>' + esc(b.title || 'Worked example') + '</b></div><div class="prose">' + md(b.problem) + '</div>' +
    (b.steps.length ? '<details><summary>Show the worked solution</summary><ol class="lp-steps">' + b.steps.map((s) => '<li>' + md(s) + '</li>').join('') + '</ol>' + (b.answer ? '<p><b>Answer:</b> ' + md(b.answer) + '</p>' : '') + '</details>' : '') + '</div>';
}
async function viewLpLesson(id) {
  if (S.me.role === 'student') await lpFlushPending();
  const [d, pr] = await Promise.all([call('lpLesson', { id }), S.me.role === 'student' ? call('lpPrefs').catch(() => null) : null]);
  LP.prefs = pr ? pr.prefs : null;
  LP.lesson = d;
  const l = d.lesson;
  const acts = d.activities;
  const left = () => acts.filter((a) => !a.done && !(LP.q[a.pres] && LP.q[a.pres].tries)).length;
  LP.onAnswered = (pres) => { const a = acts.find((x) => x.pres === pres); if (a) a.done = true; const b = $('#lp-complete'); if (b) { const n = left(); b.disabled = n > 0; $('#lp-left').textContent = n ? n + ' activit' + (n === 1 ? 'y' : 'ies') + ' left to try' : 'Ready when you are.'; } };
  const n0 = acts.filter((a) => !a.done).length;
  return {
    title: l.title,
    html: pageHead(l.title, { crumbs: [['My learning', '/learn'], [d.course.short, d.preview ? '/learn/teach/' + d.course.id : '/learn/subject/' + d.course.id], [l.title]], sub: 'About ' + l.minutes + ' min' + (l.required ? '' : ' · optional') + (d.dueAt ? ' · suggested by ' + esc(fmtDate(d.dueAt)) : '') + (d.preview ? ' · ' + badge('Teacher preview — answers are not recorded', 'warning') : '') }) +
      (d.completed && d.completed.outdated ? notice('This lesson was updated after you completed it. Your completion still counts; the new content is below.', '', 'info') : '') +
      '<div class="lp-lesson">' +
      (l.objectives.length ? '<section class="card card-pad lp-obj"><h2>By the end of this lesson you can</h2><ul>' + l.objectives.map((o) => '<li>' + esc(o) + '</li>').join('') + '</ul></section>' : '') +
      l.blocks.map(lpBlockHtml).join('') +
      (acts.length ? '<h2 class="section-title">Your turn</h2>' + acts.map((q) => lpQuestionHtml(q)).join('') : '') +
      (d.preview ? '' : '<div class="card card-pad lp-finish">' + (d.completed ? '<p>' + icon('checkCircle') + ' You completed this lesson on ' + esc(fmtDate(d.completed.at)) + '.</p>' :
        '<p id="lp-left" class="muted" aria-live="polite">' + (n0 ? n0 + ' activit' + (n0 === 1 ? 'y' : 'ies') + ' left to try' : 'Ready when you are.') + '</p><p class="small muted">Getting every answer right is not needed — trying is.</p><button class="btn btn-primary btn-lg" id="lp-complete" data-act="lpComplete" data-id="' + esc(l.id) + '"' + (n0 ? ' disabled' : '') + '>' + icon('check') + 'Complete lesson</button>') + '</div>') +
      '</div>',
    after: lpStartTimer
  };
}
ACT.lpComplete = (d, btn) => busy(btn, async () => {
  const r = await call('lpCompleteLesson', { id: d.id });
  const cel = !LP.prefs || LP.prefs.celebrate !== false;
  const box = btn.closest('.lp-finish');
  box.innerHTML = '<div class="lp-done' + (cel && !lpReduced() ? ' pop' : '') + '" role="status">' + icon('award', 'i-xl') + '<h2>Lesson complete</h2>' +
    (cel && r.rewards && r.rewards.length ? '<p class="lp-xp">' + r.rewards.map((x) => '+' + x.amount + ' XP · ' + esc(x.reason)).join(' · ') + '</p>' : '') +
    (r.badges || []).map((b) => '<p class="lp-up">' + icon('award') + 'New badge: <b>' + esc(b.name) + '</b></p>').join('') +
    '<div class="row-wrap" style="justify-content:center">' + (r.next ? '<a class="btn btn-primary" href="#/learn/lesson/' + esc(r.next.id) + '">Next: ' + esc(r.next.title) + '</a>' : '') + '<a class="btn" href="#/learn/subject/' + esc(LP.lesson.course.id) + '">Back to the subject</a></div></div>';
});

/* =====================================================================
   PRACTICE AND REVIEW SESSIONS (one question at a time)
   ===================================================================== */
async function lpSessionView(payload, title, back) {
  await lpFlushPending();
  const [d, pr] = await Promise.all([call('lpPractice', payload), call('lpPrefs').catch(() => null)]);
  LP.prefs = pr ? pr.prefs : null;
  const sess = { list: d.session, i: 0, stats: { answered: 0, own: 0, xp: 0, skills: [] } };
  LP.session = sess;
  const crumbs = [['My learning', '/learn'], [title]];
  if (!d.session.length) return { title, html: pageHead(title, { crumbs }) + emptyState(payload.mode === 'review' ? 'checkCircle' : 'target', payload.mode === 'review' ? 'All caught up' : 'Nothing to practise yet', esc(d.message), '<a class="btn" href="#' + esc(back) + '">Back</a>') };
  LP.onAnswered = (pres, r) => {
    if (r.correct === false && !r.expected) return;
    const st = sess.stats;
    st.answered++; if (r.correct && r.tries === 1) st.own++;
    (r.rewards || []).forEach((x) => { st.xp += x.amount; });
    (r.skills || []).forEach((k) => st.skills.push(k));
    const fb = $('#q-' + pres + ' .lp-fb .lp-fb-card');
    if (fb && !fb.querySelector('[data-act="lpNext"]')) fb.insertAdjacentHTML('beforeend', '<div class="row-wrap lp-next"><button class="btn btn-primary" type="button" data-act="lpNext">' + (sess.i + 1 < sess.list.length ? 'Next question' : 'Finish') + icon('right') + '</button></div>');
    const nb = $('#q-' + pres + ' [data-act="lpNext"]'); if (nb) nb.focus();
  };
  return {
    title,
    html: pageHead(title, { crumbs, sub: (d.message ? esc(d.message) + ' ' : '') + (payload.mode === 'review' ? 'Recall each answer before you check.' : 'Questions are picked for you; each shows why.') }) +
      '<div class="lp-session"><div class="lp-progress" aria-hidden="true">' + progressBar(0) + '</div><div id="lp-stage">' + lpQuestionHtml(sess.list[0], 0, sess.list.length) + '</div></div>',
    after: () => { lpStartTimer(); const f = $('#lp-stage input,#lp-stage select,#lp-stage textarea'); if (f) f.focus({ preventScroll: true }); }
  };
}
ACT.lpNext = () => {
  const sess = LP.session;
  if (!sess) return;
  sess.i++;
  const bar = $('.lp-session .progress i'); if (bar) bar.style.width = Math.round(sess.i / sess.list.length * 100) + '%';
  const stage = $('#lp-stage');
  if (sess.i >= sess.list.length) {
    const st = sess.stats;
    stage.innerHTML = '<div class="card card-pad lp-done' + (lpReduced() ? '' : ' pop') + '" role="status">' + icon('checkCircle', 'i-xl') + '<h2>Session complete</h2><p>' + plural(st.answered, 'question') + ' · ' + st.own + ' right first time on your own' + (st.xp ? ' · +' + st.xp + ' XP' : '') + '</p>' +
      st.skills.map((k) => '<p class="lp-up">' + icon('trending') + esc(k.name) + ': now ' + esc(LP_STATUS[k.to][0]) + '</p>').join('') +
      '<div class="row-wrap" style="justify-content:center"><button class="btn btn-primary" data-act="reload">' + icon('refresh') + 'Another session</button><a class="btn" href="#/learn">Back to my learning</a></div></div>';
    stage.querySelector('h2').setAttribute('tabindex', '-1'); stage.querySelector('h2').focus();
    return;
  }
  stage.innerHTML = lpQuestionHtml(sess.list[sess.i], sess.i, sess.list.length);
  const h = stage.querySelector('h3'); h.setAttribute('tabindex', '-1'); h.focus();
};
function viewLpPractice(courseId) { return lpSessionView({ courseId, mode: 'practice', size: 8 }, 'Practice', '/learn/subject/' + courseId); }
function viewLpSkill(courseId, skillId) { return lpSessionView({ courseId, mode: 'skill', skillId, size: 6 }, 'Skill practice', '/learn/subject/' + courseId + '?tab=skills'); }
function viewLpReview(courseId) { return lpSessionView(Object.assign({ mode: 'review', size: 12 }, courseId ? { courseId } : {}), 'Reviews', '/learn'); }

/* =====================================================================
   SETTINGS (goals, privacy, celebrations)
   ===================================================================== */
const LP_TZ = ['Asia/Kolkata', 'Asia/Dubai', 'Asia/Singapore', 'Asia/Kathmandu', 'Asia/Colombo', 'Asia/Dhaka', 'Europe/London', 'America/New_York', 'Australia/Sydney', 'UTC'];
async function viewLpSettings() {
  const d = await call('lpPrefs');
  const p = d.prefs;
  const here = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone; } catch (e) { return ''; } })();
  const zones = [...new Set([d.tz, here].concat(LP_TZ).filter(Boolean))];
  return {
    title: 'Learning settings',
    html: pageHead('Goals & privacy', { crumbs: [['My learning', '/learn'], ['Settings']] }) + lpNav('/learn/settings') +
      '<form class="card card-pad lp-settings" data-form="lpPrefs" novalidate><div class="form-grid">' +
      field('Time zone', '<select class="input" name="tz">' + zones.map((z) => '<option' + (z === d.tz ? ' selected' : '') + '>' + esc(z) + '</option>') + '</select>', 'Days, streaks and reviews follow this time zone.') +
      field('Active days a week', '<input class="input" type="number" name="weeklyDays" min="1" max="7" value="' + p.weeklyDays + '">', 'Your weekly goal. Rest days are fine.') +
      (d.policy.gamification ? field('Daily XP goal', '<input class="input" type="number" name="dailyXp" min="0" max="500" step="5" value="' + p.dailyXp + '">', '0 switches the daily goal off.') : '') +
      '</div>' +
      (d.policy.peers ? '<fieldset class="fieldset"><legend>How classmates see you</legend>' + (d.policy.studentChoice ? [['default', 'As my teacher sets it', 'Your name or an automatic alias, depending on the course.'], ['alias', 'Always as an alias', 'Classmates see an automatic alias, never your name.'], ['hidden', 'Hide me from class lists', 'You still count in class totals, but are not listed.']].map((o) =>
        '<label class="check"><input type="radio" name="visibility" value="' + o[0] + '"' + (p.visibility === o[0] ? ' checked' : '') + '><span>' + o[1] + '<span class="hint">' + o[2] + '</span></span></label>').join('') : '<p class="muted">Your institution sets this.</p>') +
        '<p class="small muted">Classmates never see your grades, answers, mistakes, accommodations, teacher feedback, exact times or anything from exams.</p></fieldset>' : '') +
      '<fieldset class="fieldset"><legend>Motivation</legend>' + check('competitive', 'Show rankings and comparisons', p.competitive, 'Switch off to keep class lists alphabetical and leave you out of any ranking.') +
      check('celebrate', 'Celebrations', p.celebrate, 'Short messages when you earn XP, badges or improve a skill. Animations also follow your device’s reduced-motion setting.') + '</fieldset>' +
      '<div class="form-actions"><button class="btn btn-primary" type="submit">Save</button></div></form>'
  };
}
FORMS.lpPrefs = (f, btn) => busy(btn, async () => {
  const v = (n) => (f.elements[n] ? f.elements[n].value : undefined);
  const vis = f.querySelector('input[name="visibility"]:checked');
  await call('lpSavePrefs', { tz: v('tz'), weeklyDays: Number(v('weeklyDays')), dailyXp: v('dailyXp') === undefined ? undefined : Number(v('dailyXp')), visibility: vis ? vis.value : undefined, competitive: f.elements.competitive.checked, celebrate: f.elements.celebrate.checked });
  toast('Saved.');
});
