'use strict';
/* =====================================================================
   ASSESSMENT — staff side of online proctoring
   /assessment               hub: KPIs, exams, review queue, capabilities
   /assessment/exam/:id      one exam: sessions, analytics, proctoring settings
   /assessment/live          live monitor (all exams or one)
   /assessment/reviews       integrity review queue
   /assessment/session/:id   session review: identity, timeline, snapshots, decision
   ===================================================================== */
const BAND = { low: ['Low risk', 'success'], medium: ['Medium risk', 'warning'], high: ['High risk', 'danger'] };
const REVIEW = { pending: ['Not reviewed', ''], cleared: ['Cleared', 'success'], suspicious: ['Suspicious', 'warning'], misconduct: ['Misconduct', 'danger'] };
const SEV_TONE = ['', 'info', 'warning', 'danger'];
const SEV_NAME = ['Info', 'Low', 'Medium', 'High'];

function integrityPill(x) { return '<span class="integrity ' + x.band + '" title="Integrity score (100 = no concerns)">' + x.integrity + '</span>'; }
function reviewBadge(st) { const r = REVIEW[st] || REVIEW.pending; return badge(r[0], r[1]); }
function sessionStatus(x) {
  if (x.status === 'active') return x.online ? badge('Live', 'success', 'live') : badge('Disconnected', 'warning', 'alert');
  if (x.status === 'terminated') return badge('Ended by proctoring', 'danger');
  if (x.status === 'ended') return badge('Completed');
  return badge('Checking in', 'info');
}

/* ---------- authenticated snapshots ---------- */
const PIMG = new Map();
function pimg(sid, id, cls, alt) { return '<img class="' + (cls || '') + '" data-pimg="' + esc(sid + '/' + id) + '" alt="' + esc(alt || '') + '" loading="lazy">'; }
function hydrateImages(root) {
  const load = (img) => {
    const key = img.dataset.pimg;
    img.removeAttribute('data-pimg');
    const p = PIMG.get(key) || fetch('/proctor-img/' + key, { headers: { Authorization: 'Bearer ' + S.token } })
      .then((r) => (r.ok ? r.blob() : Promise.reject(new Error('missing')))).then((b) => URL.createObjectURL(b));
    PIMG.set(key, p);
    p.then((u) => { img.src = u; }).catch(() => { PIMG.delete(key); img.classList.add('broken'); });
  };
  const imgs = $$('img[data-pimg]', root);
  if (!('IntersectionObserver' in window)) { imgs.forEach(load); return; }
  const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { io.unobserve(e.target); load(e.target); } }), { rootMargin: '200px' });
  imgs.forEach((i) => io.observe(i));
}

/* =====================================================================
   HUB
   ===================================================================== */
const CAPS = [['scan', 'Face ID & liveness', 'Selfie matched to an enrolled face signature; head-turn + blink challenge defeats photos.'],
  ['user', 'Face presence', 'Absent student or more than one face, tracked continuously with 478 landmarks.'],
  ['eye', 'Head pose & gaze', 'Personally calibrated yaw/pitch and eye-direction to spot looking away.'],
  ['camera', 'Object detection', 'Phones, books, extra laptops/screens and other people in view.'],
  ['mic', 'Voice activity', 'Speech detection fused with lip movement: student talking vs. other voices.'],
  ['monitor', 'Screen & browser lockdown', 'Entire-screen capture, tab/focus/full-screen tracking, copy/paste and shortcut blocking.'],
  ['live', 'Live monitor & chat', 'Live thumbnails, risk-sorted grid, messages, warnings and termination.'],
  ['gavel', 'Human review', 'Integrity score, timeline, evidence gallery and a recorded decision for every session.']];

async function viewProctorHub() {
  const r = await call('proctorHub');
  const k = r.kpis;
  const exams = r.exams.map((e) => '<tr data-text="' + esc((e.title + ' ' + e.course).toLowerCase()) + '"><td style="min-width:210px"><a href="#/assessment/exam/' + esc(e.id) + '"><b>' + esc(e.title) + '</b></a><div class="xs muted">' + esc(e.course || 'No course') +
    (e.closeAt ? ' · closes ' + esc(fmt(e.closeAt)) : '') + (e.durationMin ? ' · ' + e.durationMin + ' min' : '') + '</div></td>' +
    '<td>' + (e.proctored ? badge('On', 'success', 'shield') + '<div class="xs muted" style="margin-top:.2rem">' + esc(policySummary(e.policy)) + '</div>' : badge('Off')) + '</td>' +
    '<td class="num">' + e.sessions + '</td><td class="num">' + (e.live ? '<b style="color:var(--success)">' + e.live + '</b>' : '0') + '</td>' +
    '<td class="num">' + (e.highRisk ? '<b style="color:var(--danger)">' + e.highRisk + '</b>' : '0') + '</td><td class="num">' + (e.pending || 0) + '</td>' +
    '<td class="num">' + (e.avgIntegrity == null ? '—' : e.avgIntegrity) + '</td>' +
    '<td class="actions"><a class="btn btn-sm ' + (e.proctored ? 'btn-ghost' : 'btn-soft') + '" href="#/assessment/exam/' + esc(e.id) + (e.proctored ? '' : '?tab=settings') + '">' + (e.proctored ? 'Open' : 'Set up') + ' ' + icon('right', 'i-sm') + '</a></td></tr>').join('');
  const maxFlag = Math.max(1, ...r.flags.map((f) => f.n));
  return {
    title: 'Proctoring',
    html: pageHead('Proctoring', {
      crumbs: [['Assessment'], ['Proctoring']], sub: 'AI-assisted online proctoring for your quizzes and exams',
      actions: '<a class="btn" href="#/assessment/reviews">' + icon('gavel') + 'Review queue' + (k.pending ? ' <span class="badge danger">' + k.pending + '</span>' : '') + '</a>' +
        '<a class="btn btn-primary" href="#/assessment/live">' + icon('live') + 'Live monitor' + (k.live ? ' <span class="badge success">' + k.live + '</span>' : '') + '</a>'
    }) +
      '<div class="kpis">' + kpi('Proctored exams', k.proctored, 'of ' + r.exams.length + ' you manage', 'shield') + kpi('Live now', k.live, k.checkin ? k.checkin + ' checking in' : 'students in exams', 'live') +
      kpi('Awaiting review', k.pending, 'flagged sessions', 'gavel') + kpi('Average integrity', k.avgIntegrity == null ? '—' : k.avgIntegrity + '<small>/100</small>', plural(k.sessions, 'completed session'), 'checkCircle') +
      kpi('High risk', k.highRisk, k.terminated ? k.terminated + ' ended by proctoring' : 'sessions', 'alert') + '</div>' +
      '<div class="split"><div class="stack"><div class="card"><div class="card-head"><span class="i-tile sm tone-violet">' + icon('quiz') + '</span><div><h2>Exams</h2><div class="xs muted">Turn proctoring on per quiz and choose what is monitored</div></div><div class="spacer"></div>' +
      '<div class="search-box" style="width:min(220px,40vw)">' + icon('search') + '<input type="search" placeholder="Filter exams" data-input="filterRows" data-target="#pxExams" aria-label="Filter exams"></div></div>' +
      (r.exams.length ? '<div class="table-wrap"><table class="table" id="pxExams"><thead><tr><th>Exam</th><th>Proctoring</th><th class="num">Sessions</th><th class="num">Live</th><th class="num">High risk</th><th class="num">To review</th><th class="num">Avg integrity</th><th></th></tr></thead><tbody>' + exams + '</tbody></table></div>'
        : '<div class="card-body">' + emptyState('quiz', 'No quizzes yet', 'Add a quiz to a course, then switch on proctoring here.', '', false) + '</div>') + '</div>' +
      '<div class="card"><div class="card-head"><span class="i-tile sm tone-red">' + icon('gavel') + '</span><div><h2>Highest-risk sessions awaiting review</h2><div class="xs muted">Sorted by risk — the AI flags, you decide</div></div><div class="spacer"></div><a class="small" href="#/assessment/reviews">All reviews</a></div>' +
      (r.queue.length ? sessionTable(r.queue, true) : '<div class="card-body">' + emptyState('checkCircle', 'Nothing to review', 'Flagged sessions appear here when proctored exams finish.', '', false) + '</div>') + '</div></div>' +
      '<div class="stack"><div class="card"><div class="card-head"><span class="i-tile sm tone-blue">' + icon('sparkle') + '</span><div><h2>What the AI watches</h2><div class="xs muted">Runs on each student’s device</div></div></div><div class="card-body caps">' +
      CAPS.map(([ico, t, d]) => '<div class="cap">' + icon(ico) + '<div><b>' + esc(t) + '</b><span>' + esc(d) + '</span></div></div>').join('') + '</div></div>' +
      '<div class="card"><div class="card-head"><span class="i-tile sm tone-amber">' + icon('chart') + '</span><h2>Most common flags</h2></div><div class="card-body">' +
      (r.flags.length ? r.flags.slice(0, 10).map((f) => hbar(f.label, f.n, maxFlag, SEV_TONE[f.sev])).join('') : '<p class="small muted">No flags yet.</p>') + '</div></div>' +
      (r.admin ? '<div class="card"><div class="card-head"><span class="i-tile sm tone-slate">' + icon('lock') + '</span><div><h2>Data retention</h2><div class="xs muted">Snapshots and timelines are deleted after this</div></div></div><div class="card-body">' +
        '<form data-form="pxRetention" class="row"><input type="number" name="days" min="7" max="365" value="' + r.retentionDays + '" style="width:100px" aria-label="Days"><span class="small muted">days</span><div class="spacer"></div><button class="btn btn-sm" type="submit">Save</button></form>' +
        '<p class="xs muted" style="margin:.6rem 0 0">Session summaries and review decisions are kept.</p></div></div>' : '') + '</div></div>'
  };
}
function hbar(label, n, max, tone) {
  return '<div class="fbar"><div class="fbar-l"><span>' + esc(label) + '</span><b class="tnum">' + n + '</b></div><div class="fbar-t"><i class="' + (tone || '') + '" style="width:' + Math.max(3, Math.round(n / max * 100)) + '%"></i></div></div>';
}
function policySummary(p) {
  return [p.microphone && 'mic', p.screen && 'screen', p.identity && 'face ID', p.idCard && 'ID card', p.roomScan && 'room scan', p.sensitivity + ' sensitivity'].filter(Boolean).join(' · ');
}
FORMS.pxRetention = (f, btn) => busy(btn, async () => { const r = await call('proctorRetention', { days: f.elements.days.value }); toast('Recordings are kept for ' + r.retentionDays + ' days.'); });

function sessionTable(list, withQuiz) {
  return '<div class="table-wrap"><table class="table" id="pxSessions"><thead><tr><th>Student</th>' + (withQuiz ? '<th>Exam</th>' : '') + '<th>Started</th><th>Status</th><th class="num">Integrity</th><th>Top flags</th><th>Identity</th><th>Review</th><th class="num">Score</th><th></th></tr></thead><tbody>' +
    list.map((x) => '<tr data-text="' + esc((x.name + ' ' + x.username + ' ' + x.batch + ' ' + (x.quiz || '')).toLowerCase()) + '"><td><div class="cell-user">' + avatar(x.name, 'sm') + '<div><b>' + esc(x.name) + '</b><span>' + esc(x.batch || '@' + x.username) + '</span></div></div></td>' +
      (withQuiz ? '<td class="small">' + esc(x.quiz) + '</td>' : '') +
      '<td class="small nowrap">' + esc(fmt(x.startedAt || x.createdAt)) + (x.endedAt && x.startedAt ? '<div class="xs muted">' + esc(durationText(x.endedAt - x.startedAt)) + '</div>' : '') + '</td>' +
      '<td>' + sessionStatus(x) + (x.resumes ? '<div class="xs muted">' + plural(x.resumes, 're-check-in') + '</div>' : '') + '</td>' +
      '<td class="num">' + integrityPill(x) + '</td>' +
      '<td class="small" style="max-width:260px">' + (x.top.length ? x.top.map((t) => '<span class="flag-chip s' + t.sev + '">' + esc(t.label) + ' ×' + t.n + '</span>').join('') : '<span class="muted">None</span>') + '</td>' +
      '<td>' + (x.verified === 'ok' ? badge('Matched', 'success', 'check') : x.verified === 'enrolled' ? badge('Enrolled', 'info') : x.verified === 'mismatch' ? badge('Mismatch', 'danger') : '<span class="muted small">—</span>') + '</td>' +
      '<td>' + reviewBadge(x.review.status) + '</td>' +
      '<td class="num">' + (x.score != null ? x.score + ' / ' + x.maxScore : '—') + '</td>' +
      '<td class="actions"><a class="btn btn-sm btn-ghost" href="#/assessment/session/' + esc(x.id) + '">Review ' + icon('right', 'i-sm') + '</a></td></tr>').join('') + '</tbody></table></div>';
}

/* =====================================================================
   EXAM PAGE (sessions + settings)
   ===================================================================== */
async function viewProctorExam(quizId, params) {
  const r = await call('proctorExam', { quizId });
  S.pxExam = r;
  const tab = params.get('tab') || (r.policy.enabled ? 'sessions' : 'settings');
  const q = r.quiz;
  const tabs = '<nav class="tabs">' + [['sessions', 'Sessions & analytics', 'users'], ['settings', 'Proctoring settings', 'settings']].map(([k2, l, ico]) =>
    '<a class="tab' + (tab === k2 ? ' active' : '') + '" href="#/assessment/exam/' + esc(q.id) + '?tab=' + k2 + '">' + icon(ico, 'i-sm') + l + '</a>').join('') + '</nav>';
  let body;
  if (tab === 'settings') body = policyForm(r.policy);
  else {
    const s = r.sessions;
    const done = s.filter((x) => x.status === 'ended' || x.status === 'terminated');
    const avg = done.length ? Math.round(done.reduce((t, x) => t + x.integrity, 0) / done.length) : null;
    const maxFlag = Math.max(1, ...r.flags.map((f) => f.n));
    const maxH = Math.max(1, ...r.hist);
    body = (!r.policy.enabled ? notice('Proctoring is <b>off</b> for this exam. Turn it on under <a href="#/assessment/exam/' + esc(q.id) + '?tab=settings">Proctoring settings</a>.', 'warn') : '') +
      '<div class="kpis">' + kpi('Sessions', s.length, s.filter((x) => x.status === 'active').length + ' in progress', 'users') +
      kpi('Average integrity', avg == null ? '—' : avg + '<small>/100</small>', 'completed sessions', 'checkCircle') +
      kpi('High risk', r.bands.high, r.bands.medium + ' medium · ' + r.bands.low + ' low', 'alert') +
      kpi('Reviewed', s.filter((x) => x.review.status !== 'pending').length, 'of ' + done.length + ' completed', 'gavel') + '</div>' +
      '<div class="grid-2" style="margin-bottom:1.25rem"><div class="card"><div class="card-head"><span class="i-tile sm tone-amber">' + icon('chart') + '</span><h2>Flags in this exam</h2></div><div class="card-body">' +
      (r.flags.length ? r.flags.map((f) => hbar(f.label, f.n, maxFlag, SEV_TONE[f.sev])).join('') : '<p class="small muted">No flags yet.</p>') + '</div></div>' +
      '<div class="card"><div class="card-head"><span class="i-tile sm tone-green">' + icon('checkCircle') + '</span><div><h2>Integrity distribution</h2><div class="xs muted">Number of sessions per score band</div></div></div><div class="card-body"><div class="hist">' +
      r.hist.map((n, i) => '<div class="hist-col" title="' + (i * 10) + '–' + (i * 10 + 9 + (i === 9 ? 1 : 0)) + ': ' + n + '"><i class="' + (i < 5 ? 'danger' : i < 8 ? 'warning' : 'success') + '" style="height:' + Math.round(n / maxH * 100) + '%"></i><span>' + (i * 10) + '</span></div>').join('') + '</div></div></div></div>' +
      '<div class="card"><div class="card-head"><span class="i-tile sm tone-blue">' + icon('users') + '</span><h2>Sessions</h2><div class="spacer"></div>' +
      '<div class="search-box" style="width:min(220px,40vw)">' + icon('search') + '<input type="search" placeholder="Filter" data-input="filterRows" data-target="#pxSessions" aria-label="Filter sessions"></div>' +
      '<button class="btn btn-sm" data-act="pxExport">' + icon('download') + 'Export CSV</button></div>' +
      (s.length ? sessionTable(s, false) : '<div class="card-body">' + emptyState('shield', 'No proctored sessions yet', 'Sessions appear here when students check in.', '', false) + '</div>') + '</div>';
  }
  return {
    title: q.title + ' · Proctoring',
    html: pageHead(q.title, {
      crumbs: [['Assessment', '/assessment'], ['Proctoring', '/assessment'], [q.title]],
      sub: (r.policy.enabled ? badge('Proctoring on', 'success', 'shield') : badge('Proctoring off')) + ' ' + (q.published ? '' : badge('Hidden from students', 'warning', 'eyeOff')) +
        (q.closeAt ? ' <span class="small muted">Closes ' + esc(fmt(q.closeAt)) + '</span>' : ''),
      actions: (q.moduleId ? '<a class="btn" href="#/mod/' + esc(q.moduleId) + '">' + icon('quiz') + 'Quiz page</a>' : '') + '<a class="btn" href="#/quiz/' + esc(q.id) + '/results">' + icon('users') + 'Results</a>' +
        '<a class="btn btn-primary" href="#/assessment/live?quiz=' + esc(q.id) + '">' + icon('live') + 'Live monitor</a>'
    }) + tabs + body
  };
}
ACT.pxExport = () => {
  const r = S.pxExam;
  downloadText((r.quiz.title || 'exam').replace(/[^\w-]+/g, '_') + '-proctoring.csv', csv([['Name', 'Username', 'Batch', 'Started', 'Ended', 'Status', 'Integrity', 'Risk band', 'Flags', 'High-severity', 'Top flags', 'Identity', 'Review', 'Score', 'Max']]
    .concat(r.sessions.map((x) => [x.name, x.username, x.batch, fmt(x.startedAt), fmt(x.endedAt), x.status, x.integrity, x.band, x.flags, x.high, x.top.map((t) => t.label + ' x' + t.n).join('; '), x.verified, x.review.status, x.score == null ? '' : x.score, x.maxScore == null ? '' : x.maxScore]))));
};

const PRESETS = {
  light: { enabled: true, microphone: false, screen: false, identity: true, liveness: false, idCard: false, roomScan: false, aiFaces: true, aiGaze: true, aiObjects: true, aiAudio: false, sensitivity: 'low', snapshotSec: 60, strikes: 0, liveChat: true },
  standard: { enabled: true, microphone: true, screen: false, identity: true, liveness: true, idCard: false, roomScan: false, aiFaces: true, aiGaze: true, aiObjects: true, aiAudio: true, sensitivity: 'medium', snapshotSec: 30, strikes: 0, liveChat: true },
  strict: { enabled: true, microphone: true, screen: true, identity: true, liveness: true, idCard: true, roomScan: true, aiFaces: true, aiGaze: true, aiObjects: true, aiAudio: true, sensitivity: 'high', snapshotSec: 20, strikes: 5, liveChat: true }
};
function policyForm(p) {
  const sw = (name, label, hint, disabled) => '<label class="px-opt"><span class="switch"><input type="checkbox" name="' + name + '"' + (p[name] ? ' checked' : '') + (disabled ? ' disabled checked' : '') + '><span class="track"></span></span>' +
    '<span><b>' + esc(label) + '</b><span class="xs muted">' + esc(hint) + '</span></span></label>';
  return '<form data-form="pxPolicy" novalidate><div class="card"><div class="card-head"><label class="switch" style="font-size:1rem"><input type="checkbox" name="enabled"' + (p.enabled ? ' checked' : '') + '><span class="track"></span>Proctor this exam</label>' +
    '<div class="spacer"></div><span class="xs muted">Presets:</span><button class="btn btn-sm" type="button" data-act="pxPreset" data-p="light">Practice</button><button class="btn btn-sm" type="button" data-act="pxPreset" data-p="standard">Standard</button>' +
    '<button class="btn btn-sm" type="button" data-act="pxPreset" data-p="strict">High-stakes</button></div>' +
    '<div class="card-body"><div class="grid-2"><fieldset class="fieldset"><legend>Devices</legend>' + sw('webcam', 'Webcam', 'Always required for proctoring.', true) +
    sw('microphone', 'Microphone', 'Detects talking and other voices.') + sw('screen', 'Screen recording', 'Student shares the entire screen; periodic screenshots are kept. Desktop browsers only.') + '</fieldset>' +
    '<fieldset class="fieldset"><legend>Identity & environment</legend>' + sw('identity', 'Face ID', 'Selfie at check-in matched to the enrolled face; re-checked at random during the exam.') +
    sw('liveness', 'Liveness challenge', 'Head turns and a blink, so a photo can’t be used.') + sw('idCard', 'Photo ID card', 'Student shows their ID; its photo is matched to the selfie.') +
    sw('roomScan', 'Room scan', 'Four photos: desk, left, right and behind.') + '</fieldset>' +
    '<fieldset class="fieldset"><legend>AI detectors</legend>' + sw('aiFaces', 'Face presence', 'No face, or more than one face.') + sw('aiGaze', 'Head pose & gaze', 'Looking away from the screen.') +
    sw('aiObjects', 'Objects & people', 'Phones, books, other screens, other people.') + sw('aiAudio', 'Voice activity', 'Talking or background voices (needs the microphone).') + '</fieldset>' +
    '<fieldset class="fieldset"><legend>Rules</legend><div class="form-grid">' +
    field('Sensitivity', '<select name="sensitivity">' + ['low', 'medium', 'high'].map((s) => '<option value="' + s + '"' + (p.sensitivity === s ? ' selected' : '') + '>' + s.charAt(0).toUpperCase() + s.slice(1) + '</option>').join('') + '</select>', 'High flags sooner and matches faces more strictly.') +
    field('Snapshot every (s)', '<input type="number" name="snapshotSec" min="10" max="600" value="' + (p.snapshotSec || 30) + '">', 'Webcam photo interval; flagged moments are always captured.') + '</div>' +
    field('Auto-submit after serious flags', '<input type="number" name="strikes" min="0" max="50" value="' + (p.strikes || 0) + '">', '0 = never. Serious = phone, another person, face mismatch, camera off… Students are told the limit.') +
    sw('liveChat', 'Live chat', 'Students can message the proctor; proctors can message and warn students.') + '</fieldset></div></div>' +
    '<div class="card-body" style="border-top:1px solid var(--border)"><div class="form-actions" style="margin:0"><button class="btn btn-primary" type="submit">' + icon('check') + 'Save proctoring settings</button></div></div></div></form>';
}
ACT.pxPreset = (d) => {
  const f = $('form[data-form=pxPolicy]'); const p = PRESETS[d.p]; if (!f || !p) return;
  Object.keys(p).forEach((k) => { const el = f.elements[k]; if (!el) return; if (el.type === 'checkbox') { if (!el.disabled) el.checked = !!p[k]; } else el.value = p[k]; });
  toast('Preset applied — review and save.');
};
FORMS.pxPolicy = (f, btn) => busy(btn, async () => {
  const e = f.elements, pol = {};
  ['enabled', 'microphone', 'screen', 'identity', 'liveness', 'idCard', 'roomScan', 'aiFaces', 'aiGaze', 'aiObjects', 'aiAudio', 'liveChat'].forEach((k) => { pol[k] = e[k].checked; });
  pol.sensitivity = e.sensitivity.value; pol.snapshotSec = e.snapshotSec.value; pol.strikes = e.strikes.value;
  const r = await call('proctorSavePolicy', { quizId: S.pxExam.quiz.id, policy: pol });
  toast(r.policy.enabled ? 'Proctoring is on for this exam.' : 'Proctoring is off for this exam.');
  go('/assessment/exam/' + S.pxExam.quiz.id + '?tab=' + (r.policy.enabled ? 'sessions' : 'settings'));
});

/* =====================================================================
   LIVE MONITOR
   ===================================================================== */
async function viewProctorLive(params) {
  const quiz = params.get('quiz') || '';
  const r = await call('proctorLive', { quizId: quiz });
  S.pxLive = { quiz, filter: 'all', data: r, timer: null };
  return {
    title: 'Live monitor',
    html: pageHead('Live monitor', {
      crumbs: [['Assessment', '/assessment'], ['Live monitor']], sub: '<span class="live-dot"></span> Updates every 5 seconds · sorted by risk',
      actions: '<select data-change="pxLiveQuiz" aria-label="Exam" style="width:auto;min-width:220px"><option value="">All proctored exams</option>' +
        r.exams.map((e) => '<option value="' + esc(e.id) + '"' + (e.id === quiz ? ' selected' : '') + '>' + esc(e.title) + '</option>').join('') + '</select>'
    }) + '<div id="pxLiveBody"></div>',
    after() {
      renderLive();
      S.pxLive.timer = setInterval(pollLive, 5000);
      S.onLeave = () => { clearInterval(S.pxLive && S.pxLive.timer); clearInterval(S.pxWatch && S.pxWatch.timer); S.pxLive = null; };
    }
  };
}
ACT.pxLiveQuiz = (d, el) => go('/assessment/live' + (el.value ? '?quiz=' + encodeURIComponent(el.value) : ''));
ACT.pxLiveFilter = (d) => { S.pxLive.filter = d.f; renderLive(); };
async function pollLive() {
  const L = S.pxLive; if (!L || document.hidden) return;
  try { L.data = await call('proctorLive', { quizId: L.quiz }); if (S.pxLive === L) renderLive(); } catch (e) { /* keep last view */ }
}
function attention(x) { return x.band === 'high' || (x.status === 'active' && !x.online) || x.unread > 0 || (x.recent[0] && x.recent[0].sev >= 3 && Date.now() - x.recent[0].t < 120000); }
function renderLive() {
  const L = S.pxLive, el = $('#pxLiveBody'); if (!L || !el) return;
  const all = L.data.sessions;
  const act = all.filter((x) => x.status === 'active');
  const list = L.filter === 'attention' ? all.filter(attention) : L.filter === 'checkin' ? all.filter((x) => x.status !== 'active') : L.filter === 'active' ? act : all;
  const pill = (f, label, n) => '<button class="pill' + (L.filter === f ? ' active' : '') + '" data-act="pxLiveFilter" data-f="' + f + '">' + label + ' <span class="muted">' + n + '</span></button>';
  el.innerHTML = '<div class="row-wrap" style="margin-bottom:1rem"><div class="pills">' + pill('all', 'All', all.length) + pill('active', 'In exam', act.length) +
    pill('attention', 'Needs attention', all.filter(attention).length) + pill('checkin', 'Checking in', all.length - act.length) + '</div><div class="spacer"></div>' +
    '<span class="xs muted">' + plural(act.filter((x) => x.online).length, 'student') + ' connected · ' + act.filter((x) => !x.online).length + ' disconnected' + '</span></div>' +
    (list.length ? '<div class="live-grid">' + list.map(liveTile).join('') + '</div>' : emptyState('live', 'Nobody here right now', 'Students appear as soon as they begin the check-in for a proctored exam.'));
}
function liveTile(x) {
  const st = x.stats || {};
  const ind = (ok, ico, t) => '<span class="li ' + (ok ? 'ok' : 'bad') + '" title="' + esc(t) + '">' + icon(ico, 'i-sm') + '</span>';
  const prog = st.total ? Math.round(st.answered / st.total * 100) : 0;
  return '<div class="live-tile ' + x.band + (attention(x) ? ' attn' : '') + '">' +
    '<div class="lt-media">' + (x.thumb ? '<img alt="" class="mirror" src="data:image/jpeg;base64,' + x.thumb + '">' : '<div class="lt-ph">' + avatar(x.name) + '<span class="xs">' + (x.status === 'active' ? (x.online ? 'Waiting for picture…' : 'Disconnected') : 'Checking in') + '</span></div>') +
    '<span class="lt-score">' + integrityPill(x) + '</span>' + (x.unread ? '<span class="lt-msg">' + icon('message', 'i-sm') + x.unread + '</span>' : '') +
    '<span class="lt-state ' + (x.status === 'active' ? (x.online ? 'on' : 'off') : 'ci') + '"></span></div>' +
    '<div class="lt-body"><div class="row" style="gap:.4rem"><b class="lt-name">' + esc(x.name) + '</b><span class="spacer"></span><span class="xs muted">' + esc(x.batch || '') + '</span></div>' +
    '<div class="xs muted lt-quiz">' + esc(x.quiz) + '</div>' +
    (x.status === 'active' ? '<div class="lt-ind">' + ind(st.cam !== false, 'video', 'Camera') + ind(st.faces === 1, 'user', st.faces === 1 ? 'One face' : (st.faces || 0) + ' faces') +
      ind(!st.away && !st.gaze, 'eye', st.away || st.gaze ? 'Looking away' : 'Eyes on screen') + ind(!(st.voice > 0.6), 'mic', 'Voice level') + ind(st.fs !== false, 'monitor', st.fs === false ? 'Not full screen' : 'Full screen') +
      ind(st.focus !== false, 'shield', st.focus === false ? 'Window not focused' : 'Focused') + '</div>' +
      '<div class="lt-prog"><div class="bar"><i style="width:' + prog + '%"></i></div><span class="xs muted tnum">' + (st.total ? st.answered + '/' + st.total : '') + (st.remainingMs ? ' · ' + Math.ceil(st.remainingMs / 60000) + ' min left' : '') + '</span></div>' : '') +
    (x.recent.length ? '<div class="lt-flag s' + x.recent[0].sev + '">' + icon('alert', 'i-sm') + esc(x.recent[0].label) + ' <span class="muted">' + esc(rel(x.recent[0].t)) + '</span></div>' : '<div class="lt-flag none">' + icon('checkCircle', 'i-sm') + 'No flags</div>') +
    '<div class="lt-actions"><button class="btn btn-sm" data-act="pxWatch" data-id="' + esc(x.id) + '">' + icon('eye', 'i-sm') + 'Watch</button>' +
    '<button class="btn btn-sm btn-ghost" data-act="pxMsg" data-id="' + esc(x.id) + '" data-name="' + esc(x.name) + '" title="Message">' + icon('message', 'i-sm') + '</button>' +
    '<a class="btn btn-sm btn-ghost" href="#/assessment/session/' + esc(x.id) + '" title="Full review">' + icon('file', 'i-sm') + '</a></div></div></div>';
}

/* ---------- watch one student ---------- */
ACT.pxWatch = (d) => {
  clearInterval(S.pxWatch && S.pxWatch.timer);
  S.pxWatch = { sid: d.id, timer: null, n: 0 };
  openModal(modalHead('Live view', 'Higher-frequency pictures while this window is open') + '<div class="modal-body" id="pxWatchBody"><div class="sk sk-card"></div></div>', 'wide');
  const tick = async () => {
    const W = S.pxWatch;
    if (!W || W.sid !== d.id || !$('#pxWatchBody')) { clearInterval(W && W.timer); return; }
    if (W.n++ % 5 === 0) call('proctorCommand', { sid: d.id, type: 'focus' }).catch(() => {});
    try { renderWatch(await call('proctorSession', { sid: d.id })); } catch (e) { /* retry */ }
  };
  tick();
  S.pxWatch.timer = setInterval(tick, 3000);
};
function renderWatch(r) {
  const el = $('#pxWatchBody'); if (!el) return;
  const x = r.session, lv = r.live || {}, st = lv.stats || {};
  const chat = r.events.filter((e) => e.type === 'student_message' || e.type === 'proctor_message').slice(-6);
  const flags = r.events.filter((e) => e.sev >= 1).slice(-8).reverse();
  const keep = $('#pxWatchMsg') ? $('#pxWatchMsg').value : '';
  el.innerHTML = '<div class="watch"><div><div class="watch-media">' + (lv.thumb ? '<img class="mirror" alt="Live picture" src="data:image/jpeg;base64,' + lv.thumb + '">' : '<div class="lt-ph">' + avatar(x.name, 'lg') + '<span class="small">Waiting for a picture…</span></div>') + '</div>' +
    '<div class="row-wrap" style="margin-top:.6rem"><b>' + esc(x.name) + '</b>' + sessionStatus(x) + integrityPill(x) + '<span class="spacer"></span>' +
    '<span class="xs muted">' + (lv.lastBeat ? 'updated ' + esc(rel(lv.lastBeat)) : '') + '</span></div>' +
    '<div class="ai-readout" style="margin-top:.6rem">' + [['Faces', st.faces == null ? '—' : st.faces, st.faces !== 1], ['Attention', st.away ? 'Head turned' : st.gaze ? 'Eyes away' : 'On screen', st.away || st.gaze],
      ['Voice', st.voice == null ? '—' : Math.round(st.voice * 100) + '%', st.voice > 0.6], ['Light', st.light == null ? '—' : st.light, st.light != null && st.light < 40],
      ['Full screen', st.fs ? 'Yes' : 'No', !st.fs], ['Progress', st.total ? st.answered + ' / ' + st.total : '—'], ['Identity', st.identity == null ? '—' : 'distance ' + st.identity, st.identity > 0.56],
      ['Frame rate', st.fps ? st.fps + ' fps' : '—']].map(([k, v, bad]) => '<div class="ai-row' + (bad ? ' bad' : '') + '"><span>' + k + '</span><b>' + esc(v) + '</b></div>').join('') + '</div></div>' +
    '<div class="stack"><div><h4 class="subhead">Recent flags</h4>' +
    (flags.length ? '<ul class="feed">' + flags.map((e) => '<li class="s' + e.sev + '"><b>' + esc(e.label) + '</b><span>' + esc(fmtTime(e.t)) + (e.detail ? ' · ' + esc(e.detail) : '') + '</span></li>').join('') + '</ul>' : '<p class="small muted">None yet.</p>') + '</div>' +
    '<div><h4 class="subhead">Messages</h4><div class="chat">' +
    (chat.length ? chat.map((e) => '<div class="bubble ' + (e.type === 'proctor_message' ? 'me' : '') + '">' + esc(e.detail) + '<span>' + esc(fmtTime(e.t)) + '</span></div>').join('') : '<p class="small muted">No messages.</p>') + '</div>' +
    (x.status === 'active' ? '<form data-form="pxWatchSay" class="row" style="margin-top:.5rem"><input type="text" id="pxWatchMsg" name="text" maxlength="500" placeholder="Message ' + esc(firstName(x.name)) + '…" value="' + esc(keep) + '">' +
      '<button class="btn btn-sm btn-primary" type="submit">' + icon('send', 'i-sm') + '</button></form>' : '') + '</div>' +
    (x.status === 'active' ? '<div class="row-wrap"><button class="btn btn-sm" data-act="pxWarn" data-id="' + esc(x.id) + '">' + icon('alert', 'i-sm') + 'Send warning</button>' +
      '<button class="btn btn-sm btn-danger-solid" data-act="pxTerminate" data-id="' + esc(x.id) + '" data-name="' + esc(x.name) + '">' + icon('x', 'i-sm') + 'End exam</button>' +
      '<a class="btn btn-sm btn-ghost" href="#/assessment/session/' + esc(x.id) + '">Full review ' + icon('right', 'i-sm') + '</a></div>' : '') + '</div></div>';
  const inp = $('#pxWatchMsg'); if (inp && keep) { inp.focus(); inp.setSelectionRange(keep.length, keep.length); }
}
FORMS.pxWatchSay = (f, btn) => busy(btn, async () => {
  const text = f.elements.text.value.trim(); if (!text) return;
  await call('proctorCommand', { sid: S.pxWatch.sid, type: 'message', text });
  f.elements.text.value = ''; toast('Message sent.');
});
ACT.pxMsg = (d) => {
  formModal('Message ' + d.name, 'Appears on the student’s screen straight away.', 'pxMsg',
    '<input type="hidden" name="sid" value="' + esc(d.id) + '"><textarea name="text" maxlength="500" style="min-height:100px" autofocus placeholder="e.g. Please move your phone out of reach."></textarea>' +
    '<label class="check" style="margin-top:.6rem"><input type="checkbox" name="warn"> Send as a formal warning</label>', 'Send message', 'narrow');
};
FORMS.pxMsg = (f, btn) => busy(btn, async () => {
  await call('proctorCommand', { sid: f.elements.sid.value, type: f.elements.warn.checked ? 'warn' : 'message', text: f.elements.text.value });
  closeModal(); toast('Sent.');
});
ACT.pxWarn = (d) => ACT.pxMsg({ id: d.id, name: 'student' });
ACT.pxTerminate = async (d) => {
  const W = S.pxWatch;
  if (W) clearInterval(W.timer);
  if (!await confirmBox('End ' + d.name + '’s exam now?', '<p>Their attempt is submitted immediately with the answers saved so far, and the session is marked as ended by proctoring.</p>', 'End exam', true)) return;
  busy(null, async () => { await call('proctorCommand', { sid: d.id, type: 'terminate', text: 'Ended by the proctor' }); toast('Exam ended.'); pollLive(); });
};

/* =====================================================================
   REVIEW QUEUE
   ===================================================================== */
async function viewProctorReviews(params) {
  const status = params.get('status') || 'pending';
  const r = await call('proctorReviews', { status });
  const tabs = '<nav class="tabs">' + [['pending', 'Awaiting review'], ['suspicious', 'Suspicious'], ['misconduct', 'Misconduct'], ['cleared', 'Cleared'], ['all', 'All sessions']].map(([k, l]) =>
    '<a class="tab' + (status === k ? ' active' : '') + '" href="#/assessment/reviews?status=' + k + '">' + l + '</a>').join('') + '</nav>';
  return {
    title: 'Integrity reviews',
    html: pageHead('Integrity reviews', { crumbs: [['Assessment', '/assessment'], ['Reviews']], sub: 'Proctoring flags are evidence for you to judge — nothing is penalised until you decide' }) + tabs +
      '<div class="card"><div class="card-head"><span class="i-tile sm tone-red">' + icon('gavel') + '</span><h2>' + plural(r.sessions.length, 'session') + '</h2><div class="spacer"></div>' +
      '<div class="search-box" style="width:min(240px,45vw)">' + icon('search') + '<input type="search" placeholder="Filter" data-input="filterRows" data-target="#pxSessions" aria-label="Filter"></div></div>' +
      (r.sessions.length ? sessionTable(r.sessions, true) : '<div class="card-body">' + emptyState('checkCircle', status === 'pending' ? 'All caught up' : 'Nothing here', status === 'pending' ? 'No flagged sessions are waiting for review.' : '', '', false) + '</div>') + '</div>'
  };
}

/* =====================================================================
   SESSION REVIEW
   ===================================================================== */
async function viewProctorSession(sid) {
  const r = await call('proctorSession', { sid });
  S.pxSess = r;
  const x = r.session, v = r.verify || {}, a = r.attempt;
  const start = x.startedAt || x.createdAt, end = x.endedAt || (a && a.submittedAt) || Date.now();
  const flagged = r.events.filter((e) => e.sev >= 1);
  const snaps = r.snapshots;
  const idImg = (img, label, sub, tone) => '<figure class="id-fig">' + (img ? pimg(x.id, img, 'zoomable', label) : '<div class="id-none">' + icon('image') + '</div>') + '<figcaption><b>' + esc(label) + '</b>' + (sub ? '<span class="' + (tone || '') + '">' + sub + '</span>' : '') + '</figcaption></figure>';
  const selfie = v.selfie || {};
  const identity = '<div class="card"><div class="card-head"><span class="i-tile sm tone-green">' + icon('scan') + '</span><div><h2>Identity evidence</h2><div class="xs muted">Face signatures compared on the server · lower distance = more similar</div></div>' +
    '<div class="spacer"></div>' + (r.profile ? '<button class="btn btn-sm btn-ghost" data-act="pxResetFace" data-id="' + esc(x.userId) + '">' + icon('refresh', 'i-sm') + 'Reset enrolled face</button>' : '') + '</div><div class="card-body"><div class="id-row">' +
    (r.profile ? '<figure class="id-fig">' + pimg('profile', x.userId, 'zoomable', 'Enrolled face') + '<figcaption><b>Enrolled face</b><span>' + esc(fmtDate(r.profile.at)) + ' · ' + esc(r.profile.source) + '</span></figcaption></figure>' : '') +
    (r.policy.identity ? idImg(selfie.img, 'Check-in selfie', selfie.enrolled ? 'Became the reference' : selfie.match ? 'Match · distance ' + selfie.distance : selfie.match === false ? 'No match · distance ' + selfie.distance : '—', selfie.match === false ? 'bad' : 'good') : '') +
    (r.policy.idCard ? idImg(v.idcard && v.idcard.img, 'ID card', v.idcard ? (!v.idcard.faceFound ? 'No face readable' : v.idcard.match ? 'Match · distance ' + v.idcard.distance : 'No match · distance ' + v.idcard.distance) : 'Not captured', v.idcard && v.idcard.match ? 'good' : 'bad') : '') +
    '</div>' + (r.policy.liveness ? '<p class="small" style="margin:.75rem 0 0">' + (selfie.liveness ? badge('Liveness passed', 'success', 'check') + ' head turns and blink completed' : badge('Liveness not passed', 'danger')) + '</p>' : '') +
    ((v.room || []).length ? '<h4 class="subhead" style="margin-top:var(--sp-5)">Room scan</h4><div class="id-row">' + v.room.map((rm) => '<figure class="id-fig sm">' + pimg(x.id, rm.img, 'zoomable', rm.label) + '<figcaption><b>' + esc(rm.label) + '</b></figcaption></figure>').join('') + '</div>' : '') + '</div></div>';

  const counts = {};
  flagged.forEach((e) => { counts[e.type] = counts[e.type] || { n: 0, label: e.label, sev: e.sev }; counts[e.type].n++; });
  const decision = '<div class="card"><div class="card-head"><span class="i-tile sm tone-red">' + icon('gavel') + '</span><div><h2>Your decision</h2><div class="xs muted">' + (x.review.at ? 'Last saved by ' + esc(x.review.byName) + ' ' + esc(rel(x.review.at)) : 'Not reviewed yet') + '</div></div></div>' +
    '<div class="card-body"><form data-form="pxReview" novalidate><div class="decisions">' + [['cleared', 'Cleared', 'No integrity concern', 'success'], ['suspicious', 'Suspicious', 'Needs a follow-up conversation', 'warning'], ['misconduct', 'Misconduct', 'Integrity breach confirmed', 'danger'], ['pending', 'Undecided', 'Come back later', '']].map(([k, l, d2, tone]) =>
      '<label class="decision ' + tone + '"><input type="radio" name="decision" value="' + k + '"' + (x.review.status === k ? ' checked' : '') + '><span><b>' + l + '</b><span class="xs muted">' + d2 + '</span></span></label>').join('') + '</div>' +
    field('Notes', '<textarea name="note" maxlength="2000" style="min-height:80px" placeholder="What you saw and why">' + esc(x.review.note || '') + '</textarea>') +
    '<button class="btn btn-primary btn-block" type="submit">' + icon('check') + 'Save decision</button></form>' +
    (a && a.status === 'submitted' ? '<button class="btn btn-block btn-ghost btn-danger" style="margin-top:.5rem" data-act="pxVoid" data-id="' + esc(a.id) + '">' + icon('x', 'i-sm') + 'Void this attempt</button>' : a && a.status === 'void' ? '<p class="xs muted" style="margin:.6rem 0 0">The attempt has been voided.</p>' : '') + '</div></div>';

  const env = r.env || {};
  const envCard = '<div class="card"><div class="card-head"><span class="i-tile sm tone-slate">' + icon('monitor') + '</span><h2>Device & setup</h2></div><div class="card-body"><div class="facts one">' +
    [['Browser', env.ua ? browserFrom(env.ua) : '—'], ['Platform', (env.platform || '—') + (env.mobile ? ' (mobile)' : '')], ['Screen', (env.screen || '—') + (env.displays === 'multiple' ? ' · multiple displays' : '')],
      ['Camera', (env.camera || '—') + (env.cameraRes ? ' · ' + env.cameraRes : '') + (env.phoneCamera ? ' · phone used as webcam' : '')], ['Microphone', env.mic || '—'], ['Screen share', env.screenShare || '—'],
      ['AI', env.ai || '—'], ['Graphics', env.gpu || '—']].map(([k, val]) => fact(k, esc(val))).join('') + '</div></div></div>';

  const chat = r.events.filter((e) => e.type === 'student_message' || e.type === 'proctor_message');
  const html = pageHead(x.name, {
    crumbs: [['Assessment', '/assessment'], ['Proctoring', '/assessment'], [r.quiz.title, '/assessment/exam/' + r.quiz.id], ['Session']],
    sub: esc(r.quiz.title) + ' · ' + esc(fmt(start)) + (x.endedAt && x.startedAt ? ' · ' + esc(durationText(x.endedAt - x.startedAt)) : '') + ' · ' + sessionStatus(x) + ' ' + reviewBadge(x.review.status),
    actions: (x.status === 'active' ? '<button class="btn" data-act="pxWatch" data-id="' + esc(x.id) + '">' + icon('eye') + 'Watch live</button>' : '') +
      '<a class="btn" href="#/quiz/' + esc(r.quiz.id) + '/results">' + icon('users') + 'Results</a>'
  }) +
    '<div class="split"><div class="stack">' +
    '<div class="card"><div class="score-hero">' + integrityRing(x.integrity, x.band) + '<div><div class="small muted">Integrity score</div><div class="big">' + x.integrity + '<span> / 100</span></div>' +
    '<div style="margin-top:.4rem">' + badge(BAND[x.band][0], BAND[x.band][1]) + ' ' + badge(plural(flagged.length, 'flag'), flagged.length ? 'warning' : '') + (x.high ? ' ' + badge(x.high + ' high severity', 'danger') : '') + '</div></div>' +
    '<div class="spacer"></div><div class="facts" style="min-width:min(100%,360px)">' + fact('Score', a && a.score != null ? a.score + ' / ' + a.maxScore : '—') + fact('Finished', a ? esc(FINISHED_BY[a.finishedBy] || a.status) : '—') +
    fact('Snapshots', snaps.length) + fact('Re-check-ins', x.resumes || 0) + '</div></div></div>' +
    '<div class="card card-pad ai-summary">' + icon('sparkle') + '<div><b>Automated summary</b><p>' + esc(r.summary) + '</p></div></div>' +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-violet">' + icon('activity') + '</span><div><h2>Timeline</h2><div class="xs muted">Click a marker to see the moment</div></div><div class="spacer"></div>' +
    '<div class="tl-legend"><span class="s3"></span>High<span class="s2"></span>Medium<span class="s1"></span>Low<span class="snap"></span>Snapshot</div></div>' +
    '<div class="card-body">' + timelineSvg(r.events, snaps, start, end) +
    (Object.keys(counts).length ? '<div class="row-wrap" style="margin-top:.8rem">' + Object.keys(counts).sort((m, n) => counts[n].sev - counts[m].sev || counts[n].n - counts[m].n).map((k) => '<span class="flag-chip s' + counts[k].sev + '">' + esc(counts[k].label) + ' ×' + counts[k].n + '</span>').join('') + '</div>' : '') + '</div></div>' +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-blue">' + icon('image') + '</span><div><h2>Evidence gallery</h2><div class="xs muted">' + plural(snaps.length, 'image') + '</div></div><div class="spacer"></div>' +
    '<div class="pills"><button class="pill active" data-act="pxGal" data-f="flag">Flagged</button><button class="pill" data-act="pxGal" data-f="all">All</button>' + (snaps.some((sn) => sn.kind === 'screen') ? '<button class="pill" data-act="pxGal" data-f="screen">Screen</button>' : '') + '</div></div>' +
    '<div class="card-body"><div class="gallery" id="pxGallery"></div></div></div>' +
    identity +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-amber">' + icon('list') + '</span><h2>Event log</h2><div class="spacer"></div><button class="btn btn-sm" data-act="pxEvExport">' + icon('download') + 'CSV</button></div>' +
    (r.events.length ? '<div class="table-wrap" style="max-height:460px;overflow:auto"><table class="table"><thead><tr><th>Time</th><th>Event</th><th>Severity</th><th class="num">Confidence</th><th>Detail</th><th></th></tr></thead><tbody>' +
      r.events.map((e) => '<tr id="ev-' + esc(e.id) + '"><td class="small nowrap tnum">' + esc(fmtTime(e.t)) + '<div class="xs muted">+' + esc(clock(e.t - start)) + '</div></td><td><b class="small">' + esc(e.label) + '</b></td>' +
        '<td>' + (e.sev ? badge(SEV_NAME[e.sev], SEV_TONE[e.sev]) : '<span class="xs muted">Info</span>') + '</td><td class="num small">' + (e.conf != null ? Math.round(e.conf * 100) + '%' : '') + '</td>' +
        '<td class="small muted" style="max-width:280px">' + esc(e.detail || '') + (e.by ? ' <span class="xs">— ' + esc(e.by) + '</span>' : '') + '</td>' +
        '<td>' + (e.img ? '<button class="btn btn-sm btn-ghost" data-act="pxShot" data-img="' + esc(e.img) + '">' + icon('image', 'i-sm') + '</button>' : '') + '</td></tr>').join('') + '</tbody></table></div>'
      : '<div class="card-body"><p class="small muted">No events.</p></div>') + '</div></div>' +
    '<div class="stack">' + decision +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-blue">' + icon('message') + '</span><h2>Messages</h2></div><div class="card-body"><div class="chat">' +
    (chat.length ? chat.map((e) => '<div class="bubble ' + (e.type === 'proctor_message' ? 'me' : '') + '">' + esc(e.detail) + '<span>' + esc((e.by ? e.by + ' · ' : '') + fmtTime(e.t)) + '</span></div>').join('') : '<p class="small muted">No messages.</p>') + '</div></div></div>' +
    envCard + '</div></div>';
  return { title: x.name + ' · Proctoring review', html, after(root) { renderGallery('flag'); hydrateImages(root); } };
}
function browserFrom(ua) {
  const name = /Edg\//.test(ua) ? 'Edge' : /Chrome\//.test(ua) ? 'Chrome' : /Firefox\//.test(ua) ? 'Firefox' : /Safari/.test(ua) ? 'Safari' : 'Other';
  const m = /(?:Edg|Chrome|Firefox|Version)\/(\d+)/.exec(ua);
  const os = /Windows/.test(ua) ? 'Windows' : /Mac OS/.test(ua) ? 'macOS' : /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iOS' : /Linux/.test(ua) ? 'Linux' : '';
  return name + (m ? ' ' + m[1] : '') + (os ? ' on ' + os : '');
}
function clock(ms) { const s = Math.max(0, Math.round(ms / 1000)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
function integrityRing(p, band) {
  const size = 96, r = 40, c = 2 * Math.PI * r, off = c * (1 - p / 100);
  return '<span class="ring integ ' + band + '" style="width:' + size + 'px;height:' + size + 'px"><svg width="' + size + '" height="' + size + '"><circle class="ring-track" cx="48" cy="48" r="' + r + '" fill="none" stroke-width="8"/>' +
    '<circle class="ring-val" cx="48" cy="48" r="' + r + '" fill="none" stroke-width="8" stroke-dasharray="' + c + '" stroke-dashoffset="' + off + '"/></svg><b>' + p + '</b></span>';
}
function timelineSvg(evs, snaps, start, end) {
  const span = Math.max(60000, end - start);
  const W = 1000, H = 92;
  const X = (t) => Math.max(0, Math.min(W, (t - start) / span * W));
  const ticks = [];
  const step = span > 7200000 ? 1800000 : span > 1800000 ? 600000 : span > 600000 ? 300000 : 60000;
  for (let t = 0; t <= span; t += step) ticks.push('<line x1="' + X(start + t) + '" x2="' + X(start + t) + '" y1="14" y2="70" class="tl-grid"/><text x="' + X(start + t) + '" y="88" class="tl-tick">' + clock(t) + '</text>');
  const lane = { 3: 24, 2: 38, 1: 52 };
  const marks = evs.filter((e) => e.sev >= 1).map((e) => '<g class="tl-m s' + e.sev + '" data-act="pxJump" data-id="' + esc(e.id) + '" data-img="' + esc(e.img || '') + '" tabindex="0"><title>' + esc(clock(e.t - start) + ' — ' + e.label + (e.detail ? ' (' + e.detail + ')' : '')) + '</title>' +
    '<circle cx="' + X(e.t) + '" cy="' + lane[e.sev] + '" r="6"/></g>').join('');
  const sn = snaps.filter((s) => s.type === 'snapshot').map((s) => '<rect x="' + (X(s.t) - 1) + '" y="64" width="2" height="7" class="tl-snap"/>').join('');
  const band = evs.filter((e) => e.type === 'exam_started' || e.type === 'exam_resumed' || e.type === 'exam_submitted' || e.type === 'terminated')
    .map((e) => '<line x1="' + X(e.t) + '" x2="' + X(e.t) + '" y1="10" y2="74" class="tl-mark ' + e.type + '"><title>' + esc(e.label) + '</title></line>').join('');
  return '<svg class="timeline" viewBox="-10 0 ' + (W + 20) + ' ' + H + '" preserveAspectRatio="none" role="img" aria-label="Session timeline">' +
    '<rect x="0" y="14" width="' + W + '" height="56" rx="6" class="tl-bg"/>' + ticks.join('') + band + sn + marks + '</svg>';
}
ACT.pxGal = (d, el) => { $$('.pill', el.parentNode).forEach((p) => p.classList.toggle('active', p === el)); renderGallery(d.f); };
function renderGallery(filter) {
  const r = S.pxSess, el = $('#pxGallery'); if (!r || !el) return;
  const x = r.session, start = x.startedAt || x.createdAt;
  const list = r.snapshots.filter((s) => filter === 'all' ? true : filter === 'screen' ? s.kind === 'screen' : s.type !== 'snapshot');
  el.innerHTML = list.length ? list.map((s) => '<button class="shot s' + s.sev + (s.kind === 'screen' ? ' screen' : '') + '" data-act="pxShot" data-img="' + esc(s.id) + '">' + pimg(x.id, s.id, '', s.label) +
    '<span class="shot-cap"><b>' + esc(s.label || 'Snapshot') + '</b><span>' + esc(fmtTime(s.t)) + ' · +' + esc(clock(s.t - start)) + '</span></span></button>').join('')
    : '<p class="small muted">' + (filter === 'flag' ? 'No flagged moments had a picture.' : 'No images.') + '</p>';
  hydrateImages(el);
}
ACT.pxJump = (d) => {
  if (d.img) { ACT.pxShot({ img: d.img }); return; }
  const row = document.getElementById('ev-' + d.id);
  if (row) { row.scrollIntoView({ behavior: 'smooth', block: 'center' }); row.classList.add('flash'); setTimeout(() => row.classList.remove('flash'), 1600); }
};
ACT.pxShot = (d) => {
  const r = S.pxSess; if (!r) return;
  const list = r.snapshots;
  let i = Math.max(0, list.findIndex((s) => s.id === d.img));
  const show = () => {
    const s = list[i], x = r.session;
    openModal(modalHead(s.label || 'Snapshot', esc(fmt(s.t)) + ' · +' + esc(clock(s.t - (x.startedAt || x.createdAt))) + ' · ' + (i + 1) + ' of ' + list.length) +
      '<div class="modal-body"><div class="lightbox">' + pimg(x.id, s.id, s.kind === 'screen' ? '' : '', s.label) + '</div>' +
      '<div class="form-actions"><button class="btn" data-act="pxShotNav" data-d="-1"' + (i === 0 ? ' disabled' : '') + '>' + icon('arrowLeft') + 'Previous</button>' +
      '<button class="btn" data-act="pxShotNav" data-d="1"' + (i === list.length - 1 ? ' disabled' : '') + '>Next' + icon('right') + '</button></div></div>', 'wide');
    hydrateImages($('#modal-root'));
  };
  ACT.pxShotNav = (dd) => { i = Math.max(0, Math.min(list.length - 1, i + Number(dd.d))); show(); };
  show();
};
FORMS.pxReview = (f, btn) => busy(btn, async () => {
  const dec = f.querySelector('input[name=decision]:checked');
  if (!dec) { toast('Choose a decision.', 'err'); return; }
  await call('proctorReview', { sid: S.pxSess.session.id, decision: dec.value, note: f.elements.note.value });
  toast('Decision saved.'); refresh();
});
ACT.pxVoid = async (d) => {
  if (!await confirmBox('Void this attempt?', '<p>It will not count toward the student’s grade, and they can re-attempt if attempts remain.</p>', 'Void attempt', true)) return;
  busy(null, async () => { await call('voidAttempt', { attemptId: d.id }); toast('Attempt voided.'); refresh(); });
};
ACT.pxResetFace = async (d) => {
  if (!await confirmBox('Reset the enrolled face?', '<p>The student’s next check-in selfie becomes their new reference face. Use this when the old photo is poor or out of date.</p>', 'Reset face')) return;
  busy(null, async () => { await call('resetFace', { userId: d.id }); toast('Enrolled face removed.'); refresh(); });
};
ACT.pxEvExport = () => {
  const r = S.pxSess;
  downloadText('proctoring-' + r.session.username + '-' + r.session.id + '.csv', csv([['Time', 'Event', 'Severity', 'Confidence', 'Detail', 'By']]
    .concat(r.events.map((e) => [fmt(e.t), e.label, SEV_NAME[e.sev] || '', e.conf != null ? e.conf : '', e.detail || '', e.by || '']))));
};
