'use strict';
/* =====================================================================
   USERS (admins: everyone; teachers: student accounts)
   ===================================================================== */
const TEMPLATE_COLS = ['Sl.No.', 'Register No', 'Student Name', 'Program & Section', 'Student Mobile No.', 'Institution Mail Id'];
const USER_TABS = [['', 'All'], ['student', 'Students'], ['teacher', 'Faculty'], ['parent', 'Parents'], ['admin', 'Administrators']];
async function viewAdminUsers(params) {
  const batch = params.get('batch') || '';
  const admin = S.me.role === 'admin';
  const role = USER_TABS.some((t) => t[0] === params.get('role')) && (admin || /^(student|parent)$/.test(params.get('role'))) ? params.get('role') : '';
  const all = await call('listUsers', { batch });
  const list = role ? all.filter((u) => u.role === role) : all;
  S.users = all;
  const roleTone = { admin: 'danger', teacher: 'primary', student: '', parent: 'info' };
  const roleName = { admin: 'admin', teacher: 'faculty', student: 'student', parent: 'parent' };
  const counts = { student: 0, parent: 0, teacher: 0, admin: 0 };
  all.forEach((u) => { counts[u.role] = (counts[u.role] || 0) + 1; });
  const qs = (r) => { const q = []; if (r) q.push('role=' + r); if (batch) q.push('batch=' + encodeURIComponent(batch)); return '#/admin/users' + (q.length ? '?' + q.join('&') : ''); };
  const tabs = '<div class="pills" role="tablist">' + USER_TABS.filter((t) => admin || t[0] === '' || t[0] === 'student' || t[0] === 'parent')
    .map((t) => '<a class="pill' + (t[0] === role ? ' active' : '') + '" role="tab" href="' + qs(t[0]) + '">' + esc(t[1]) + ' <span class="pill-n">' + (t[0] ? counts[t[0]] : all.length) + '</span></a>').join('') + '</div>';
  const rows = list.map((u) => '<tr data-text="' + esc((u.name + ' ' + u.username + ' ' + u.batch + ' ' + u.email + ' ' + u.phone + ' ' + u.role + ' ' + u.links.join(' ')).toLowerCase()) + '">' +
    '<td><div class="cell-user">' + avatar(u.name) + '<div><b>' + esc(u.name) + '</b><span>' + (u.signIn !== u.username ? 'Signs in with ' + esc(u.signIn) : '@' + esc(u.username)) + '</span></div></div></td>' +
    '<td>' + badge(roleName[u.role] || u.role, roleTone[u.role]) + '</td><td class="small nowrap">' + esc(u.batch || '—') + '</td>' +
    '<td class="small">' + (u.email ? esc(u.email) : '<span class="muted">no email</span>') + '<div class="xs muted">' + (u.phone ? icon('message', 'i-sm') + ' ' + esc(u.phone) : 'no mobile') + '</div></td>' +
    '<td class="small">' + (u.links.length ? '<span class="xs muted">' + (u.role === 'parent' ? 'Parent of' : 'Parents') + '</span><br>' + esc(u.links.join(', ')) : '<span class="muted">—</span>') + '</td>' +
    '<td>' + (u.status === 'active' ? badge('Active', 'success') : badge('Disabled')) + (u.locked ? ' ' + badge('Locked', 'danger', 'lock') : '') + (u.mustChange ? ' ' + badge('First login pending', 'warning') : '') + '</td>' +
    '<td class="small muted">' + (u.lastLogin ? esc(rel(u.lastLogin)) : 'Never') + '</td>' +
    '<td class="actions"><button class="btn-icon sm" title="Edit" data-act="editUser" data-id="' + esc(u.id) + '">' + icon('edit') + '</button>' +
    (admin && u.id !== S.me.id ? '<button class="btn-icon sm" title="Reset password" data-act="resetPw" data-id="' + esc(u.id) + '">' + icon('key') + '</button>' : '') + '</td></tr>').join('');
  // One way in per kind of account. The button for the tab you're on is the primary one.
  const primary = role === 'teacher' || role === 'admin' ? 'addFaculty' : role === 'parent' && admin ? 'addParents' : 'addStudents';
  const addBtn = (act, ico, label) => '<button class="btn' + (act === primary ? ' btn-primary' : '') + '" data-act="' + act + '">' + icon(ico) + label + '</button>';
  const batchCol = role === 'teacher' || role === 'admin' ? 'Department' : role === 'student' ? 'Class' : 'Batch';
  const empty = { student: ['cap', 'No students yet', 'Use Add students to upload your class list or add one student at a time.'],
    teacher: ['id', 'No faculty yet', 'Use Add faculty to create accounts for teaching staff.'],
    parent: ['users', 'No parents yet', admin ? 'Use Add parents to link parents to their children.' : 'Add a parent together with a new student under Add students.'],
    admin: ['shield', 'No administrators', 'Use Add faculty and choose Administrator.'] }[role] || ['users', 'No accounts found', 'Upload your class list (.xlsx) or add people with the buttons above.'];
  return {
    title: admin ? 'Users' : 'Students & parents',
    html: pageHead(admin ? 'Users' : 'Students & parents', {
      crumbs: [[admin ? 'Site administration' : 'Teaching'], [admin ? 'Users' : 'Students & parents']],
      sub: plural(counts.student, 'student') + ' · ' + plural(counts.parent, 'parent') + (admin ? ' · ' + counts.teacher + ' faculty · ' + plural(counts.admin, 'admin') : ''),
      actions: (admin ? '<button class="btn btn-ghost" data-act="firstLogin">' + icon('key') + 'First-login passwords</button>' : '') +
        addBtn('addStudents', 'cap', 'Add students') + (admin ? addBtn('addFaculty', 'id', 'Add faculty') + addBtn('addParents', 'users', 'Add parents') : '')
    }) +
      '<div class="users-tabs">' + tabs + '</div>' +
      '<div class="card"><div class="card-head"><div class="search-box" style="flex:1;max-width:340px">' + icon('search') + '<input type="search" placeholder="Search name, username, email, phone…" data-input="filterRows" data-target="#userTable" aria-label="Search users"></div>' +
      '<div class="spacer"></div><form data-form="filterUsers" class="row"><input type="hidden" name="r" value="' + esc(role) + '"><input type="text" name="b" placeholder="' + esc(batchCol) + '" value="' + esc(batch) + '" style="width:170px" aria-label="Filter by ' + esc(batchCol.toLowerCase()) + '">' +
      '<button class="btn" type="submit">' + icon('filter', 'i-sm') + 'Filter</button>' + (batch ? '<a class="btn btn-ghost" href="' + qs(role).replace(/[?&]batch=[^&]*/, '') + '">Clear</a>' : '') + '</form></div>' +
      (list.length ? '<div class="table-wrap"><table class="table" id="userTable"><thead><tr><th>Name</th><th>Role</th><th>' + esc(batchCol) + '</th><th>Contact</th><th>Linked</th><th>Status</th><th>Last sign-in</th><th></th></tr></thead><tbody>' + rows + '</tbody></table></div>'
        : '<div class="card-body">' + emptyState(empty[0], empty[1], empty[2], '', false) + '</div>') + '</div>'
  };
}
FORMS.filterUsers = (f) => {
  const q = [];
  if (f.elements.r.value) q.push('role=' + encodeURIComponent(f.elements.r.value));
  if (f.elements.b.value.trim()) q.push('batch=' + encodeURIComponent(f.elements.b.value.trim()));
  go('/admin/users' + (q.length ? '?' + q.join('&') : ''));
};

/* =====================================================================
   ADD USERS — a separate path for students, faculty and parents.
   Each path has "one person" (a form) and "paste a list" (spreadsheet columns);
   students also have "upload the class list" (.xlsx/.csv).
   ===================================================================== */
const ADD_KIND = {
  student: {
    act: 'addStudents', title: 'Add students', ico: 'cap',
    sub: 'Students sign in with their college ID; their mobile number is the first password.',
    cols: 'college ID, full name, class, email, mobile, parent name, parent mobile',
    example: '22bcs101, Anitha R, III BCom CS A, anitha@example.com, 9876543210, Raman K, 9845012345\n22bcs102, Bharath K, III BCom CS A, , 9876500001',
    help: 'Only <b>college ID</b> and <b>full name</b> are required. Give a <b>mobile number</b> — it is the student’s first password. ' +
      'The last two columns are optional: fill them in and a <b>parent account</b> is made and linked to the student (brothers and sisters with the same parent mobile share one parent account).'
  },
  teacher: {
    act: 'addFaculty', title: 'Add faculty', ico: 'id',
    sub: 'Faculty sign in with their staff ID; their mobile number is the first password.',
    cols: 'staff ID, full name, department, email, mobile',
    example: 'st1024, Dr. Priya S, Commerce, priya@college.edu, 9876501234\nst1031, Arun Kumar, Corporate Secretaryship, arun@college.edu, 9876501235',
    help: 'Only <b>staff ID</b> and <b>full name</b> are required. Give a <b>mobile number</b> — it is their first password (without one they get a temporary password). ' +
      'The department shows in the Users list. To give them courses, add them as a teacher from the course’s Participants page.'
  },
  parent: {
    act: 'addParents', title: 'Add parents', ico: 'users',
    sub: 'Parents sign in with their mobile number; their child’s college ID is the first password.',
    cols: 'mobile, full name, children’s college IDs, email',
    example: '9845012345, Raman K, 22bcs101; 23bcs044, raman@example.com\n9845000022, Lakshmi P, 22bcs102',
    help: 'All three of <b>mobile</b>, <b>full name</b> and <b>children</b> are required. List every child’s college ID, separated by semicolons — the children must already have student accounts. ' +
      'The <b>first</b> child’s college ID is the parent’s first password. One mobile number can belong to only one parent account.'
  }
};
function addTabs(kind, tab) {
  const k = ADD_KIND[kind];
  const t = [['one', 'edit', kind === 'teacher' ? 'One person' : kind === 'parent' ? 'One parent' : 'One student'], ['paste', 'list', 'Paste a list']];
  if (kind === 'student') t.unshift(['upload', 'upload', 'Upload class list']);
  return '<div class="pills" role="tablist" style="margin-bottom:1.1rem">' + t.map((x) =>
    '<button type="button" class="pill' + (tab === x[0] ? ' active' : '') + '" data-act="' + k.act + '" data-tab="' + x[0] + '" role="tab">' + icon(x[1], 'i-sm') + ' ' + x[2] + '</button>').join('') + '</div>';
}
function addForm(kind, tab) {
  const k = ADD_KIND[kind];
  const tabs = addTabs(kind, tab);
  const hidden = '<input type="hidden" name="kind" value="' + kind + '"><input type="hidden" name="mode" value="' + tab + '">';
  const inp = (name, type, extra) => '<input type="' + (type || 'text') + '" name="' + name + '"' + (extra || '') + '>';
  const staffType = kind === 'teacher' ? field('Account type', '<select name="admin"><option value="">Faculty (teacher)</option><option value="1">Administrator — full access to Site administration</option></select>') : '';
  if (tab === 'paste') {
    formModal(k.title, k.sub, 'addPeople', tabs + hidden +
      '<p class="small muted">One person per line, pasted from a spreadsheet or typed with commas. Columns: <b>' + esc(k.cols) + '</b>. A header row is skipped.</p>' +
      '<p class="small muted">' + k.help + '</p>' +
      '<div class="prose" style="margin:0 0 1rem"><pre><code>' + esc(k.example) + '</code></pre></div>' + staffType +
      field('People to add', '<textarea class="mono" name="text" style="min-height:170px" autofocus></textarea>') + '<div id="userErr"></div>', 'Create accounts', 'wide');
    return;
  }
  let body;
  if (kind === 'student') {
    body = '<div class="form-grid">' + field('College ID', inp('id', 'text', ' maxlength="64" placeholder="22bcs101" required autofocus'), 'They sign in with this.') +
      field('Full name', inp('name', 'text', ' maxlength="100" required')) + '</div>' +
      '<div class="form-grid">' + field('Class', inp('batch', 'text', ' maxlength="100" placeholder="III BCom CS A"')) +
      field('Mobile number', inp('phone', 'tel', ' maxlength="20" placeholder="98765 43210"'), 'Their first password.') + '</div>' +
      field('Email', inp('email', 'email', ' maxlength="200"')) +
      '<fieldset class="fieldset"><legend>Parent (optional)</legend><div class="form-grid">' +
      field('Parent’s name', inp('pname', 'text', ' maxlength="100"')) +
      field('Parent’s mobile', inp('pphone', 'tel', ' maxlength="20" placeholder="98450 12345"'), 'The parent signs in with this.') + '</div>' +
      '<p class="xs muted" style="margin:.1rem 0 .6rem">If this mobile already belongs to a parent, ' + (S.me.role === 'admin' ? 'the student is linked to that parent.' : 'ask an administrator to link them.') + '</p></fieldset>';
  } else if (kind === 'teacher') {
    body = '<div class="form-grid">' + field('Staff ID', inp('id', 'text', ' maxlength="64" placeholder="st1024" required autofocus'), 'They sign in with this.') +
      field('Full name', inp('name', 'text', ' maxlength="100" required')) + '</div>' +
      '<div class="form-grid">' + field('Department', inp('batch', 'text', ' maxlength="100" placeholder="Commerce"')) +
      field('Mobile number', inp('phone', 'tel', ' maxlength="20" placeholder="98765 43210"'), 'Their first password.') + '</div>' +
      field('Email', inp('email', 'email', ' maxlength="200"'), 'Needed for the sign-in code staff get by email, when that is switched on.') + staffType;
  } else {
    body = '<div class="form-grid">' + field('Mobile number', inp('phone', 'tel', ' maxlength="20" placeholder="98450 12345" required autofocus'), 'They sign in with this.') +
      field('Full name', inp('name', 'text', ' maxlength="100" required')) + '</div>' +
      field('Children’s college IDs', inp('kids', 'text', ' maxlength="300" placeholder="22bcs101; 23bcs044" required'), 'Separate with semicolons. The first child’s ID is the parent’s first password.') +
      field('Email', inp('email', 'email', ' maxlength="200"'));
  }
  formModal(k.title, k.sub, 'addPeople', tabs + hidden + body + '<div id="userErr"></div>', 'Create account', 'wide');
}
ACT.addStudents = (d) => {
  const tab = (d && d.tab) || 'upload';
  S.userImport = null;
  if (tab !== 'upload') { addForm('student', tab); return; }
  openModal(modalHead('Add students', 'Upload the class list and every student gets an account automatically.') + '<div class="modal-body" id="importBody">' + addTabs('student', 'upload') +
    '<label class="dropzone" style="padding:1.75rem 1.25rem">' + icon('upload') + '<b>Choose the student list (.xlsx or .csv)</b><span class="small">or drop it here — the Faculty Subject Wise Students export works as it is</span>' +
    '<input type="file" accept=".xlsx,.csv" data-change="importFile"></label>' +
    '<div class="small muted" style="margin:1.1rem 0 .5rem"><b style="color:var(--text)">Expected layout</b> — a title row is fine; the header row is found automatically and columns can be in any order.</div>' +
    '<div class="card" style="margin:0"><div class="table-wrap"><table class="table"><thead><tr>' + TEMPLATE_COLS.map((c) => '<th class="nowrap">' + esc(c) + '</th>').join('') + '</tr></thead>' +
    '<tbody><tr><td>1</td><td class="nowrap">24-UBC-202</td><td class="nowrap">ADHIRAJ M</td><td class="small">24UBC - B.Com. Corporate Secretaryship 5th Semester-Shift II C</td><td>7418883421</td><td class="small">24ubc202@loyolacollege.edu</td></tr></tbody></table></div></div>' +
    '<ul class="small muted" style="margin:.8rem 0 0;padding-left:1.1rem;line-height:1.7">' +
    '<li><b>Register No</b> becomes the username (in lower case, e.g. <code>24-ubc-202</code>) and <b>Program &amp; Section</b> becomes the batch.</li>' +
    '<li>Only <b>Register No</b> and <b>Student Name</b> are required. Mobile and mail ID are used for alerts.</li>' +
    '<li>You will see a preview before anything is saved. Students who already have an account are not duplicated.</li></ul>' +
    '<div class="form-actions"><button class="btn" type="button" data-act="importTemplate">' + icon('download') + 'Download blank template</button>' +
    '<button class="btn" type="button" data-act="close">Cancel</button></div></div>', 'wide');
};
ACT.addUsers = ACT.addStudents; // older links and the "Choose another file" button
ACT.addFaculty = (d) => addForm('teacher', (d && d.tab) || 'one');
ACT.addParents = (d) => addForm('parent', (d && d.tab) || 'one');
FORMS.addPeople = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  const kind = el.kind.value, mode = el.mode.value;
  const v = (n) => (el[n] ? el[n].value : '').replace(/[\t\r\n]+/g, ' ').trim();
  let text = '';
  if (mode === 'paste') text = el.text.value;
  else {
    const need = kind === 'parent' ? [['phone', 'the mobile number'], ['name', 'the full name'], ['kids', 'at least one child’s college ID']] : [['id', kind === 'teacher' ? 'the staff ID' : 'the college ID'], ['name', 'the full name']];
    const miss = need.filter((x) => !v(x[0]));
    if (miss.length) { $('#userErr').innerHTML = '<div style="margin-top:1rem">' + notice('Enter ' + miss.map((x) => x[1]).join(' and ') + '.', 'err') + '</div>'; return; }
    const cols = kind === 'student' ? [v('id'), v('name'), v('batch'), v('email'), v('phone'), v('pname'), v('pphone')]
      : kind === 'teacher' ? [v('id'), v('name'), v('batch'), v('email'), v('phone')]
        : [v('phone'), v('name'), v('kids'), v('email')];
    text = cols.join('\t');
  }
  const r = await call('addUsers', { path: kind, text, admin: !!(el.admin && el.admin.value) });
  if (r.errors.length) {
    const errs = mode === 'paste' ? r.errors : r.errors.map((e) => e.replace(/^Line 1: /, ''));
    $('#userErr').innerHTML = '<div style="margin-top:1rem">' + notice('<b>' + (mode === 'paste' ? 'No accounts were created. Fix these lines:' : 'The account was not created:') + '</b><br>' + errs.map(esc).join('<br>'), 'err') + '</div>';
    return;
  }
  const noun = kind === 'teacher' ? (el.admin && el.admin.value ? 'administrator' : 'faculty account') : kind;
  showPasswords(plural(r.created.length, r.created.length === 1 ? noun : 'account') + ' created' + (r.linked ? ' · ' + plural(r.linked, 'parent link') + ' added' : ''), r.created);
  refresh();
});
ACT.importTemplate = () => downloadText('student-list-template.csv', csv([['Faculty Subject Wise Students'], TEMPLATE_COLS, ['1', '24-UBC-202', 'ADHIRAJ M', '24UBC - B.Com. Corporate Secretaryship 5th Semester-Shift II C', '7418883421', '24ubc202@loyolacollege.edu']]));
ACT.importFile = (d, el) => {
  const file = el.files && el.files[0];
  if (!file) return;
  if (!/\.(xlsx|csv)$/i.test(file.name)) { toast(/\.xls$/i.test(file.name) ? 'Old .xls files are not supported — open it in Excel and Save As "Excel Workbook (.xlsx)".' : 'Choose an .xlsx or .csv file.', 'err'); return; }
  if (file.size > 10 * 1024 * 1024) { toast('The file must be 10 MB or smaller.', 'err'); return; }
  const zone = el.closest('.dropzone');
  if (zone) zone.innerHTML = icon('refresh') + '<b>Reading ' + esc(file.name) + '…</b>';
  busy(null, async () => {
    const data = await readFileB64(file);
    const r = await call('previewUserFile', { name: file.name, data });
    S.userImport = { name: file.name, data, preview: r };
    renderImportPreview();
  }).then(() => { if (!S.userImport) ACT.addUsers({ tab: 'upload' }); });
};
function renderImportPreview() {
  const { preview: r, name } = S.userImport;
  const c = r.counts;
  const tone = { new: 'success', exists: 'info', duplicate: 'warning', error: 'danger' };
  const label = { new: 'New', exists: 'Already has account', duplicate: 'Duplicate', error: 'Skipped' };
  const cols = r.found.map((f) => f.columns.map((x) => '<span class="badge">' + esc(x.header) + ' ' + icon('right', 'i-sm') + ' ' + esc(x.label) + '</span>').join(' ')).join('<br>');
  const rows = r.rows.map((x) => '<tr' + (x.status === 'error' || x.status === 'duplicate' ? ' style="opacity:.75"' : '') + '><td class="xs muted nowrap">' + esc(x.line) + '</td>' +
    '<td class="nowrap"><b>' + esc(x.name || '—') + '</b><div class="xs muted">@' + esc(x.username || '—') + '</div></td>' +
    '<td class="small" style="min-width:240px">' + esc(x.batch || '—') + '</td>' +
    '<td class="small">' + (x.email ? esc(x.email) : '<span class="muted">no email</span>') + '<div class="xs muted">' + (x.phone ? esc(x.phone) : 'no mobile') + '</div></td>' +
    '<td>' + badge(label[x.status], tone[x.status]) + (x.error ? '<div class="xs" style="color:var(--danger);margin-top:.25rem">' + esc(x.error) + '</div>' : '') +
    (x.warning ? '<div class="xs" style="color:var(--warning);margin-top:.25rem">' + esc(x.warning) + '</div>' : '') + '</td></tr>').join('');
  const importable = c.new + c.exists;
  const courseSel = r.courses.length ? field('Enrol them in a course (optional)', '<select name="courseId"><option value="">Don’t enrol now</option>' +
    r.courses.map((x) => '<option value="' + esc(x.id) + '">' + esc(x.fullname) + ' (' + esc(x.shortname) + ')</option>').join('') + '</select>', 'New and existing students from this file are enrolled.') : '';
  $('#importBody').innerHTML =
    '<div class="row" style="gap:.6rem;margin-bottom:1rem;flex-wrap:wrap">' + icon('file') + '<b>' + esc(name) + '</b><span class="spacer"></span>' +
    '<button class="btn btn-ghost" type="button" data-act="addUsers" data-tab="upload">' + icon('refresh', 'i-sm') + 'Choose another file</button></div>' +
    '<div class="grid-4" style="margin-bottom:1rem">' + statCard('userPlus', 'green', c.new, 'New accounts') + statCard('users', 'blue', c.exists, 'Already registered') +
    statCard('copy', 'amber', c.duplicate, 'Duplicates in file') + statCard('alert', 'red', c.error, 'Rows with problems') + '</div>' +
    '<div class="small muted" style="margin-bottom:.4rem">Columns detected' + (r.found.length === 1 ? ' on “' + esc(r.found[0].sheet) + '”, header on row ' + r.found[0].headerRow : '') + ':</div>' +
    '<div style="margin-bottom:1rem;line-height:2">' + cols + '</div>' +
    '<div class="card" style="margin:0 0 1rem"><div class="table-wrap" style="max-height:340px;overflow:auto"><table class="table"><thead><tr><th>Row</th><th>Student</th><th>Batch</th><th>Contact</th><th>Status</th></tr></thead><tbody>' + rows + '</tbody></table></div></div>' +
    (importable ? '<form data-form="importUsers" novalidate>' + courseSel +
      (c.exists ? check('updateExisting', 'Update name, batch, mobile and email of students who already have an account', false) : '') +
      (r.emailReady ? check('sendEmail', 'Email each new student their username and temporary password', false) : '') +
      (r.smsReady ? check('sendSms', 'Text (SMS) each new student their username and temporary password', false) : '') +
      (!r.emailReady && !r.smsReady ? '<p class="xs muted">To send sign-in details automatically, set up email or SMS under Site administration → Settings. You can always download the passwords after importing.</p>' : '') +
      '<div class="form-actions"><button class="btn" type="button" data-act="close">Cancel</button><button class="btn btn-primary" type="submit">' + icon('userPlus') +
      (c.new ? 'Create ' + plural(c.new, 'account') : 'Apply to ' + plural(c.exists, 'existing student')) + '</button></div></form>'
      : notice('There is nothing to import from this file. Fix the rows marked “Skipped” and upload it again.', 'warn') +
        '<div class="form-actions"><button class="btn" type="button" data-act="close">Close</button></div>');
}
FORMS.importUsers = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  const r = await call('importUserFile', {
    name: S.userImport.name, data: S.userImport.data,
    courseId: el.courseId ? el.courseId.value : '',
    updateExisting: !!(el.updateExisting && el.updateExisting.checked),
    sendEmail: !!(el.sendEmail && el.sendEmail.checked), sendSms: !!(el.sendSms && el.sendSms.checked)
  });
  S.userImport = null;
  const parts = [];
  if (r.existing) parts.push(plural(r.existing, 'student') + ' already had accounts' + (r.updated ? ' (' + r.updated + ' updated)' : ''));
  if (r.enrolled) parts.push(plural(r.enrolled, 'student') + ' enrolled in ' + r.course);
  if (r.sent) parts.push(plural(r.sent, 'sign-in message') + ' queued');
  if (r.skipped) parts.push(plural(r.skipped, 'row') + ' skipped');
  if (r.created.length) showPasswords(plural(r.created.length, 'account') + ' created', r.created, parts.join(' · '));
  else { closeModal(); toast(parts.join(' · ') || 'Nothing changed.'); }
  refresh();
});
const PW_RULE = { mobile: 'mobile number', child: 'child’s college ID', temp: 'temporary' };
function showPasswords(title, list, summary) {
  S.pwList = list;
  const temps = list.filter((u) => u.rule === 'temp' || !u.rule).length;
  openModal(modalHead(title, temps ? 'Copy the temporary passwords now — they are not shown again.' : 'Sign-in details for each account.') + '<div class="modal-body">' +
    (summary ? notice(esc(summary), 'ok') : '') +
    notice('Students and teachers sign in with their college ID and their mobile number; parents with their mobile number and their child’s college ID. Everyone chooses a new password the first time.' +
      (temps ? ' <b>' + plural(temps, 'account') + '</b> had no mobile number (or no linked child) and got a temporary password instead.' : ''), 'warn', 'key') +
    '<div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>Name</th><th>Sign-in ID</th><th>First password</th></tr></thead><tbody>' +
    list.map((u) => '<tr><td>' + esc(u.name) + '<div class="xs muted">' + esc(u.role || '') + '</div></td><td><code>' + esc(u.signIn || u.username) + '</code></td><td><code style="font-size:.9rem">' + esc(u.password) + '</code>' +
      '<div class="xs muted">' + esc(PW_RULE[u.rule] || 'temporary') + '</div></td></tr>').join('') + '</tbody></table></div></div>' +
    '<div class="form-actions"><button class="btn" data-act="copyPw">' + icon('copy') + 'Copy as CSV</button><button class="btn" data-act="downloadPw">' + icon('download') + 'Download CSV</button>' +
    '<button class="btn btn-primary" data-act="close">Done</button></div></div>', 'wide');
}
function pwCsv() { return csv([['Name', 'Role', 'Batch', 'Sign-in ID', 'First password', 'Password is']].concat(S.pwList.map((u) => [u.name, u.role || '', u.batch || '', u.signIn || u.username, u.password, PW_RULE[u.rule] || 'temporary']))); }
ACT.copyPw = () => {
  const text = pwCsv();
  (navigator.clipboard ? navigator.clipboard.writeText(text) : Promise.reject(new Error('no clipboard')))
    .then(() => toast('Copied to the clipboard.')).catch(() => toast('Your browser blocked copying. Use Download instead.', 'err'));
};
ACT.downloadPw = () => downloadText('sign-in-details.csv', pwCsv());
ACT.firstLogin = () => busy(null, async () => {
  const r = await call('firstLoginPasswords', {});
  const roles = Object.keys(r.readyByRole).map((k) => plural(r.readyByRole[k], k)).join(', ');
  openModal(modalHead('First-login passwords', 'For accounts that have not signed in yet.') + '<div class="modal-body">' +
    '<p>Students and teachers sign in the first time with their <b>college ID</b> and their <b>mobile number</b> as the password. Parents use their <b>mobile number</b> and their <b>child’s college ID</b>. Everyone then chooses their own password.</p>' +
    (r.ready ? notice('<b>' + plural(r.ready, 'account') + '</b> (' + esc(roles) + ') can be switched to this. Any temporary passwords handed out to these people earlier will stop working.', 'warn', 'key')
      : notice('Every account that has not signed in yet already follows the rule, or is missing details.', 'ok')) +
    (r.missingCount ? '<details style="margin-top:.75rem"><summary class="small">' + plural(r.missingCount, 'account') + ' can’t use the rule — missing details</summary><ul class="small" style="margin:.5rem 0 0;padding-left:1.1rem">' +
      r.missing.map((x) => '<li>' + esc(x.name) + ' <span class="muted">(@' + esc(x.username) + ', ' + esc(x.role) + ': ' + esc(x.why) + ')</span></li>').join('') + (r.missingCount > r.missing.length ? '<li class="muted">…and ' + (r.missingCount - r.missing.length) + ' more</li>' : '') + '</ul></details>' : '') +
    '<div class="form-actions"><button class="btn" data-act="close">Cancel</button>' + (r.ready ? '<button class="btn btn-primary" data-act="firstLoginApply">Apply to ' + plural(r.ready, 'account') + '</button>' : '') + '</div></div>');
});
ACT.firstLoginApply = (d, btn) => busy(btn, async () => {
  const r = await call('firstLoginPasswords', { apply: true });
  closeModal(); toast(plural(r.ready, 'account') + ' now use the first-login rule.'); refresh();
});
ACT.resetPw = async (d) => {
  const u = S.users.find((x) => x.id === d.id);
  if (!await confirmBox('Reset password for ' + u.name + '?', '<p>They will be signed out and their password goes back to the first-login password: ' + (u.role === 'parent' ? 'their child’s college ID' : u.role === 'admin' ? 'a new temporary password' : 'their mobile number') + ' (a temporary one if that is missing). They choose a new one when they sign in. This also unlocks the account.</p>', 'Reset password')) return;
  busy(null, async () => { const r = await call('resetPassword', { id: d.id }); showPasswords('Password reset', [r]); refresh(); });
};
ACT.editUser = (d) => {
  const u = S.users.find((x) => x.id === d.id);
  const admin = S.me.role === 'admin';
  const linkable = admin && (u.role === 'parent' || u.role === 'student');
  formModal('Edit account', '@' + esc(u.username) + ' · ' + esc(u.role), 'editUser',
    '<input type="hidden" name="id" value="' + esc(u.id) + '">' +
    field('Full name', '<input type="text" name="name" maxlength="100" value="' + esc(u.name) + '" autofocus>') +
    '<div class="form-grid">' + field('Email', '<input type="email" name="email" maxlength="200" value="' + esc(u.email) + '">') +
    field('Mobile number', '<input type="tel" name="phone" maxlength="20" value="' + esc(u.phone) + '" placeholder="+91 98765 43210"' + (admin ? '' : ' readonly') + '>', admin ? 'Used to sign in (parents), for first passwords and for SMS alerts.' : 'Only an administrator can change a mobile number — it is used to sign in.') + '</div>' +
    field('Batch', '<input type="text" name="batch" maxlength="100" value="' + esc(u.batch) + '">') +
    (admin ? '<div class="form-grid">' + field('Role', '<select name="role">' + ['student', 'parent', 'teacher', 'admin'].map((r) => '<option' + (u.role === r ? ' selected' : '') + '>' + r + '</option>').join('') + '</select>', 'Changing the role removes parent links and, for parents, course enrolments.') +
      field('Status', '<select name="status"><option value="active"' + (u.status === 'active' ? ' selected' : '') + '>Active</option><option value="disabled"' + (u.status !== 'active' ? ' selected' : '') + '>Disabled</option></select>') + '</div>' : '') +
    (linkable ? '<fieldset class="fieldset"><legend>' + (u.role === 'parent' ? 'Children (student accounts)' : 'Parents') + '</legend><div id="guardianBox"><p class="small muted">Loading…</p></div>' +
      (u.role === 'parent' ? '<div class="row" style="margin:.5rem 0 .75rem"><input type="text" id="linkChild" placeholder="Student username, e.g. 22bcs101" style="flex:1" aria-label="Student username">' +
        '<button class="btn btn-soft" type="button" data-act="linkChild" data-id="' + esc(u.id) + '">' + icon('link', 'i-sm') + 'Link</button></div>'
        : '<p class="xs muted" style="margin:.2rem 0 .75rem">Link a parent from the parent’s own account.</p>') + '</fieldset>' : ''),
    'Save account', 'wide');
  if (linkable) loadGuardians(u);
};
async function loadGuardians(u) {
  const box = $('#guardianBox');
  if (!box) return;
  try {
    const r = await call('guardianLinks', { userId: u.id });
    if (!$('#guardianBox')) return;
    box.innerHTML = r.people.length ? r.people.map((x) => '<div class="row" style="padding:.35rem 0">' + avatar(x.name, 'sm') + '<div style="flex:1;min-width:0"><b class="small">' + esc(x.name) + '</b> <span class="xs muted">@' + esc(x.username) + (x.batch ? ' · ' + esc(x.batch) : '') + (x.phone ? ' · ' + esc(x.phone) : '') + '</span></div>' +
      '<button class="btn btn-sm btn-ghost btn-danger" type="button" data-act="unlinkGuardian" data-parent="' + esc(u.role === 'parent' ? u.id : x.id) + '" data-student="' + esc(u.role === 'parent' ? x.id : u.id) + '" data-user="' + esc(u.id) + '">' + icon('x', 'i-sm') + 'Unlink</button></div>').join('')
      : '<p class="small muted" style="margin:0">' + (u.role === 'parent' ? 'No children linked yet.' : 'No parents linked.') + '</p>';
  } catch (e) { if (!isExpired(e)) box.innerHTML = '<p class="small muted">' + esc(e.message) + '</p>'; }
}
ACT.linkChild = (d, btn) => busy(btn, async () => {
  const input = $('#linkChild');
  if (!input.value.trim()) throw new Error('Enter the student’s username.');
  const r = await call('linkGuardian', { parentId: d.id, student: input.value.trim() });
  input.value = '';
  toast(r.added ? 'Student linked.' : 'That student is already linked.');
  loadGuardians(S.users.find((x) => x.id === d.id));
});
ACT.unlinkGuardian = (d, btn) => busy(btn, async () => {
  await call('unlinkGuardian', { parentId: d.parent, studentId: d.student });
  toast('Link removed.');
  loadGuardians(S.users.find((x) => x.id === d.user));
});
FORMS.editUser = (f, btn) => busy(btn, async () => {
  const e = f.elements;
  await call('updateUser', {
    id: e.id.value, name: e.name.value, batch: e.batch.value, email: e.email.value, phone: e.phone.value,
    role: e.role ? e.role.value : undefined, status: e.status ? e.status.value : undefined
  });
  closeModal(); toast('Account saved.'); await refresh();
});

/* =====================================================================
   ALL COURSES, SITE NEWS, SETTINGS, AUDIT (admin)
   ===================================================================== */
async function viewAdminCourses() {
  const list = await call('allCourses');
  const rows = list.map((c) => '<tr data-text="' + esc((c.fullname + ' ' + c.shortname + ' ' + c.category + ' ' + c.owner).toLowerCase()) + '">' +
    '<td><div class="row"><span class="course-glyph cc-' + esc(c.color) + '">' + icon('cap', 'i-sm') + '</span>' +
    '<div><a class="strong" href="#/course/' + esc(c.id) + '">' + esc(c.fullname) + '</a><div class="xs muted">' + esc(c.shortname) + (c.category ? ' · ' + esc(c.category) : '') + '</div></div></div></td>' +
    '<td class="small">' + esc(c.teachers.join(', ') || c.owner) + '</td><td class="num">' + c.students + '</td><td class="num">' + c.activities + '</td>' +
    '<td>' + (c.visible ? badge('Visible', 'success') : badge('Hidden', 'warning')) + (c.selfEnrol ? ' ' + badge('Self-enrol', 'info') : '') + '</td>' +
    '<td class="small muted">' + esc(fmtDate(c.createdAt)) + '</td>' +
    '<td class="actions"><a class="btn btn-sm btn-ghost" href="#/course/' + esc(c.id) + '/settings">' + icon('settings', 'i-sm') + '</a></td></tr>').join('');
  return {
    title: 'Courses',
    html: pageHead('Courses', { crumbs: [['Site administration'], ['Courses']], sub: plural(list.length, 'course') + ' on the site', actions: '<button class="btn btn-primary" data-act="newCourse">' + icon('plus') + 'Create course</button>' }) +
      '<div class="card"><div class="card-head"><div class="search-box" style="flex:1;max-width:340px">' + icon('search') + '<input type="search" placeholder="Search courses" data-input="filterRows" data-target="#courseTable" aria-label="Search courses"></div></div>' +
      (list.length ? '<div class="table-wrap"><table class="table" id="courseTable"><thead><tr><th>Course</th><th>Teachers</th><th class="num">Students</th><th class="num">Activities</th><th>Status</th><th>Created</th><th></th></tr></thead><tbody>' + rows + '</tbody></table></div>'
        : '<div class="card-body">' + emptyState('layers', 'No courses yet', 'Create the first course for your site.', '', false) + '</div>') + '</div>'
  };
}

async function viewAdminNews() {
  const r = await call('announcements', { courseId: '' });
  return {
    title: 'Site news',
    html: pageHead('Site news', { crumbs: [['Site administration'], ['Site news']], sub: 'Announcements shown on everyone’s dashboard.' }) + announcementsHtml(r, '')
  };
}

const ALERT_EVENTS = [
  ['assignmentNew', 'New assignment posted'], ['assignmentDue', 'Assignment due within 24 hours'], ['assignmentOverdue', 'Assignment overdue'],
  ['assignmentGraded', 'Assignment graded'], ['quizNew', 'New test / test opens'], ['quizClosing', 'Test closes within 24 hours (not yet attempted)'],
  ['quizResult', 'Test result'], ['weeklyDigest', 'Weekly progress report'], ['reminders', 'Teacher reminders (when the teacher ticks email/SMS)']
];
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
function secretField(name, label, isSet, hint) {
  return field(label, '<input type="password" name="' + name + '" maxlength="500" autocomplete="new-password" placeholder="' + (isSet ? '•••••••• saved — leave blank to keep' : '') + '">', hint || '') +
    (isSet ? check(name + 'Clear', 'Remove the saved ' + label.toLowerCase(), false) : '');
}
function messagingCard(m) {
  const envNote = m.env && m.env.length ? notice('Some values come from environment variables on the server and override what you enter here: <code>' + m.env.map(esc).join('</code>, <code>') + '</code>.', '', 'info') : '';
  const status = (ready, on) => on ? (ready ? badge('On', 'success', 'check') : badge('Needs setup', 'warning', 'alert')) : badge('Off');
  return '<div class="card" style="max-width:880px"><div class="card-head"><span class="i-tile sm tone-amber">' + icon('send') + '</span><div><h2>Email & SMS alerts</h2>' +
    '<div class="xs muted">Alert students and parents about tests, assignments, scores and progress. Everyone can fine-tune what they get under Profile → Alerts &amp; contact.</div></div>' +
    '<div class="spacer"></div><a class="btn btn-sm" href="#/admin/messages">' + icon('list', 'i-sm') + 'Delivery log</a></div><div class="card-body">' + envNote +
    '<form data-form="messaging" novalidate>' +
    '<div class="form-grid">' + field('Site address', '<input type="url" name="siteUrl" maxlength="300" value="' + esc(m.siteUrl) + '" placeholder="https://lms.yourcollege.edu">', 'Used for the “Open” links in emails and SMS. Leave blank to send messages without links.') +
    field('Default country code', '<input type="text" name="countryCode" maxlength="5" value="' + esc(m.countryCode) + '" style="max-width:120px">', 'Added to mobile numbers entered without one.') + '</div>' +

    '<fieldset class="fieldset"><legend>Email ' + status(m.emailReady, m.email.enabled) + '</legend>' +
    '<label class="switch" style="margin-bottom:.9rem"><input type="checkbox" name="emailEnabled"' + (m.email.enabled ? ' checked' : '') + '><span class="track"></span>Send email alerts</label>' +
    field('How to send', '<select name="emailProvider" data-change="msgProvider">' +
      [['smtp', 'SMTP server (Gmail, Outlook, SendGrid, your college mail server…)'], ['log', 'Log only — record messages without sending (for testing)']].map(([v, l]) => '<option value="' + v + '"' + (m.email.provider === v ? ' selected' : '') + '>' + l + '</option>').join('') + '</select>') +
    '<div class="prov-email-smtp' + (m.email.provider === 'smtp' ? '' : ' hidden') + '"><div class="form-grid-3">' +
    field('SMTP host', '<input type="text" name="host" maxlength="200" value="' + esc(m.email.host) + '" placeholder="smtp.gmail.com">') +
    field('Port', '<input type="number" name="port" min="1" max="65535" value="' + esc(m.email.port) + '">', '587 (STARTTLS) or 465 (SSL)') +
    '<div class="field"><span class="label">&nbsp;</span>' + check('secure', 'Use SSL (port 465)', m.email.secure) + '</div></div>' +
    '<div class="form-grid">' + field('Username', '<input type="text" name="user" maxlength="200" autocomplete="off" value="' + esc(m.email.user) + '">') +
    secretField('pass', 'Password', m.email.passSet, 'For Gmail, use an app password.') + '</div>' +
    field('From address', '<input type="text" name="from" maxlength="200" value="' + esc(m.email.from) + '" placeholder="Jacob Davis LMS &lt;no-reply@yourcollege.edu&gt;">') + '</div>' +
    '<div class="row"><input type="email" id="testEmailTo" placeholder="you@example.com" style="max-width:260px" aria-label="Test email address"><button class="btn btn-sm" type="button" data-act="testMsg" data-channel="email">' + icon('send', 'i-sm') + 'Send test email</button><span class="xs muted">Save first if you changed anything.</span></div></fieldset>' +

    '<fieldset class="fieldset"><legend>SMS ' + status(m.smsReady, m.sms.enabled) + '</legend>' +
    '<label class="switch" style="margin-bottom:.9rem"><input type="checkbox" name="smsEnabled"' + (m.sms.enabled ? ' checked' : '') + '><span class="track"></span>Send SMS alerts</label>' +
    field('SMS provider', '<select name="smsProvider" data-change="msgProvider">' +
      [['twilio', 'Twilio'], ['webhook', 'HTTP gateway (MSG91, Fast2SMS, Textlocal… via a small relay)'], ['log', 'Log only — record messages without sending (for testing)']].map(([v, l]) => '<option value="' + v + '"' + (m.sms.provider === v ? ' selected' : '') + '>' + l + '</option>').join('') + '</select>') +
    '<div class="prov-sms-twilio' + (m.sms.provider === 'twilio' ? '' : ' hidden') + '"><div class="form-grid">' +
    field('Account SID', '<input type="text" name="twilioSid" maxlength="100" autocomplete="off" value="' + esc(m.sms.twilioSid) + '">') +
    secretField('twilioToken', 'Auth token', m.sms.twilioTokenSet) + '</div>' +
    field('Sender number', '<input type="text" name="twilioFrom" maxlength="40" value="' + esc(m.sms.twilioFrom) + '" placeholder="+1 555 0100">', 'A Twilio number or approved sender ID.') + '</div>' +
    '<div class="prov-sms-webhook' + (m.sms.provider === 'webhook' ? '' : ' hidden') + '">' +
    field('Gateway URL', '<input type="url" name="webhookUrl" maxlength="500" value="' + esc(m.sms.webhookUrl) + '" placeholder="https://…">', 'Receives POST JSON <code>{"to":"+9198…","message":"…","sender":"…"}</code>.') +
    secretField('webhookToken', 'Bearer token', m.sms.webhookTokenSet, 'Sent as an Authorization header. Optional.') + '</div>' +
    '<div class="row"><input type="tel" id="testSmsTo" placeholder="+91 98765 43210" style="max-width:260px" aria-label="Test mobile number"><button class="btn btn-sm" type="button" data-act="testMsg" data-channel="sms">' + icon('send', 'i-sm') + 'Send test SMS</button><span class="xs muted">SMS may cost money with your provider.</span></div></fieldset>' +

    '<fieldset class="fieldset"><legend>Which alerts to send</legend><div class="form-grid">' +
    ALERT_EVENTS.map(([k, l]) => check('ev_' + k, l, m.events[k] !== false)).join('') + '</div>' +
    '<div class="form-grid">' + field('Weekly report day', '<select name="digestDay">' + DAYS.map((d, i) => '<option value="' + i + '"' + (Number(m.digest.day) === i ? ' selected' : '') + '>' + d + '</option>').join('') + '</select>') +
    field('Weekly report time', '<select name="digestHour">' + Array.from({ length: 24 }, (_, h) => '<option value="' + h + '"' + (Number(m.digest.hour) === h ? ' selected' : '') + '>' + String(h).padStart(2, '0') + ':00</option>').join('') + '</select>') + '</div>' +
    '<div class="row-wrap">' + check('audStudents', 'Send to students', m.audience.students !== false) + check('audParents', 'Send to parents', m.audience.parents !== false) + '</div></fieldset>' +
    '<div class="form-actions"><button class="btn btn-primary" type="submit">Save alert settings</button></div></form></div></div>';
}
async function viewAdminSettings() {
  const [s, m, ai, chat] = await Promise.all([call('getSettings'), call('messagingConfig'), call('assistantConfig'), call('chatSettings')]);
  return {
    title: 'Settings',
    html: pageHead('Settings', { crumbs: [['Site administration'], ['Settings']] }) +
      '<div class="card" style="max-width:880px"><div class="card-head"><span class="i-tile sm tone-indigo">' + icon('settings') + '</span><h2>General</h2></div><div class="card-body">' +
      '<form data-form="settings" novalidate>' + field('Site name', '<input type="text" name="siteName" maxlength="80" value="' + esc(s.siteName) + '">', 'Shown in the sidebar, sign-in page, browser tab and every email.') +
      check('otp', 'Require an emailed sign-in code for teachers and admins', s.requireOtpStaff, 'Accounts need an email address. Codes are emailed when SMTP email is set up below.') +
      field('First-time passwords expire after (days)', '<input type="number" name="firstPwDays" min="1" max="90" value="' + esc(s.firstPwDays) + '" style="max-width:120px">',
        'Mobile-number and child’s-college-ID passwords stop working after this long; a reset starts the clock again. ' +
        (s.smsReady ? 'SMS is set up, so the first sign-in also needs a code texted to the registered mobile.' : '<b>Tip:</b> set up SMS below and the first sign-in will also need a code texted to the registered mobile.')) +
      (s.demoAvailable ? check('demoLogins', 'Show demo sign-ins on the sign-in page', s.demoLogins, 'One-click Admin, Faculty, Student and Parent demo accounts (' +
        s.demoAccounts.map((a) => a.username).join(', ') + '). Demo accounts can explore everything but never change accounts or settings.')
        : '<input type="hidden" name="demoLogins" value=""><p class="xs muted">Demo sign-ins are switched off: this is not a demo installation, and the demo accounts cannot sign in here.</p>') +
      '<div class="form-actions"><button class="btn btn-primary" type="submit">Save settings</button></div></form></div></div>' +
      '<div class="card" style="max-width:880px"><div class="card-head"><div><h2>Messages</h2><div class="xs muted">Course channels and direct messages under Communication → Messages.</div></div></div><div class="card-body">' +
      '<form data-form="chatCfg" novalidate><label class="px-opt"><span class="switch"><input type="checkbox" name="studentDM"' + (chat.studentDM ? ' checked' : '') + ' data-change="chatCfgSave"><span class="track"></span></span>' +
      '<span><b>Students can message classmates directly</b><span class="xs muted">Students can always message their teachers and talk in course channels. Turn this on to allow private messages between students who share a course.</span></span></label></form></div></div>' +
      assistantCard(ai) + messagingCard(m)
  };
}
ACT.chatCfgSave = (d, el) => busy(null, async () => { const r = await call('saveChatSettings', { studentDM: el.checked }); toast(r.studentDM ? 'Students can now message each other.' : 'Student-to-student messages are off.'); });

/* ---------- St. Ignatius, the AI guide ---------- */
const AI_MODELS = [['claude-sonnet-5', 'Claude Sonnet 5 — recommended: fast, warm, excellent with data'], ['claude-opus-5-5', 'Claude Opus 5.5 — most capable, slower and costlier'],
  ['claude-haiku-4-5-20251001', 'Claude Haiku 4.5 — fastest and cheapest']];
function assistantCard(a) {
  const models = AI_MODELS.some(([k]) => k === a.model) ? AI_MODELS : AI_MODELS.concat([[a.model, a.model]]);
  return '<div class="card" style="max-width:880px"><div class="card-head"><div><h2>St. Ignatius — AI guide ' + (a.enabled ? (a.mode === 'ai' ? badge('AI on', 'success', 'sparkle') : badge('Basic mode', 'warning')) : badge('Off')) + '</h2>' +
    '<div class="xs muted">The companion that floats over every page and answers questions about each person’s own courses, deadlines, grades and progress.</div></div></div><div class="card-body">' +
    notice('<b>Privacy:</b> in AI mode, each question and the person’s own course data needed to answer it are sent to Anthropic’s API. Mention this in your privacy notice to students and parents. Basic mode keeps everything on this server.', '', 'shield') +
    (a.env.length ? notice('Set on the server and used instead of the values here: <code>' + a.env.map(esc).join('</code>, <code>') + '</code>.', '', 'info') : '') +
    '<form data-form="assistantCfg" novalidate>' +
    '<label class="px-opt"><span class="switch"><input type="checkbox" name="enabled"' + (a.enabled ? ' checked' : '') + '><span class="track"></span></span><span><b>Show the guide to everyone</b><span class="xs muted">Students, parents and staff. People can still close it for themselves. It is never shown during a quiz attempt.</span></span></label>' +
    '<label class="px-opt"><span class="switch"><input type="checkbox" name="voice"' + (a.voice ? ' checked' : '') + '><span class="track"></span></span><span><b>Allow spoken replies</b><span class="xs muted">Uses the device’s built-in voice. Each person switches it on in the guide’s window.</span></span></label>' +
    '<div class="form-grid">' +
    field('Anthropic API key', '<input type="password" name="apiKey" autocomplete="off" placeholder="' + (a.hasKey ? 'Saved (' + esc(a.keyHint) + ') — leave blank to keep' : 'sk-ant-…') + '">',
      'From console.anthropic.com. Without a key the guide still works in basic mode, answering common questions from each person’s data.') +
    field('Model', '<select name="model">' + models.map(([k, l]) => '<option value="' + esc(k) + '"' + (k === a.model ? ' selected' : '') + '>' + esc(l) + '</option>').join('') + '</select>') + '</div>' +
    (a.hasKey ? check('clearKey', 'Remove the saved key (switch to basic mode)', false) : '') +
    '<p class="xs muted">Privacy: when a key is set, a person’s question and the parts of <b>their own</b> LMS data needed to answer it are sent to Anthropic to generate the reply. The guide can only read what that person can already see, and cannot change anything.</p>' +
    '<div class="form-actions"><button class="btn btn-primary" type="submit">Save guide settings</button></div></form></div></div>';
}
FORMS.assistantCfg = (f, btn) => busy(btn, async () => {
  const e = f.elements;
  const r = await call('saveAssistantConfig', { enabled: e.enabled.checked, voice: e.voice.checked, model: e.model.value, apiKey: e.apiKey.value, clearKey: !!(e.clearKey && e.clearKey.checked) });
  toast(r.enabled ? (r.mode === 'ai' ? 'The guide is on, powered by ' + r.model + '.' : 'The guide is on in basic mode.') : 'The guide is switched off.');
  refresh();
});
ACT.msgProvider = (d, el) => {
  const ch = el.name === 'emailProvider' ? 'email' : 'sms';
  $$('[class*="prov-' + ch + '-"]').forEach((x) => x.classList.toggle('hidden', !x.classList.contains('prov-' + ch + '-' + el.value)));
};
FORMS.messaging = (f, btn) => busy(btn, async () => {
  const e = f.elements;
  const events = {};
  ALERT_EVENTS.forEach(([k]) => { events[k] = e['ev_' + k].checked; });
  await call('saveMessagingConfig', {
    siteUrl: e.siteUrl.value, countryCode: e.countryCode.value,
    email: {
      enabled: e.emailEnabled.checked, provider: e.emailProvider.value, host: e.host.value, port: e.port.value, secure: e.secure.checked,
      user: e.user.value, pass: e.pass.value, clearPass: e.passClear ? e.passClear.checked : false, from: e.from.value
    },
    sms: {
      enabled: e.smsEnabled.checked, provider: e.smsProvider.value, twilioSid: e.twilioSid.value, twilioFrom: e.twilioFrom.value,
      twilioToken: e.twilioToken.value, clearTwilioToken: e.twilioTokenClear ? e.twilioTokenClear.checked : false,
      webhookUrl: e.webhookUrl.value, webhookToken: e.webhookToken.value, clearWebhookToken: e.webhookTokenClear ? e.webhookTokenClear.checked : false
    },
    events, audience: { students: e.audStudents.checked, parents: e.audParents.checked },
    digest: { day: e.digestDay.value, hour: e.digestHour.value }
  });
  toast('Alert settings saved.');
  await refresh();
});
ACT.testMsg = (d, btn) => busy(btn, async () => {
  const to = (d.channel === 'email' ? $('#testEmailTo') : $('#testSmsTo')).value.trim();
  if (!to) throw new Error('Enter where to send the test.');
  const r = await call('testMessage', { channel: d.channel, to });
  if (!r.ok) throw new Error('Test failed: ' + r.error);
  toast(r.status === 'logged' ? 'Test recorded in the delivery log (log-only mode — nothing was actually sent).' : 'Test ' + (d.channel === 'email' ? 'email' : 'SMS') + ' sent to ' + r.to + '.');
});

/* ---------- delivery log ---------- */
async function viewAdminMessages(params) {
  const status = params.get('status') || '';
  const channel = params.get('channel') || '';
  const r = await call('messageLog', { status, channel });
  const q = (k, v) => { const p = new URLSearchParams(params); if (v) p.set(k, v); else p.delete(k); const s = p.toString(); return '#/admin/messages' + (s ? '?' + s : ''); };
  const tone = { sent: 'success', logged: 'info', queued: 'warning', sending: 'warning', failed: 'danger', cancelled: '' };
  const k = r.counts;
  const rows = r.list.map((m) => '<tr><td class="small nowrap">' + esc(fmt(m.createdAt)) + '</td>' +
    '<td>' + badge(m.channel === 'sms' ? 'SMS' : 'Email', m.channel === 'sms' ? 'primary' : '', m.channel === 'sms' ? 'message' : 'mail') + '</td>' +
    '<td class="small"><b>' + esc(m.user || '—') + '</b>' + (m.role ? ' <span class="xs muted">' + esc(m.role) + '</span>' : '') + '<div class="xs muted">' + esc(m.to) + '</div></td>' +
    '<td class="small" style="min-width:260px;max-width:460px">' + esc(m.subject) + '<div class="xs muted">' + esc(m.event) + '</div></td>' +
    '<td>' + badge(m.status, tone[m.status]) + (m.error ? '<div class="xs" style="color:var(--danger);max-width:260px;margin-top:.2rem">' + esc(m.error) + '</div>' : '') +
    (m.attempts > 1 ? '<div class="xs muted">' + m.attempts + ' attempts</div>' : '') + '</td></tr>').join('');
  return {
    title: 'Email & SMS log',
    html: pageHead('Email & SMS log', {
      crumbs: [['Site administration'], ['Email & SMS log']], sub: 'Every alert sent to students and parents. Failed messages are retried 3 times automatically.',
      actions: (k.failed ? '<button class="btn" data-act="retryMessages">' + icon('refresh') + 'Retry ' + plural(k.failed, 'failed message') + '</button>' : '') + '<a class="btn" href="#/admin/settings">' + icon('settings') + 'Alert settings</a>'
    }) +
      '<div class="kpis">' + kpi('Sent', String(k.sent || 0), 'Last 7 days', 'checkCircle', true) + kpi('Logged (test mode)', String(k.logged || 0), 'Recorded, not sent', 'list') +
      kpi('Waiting', String((k.queued || 0) + (k.sending || 0)), 'In the queue', 'clock') + kpi('Failed', String(k.failed || 0), 'After 3 attempts', 'alert') + '</div>' +
      '<div class="filter-row"><span class="label-sm">Status</span><div class="pills">' +
      [['', 'All'], ['sent', 'Sent'], ['logged', 'Logged'], ['queued', 'Queued'], ['failed', 'Failed']].map(([v, l]) => '<a class="pill' + (status === v ? ' active' : '') + '" href="' + q('status', v) + '">' + l + '</a>').join('') + '</div>' +
      '<span class="label-sm">Channel</span><div class="pills">' + [['', 'Both'], ['email', 'Email'], ['sms', 'SMS']].map(([v, l]) => '<a class="pill' + (channel === v ? ' active' : '') + '" href="' + q('channel', v) + '">' + l + '</a>').join('') + '</div>' +
      '<div class="spacer"></div><button class="btn btn-sm" data-act="reload">' + icon('refresh', 'i-sm') + 'Refresh</button></div>' +
      '<div class="card">' + (r.list.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Time</th><th>Channel</th><th>Recipient</th><th>Message</th><th>Status</th></tr></thead><tbody>' + rows + '</tbody></table></div>'
        : '<div class="card-body">' + emptyState('send', 'No messages yet', 'Alerts appear here once email or SMS is switched on in Settings.', '<a class="btn btn-primary" href="#/admin/settings">Set up alerts</a>', false) + '</div>') + '</div>'
  };
}
ACT.retryMessages = (d, btn) => busy(btn, async () => { const r = await call('retryMessages'); toast(plural(r.retried, 'message') + ' queued again.'); await refresh(); });
FORMS.settings = (f, btn) => busy(btn, async () => {
  await call('saveSettings', { siteName: f.elements.siteName.value, requireOtpStaff: f.elements.otp.checked, firstPwDays: f.elements.firstPwDays.value,
    demoLogins: f.elements.demoLogins.type === 'checkbox' ? f.elements.demoLogins.checked : undefined });
  toast('Settings saved. Reload the page to see a new site name everywhere.');
});

async function viewAdminAudit() {
  const list = await call('auditLog', { limit: 500 });
  const bad = /FAIL|LOCK|DENIED|BLOCK/;
  return {
    title: 'Audit log',
    html: pageHead('Audit log', { crumbs: [['Site administration'], ['Audit log']], sub: 'The latest 500 security and activity events.' }) +
      '<div class="card"><div class="card-head"><div class="search-box" style="flex:1;max-width:340px">' + icon('search') + '<input type="search" placeholder="Filter events" data-input="filterRows" data-target="#auditTable" aria-label="Filter events"></div>' +
      '<div class="spacer"></div><span class="small muted">' + plural(list.filter((a) => bad.test(a.action)).length, 'security warning') + '</span></div>' +
      '<div class="table-wrap"><table class="table" id="auditTable"><thead><tr><th>Time</th><th>User</th><th>Event</th><th>Details</th></tr></thead><tbody>' +
      list.map((a) => '<tr data-text="' + esc((a.username + ' ' + a.action + ' ' + a.details).toLowerCase()) + '"><td class="small nowrap">' + esc(fmt(a.ts)) + '</td><td>' + esc(a.username || '—') + '</td>' +
        '<td>' + badge(a.action, bad.test(a.action) ? 'danger' : 'primary') + '</td><td class="small muted" style="word-break:break-word">' + esc(a.details) + '</td></tr>').join('') +
      '</tbody></table></div></div>'
  };
}

/* =====================================================================
   SITE ADMINISTRATION → USER DEMO
   Four working demo accounts (Admin, Faculty, Student, Parent) on this site, with a sandbox course.
   ===================================================================== */
const UD_ICON = { admin: ['shield', 'indigo'], teacher: ['book', 'blue'], student: ['cap', 'green'], parent: ['users', 'amber'] };
async function viewAdminUserDemo() {
  const d = await call('userDemoStatus');
  S.userDemo = d;
  const exp = d.expiresAt ? new Date(d.expiresAt) : null;
  const statusBadge = !d.exists ? badge('Not created') : d.expired ? badge('Expired', 'danger') : d.accounts.some((a) => a.active) ? badge('Active', 'success') : badge('Disabled');
  const card = (a) => {
    const ic = UD_ICON[a.role];
    return '<div class="card ud-card' + (a.exists ? '' : ' off') + '"><div class="ud-top"><span class="i-tile tone-' + ic[1] + '">' + icon(ic[0]) + '</span><div><b>' + esc(a.label) + '</b><div class="xs muted">' + esc(a.name) + '</div></div><span class="spacer"></span>' +
      (a.exists ? (a.active && !d.expired ? badge('Active', 'success') : badge(d.expired ? 'Expired' : 'Disabled')) : badge(a.role === 'admin' ? 'Not included' : 'Not created')) + '</div>' +
      '<div class="ud-login"><span class="xs muted">Username</span><code>' + esc(a.username) + '</code></div>' +
      '<ul class="ud-funcs">' + a.functions.map((f) => '<li>' + icon('check', 'i-sm') + esc(f) + '</li>').join('') + '</ul>' +
      (a.exists ? '<div class="xs muted">Last sign-in: ' + (a.lastLogin ? esc(rel(a.lastLogin)) : 'never') + '</div>' : '') + '</div>';
  };
  const actions = d.exists
    ? '<button class="btn" data-act="udPasswords">' + icon('key') + 'New passwords</button><button class="btn" data-act="udExtend">' + icon('clock') + 'Extend</button>' +
      (d.accounts.some((a) => a.active) ? '<button class="btn" data-act="udActive" data-on="0">' + icon('minus') + 'Disable</button>' : '<button class="btn" data-act="udActive" data-on="1">' + icon('check') + 'Enable</button>') +
      '<button class="btn btn-danger" data-act="udRemove">' + icon('trash') + 'Remove</button><button class="btn btn-primary" data-act="udCreate">' + icon('refresh') + 'Re-create</button>'
    : '<button class="btn btn-primary" data-act="udCreate">' + icon('userPlus') + 'Create demo accounts</button>';
  return {
    title: 'User demo',
    html: pageHead('User demo', { crumbs: [['Site administration'], ['User demo']], sub: 'Four working demo accounts — Admin, Faculty, Student and Parent — with a private sandbox course, for showing the LMS without touching real students.', actions }) +
      '<div class="card ud-summary"><div class="ud-sum-row"><div><span class="xs muted">Status</span><div>' + statusBadge + '</div></div>' +
      '<div><span class="xs muted">Expires</span><b>' + (exp ? esc(fmt(d.expiresAt)) : '—') + '</b></div>' +
      '<div><span class="xs muted">Sandbox course</span><b>' + (d.course ? '<a href="#/course/' + esc(d.course.id) + '">' + esc(d.course.fullname) + '</a>' : '—') + '</b></div>' +
      '<div><span class="xs muted">Created by</span><b>' + esc(d.createdBy || '—') + (d.createdAt ? ' · ' + esc(rel(d.createdAt)) : '') + '</b></div></div>' +
      notice('<b>How it keeps real data safe:</b> Faculty, Student and Parent work only in the sandbox course and never see real students. Passwords are random and shown to you once (use <i>New passwords</i> to see fresh ones); they are never shown on the sign-in page. The accounts stop working when they expire. <b>The Admin demo is a full administrator</b> — it can see the whole site, so include it only for people you’d trust with an admin account.', 'warn', 'shield') + '</div>' +
      '<div class="ud-grid">' + d.accounts.map(card).join('') + '</div>'
  };
}
function udPasswordsModal(r, title) {
  S.udPw = r.passwords;
  openModal(modalHead(title, 'Copy these now — they are not shown again. Use “New passwords” any time to get fresh ones.') + '<div class="modal-body">' +
    '<div class="ud-pw">' + r.passwords.map((p) => { const ic = UD_ICON[p.role]; return '<div class="ud-pw-row"><span class="i-tile sm tone-' + ic[1] + '">' + icon(ic[0]) + '</span><div><b>' + esc(p.label) + '</b><div class="xs muted">' + esc(p.name) + '</div></div>' +
      '<div class="ud-cred"><span>Username</span><code>' + esc(p.username) + '</code></div><div class="ud-cred"><span>Password</span><code>' + esc(p.password) + '</code></div></div>'; }).join('') + '</div>' +
    notice('Sign in with these on the normal sign-in page — for example in a private / incognito window so you stay signed in here.', '', 'info') +
    '<div class="form-actions"><button class="btn" data-act="udCopy">' + icon('copy') + 'Copy all</button><button class="btn btn-primary" data-act="close">Done</button></div></div>', 'wide');
}
ACT.udCopy = () => {
  const text = S.udPw.map((p) => p.label + ': ' + p.username + ' / ' + p.password).join('\n');
  (navigator.clipboard ? navigator.clipboard.writeText(text) : Promise.reject(new Error('no clipboard'))).then(() => toast('Copied.')).catch(() => toast('Your browser blocked copying — select the text instead.', 'err'));
};
ACT.udCreate = () => {
  formModal(S.userDemo && S.userDemo.exists ? 'Re-create the user demo' : 'Create demo accounts', 'Faculty, Student and Parent get a fresh sandbox course with sample lessons, an assignment, a quiz and an announcement.', 'udCreate',
    field('Keep the accounts for', '<select name="days"><option value="1">1 day</option><option value="3">3 days</option><option value="7" selected>7 days</option><option value="14">14 days</option><option value="30">30 days</option></select>', 'After this they stop working automatically. You can extend them.') +
    check('includeAdmin', 'Also create the Admin demo (a full administrator)', false, 'It can see and change everything on this site, including real students’ records. Leave this off unless you are demonstrating site administration to trusted people.') +
    (S.userDemo && S.userDemo.exists ? notice('Re-creating gives every demo account a new password and replaces the sandbox course with a fresh one.', 'warn') : ''), S.userDemo && S.userDemo.exists ? 'Re-create' : 'Create accounts');
};
FORMS.udCreate = (f, btn) => busy(btn, async () => {
  const r = await call('userDemoCreate', { days: Number(f.elements.days.value), includeAdmin: f.elements.includeAdmin.checked });
  closeModal(); await refresh(); udPasswordsModal(r, 'Demo accounts ready');
});
ACT.udPasswords = async () => {
  if (!(await confirmBox('Give every demo account a new password?', 'Anyone signed in with a demo account is signed out.', 'New passwords'))) return;
  busy(null, async () => { const r = await call('userDemoPasswords'); await refresh(); udPasswordsModal(r, 'New demo passwords'); });
};
ACT.udExtend = () => formModal('Extend the user demo', 'The demo accounts keep working until the new date.', 'udExtend',
  field('Extend to', '<select name="days"><option value="1">1 day from now</option><option value="3">3 days from now</option><option value="7" selected>7 days from now</option><option value="14">14 days from now</option><option value="30">30 days from now</option></select>'), 'Extend');
FORMS.udExtend = (f, btn) => busy(btn, async () => { await call('userDemoExtend', { days: Number(f.elements.days.value) }); closeModal(); toast('Demo extended.'); await refresh(); });
ACT.udActive = (d, btn) => busy(btn, async () => { await call('userDemoActive', { active: d.on === '1' }); toast(d.on === '1' ? 'Demo accounts enabled.' : 'Demo accounts disabled and signed out.'); await refresh(); });
ACT.udRemove = async () => {
  if (!(await confirmBox('Remove the user demo?', 'The four demo accounts are disabled and signed out, and the sandbox course is hidden. You can create a new demo any time.', 'Remove', true))) return;
  busy(null, async () => { await call('userDemoRemove'); toast('User demo removed.'); await refresh(); });
};
