'use strict';
/* =====================================================================
   ST. IGNATIUS — the AI guide that drifts over the page.
   • A small portrait wanders slowly across the screen (still, for reduced motion).
   • Click it to talk: it settles, and a conversation sheet opens beside it.
   • It speaks: the mouth moves while a reply appears, and optionally aloud.
   • Minimise (–) sends it back to wandering; close (×) sends it away until it
     is called back from the account menu. Never shown during a quiz attempt.
   ===================================================================== */
const IG = (() => {
  const SIZE = 76;
  const st = {
    mounted: false, open: false, hello: null, busy: false, speaking: false, dragging: null, hover: false,
    x: 0, y: 0, tx: 0, ty: 0, t0: performance.now(), pauseUntil: 0, last: 0, raf: 0, uid: '', voice: false
  };
  const reduce = () => window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const hiddenPref = () => prefs.get('ig.hidden', false);
  const logKey = () => 'ig.log.' + st.uid;
  const loadLog = () => { try { return JSON.parse(sessionStorage.getItem(logKey()) || '[]'); } catch (e) { return []; } };
  const saveLog = (l) => { try { sessionStorage.setItem(logKey(), JSON.stringify(l.slice(-40))); } catch (e) { /* storage full or blocked */ } };

  /* ---------- the portrait (original illustration) ---------- */
  function portrait(id) {
    return '<svg class="ig-face" viewBox="0 0 160 160" role="img" aria-hidden="true"><defs>' +
      '<radialGradient id="' + id + 'bg" cx="50%" cy="36%" r="72%"><stop offset="0" stop-color="#f7eedc"/><stop offset="1" stop-color="#d7bf97"/></radialGradient>' +
      '<radialGradient id="' + id + 'sk" cx="44%" cy="38%" r="68%"><stop offset="0" stop-color="#e7ba95"/><stop offset="1" stop-color="#c08765"/></radialGradient>' +
      '<linearGradient id="' + id + 'rb" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2b272a"/><stop offset="1" stop-color="#121013"/></linearGradient>' +
      '<clipPath id="' + id + 'cl"><circle cx="80" cy="80" r="80"/></clipPath></defs>' +
      '<g clip-path="url(#' + id + 'cl)">' +
      '<rect width="160" height="160" fill="url(#' + id + 'bg)"/>' +
      '<circle class="ig-halo" cx="80" cy="60" r="47" fill="none" stroke="#c9a24a" stroke-width="2.4" opacity=".5"/>' +
      '<path d="M12 160 C16 124 44 109 80 109 C116 109 144 124 148 160 Z" fill="url(#' + id + 'rb)"/>' +
      '<path d="M66 97 L66 113 C72 118 88 118 94 113 L94 97 Z" fill="#b97f61"/>' +
      '<path d="M58 111 C66 121 94 121 102 111 L97 108 C90 115 70 115 63 108 Z" fill="#eee6d8"/>' +
      '<ellipse cx="53" cy="69" rx="5" ry="8.5" fill="#c68b68"/><ellipse cx="107" cy="69" rx="5" ry="8.5" fill="#c68b68"/>' +
      '<path d="M80 25 C101 25 109 42 109 60 C109 83 98 101 80 103 C62 101 51 83 51 60 C51 42 59 25 80 25 Z" fill="url(#' + id + 'sk)"/>' +
      '<ellipse cx="75" cy="35" rx="15" ry="6" fill="#fff" opacity=".2"/>' +
      '<path d="M52 60 C50 47 55 39 61 36 C57 45 57 54 58.5 64 Z" fill="#3a2c25"/><path d="M108 60 C110 47 105 39 99 36 C103 45 103 54 101.5 64 Z" fill="#3a2c25"/>' +
      '<path d="M62.5 57 C66 53.8 72 53 76 54" stroke="#2c211d" stroke-width="2.6" fill="none" stroke-linecap="round"/>' +
      '<path d="M84 54 C88 53 94 53.8 97.5 57" stroke="#2c211d" stroke-width="2.6" fill="none" stroke-linecap="round"/>' +
      '<g class="ig-eyes"><path d="M64 63 C67 60 73 60 76 63 C73 65.6 67 65.6 64 63 Z" fill="#f3ebe1"/><path d="M84 63 C87 60 93 60 96 63 C93 65.6 87 65.6 84 63 Z" fill="#f3ebe1"/>' +
      '<circle class="ig-pupil" cx="70" cy="63" r="2.5" fill="#26190f"/><circle class="ig-pupil" cx="90" cy="63" r="2.5" fill="#26190f"/>' +
      '<circle cx="70.9" cy="62.1" r=".75" fill="#fff"/><circle cx="90.9" cy="62.1" r=".75" fill="#fff"/></g>' +
      '<path d="M63.5 62.4 C67 59.3 73 59.3 76.5 62.4" stroke="#6a4230" stroke-width="1.3" fill="none"/><path d="M83.5 62.4 C87 59.3 93 59.3 96.5 62.4" stroke="#6a4230" stroke-width="1.3" fill="none"/>' +
      '<path d="M80.5 61 C79.5 69 76.5 75.5 75 79.5 C77 82.3 83 82.3 85.5 80" stroke="#95603f" stroke-width="1.9" fill="none" stroke-linecap="round" stroke-linejoin="round"/>' +
      '<path d="M55 71 C55 87 62 105 80 109 C98 105 105 87 105 71 C101 82 95 88.5 89 88.5 C84.5 86.5 75.5 86.5 71 88.5 C65 88.5 59 82 55 71 Z" fill="#2e231e"/>' +
      '<path d="M66 97 C70 101 74 103 78 104" stroke="#75675f" stroke-width="1" fill="none" opacity=".55"/><path d="M94 97 C90 101 86 103 82 104" stroke="#75675f" stroke-width="1" fill="none" opacity=".55"/>' +
      '<ellipse cx="80" cy="91.5" rx="6" ry="2.3" fill="#9a5446"/><ellipse class="ig-mouth" cx="80" cy="91.6" rx="4.6" ry="1.9" fill="#1b0e0c"/>' +
      '<path d="M69.5 86.5 C73.5 83 78 83.6 80 85.2 C82 83.6 86.5 83 90.5 86.5 C86.5 88.6 83 88 80 87.3 C77 88 73.5 88.6 69.5 86.5 Z" fill="#231915"/>' +
      '<g transform="translate(80 138)"><circle r="9.5" fill="none" stroke="#c9a24a" stroke-width="1.2" opacity=".9"/><text y="3" text-anchor="middle" font-family="Georgia,\'Times New Roman\',serif" font-size="8" font-weight="700" fill="#d9b55e">IHS</text></g>' +
      '</g></svg>';
  }

  /* ---------- mount / unmount ---------- */
  function mount() {
    if (st.mounted) return;
    st.mounted = true;
    st.uid = S.me.id;
    st.voice = prefs.get('ig.voice', false);
    const w = document.createElement('div');
    w.id = 'ig';
    w.className = 'ig';
    w.innerHTML = '<div class="ig-bubble" id="igBubble" role="status" hidden></div>' +
      '<button type="button" class="ig-avatar" id="igAvatar" aria-label="Talk to St. Ignatius, your AI guide" aria-expanded="false" aria-controls="igPanel">' + portrait('igA') + '</button>' +
      '<span class="ig-name" aria-hidden="true">St. Ignatius</span>';
    document.body.appendChild(w);
    const p = document.createElement('section');
    p.id = 'igPanel';
    p.className = 'ig-panel';
    p.setAttribute('role', 'dialog');
    p.setAttribute('aria-label', 'Conversation with St. Ignatius');
    p.hidden = true;
    p.innerHTML = '<header class="ig-head"><span class="ig-mini">' + portrait('igM') + '</span><div class="ig-title"><b>St. Ignatius of Loyola</b><span id="igSub">Your guide</span></div>' +
      '<button type="button" class="btn-icon sm" id="igVoice" data-act="igVoice" aria-pressed="false" title="Read replies aloud"></button>' +
      '<button type="button" class="btn-icon sm" data-act="igMin" title="Minimise" aria-label="Minimise">' + icon('minus') + '</button>' +
      '<button type="button" class="btn-icon sm" data-act="igClose" title="Send him away" aria-label="Close the guide">' + icon('x') + '</button></header>' +
      '<div class="ig-log" id="igLog" role="log" aria-live="polite"></div>' +
      '<div class="ig-chips" id="igChips"></div>' +
      '<form class="ig-input" data-form="igSend" novalidate><textarea name="q" rows="1" maxlength="2000" placeholder="Ask about your courses, deadlines, grades…" aria-label="Your message"></textarea>' +
      '<button class="btn-icon ig-send" type="submit" aria-label="Send">' + icon('send') + '</button></form>' +
      '<p class="ig-foot">An AI guide in the spirit of St. Ignatius. It reads only your own LMS data and can make mistakes.</p>';
    document.body.appendChild(p);
    voiceButton();
    const av = $('#igAvatar');
    av.addEventListener('pointerdown', dragStart);
    w.addEventListener('pointerenter', () => { st.hover = true; });
    w.addEventListener('pointerleave', () => { st.hover = false; });
    $('#igBubble').addEventListener('click', () => openPanel());
    p.querySelector('textarea').addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); p.querySelector('form').requestSubmit(); }
      if (e.key === 'Escape') { e.stopPropagation(); minimise(); }
    });
    p.querySelector('textarea').addEventListener('input', (e) => { const t = e.target; t.style.height = 'auto'; t.style.height = Math.min(140, t.scrollHeight) + 'px'; });
    // Start somewhere calm on the right, then wander.
    st.x = innerWidth - SIZE - 40; st.y = innerHeight * 0.55;
    pickTarget();
    place();
    st.last = performance.now();
    st.raf = requestAnimationFrame(frame);
    call('assistantHello', { tz: tz() }).then((h) => {
      st.hello = h;
      if (!h.enabled) { unmount(); return; }
      $('#igSub').textContent = h.mode === 'ai' ? 'Your guide · AI' : 'Your guide';
      if (!h.voice) { st.voice = false; $('#igVoice').hidden = true; }
      renderLog();
      if (!sessionStorage.getItem('ig.greeted.' + st.uid)) {
        sessionStorage.setItem('ig.greeted.' + st.uid, '1');
        setTimeout(() => bubble(h.line), 1200);
      }
    }).catch(() => { /* the guide simply stays quiet */ });
  }
  function unmount() {
    cancelAnimationFrame(st.raf);
    stopVoice();
    ['ig', 'igPanel'].forEach((id) => { const el = document.getElementById(id); if (el) el.remove(); });
    st.mounted = false; st.open = false; st.hello = null;
  }
  const tz = () => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) { return ''; } };

  /* ---------- where it may appear ---------- */
  function allowed() {
    if (!S.me || !S.token || S.attempt || hiddenPref()) return false;
    if (/^#\/assessment\/checkin\//.test(location.hash)) return false;
    return !!document.getElementById('main');
  }
  setInterval(() => {
    const ok = allowed();
    if (!S.me && !st.cleared) {
      // Signed out: forget this tab's conversations (shared computers).
      st.cleared = true;
      try { Object.keys(sessionStorage).filter((k) => /^ig\.(log|greeted)\./.test(k)).forEach((k) => sessionStorage.removeItem(k)); } catch (e) { /* ignore */ }
    }
    if (S.me) st.cleared = false;
    if (ok && !st.mounted) mount();
    else if (!ok && st.mounted) unmount();
    if (st.mounted) {
      const modal = !!$('.modal-bg');
      $('#ig').classList.toggle('ig-away', modal && !st.open);
    }
  }, 600);

  /* ---------- wandering ---------- */
  function bounds() {
    const mobile = innerWidth < 960;
    return {
      minX: mobile ? 12 : 290, maxX: innerWidth - SIZE - 16,
      minY: 84, maxY: innerHeight - SIZE - (mobile ? 110 : 28)
    };
  }
  function pickTarget() {
    const b = bounds();
    // Prefer the page margins so it rarely sits over what you are reading.
    const edge = Math.random();
    st.tx = edge < 0.7 ? (Math.random() < 0.5 ? b.maxX - Math.random() * 160 : b.minX + Math.random() * 120) : b.minX + Math.random() * (b.maxX - b.minX);
    st.ty = b.minY + Math.random() * Math.max(10, b.maxY - b.minY);
    st.tx = Math.max(b.minX, Math.min(b.maxX, st.tx));
  }
  function dock() {
    // Where it settles while you talk: right side, beside the conversation.
    const mobile = innerWidth < 700;
    st.tx = mobile ? innerWidth - SIZE - 14 : innerWidth - SIZE - 28;
    st.ty = mobile ? Math.max(70, innerHeight * 0.18 - SIZE / 2) : Math.max(90, innerHeight * 0.5 - SIZE / 2);
  }
  function frame(now) {
    const dt = Math.min(64, now - st.last) / 1000;
    st.last = now;
    const el = $('#ig');
    if (!el) return;
    if (!st.dragging) {
      if (st.open) dock();
      const still = reduce() && !st.open;
      if (still) { const b = bounds(); st.tx = b.maxX - 10; st.ty = Math.min(b.maxY, innerHeight * 0.6); }
      const moving = !st.hover && now > st.pauseUntil;
      if (moving || st.open) {
        const dx = st.tx - st.x, dy = st.ty - st.y, dist = Math.hypot(dx, dy);
        const speed = st.open ? 900 : 28; // gliding to the dock is quick; wandering is slow
        if (dist < 2) {
          if (!st.open && !still) { st.pauseUntil = now + 2500 + Math.random() * 6000; pickTarget(); }
        } else {
          const step = Math.min(dist, speed * dt * (st.open ? Math.max(0.25, dist / 300) : 1));
          st.x += dx / dist * step; st.y += dy / dist * step;
          st.tilt = Math.max(-5, Math.min(5, dx / dist * 5));
        }
      }
    }
    place(now);
    st.raf = requestAnimationFrame(frame);
  }
  function place(now) {
    const el = $('#ig');
    if (!el) return;
    const b = bounds();
    if (!st.dragging) { st.x = Math.max(8, Math.min(innerWidth - SIZE - 8, st.x)); st.y = Math.max(64, Math.min(innerHeight - SIZE - 8, st.y)); }
    const bob = reduce() || st.dragging ? 0 : Math.sin((now || 0) / 900) * 4;
    el.style.transform = 'translate3d(' + Math.round(st.x) + 'px,' + Math.round(st.y + bob) + 'px,0) rotate(' + ((st.open || reduce()) ? 0 : (st.tilt || 0)).toFixed(2) + 'deg)';
    el.classList.toggle('ig-left', st.x < innerWidth / 2);
    if (st.open) placePanel();
    void b;
  }
  function placePanel() {
    const p = $('#igPanel');
    if (!p || p.hidden) return;
    if (innerWidth < 700) { p.style.left = ''; p.style.top = ''; return; } // bottom sheet via CSS
    const w = p.offsetWidth, h = p.offsetHeight;
    let left = st.x - w - 18;
    if (left < 12) left = Math.min(innerWidth - w - 12, st.x + SIZE + 18);
    const top = Math.max(76, Math.min(innerHeight - h - 16, st.y + SIZE / 2 - h / 2));
    p.style.left = Math.round(left) + 'px';
    p.style.top = Math.round(top) + 'px';
  }

  /* ---------- drag, or click to talk ---------- */
  function dragStart(e) {
    if (e.button !== 0) return;
    const sx = e.clientX, sy = e.clientY, ox = st.x, oy = st.y;
    let moved = false;
    const av = e.currentTarget;
    av.setPointerCapture(e.pointerId);
    const move = (ev) => {
      const dx = ev.clientX - sx, dy = ev.clientY - sy;
      if (!moved && Math.hypot(dx, dy) < 5) return;
      moved = true;
      st.dragging = true;
      $('#ig').classList.add('ig-drag');
      st.x = ox + dx; st.y = oy + dy;
    };
    const up = () => {
      av.removeEventListener('pointermove', move);
      av.removeEventListener('pointerup', up);
      av.removeEventListener('pointercancel', up);
      $('#ig').classList.remove('ig-drag');
      if (moved) { st.dragging = false; st.tx = st.x; st.ty = st.y; st.pauseUntil = performance.now() + 20000; }
      else if (st.open) minimise(); else openPanel();
    };
    av.addEventListener('pointermove', move);
    av.addEventListener('pointerup', up);
    av.addEventListener('pointercancel', up);
  }
  // Keyboard: Enter/Space on the focused avatar.
  document.addEventListener('keydown', (e) => {
    if (e.target && e.target.id === 'igAvatar' && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); if (st.open) minimise(); else openPanel(); }
  });

  /* ---------- panel ---------- */
  function openPanel() {
    if (!st.mounted) return;
    bubble('');
    st.open = true;
    const p = $('#igPanel');
    p.hidden = false;
    $('#ig').classList.add('ig-open');
    $('#igAvatar').setAttribute('aria-expanded', 'true');
    renderLog();
    requestAnimationFrame(() => { placePanel(); p.classList.add('in'); });
    setTimeout(() => { const t = p.querySelector('textarea'); if (t && innerWidth >= 700) t.focus(); }, 60);
  }
  function minimise() {
    if (!st.open) return;
    st.open = false;
    const p = $('#igPanel');
    p.classList.remove('in');
    setTimeout(() => { if (!st.open) p.hidden = true; }, 200);
    $('#ig').classList.remove('ig-open');
    $('#igAvatar').setAttribute('aria-expanded', 'false');
    st.pauseUntil = performance.now() + 4000;
    pickTarget();
    $('#igAvatar').focus({ preventScroll: true });
  }
  ACT.igMin = () => minimise();
  ACT.igClose = () => {
    stopVoice();
    prefs.set('ig.hidden', true);
    unmount();
    toast('St. Ignatius has stepped away. Call him back any time from your account menu.');
  };
  /** From the account menu: bring the guide back, or open him. */
  ACT.igSummon = () => {
    prefs.set('ig.hidden', false);
    closeMenus();
    if (!st.mounted && allowed()) mount();
    setTimeout(() => openPanel(), 150);
  };

  function bubble(text) {
    const b = $('#igBubble');
    if (!b) return;
    clearTimeout(st.bubbleT);
    if (!text) { b.hidden = true; return; }
    b.textContent = text;
    b.hidden = false;
    speakingFace(true);
    setTimeout(() => speakingFace(false), Math.min(4000, 60 * text.length));
    st.bubbleT = setTimeout(() => { b.hidden = true; }, 11000);
  }

  /* ---------- conversation ---------- */
  function fmtMsg(text) { return md(text); }
  function renderLog() {
    const log = $('#igLog');
    if (!log) return;
    const items = loadLog();
    const hello = st.hello && st.hello.line ? '<div class="ig-msg bot"><div class="ig-text">' + esc(st.hello.line) + '</div></div>' : '';
    log.innerHTML = hello + items.map((m) => '<div class="ig-msg ' + (m.role === 'user' ? 'me' : 'bot') + '"><div class="ig-text">' + (m.role === 'user' ? esc(m.content) : fmtMsg(m.content)) + '</div></div>').join('');
    const chips = $('#igChips');
    const sugg = st.hello && st.hello.suggestions ? st.hello.suggestions : [];
    chips.innerHTML = items.length > 6 ? '' : sugg.map((s) => '<button type="button" class="ig-chip" data-act="igAsk" data-q="' + esc(s) + '">' + esc(s) + '</button>').join('');
    log.scrollTop = log.scrollHeight;
  }
  ACT.igAsk = (d) => send(d.q);
  FORMS.igSend = (f) => { const t = f.elements.q; const q = t.value.trim(); if (!q) return; t.value = ''; t.style.height = 'auto'; send(q); };

  async function send(q) {
    if (st.busy) return;
    st.busy = true;
    stopVoice();
    const items = loadLog();
    items.push({ role: 'user', content: q });
    saveLog(items);
    renderLog();
    const log = $('#igLog');
    const typing = document.createElement('div');
    typing.className = 'ig-msg bot';
    typing.innerHTML = '<div class="ig-text ig-typing" aria-label="St. Ignatius is thinking"><i></i><i></i><i></i></div>';
    log.appendChild(typing);
    log.scrollTop = log.scrollHeight;
    $('#ig').classList.add('ig-thinking');
    let r;
    try {
      r = await call('assistantChat', { messages: items.slice(-16), tz: tz(), page: document.title.replace(/ · .*$/, '') });
    } catch (e) {
      r = { text: 'Forgive me — ' + (e.message || 'something went wrong') + '. Could you try again in a moment?' };
    }
    $('#ig') && $('#ig').classList.remove('ig-thinking');
    typing.remove();
    items.push({ role: 'assistant', content: r.text });
    saveLog(items);
    await reveal(r.text);
    if (r.notice && S.me && S.me.role === 'admin') toast(r.notice, 'err');
    st.busy = false;
    renderLog();
  }
  /** The reply appears as if spoken: word by word, mouth moving; aloud if voice is on. */
  function reveal(text) {
    return new Promise((resolve) => {
      const log = $('#igLog');
      if (!log) { resolve(); return; }
      const box = document.createElement('div');
      box.className = 'ig-msg bot';
      box.innerHTML = '<div class="ig-text"></div>';
      log.appendChild(box);
      const out = box.firstChild;
      speakingFace(true);
      if (st.voice) speak(text);
      const words = text.split(/(\s+)/);
      let i = 0;
      const pace = reduce() ? 0 : 28;
      const step = () => {
        if (!document.body.contains(out)) { speakingFace(false); resolve(); return; }
        i = Math.min(words.length, i + 2);
        out.innerHTML = fmtMsg(words.slice(0, i).join(''));
        log.scrollTop = log.scrollHeight;
        if (i < words.length && pace) setTimeout(step, pace);
        else { out.innerHTML = fmtMsg(text); if (!st.voice || !speechSynthesis.speaking) speakingFace(false); resolve(); }
      };
      step();
    });
  }
  function speakingFace(on) {
    st.speaking = on;
    ['ig', 'igPanel'].forEach((id) => { const el = document.getElementById(id); if (el) el.classList.toggle('ig-speaking', on); });
  }

  /* ---------- voice ---------- */
  function voiceButton() {
    const b = $('#igVoice');
    if (!b) return;
    const ok = 'speechSynthesis' in window;
    b.hidden = !ok;
    b.innerHTML = icon(st.voice ? 'volume' : 'volumeOff');
    b.setAttribute('aria-pressed', String(!!st.voice));
    b.setAttribute('aria-label', st.voice ? 'Voice on — stop reading aloud' : 'Voice off — read replies aloud');
  }
  ACT.igVoice = () => { st.voice = !st.voice; prefs.set('ig.voice', st.voice); if (!st.voice) stopVoice(); voiceButton(); };
  function pickVoice() {
    const vs = speechSynthesis.getVoices().filter((v) => /^en/i.test(v.lang));
    const pref = [/en-IN/i, /en-GB/i, /en-US/i];
    const male = /(male|ravi|prabhat|george|daniel|guy|ryan|arthur|david|mark|james|thomas)/i;
    for (const re of pref) { const v = vs.find((x) => re.test(x.lang) && male.test(x.name)); if (v) return v; }
    for (const re of pref) { const v = vs.find((x) => re.test(x.lang)); if (v) return v; }
    return vs[0] || null;
  }
  function speak(text) {
    try {
      const plain = text.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1').replace(/[*_`#>•]/g, '').replace(/\n+/g, '. ');
      const u = new SpeechSynthesisUtterance(plain);
      const v = pickVoice();
      if (v) { u.voice = v; u.lang = v.lang; }
      u.rate = 0.97; u.pitch = 0.86;
      u.onstart = () => speakingFace(true);
      u.onend = u.onerror = () => speakingFace(false);
      speechSynthesis.cancel();
      speechSynthesis.speak(u);
    } catch (e) { /* no voice available */ }
  }
  function stopVoice() { try { if ('speechSynthesis' in window) speechSynthesis.cancel(); } catch (e) { /* ignore */ } speakingFace(false); }
  if ('speechSynthesis' in window) speechSynthesis.onvoiceschanged = () => {};

  window.addEventListener('resize', () => {
    if (!st.mounted) return;
    if (st.open) { dock(); st.x = st.tx; st.y = st.ty; place(performance.now()); return; }
    const b = bounds(); st.x = Math.min(st.x, b.maxX); st.y = Math.min(st.y, b.maxY); pickTarget();
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && st.open && document.activeElement && document.activeElement.closest && document.activeElement.closest('#igPanel')) minimise(); });

  return { mount, unmount, open: openPanel, state: st };
})();
