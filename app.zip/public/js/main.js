'use strict';
/* =====================================================================
   ROUTES
   ===================================================================== */
const ID = '([A-Za-z0-9]+)';
route(/^\/dashboard$/, viewDashboard);
route(/^\/courses$/, viewMyCourses);
route(/^\/catalog$/, viewCatalog);
route(new RegExp('^/course/' + ID + '(?:/([a-z]+))?$'), viewCourse);
route(new RegExp('^/mod/' + ID + '$'), viewModule);
route(new RegExp('^/discussion/' + ID + '$'), viewDiscussion);
route(new RegExp('^/quiz/' + ID + '/(questions|results|analysis)$'), viewQuizAdmin);
route(new RegExp('^/review/' + ID + '$'), viewReview);
route(/^\/calendar$/, viewCalendar);
route(/^\/grades$/, viewGradesOverview);
route(/^\/notifications$/, viewNotifications);
route(/^\/profile$/, viewProfile);
route(/^\/search$/, viewSearch);
route(/^\/family$/, viewFamily);
route(new RegExp('^/child/' + ID + '$'), viewChild);
route(/^\/chat$/, () => viewChat(''));
route(new RegExp('^/chat/' + ID + '$'), viewChat);
route(/^\/assessment$/, viewAssessment);
route(/^\/assessment\/check$/, viewSystemCheck);
route(new RegExp('^/assessment/checkin/' + ID + '$'), viewCheckin);
route(/^\/assessment\/live$/, viewProctorLive);
route(/^\/assessment\/reviews$/, viewProctorReviews);
route(new RegExp('^/assessment/exam/' + ID + '$'), viewProctorExam);
route(new RegExp('^/assessment/session/' + ID + '$'), viewProctorSession);
route(/^\/admin\/messages$/, viewAdminMessages);
route(/^\/insights$/, viewInsights);
route(/^\/admin\/analytics$/, viewSiteAnalytics);
route(/^\/admin\/users$/, viewAdminUsers);
route(/^\/admin\/courses$/, viewAdminCourses);
route(/^\/admin\/announcements$/, viewAdminNews);
route(/^\/admin\/settings$/, viewAdminSettings);
route(/^\/admin\/audit$/, viewAdminAudit);
route(/^\/admin\/userdemo$/, viewAdminUserDemo);
route(/^\/mentoring$/, viewMtHome);
route(/^\/mentoring\/mentees$/, viewMtMentees);
route(new RegExp('^/mentoring/student/' + ID + '$'), viewMtStudent);
route(new RegExp('^/mentoring/report/' + ID + '$'), viewMtPrint);
route(/^\/mentoring\/sessions$/, viewMtSessions);
route(/^\/mentoring\/followups$/, viewMtFollowups);
route(/^\/mentoring\/concerns$/, viewMtConcerns);
route(/^\/mentoring\/goals$/, viewMtGoals);
route(/^\/mentoring\/interventions$/, viewMtInterventions);
route(/^\/mentoring\/indicators$/, viewMtIndicators);
route(/^\/mentoring\/allocation$/, viewMtAllocation);
route(/^\/mentoring\/analytics$/, viewMtAnalytics);
route(/^\/mentoring\/settings$/, viewMtSettings);
route(/^\/mentoring\/development$/, viewMtDevelopment);
route(/^\/mentoring\/search$/, viewMtSearch);
route(/^\/studio$/, viewStHome);
route(/^\/studio\/new$/, viewStNew);
route(/^\/studio\/library$/, viewStLibrary);
route(new RegExp('^/studio/edit/' + ID + '$'), viewStEdit);
route(new RegExp('^/studio/view/' + ID + '$'), viewStView);
route(new RegExp('^/studio/print/' + ID + '$'), viewStPrint);
route(/^\/studio\/live$/, viewStLiveList);
route(new RegExp('^/studio/live/' + ID + '$'), viewStLive);
route(/^\/studio\/analytics$/, viewStAnalytics);
route(/^\/studio\/outcomes$/, viewStOutcomes);
route(/^\/studio\/settings$/, viewStSettings);
route(/^\/sim$/, viewSmHome);
route(/^\/sim\/library$/, viewSmLibrary);
route(/^\/sim\/new$/, viewSmNew);
route(/^\/sim\/settings$/, viewSmSettings);
route(new RegExp('^/sim/build/' + ID + '$'), viewSmBuild);
route(new RegExp('^/sim/run/' + ID + '$'), viewSmRun);
route(new RegExp('^/sim/play/' + ID + '$'), viewSmPlay);
route(new RegExp('^/sim/report/' + ID + '$'), viewSmReport);

/* =====================================================================
   DRAG & DROP UPLOADS onto any .dropzone
   ===================================================================== */
function hasFiles(e) { return !!(e.dataTransfer && Array.from(e.dataTransfer.types || []).indexOf('Files') >= 0); }
document.addEventListener('dragover', (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault(); // otherwise the browser would open the file and leave the app
  const z = e.target.closest && e.target.closest('.dropzone');
  $$('.dropzone.drag').forEach((x) => { if (x !== z) x.classList.remove('drag'); });
  if (z) z.classList.add('drag');
});
document.addEventListener('dragleave', (e) => {
  const z = e.target.closest && e.target.closest('.dropzone');
  if (z && !z.contains(e.relatedTarget)) z.classList.remove('drag');
});
document.addEventListener('drop', (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault();
  const z = e.target.closest && e.target.closest('.dropzone');
  $$('.dropzone.drag').forEach((x) => x.classList.remove('drag'));
  if (!z) return;
  const input = z.querySelector('input[type=file]');
  const fn = input && ACT[input.dataset.change];
  if (!fn) return;
  const files = input.multiple ? Array.from(e.dataTransfer.files) : Array.from(e.dataTransfer.files).slice(0, 1);
  fn(input.dataset, { files, form: input.form, closest: (sel) => input.closest(sel), value: '' }, e);
});

/* =====================================================================
   BOOT
   ===================================================================== */
(async function boot() {
  const tok = tokenStore.get();
  if (tok) {
    try {
      S.me = await run('api', tok, 'me', {});
      S.token = tok;
    } catch (e) {
      tokenStore.set(null);
    }
  }
  if (!S.me) { viewLogin(); return; }
  if (S.me.mustChange) { viewChangePw(true); return; }
  startApp();
})();
