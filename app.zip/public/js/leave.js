'use strict';
/* =====================================================================
   STAFF LEAVE & MOVEMENTS (Attendance tab)
   /leave          my leave: balance dashboard, apply CL / OD / ML, requests with progress
   /movements      my movements: monthly quota, apply, requests with progress
   /leave/desk     approvals (query / approve / reject), staff dashboard, all requests, settings
   Any page takes ?open=<id> to open a request.
   ===================================================================== */
const LV = { home: null, mv: null, desk: null, paths: null, filter: 'all' };
const LV_TYPE_TONE = { CL: 'blue', OD: 'violet', ML: 'pink' };
const LV_TYPE_ICON = { CL: 'calendar', OD: 'building', ML: 'activity' };
const LV_STATUS = {
  pending: ['warning', 'Awaiting approval'], query: ['info', 'Query raised'], approved: ['success', 'Approved'],
  rejected: ['danger', 'Rejected'], cancelled: ['', 'Cancelled']
};
const LV_MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const lvIsStaff = () => S.me && (S.me.role === 'teacher' || S.me.role === 'admin');

function lvDate(d, withYear) { if (!d) return ''; return new Date(d + 'T00:00').toLocaleDateString(undefined, withYear === false ? { day: 'numeric', month: 'short' } : { day: 'numeric', month: 'short', year: 'numeric' }); }
function lvDay(d) { return new Date(d + 'T00:00').toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' }); }
function lvNum(n) { return Number.isInteger(n) ? String(n) : String(Math.round(n * 10) / 10).replace(/\.5$/, '½').replace(/^0½$/, '½'); }
function lvDays(n) { return n === 0.5 ? '½ day' : lvNum(n) + (n === 1 ? ' day' : ' days'); }
function lvWhen(r) {
  if (r.kind === 'movement') return lvDay(r.date) + ' · ' + r.fromTime + '–' + r.toTime;
  if (r.from === r.to) return lvDay(r.from) + (r.half ? ' · half day' : '');
  return lvDate(r.from, false) + ' – ' + lvDate(r.to);
}
function lvStatus(st) { const s = LV_STATUS[st] || ['', st]; return badge(s[1], s[0]); }
function lvTile(r) {
  const t = r.kind === 'movement' ? ['clock', 'amber', 'MV'] : [LV_TYPE_ICON[r.type], LV_TYPE_TONE[r.type], r.type];
  return '<span class="lv-tile tone-' + t[1] + '">' + icon(t[0]) + '<b>' + esc(t[2]) + '</b></span>';
}
/** Compact dots: applied → each stage → done. */
function lvMini(r) {
  return '<span class="lv-mini" title="' + esc(r.path.map((p) => p.name).join(' → ')) + '"><i class="done"></i>' +
    r.path.map((p) => '<i class="' + p.state + '"></i>').join('') + '<i class="' + (r.status === 'approved' ? 'done' : 'todo') + '"></i></span>';
}
function lvReqRow(r, showName) {
  const stage = r.path[Math.min(r.stage, r.path.length - 1)];
  const where = r.status === 'pending' ? 'With ' + stage.name : r.status === 'query' ? 'Query from ' + stage.name : r.status === 'approved' ? 'Approved' : r.status === 'rejected' ? 'Rejected at ' + stage.name : 'Cancelled';
  return '<button type="button" class="lv-row" data-act="lvOpen" data-id="' + esc(r.id) + '">' + lvTile(r) +
    '<span class="lv-row-main">' + (showName ? '<b class="lv-row-name">' + esc(r.name) + '</b>' : '') +
    '<span class="lv-row-when">' + esc(lvWhen(r)) + '<span class="muted"> · ' + (r.kind === 'movement' ? r.minutes + ' min' : lvDays(r.days)) + '</span></span>' +
    '<span class="lv-row-reason">' + esc(r.reason) + '</span></span>' +
    '<span class="lv-row-prog">' + lvMini(r) + '<span class="xs muted">' + esc(where) + '</span></span>' +
    '<span class="lv-row-st">' + lvStatus(r.status) + '<span class="xs muted">' + esc(r.ref) + '</span></span></button>';
}
function lvList(list, showName, empty) {
  return list.length ? '<div class="lv-list">' + list.map((r) => lvReqRow(r, showName)).join('') + '</div>' : emptyState('inbox', empty[0], empty[1], '', false);
}

/* ---------- the progress tracker (detail) ---------- */
function lvStepper(r) {
  const last = (i) => { for (let k = r.trail.length - 1; k >= 0; k--) { const t = r.trail[k]; if (t.stage === i && ['approved', 'rejected', 'query', 'auto', 'reply'].indexOf(t.action) >= 0) return t; } return null; };
  const applied = r.trail[0];
  const steps = [{ name: 'Applied', state: 'done', sub: esc(applied.by) + '<br>' + esc(fmt(applied.at)) }];
  r.path.forEach((p, i) => {
    const t = last(i);
    let sub = '';
    if (p.state === 'current') sub = 'Waiting on ' + esc(r.waitingOn.join(', ') || 'approver');
    else if (p.state === 'query') sub = 'Query raised — waiting for ' + esc(r.name.split(' ')[0]);
    else if (t) sub = esc(t.by) + '<br>' + esc(fmt(t.at));
    steps.push({ name: p.name, state: p.state, sub });
  });
  const fin = { approved: ['done', 'Approved'], rejected: ['rejected', 'Rejected'], cancelled: ['cancelled', 'Cancelled'] }[r.status] || ['todo', 'Approved'];
  steps.push({ name: fin[1], state: fin[0], sub: r.status === 'approved' || r.status === 'cancelled' ? esc(fmt(r.updatedAt)) : '' });
  const ico = { done: 'check', current: 'clock', query: 'message', rejected: 'x', cancelled: 'minus', todo: '' };
  const doneN = steps.filter((s) => s.state === 'done').length;
  return '<div class="lv-steps" style="--n:' + steps.length + ';--done:' + Math.max(0, doneN - 1) + '"><div class="lv-steps-track"><i></i></div>' +
    steps.map((s) => '<div class="lv-step ' + s.state + '"><span class="lv-step-dot">' + (ico[s.state] ? icon(ico[s.state], 'i-sm') : '') + '</span>' +
      '<b>' + esc(s.name) + '</b><span class="lv-step-sub">' + s.sub + '</span></div>').join('') + '</div>';
}
const LV_VERB = {
  applied: ['send', 'applied'], approved: ['checkCircle', 'approved'], rejected: ['x', 'rejected'], query: ['message', 'raised a query'],
  reply: ['reply', 'replied'], cancelled: ['minus', 'cancelled the request'], auto: ['zap', 'forwarded automatically']
};
function lvTrail(r) {
  return '<ol class="lv-trail">' + r.trail.map((t) => {
    const v = LV_VERB[t.action] || ['info', t.action];
    const at = t.stage >= 0 && r.path[t.stage] && ['approved', 'rejected', 'query', 'auto'].indexOf(t.action) >= 0 ? ' at <b>' + esc(r.path[t.stage].name) + '</b>' : '';
    return '<li class="lv-t-' + t.action + '"><span class="lv-t-ico">' + icon(v[0], 'i-sm') + '</span><div><div><b>' + esc(t.by) + '</b> ' + v[1] + at +
      ' <span class="xs muted">· ' + esc(fmt(t.at)) + '</span></div>' + (t.note ? '<div class="lv-bubble">' + esc(t.note) + '</div>' : '') + '</div></li>';
  }).join('') + '</ol>';
}
function lvDetail(r) {
  const facts = r.kind !== 'movement'
    ? [['Type', esc(r.typeLabel) + ' (' + esc(r.type) + ')'], ['Dates', esc(r.from === r.to ? lvDay(r.from) : lvDay(r.from) + ' – ' + lvDay(r.to))], ['Days', esc(lvDays(r.days))]]
    : [['Date', esc(lvDay(r.date))], ['Out – In', esc(r.fromTime + ' – ' + r.toTime)], ['Duration', r.minutes + ' min']];
  let act = '';
  if (r.canAct) {
    act = '<div class="lv-act"><label class="label" for="lvNote">Remarks <span class="hint">Needed for a query or a rejection; optional when approving.</span></label>' +
      '<textarea id="lvNote" rows="2" maxlength="500" placeholder="e.g. Please attach the medical certificate"></textarea><div class="lv-act-btns">' +
      '<button class="btn btn-danger" data-act="lvDo" data-id="' + esc(r.id) + '" data-action="reject">' + icon('x') + 'Reject</button>' +
      '<button class="btn" data-act="lvDo" data-id="' + esc(r.id) + '" data-action="query">' + icon('message') + 'Raise query</button>' +
      '<button class="btn btn-primary" data-act="lvDo" data-id="' + esc(r.id) + '" data-action="approve"' + (r.status === 'query' ? ' disabled title="Waiting for the applicant to reply"' : '') + '>' + icon('check') +
      (r.stage < r.path.length - 1 ? 'Approve &amp; forward' : 'Approve') + '</button></div></div>';
  } else if (r.canReply) {
    act = '<div class="lv-act lv-act-q"><label class="label" for="lvNote">Your reply to the query</label><textarea id="lvNote" rows="2" maxlength="500" autofocus></textarea>' +
      '<div class="lv-act-btns"><button class="btn btn-primary" data-act="lvDo" data-id="' + esc(r.id) + '" data-action="reply">' + icon('reply') + 'Send reply</button></div></div>';
  }
  const cancel = r.canCancel ? '<button class="btn btn-ghost btn-sm" data-act="lvDo" data-id="' + esc(r.id) + '" data-action="cancel">' + icon('minus') + (r.status === 'approved' ? 'Cancel this ' + (r.kind === 'movement' ? 'movement' : 'leave') : 'Withdraw') + '</button>' : '';
  return modalHead((r.kind !== 'movement' ? r.typeLabel : 'Movement') + ' · ' + r.ref, esc(r.name) + (r.applicantRole === 'student' ? ' · student' + (r.batch ? ', ' + esc(r.batch) : '') : '') + ' · applied ' + esc(fmt(r.createdAt))) +
    '<div class="modal-body lv-detail"><div class="lv-d-top">' + lvStatus(r.status) + '<span class="spacer"></span>' + cancel + '</div>' +
    '<div class="lv-facts">' + facts.map((f) => '<div><span>' + f[0] + '</span><b>' + f[1] + '</b></div>').join('') + '</div>' +
    '<div class="lv-reason"><span>Reason</span><p>' + esc(r.reason) + '</p></div>' +
    '<h4 class="lv-h4">Approval progress</h4>' + lvStepper(r) + act +
    '<h4 class="lv-h4">History</h4>' + lvTrail(r) + '</div>';
}
ACT.lvOpen = async (d) => {
  try { const r = await call('leaveRequest', { id: d.id }); openModal(lvDetail(r), 'lg'); } catch (e) { toast(e.message, 'err'); }
};
ACT.lvDo = async (d, btn) => {
  const note = ($('#lvNote') || {}).value || '';
  if (d.action === 'cancel' && !(await confirmBox('Cancel this request?', 'It will be marked cancelled and any days it held go back to the balance.', 'Cancel request', true))) return;
  busy(btn, async () => {
    const r = await call('leaveAct', { id: d.id, action: d.action, note });
    const msg = { approve: r.request.status === 'approved' ? 'Approved.' : 'Approved and forwarded to ' + r.request.path[r.request.stage].name + '.', reject: 'Rejected.', query: 'Query sent to ' + r.request.name + '.', reply: 'Reply sent.', cancel: 'Request cancelled.' }[d.action];
    toast(msg);
    if ($('.modal-bg')) openModal(lvDetail(r.request), 'lg');
    lvNavCount();
    await refresh();
  });
};
async function lvNavCount() {
  try { const me = await call('me'); S.me.leavePending = me.leavePending; const el = $('#navLeave'); if (el) { el.textContent = me.leavePending || ''; el.classList.toggle('hidden', !me.leavePending); } } catch (e) { /* badge only */ }
}
function lvPathLine(p) { return p.map((x) => esc(x.name)).join(' <span class="muted">→</span> '); }

/* =====================================================================
   MY LEAVE
   ===================================================================== */
route(/^\/leave$/, async (params) => {
  if (!lvIsStaff()) { go('/attendance'); return null; }
  const d = await call('leaveHome');
  LV.home = d;
  const b = d.balance, st = d.settings;
  const usedPct = b.total ? Math.min(100, b.used / b.total * 100) : 0, pendPct = b.total ? Math.min(100 - usedPct, b.pending / b.total * 100) : 0;
  const typeBar = (t) => {
    const x = b.byType[t], counted = st.counted[t];
    return '<div class="lv-type"><span class="lv-type-h"><span class="lv-sw tone-' + LV_TYPE_TONE[t] + '"></span><b>' + t + '</b><span class="muted small">' + esc(st.types[t].label) + '</span>' +
      (counted ? '' : '<span class="badge outline">not counted</span>') + '<span class="spacer"></span><b>' + lvNum(x.used) + '</b><span class="muted small">' + (x.pending ? ' +' + lvNum(x.pending) + ' pending' : '') + '</span></span>' +
      '<span class="lv-type-bar tone-' + LV_TYPE_TONE[t] + '"><i style="width:' + (b.total ? Math.min(100, x.used / b.total * 100) : 0) + '%"></i><i class="p" style="width:' + (b.total ? Math.min(100, x.pending / b.total * 100) : 0) + '%"></i></span></div>';
  };
  const mv = d.movements;
  const hero = '<div class="card lv-hero"><div class="lv-ring" style="--u:' + usedPct + ';--p:' + pendPct + '"><div><b>' + lvNum(b.remaining) + '</b><span>of ' + lvNum(b.total) + ' days left</span></div></div>' +
    '<div class="lv-hero-body"><div class="lv-hero-top"><div><div class="lv-eyebrow">Leave year ' + esc(b.year.label) + '</div><h2>' + (b.remaining ? lvDays(b.remaining) + ' available' : 'No leave left') + '</h2>' +
    '<div class="small muted">' + lvNum(b.used) + ' used · ' + lvNum(b.pending) + ' awaiting approval · counts ' + esc(b.counted.join(' + ') || 'nothing') + ' against your ' + lvNum(b.total) + '-day allowance</div></div></div>' +
    '<div class="lv-types">' + ['CL', 'OD', 'ML'].map(typeBar).join('') + '</div></div>' +
    '<a class="lv-mvcard" href="#/movements"><span class="lv-eyebrow">Movements · ' + esc(mv.month) + '</span><span class="lv-slots">' +
    Array.from({ length: Math.max(mv.limit, 1) }, (_, i) => '<i class="' + (i < mv.used ? 'on' : '') + '"></i>').join('') + '</span><b>' + mv.used + ' of ' + mv.limit + ' used</b><span class="xs muted">' + (mv.used >= mv.limit ? 'Limit reached this month' : (mv.limit - mv.used) + ' left this month') + ' ' + icon('arrowRight', 'i-sm') + '</span></a></div>';
  const max = Math.max(1, ...d.monthly.map((m) => m.CL + m.OD + m.ML));
  const chart = '<div class="card"><div class="card-head"><span class="i-tile sm tone-indigo">' + icon('chart') + '</span><div><h2>Leave by month</h2><div class="xs muted">Approved days in ' + esc(b.year.label) + '</div></div><span class="spacer"></span>' +
    '<span class="lv-legend">' + ['CL', 'OD', 'ML'].map((t) => '<span><i class="lv-sw tone-' + LV_TYPE_TONE[t] + '"></i>' + t + '</span>').join('') + '</span></div><div class="card-body"><div class="lv-bars">' +
    d.monthly.map((m) => { const tot = m.CL + m.OD + m.ML; return '<div class="lv-bar" title="' + esc(m.label + ': ' + (tot ? ['CL', 'OD', 'ML'].filter((t) => m[t]).map((t) => t + ' ' + lvNum(m[t])).join(', ') : 'no leave')) + '"><div class="lv-bar-col">' +
      ['ML', 'OD', 'CL'].map((t) => (m[t] ? '<i class="tone-' + LV_TYPE_TONE[t] + '" style="height:' + (m[t] / max * 100) + '%"></i>' : '')).join('') + '</div><span>' + esc(m.label) + '</span>' + (tot ? '<b>' + lvNum(tot) + '</b>' : '<b class="muted">·</b>') + '</div>'; }).join('') + '</div></div></div>';
  const counts = { all: d.requests.length, open: d.requests.filter((r) => r.status === 'pending' || r.status === 'query').length, approved: d.requests.filter((r) => r.status === 'approved').length, closed: d.requests.filter((r) => r.status === 'rejected' || r.status === 'cancelled').length };
  const f = LV.filter in counts ? LV.filter : 'all';
  const shown = d.requests.filter((r) => f === 'all' || (f === 'open' ? r.status === 'pending' || r.status === 'query' : f === 'approved' ? r.status === 'approved' : r.status === 'rejected' || r.status === 'cancelled'));
  const queries = d.requests.filter((r) => r.status === 'query');
  return {
    title: 'Leave',
    html: pageHead('Leave', {
      crumbs: [['Attendance', '/attendance'], ['Leave']],
      sub: 'Apply for Casual Leave, On Duty or Medical Leave and follow each application through its approval path.',
      actions: '<button class="btn" data-act="lvReport">' + icon('download') + 'My statement</button><button class="btn btn-primary" data-act="lvApply">' + icon('plus') + 'Apply for leave</button>'
    }) +
      (queries.length ? notice('<b>' + plural(queries.length, 'query', 'queries') + ' waiting for your reply.</b> ' + queries.map((r) => '<button class="link" data-act="lvOpen" data-id="' + esc(r.id) + '">' + esc(r.ref) + '</button>').join(', '), 'warn', 'message') : '') +
      (d.pendingForMe ? notice('<b>' + plural(d.pendingForMe, 'request') + ' awaiting your approval.</b> <a href="#/leave/desk">Open the leave desk</a>', '', 'checkCircle') : '') +
      '<div class="lv">' + hero +
      '<div class="grid-4 kpis lv-kpis">' + kpi('Allowance', lvNum(b.total) + '<small> days</small>', 'for ' + b.year.label, 'calendar') + kpi('Used', lvNum(b.used) + '<small> days</small>', 'approved ' + (b.counted.join(' + ') || ''), 'checkCircle') +
      kpi('Awaiting approval', lvNum(b.pending) + '<small> days</small>', plural(counts.open, 'open application'), 'clock') + kpi('Remaining', lvNum(b.remaining) + '<small> days</small>', 'after pending ones', 'target') + '</div>' +
      '<div class="lv-split">' + chart +
      '<div class="card"><div class="card-head"><span class="i-tile sm tone-green">' + icon('layers') + '</span><div><h2>Approval path</h2><div class="xs muted">Every leave application goes through</div></div></div><div class="card-body"><ol class="lv-path">' +
      '<li><span>' + icon('send', 'i-sm') + '</span>You apply</li>' + st.leavePath.map((p) => '<li><span>' + icon('user', 'i-sm') + '</span><div><b>' + esc(p.name) + '</b><div class="xs muted">' + esc(p.approvers.length ? p.approvers.map((a) => a.name).join(', ') : 'Administrators') + '</div></div></li>').join('') +
      '<li><span>' + icon('checkCircle', 'i-sm') + '</span>Approved</li></ol><p class="xs muted" style="margin:var(--sp-3) 0 0">At each stage the approver can approve, reject or raise a query. Answer a query and the application continues from the same stage.</p></div></div></div>' +
      '<div class="card"><div class="card-head"><span class="i-tile sm tone-blue">' + icon('list') + '</span><h2>My applications</h2><span class="spacer"></span><div class="pills lv-seg">' +
      [['all', 'All'], ['open', 'In progress'], ['approved', 'Approved'], ['closed', 'Rejected / cancelled']].map(([k, l]) => '<button class="pill' + (f === k ? ' active' : '') + '" data-act="lvFilter" data-f="' + k + '">' + l + ' <span class="muted">' + counts[k] + '</span></button>').join('') + '</div></div>' +
      '<div class="card-body lv-list-wrap">' + lvList(shown, false, ['No applications here', d.requests.length ? 'Try another filter.' : 'Use “Apply for leave” to send your first application.']) + '</div></div></div>',
    after: () => { if (params.get('open')) ACT.lvOpen({ id: params.get('open') }); }
  };
});
ACT.lvFilter = (d) => { LV.filter = d.f; refresh(); };
ACT.lvReport = (d, btn) => erpDownload('leaveReport', { scope: d.scope || 'mine' }, btn);

/* ---------- apply for leave ---------- */
ACT.lvApply = async () => {
  const d = LV.home || await call('leaveHome');
  LV.home = d;
  const st = d.settings, b = d.balance;
  const t0 = new Date(); t0.setDate(t0.getDate() + 1);
  const tomorrow = toDateInput(t0.getTime());
  const opt = (t) => '<label class="lv-type-opt tone-' + LV_TYPE_TONE[t] + '"><input type="radio" name="type" value="' + t + '"' + (t === 'CL' ? ' checked' : '') + ' data-change="lvCalc">' +
    '<span>' + icon(LV_TYPE_ICON[t]) + '<b>' + t + '</b><small>' + esc(st.types[t].label) + '</small><em>' + (st.counted[t] ? lvNum(b.remaining) + ' left' : 'not deducted') + '</em></span></label>';
  formModal('Apply for leave', 'Leave year ' + esc(b.year.label) + ' · ' + lvNum(b.remaining) + ' of ' + lvNum(b.total) + ' days available', 'lvApply',
    '<div class="lv-type-opts">' + ['CL', 'OD', 'ML'].map(opt).join('') + '</div>' +
    '<div class="form-grid">' + field('From', '<input type="date" name="from" value="' + tomorrow + '" data-change="lvCalc" required>') +
    field('To', '<input type="date" name="to" value="' + tomorrow + '" data-change="lvCalc" required>') + '</div>' +
    '<label class="check"><input type="checkbox" name="half" data-change="lvCalc"><span>Half day<span class="hint">Only for a single date</span></span></label>' +
    field('Reason', '<textarea name="reason" rows="3" maxlength="500" placeholder="e.g. Attending a family function in Madurai"></textarea>') +
    '<div class="lv-calc" id="lvCalc"></div>' +
    '<div class="lv-route">' + icon('layers', 'i-sm') + '<span>Goes to ' + lvPathLine(st.leavePath) + '</span></div>', 'Submit application');
  ACT.lvCalc();
};
ACT.lvCalc = () => {
  const f = $('form[data-form="lvApply"]');
  if (!f || !LV.home) return;
  const st = LV.home.settings, b = LV.home.balance;
  const type = (f.querySelector('input[name=type]:checked') || {}).value || 'CL';
  if (f.half.checked) f.to.value = f.from.value;
  f.to.disabled = f.half.checked;
  if (f.from.value && f.to.value && f.to.value < f.from.value) f.to.value = f.from.value;
  let n = 0, sun = 0;
  if (f.from.value && f.to.value) {
    for (let x = new Date(f.from.value + 'T00:00'); toDateInput(x.getTime()) <= f.to.value; x.setDate(x.getDate() + 1)) { if (st.excludeSundays && x.getDay() === 0) sun++; else n++; }
    if (f.half.checked) n = n ? 0.5 : 0;
  }
  const counted = st.counted[type];
  const left = b.remaining - (counted ? n : 0);
  $('#lvCalc').innerHTML = '<div><b>' + lvDays(n) + '</b><span>' + (sun ? plural(sun, 'Sunday') + ' not counted' : 'working days') + '</span></div>' +
    '<div class="' + (left < 0 ? 'bad' : '') + '"><b>' + (counted ? lvNum(Math.max(left, 0)) : lvNum(b.remaining)) + '</b><span>' + (counted ? (left < 0 ? 'short by ' + lvNum(-left) + ' — not enough leave' : 'days left after this') : type + ' is not deducted') + '</span></div>';
};
FORMS.lvApply = (f, btn) => busy(btn, async () => {
  const type = (f.querySelector('input[name=type]:checked') || {}).value;
  const r = await call('leaveApply', { type, from: f.from.value, to: f.half.checked ? f.from.value : f.to.value, half: f.half.checked, reason: f.reason.value });
  closeModal();
  toast(r.request.ref + ' sent to ' + r.request.path[r.request.stage].name + '.');
  LV.filter = 'all';
  await refresh();
});

/* =====================================================================
   MOVEMENTS
   ===================================================================== */
route(/^\/movements$/, async (params) => {
  if (!lvIsStaff()) { go('/attendance'); return null; }
  const d = await call('movementHome');
  LV.mv = d;
  const full = d.used >= d.limit;
  const months = [];
  const now = new Date();
  for (let i = 5; i >= 0; i--) { const x = new Date(now.getFullYear(), now.getMonth() - i, 1); const k = x.getFullYear() + '-' + String(x.getMonth() + 1).padStart(2, '0'); months.push({ k, label: LV_MONTHS[x.getMonth()].slice(0, 3), n: d.byMonth[k] || 0 }); }
  const hero = '<div class="card lv-hero lv-mv-hero"><div class="lv-quota"><div class="lv-eyebrow">' + esc(d.month) + '</div><div class="lv-quota-slots">' +
    Array.from({ length: Math.max(d.limit, 1) }, (_, i) => '<span class="' + (i < d.used ? 'on' : '') + '">' + icon(i < d.used ? 'check' : 'clock') + '</span>').join('') + '</div>' +
    '<h2>' + d.used + ' of ' + d.limit + ' movements used</h2><div class="small muted">' + (full ? 'You have reached this month’s limit. It resets on the 1st.' : (d.limit - d.used) + ' left this month · each up to ' + d.maxMinutes + ' minutes') + '</div></div>' +
    '<div class="lv-mv-hist"><div class="lv-eyebrow">Last 6 months</div><div class="lv-mv-months">' + months.map((m) => '<div class="' + (m.n >= d.limit ? 'full' : '') + '"><span class="lv-slots sm">' +
      Array.from({ length: Math.max(d.limit, 1) }, (_, i) => '<i class="' + (i < m.n ? 'on' : '') + '"></i>').join('') + '</span><b>' + m.n + '/' + d.limit + '</b><span class="xs muted">' + m.label + '</span></div>').join('') + '</div>' +
    '<div class="lv-route">' + icon('layers', 'i-sm') + '<span>Approval path: You → ' + lvPathLine(d.settings.movementPath) + ' → Approved</span></div></div></div>';
  const queries = d.requests.filter((r) => r.status === 'query');
  return {
    title: 'Movements',
    html: pageHead('Movements', {
      crumbs: [['Attendance', '/attendance'], ['Movements']],
      sub: 'Short permissions to step out during working hours — up to ' + plural(d.limit, 'movement') + ' a month.',
      actions: '<button class="btn btn-primary" data-act="mvApply"' + (full ? ' disabled title="Monthly limit reached"' : '') + '>' + icon('plus') + 'Apply for movement</button>'
    }) +
      (queries.length ? notice('<b>' + plural(queries.length, 'query', 'queries') + ' waiting for your reply.</b> ' + queries.map((r) => '<button class="link" data-act="lvOpen" data-id="' + esc(r.id) + '">' + esc(r.ref) + '</button>').join(', '), 'warn', 'message') : '') +
      (d.pendingForMe ? notice('<b>' + plural(d.pendingForMe, 'request') + ' awaiting your approval.</b> <a href="#/leave/desk">Open the leave desk</a>', '', 'checkCircle') : '') +
      '<div class="lv">' + hero + '<div class="card"><div class="card-head"><span class="i-tile sm tone-amber">' + icon('clock') + '</span><h2>My movements</h2></div><div class="card-body lv-list-wrap">' +
      lvList(d.requests, false, ['No movements yet', 'Use “Apply for movement” when you need to step out for a short while.']) + '</div></div></div>',
    after: () => { if (params.get('open')) ACT.lvOpen({ id: params.get('open') }); }
  };
});
ACT.mvApply = () => {
  const d = LV.mv;
  formModal('Apply for movement', d.used + ' of ' + d.limit + ' used in ' + esc(d.month) + ' · each up to ' + d.maxMinutes + ' minutes', 'mvApply',
    field('Date', '<input type="date" name="date" value="' + d.today + '" required>') +
    '<div class="form-grid">' + field('Out time', '<input type="time" name="fromTime" value="11:00" data-change="mvCalc">') + field('Return time', '<input type="time" name="toTime" value="12:00" data-change="mvCalc">') + '</div>' +
    field('Reason', '<textarea name="reason" rows="3" maxlength="500" placeholder="e.g. Bank visit for salary account KYC"></textarea>') +
    '<div class="lv-calc" id="mvCalc"></div><div class="lv-route">' + icon('layers', 'i-sm') + '<span>Goes to ' + lvPathLine(d.settings.movementPath) + '</span></div>', 'Submit movement');
  ACT.mvCalc();
};
ACT.mvCalc = () => {
  const f = $('form[data-form="mvApply"]'); if (!f) return;
  const m = (v) => (v ? Number(v.slice(0, 2)) * 60 + Number(v.slice(3, 5)) : 0);
  const n = m(f.toTime.value) - m(f.fromTime.value), max = LV.mv.maxMinutes;
  $('#mvCalc').innerHTML = '<div class="' + (n <= 0 || (max && n > max) ? 'bad' : '') + '"><b>' + (n > 0 ? n + ' min' : '—') + '</b><span>' + (n <= 0 ? 'return must be after out time' : max && n > max ? 'longer than ' + max + ' min — apply for leave instead' : 'duration') + '</span></div>' +
    '<div><b>' + Math.max(0, LV.mv.limit - LV.mv.used - 1) + '</b><span>left this month after this</span></div>';
};
FORMS.mvApply = (f, btn) => busy(btn, async () => {
  const r = await call('movementApply', { date: f.date.value, fromTime: f.fromTime.value, toTime: f.toTime.value, reason: f.reason.value });
  closeModal();
  toast(r.request.ref + ' sent to ' + r.request.path[r.request.stage].name + '.');
  await refresh();
});

/* =====================================================================
   LEAVE DESK — approvals, staff dashboard, all requests, settings
   ===================================================================== */
route(/^\/leave\/desk$/, async (params) => {
  if (!lvIsStaff()) { go('/attendance'); return null; }
  const d = await call('leaveDesk');
  LV.desk = d;
  const el = $('#navLeave'); if (el) { el.textContent = d.pending.length || ''; el.classList.toggle('hidden', !d.pending.length); }
  const tabs = [['approvals', 'Approvals', d.pending.length]].concat(d.isAdmin ? [['staff', 'Staff dashboard'], ['all', 'All requests'], ['settings', 'Settings']] : []);
  const tab = tabs.some((t) => t[0] === params.get('tab')) ? params.get('tab') : 'approvals';
  let body = '';
  if (tab === 'approvals') body = lvApprovalsHtml(d);
  else if (tab === 'staff') body = lvStaffHtml(d);
  else if (tab === 'all') body = lvAllHtml(d);
  else body = lvSettingsHtml(d) + lvStudentSettingsHtml(d);
  return {
    title: 'Leave desk',
    html: pageHead('Leave desk', {
      crumbs: [['Attendance', '/attendance'], ['Leave desk']],
      sub: d.isAdmin ? 'Approve leave and movements, watch every staff member’s balance, and set the rules.' : 'Leave and movement requests waiting for you.',
      actions: d.isAdmin ? '<button class="btn" data-act="lvReport" data-scope="all">' + icon('download') + 'Staff leave report</button>' : ''
    }) +
      '<div class="tabs lv-tabs">' + tabs.map((t) => '<a class="tab' + (t[0] === tab ? ' active' : '') + '" href="#/leave/desk?tab=' + t[0] + '">' + esc(t[1]) + (t[2] ? ' <span class="count">' + t[2] + '</span>' : '') + '</a>').join('') + '</div>' +
      '<div class="lv">' + body + '</div>',
    after: () => { if (params.get('open')) ACT.lvOpen({ id: params.get('open') }); if (tab === 'settings') lvPathsRender(); }
  };
});

function lvApprovalsHtml(d) {
  const card = (r) => {
    const stage = r.path[r.stage];
    return '<div class="card lv-appr' + (r.status === 'query' ? ' is-query' : '') + '"><div class="lv-appr-top">' + avatar(r.name) + '<div class="lv-appr-who"><b>' + esc(r.name) + '</b><span class="xs muted">' + (r.applicantRole === 'student' ? '<span class="badge info">Student</span> ' + (r.batch ? esc(r.batch) + ' · ' : '') : '') + esc(r.ref) + ' · applied ' + esc(rel(r.createdAt)) + '</span></div>' + lvTile(r) + '</div>' +
      '<div class="lv-appr-when"><b>' + esc(lvWhen(r)) + '</b><span>' + (r.kind === 'movement' ? r.minutes + ' min' : lvDays(r.days)) + '</span></div>' +
      '<p class="lv-appr-reason">' + esc(r.reason) + '</p>' +
      '<div class="lv-appr-stage">' + lvMini(r) + '<span class="xs">Stage ' + (r.stage + 1) + ' of ' + r.path.length + ' · <b>' + esc(stage.name) + '</b></span></div>' +
      (r.status === 'query' ? '<div class="lv-appr-q">' + icon('message', 'i-sm') + 'Query raised — waiting for the applicant’s reply</div>' : '') +
      '<div class="lv-appr-btns"><button class="btn btn-sm btn-ghost" data-act="lvOpen" data-id="' + esc(r.id) + '">Details</button><span class="spacer"></span>' +
      '<button class="btn btn-sm btn-danger" data-act="lvQuick" data-id="' + esc(r.id) + '" data-action="reject" title="Reject">' + icon('x') + '</button>' +
      '<button class="btn btn-sm" data-act="lvQuick" data-id="' + esc(r.id) + '" data-action="query">' + icon('message') + 'Query</button>' +
      '<button class="btn btn-sm btn-primary" data-act="lvQuick" data-id="' + esc(r.id) + '" data-action="approve"' + (r.status === 'query' ? ' disabled' : '') + '>' + icon('check') + 'Approve</button></div></div>';
  };
  const waiting = d.pending.filter((r) => r.status === 'pending'), queried = d.pending.filter((r) => r.status === 'query');
  return (d.pending.length
    ? '<div class="lv-sec-h"><h2>Waiting for you</h2><span class="muted small">' + plural(waiting.length, 'request') + (queried.length ? ' · ' + queried.length + ' with an open query' : '') + '</span></div><div class="lv-appr-grid">' + waiting.concat(queried).map(card).join('') + '</div>'
    : '<div class="card card-pad">' + emptyState('checkCircle', 'All caught up', 'No leave or movement requests are waiting for you.', '', false) + '</div>') +
    (d.decided.length ? '<div class="card"><div class="card-head"><span class="i-tile sm tone-slate">' + icon('history') + '</span><h2>Recently handled by you</h2></div><div class="card-body lv-list-wrap">' + lvList(d.decided, true, ['', '']) + '</div></div>' : '');
}
ACT.lvQuick = (d, btn) => {
  if (d.action === 'approve') { lvQuickGo(d.id, 'approve', '', btn); return; }
  const r = LV.desk.pending.find((x) => x.id === d.id);
  LV.quick = { id: d.id, action: d.action };
  formModal(d.action === 'query' ? 'Raise a query' : 'Reject request', esc(r.name) + ' · ' + esc(r.ref) + ' · ' + esc(lvWhen(r)), 'lvQuick',
    field(d.action === 'query' ? 'Your question' : 'Reason for rejecting', '<textarea name="note" rows="3" maxlength="500" autofocus placeholder="' + (d.action === 'query' ? 'e.g. Who will take your classes on these days?' : 'e.g. Internal exams are scheduled that week') + '"></textarea>'),
    d.action === 'query' ? 'Send query' : 'Reject', '', d.action === 'reject');
};
FORMS.lvQuick = (f, btn) => lvQuickGo(LV.quick.id, LV.quick.action, f.note.value, btn, true);
function lvQuickGo(id, action, note, btn, modal) {
  return busy(btn, async () => {
    const r = await call('leaveAct', { id, action, note });
    if (modal) closeModal();
    toast({ approve: r.request.status === 'approved' ? 'Approved ' + r.request.ref + '.' : 'Approved and forwarded to ' + r.request.path[r.request.stage].name + '.', reject: 'Rejected ' + r.request.ref + '.', query: 'Query sent to ' + r.request.name + '.' }[action]);
    lvNavCount();
    await refresh();
  });
}

function lvStaffHtml(d) {
  const onToday = d.staff.filter((s) => s.today);
  const pendingAll = d.all.filter((r) => r.status === 'pending' || r.status === 'query').length;
  const taken = d.staff.reduce((n, s) => n + s.used, 0);
  const row = (s) => {
    const pct = s.total ? Math.min(100, (s.used + s.pending) / s.total * 100) : 100;
    return '<tr><td>' + avatar(s.name, 'sm') + '</td><td><b>' + esc(s.name) + '</b><div class="xs muted">' + esc(s.username) + (s.role === 'admin' ? ' · admin' : '') + '</div></td>' +
      '<td><button class="lv-allow' + (s.custom ? ' custom' : '') + '" data-act="lvAllow" data-uid="' + esc(s.id) + '" title="Change allowance">' + lvNum(s.total) + icon('edit', 'i-sm') + '</button></td>' +
      '<td class="num">' + lvNum(s.CL) + '</td><td class="num">' + lvNum(s.OD) + '</td><td class="num">' + lvNum(s.ML) + '</td>' +
      '<td class="lv-prog-cell"><div class="lv-prog' + (s.remaining <= 2 ? ' low' : '') + '"><i style="width:' + (s.total ? Math.min(100, s.used / s.total * 100) : 0) + '%"></i><i class="p" style="width:' + Math.max(0, pct - (s.total ? s.used / s.total * 100 : 0)) + '%"></i></div>' +
      '<span class="xs">' + lvNum(s.used) + ' used' + (s.pending ? ' · ' + lvNum(s.pending) + ' pending' : '') + '</span></td>' +
      '<td class="num"><b class="' + (s.remaining <= 2 ? 'lv-low' : '') + '">' + lvNum(s.remaining) + '</b></td>' +
      '<td><span class="lv-slots sm">' + Array.from({ length: Math.max(d.settings.movementsPerMonth, 1) }, (_, i) => '<i class="' + (i < s.movementsHeld ? 'on' : '') + '"></i>').join('') + '</span> <span class="xs muted">' + s.movementsHeld + '/' + d.settings.movementsPerMonth + '</span></td>' +
      '<td>' + (s.today ? badge(s.today, 'warning') : '<span class="xs muted">On duty</span>') + '</td></tr>';
  };
  return '<div class="grid-4 kpis lv-kpis">' + kpi('Staff', d.staff.length, 'teachers and admins', 'users') + kpi('Away today', onToday.length, onToday.length ? esc(onToday.slice(0, 3).map((s) => s.name.split(' ')[0]).join(', ')) + (onToday.length > 3 ? '…' : '') : 'everyone on duty', 'calendar') +
    kpi('Awaiting approval', pendingAll, 'leave + movement requests', 'clock') + kpi('Leave taken', lvNum(taken) + '<small> days</small>', 'counted days in ' + esc(d.year.label), 'chart') + '</div>' +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-indigo">' + icon('users') + '</span><div><h2>Staff leave progress</h2><div class="xs muted">Leave year ' + esc(d.year.label) + ' · movements for ' + esc(d.monthLabel) + ' · click an allowance to change it</div></div><span class="spacer"></span>' +
    '<button class="btn btn-sm" data-act="lvReport" data-scope="all">' + icon('download') + 'Excel</button></div>' +
    '<div class="table-wrap"><table class="table lv-staff"><thead><tr><th></th><th>Staff</th><th>Allowance</th><th class="num">CL</th><th class="num">OD</th><th class="num">ML</th><th>Progress</th><th class="num">Left</th><th>Movements</th><th>Today</th></tr></thead><tbody>' +
    (d.staff.length ? d.staff.map(row).join('') : '<tr><td colspan="10" class="muted">No staff accounts.</td></tr>') + '</tbody></table></div></div>';
}
ACT.lvAllow = (d) => {
  const s = LV.desk.staff.find((x) => x.id === d.uid);
  LV.allowUid = d.uid;
  formModal('Leave allowance', esc(s.name) + ' · leave year ' + esc(LV.desk.year.label), 'lvAllow',
    field('Days allowed this year', '<input type="number" name="days" min="0" max="365" step="0.5" value="' + s.total + '">', 'The default for everyone is ' + LV.desk.settings.total + ' days (Settings tab).') +
    check('useDefault', 'Use the default (' + LV.desk.settings.total + ' days)', !s.custom), 'Save');
};
FORMS.lvAllow = (f, btn) => busy(btn, async () => {
  await call('leaveAllowance', { uid: LV.allowUid, days: f.useDefault.checked ? null : f.days.value });
  closeModal(); toast('Allowance saved.'); await refresh();
});

function lvAllHtml(d) {
  return '<div class="card"><div class="card-head"><span class="i-tile sm tone-blue">' + icon('list') + '</span><h2>All requests</h2><span class="spacer"></span>' +
    '<select id="lvAllKind" data-change="lvAllFilter"><option value="">Leave and movements</option><option value="leave">Leave only</option><option value="movement">Movements only</option><option value="student">Student OD / ML</option></select>' +
    '<select id="lvAllStatus" data-change="lvAllFilter"><option value="">Any status</option><option value="pending">Awaiting approval</option><option value="query">Query raised</option><option value="approved">Approved</option><option value="rejected">Rejected</option><option value="cancelled">Cancelled</option></select>' +
    '<input type="search" id="lvAllQ" placeholder="Search name, ref, reason" data-input="lvAllFilter"></div><div class="card-body lv-list-wrap" id="lvAllList">' +
    lvList(d.all, true, ['No requests yet', 'Applications from all staff appear here.']) + '</div></div>';
}
ACT.lvAllFilter = () => {
  const k = $('#lvAllKind').value, st = $('#lvAllStatus').value, q = $('#lvAllQ').value.trim().toLowerCase();
  const list = LV.desk.all.filter((r) => (!k || r.kind === k) && (!st || r.status === st) && (!q || (r.name + ' ' + r.ref + ' ' + r.reason + ' ' + r.type).toLowerCase().indexOf(q) >= 0));
  $('#lvAllList').innerHTML = lvList(list, true, ['Nothing matches', 'Try another filter.']);
};
INPUTS.lvAllFilter = () => ACT.lvAllFilter();

/* ---------- settings (admin) ---------- */
function lvSettingsHtml(d) {
  const st = d.settings;
  LV.paths = { leave: st.leavePath.map((p) => ({ name: p.name, approvers: p.approvers.map((a) => a.id) })), movement: st.movementPath.map((p) => ({ name: p.name, approvers: p.approvers.map((a) => a.id) })) };
  return '<form data-form="lvSettings" novalidate class="lv-settings"><div class="lv-split">' +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-blue">' + icon('calendar') + '</span><h2>Leave rules</h2></div><div class="card-body">' +
    '<div class="form-grid">' + field('Total leave per year (days)', '<input type="number" name="total" min="0" max="365" step="0.5" value="' + st.total + '">', 'Every staff member’s allowance unless changed on the Staff dashboard.') +
    field('Leave year starts in', '<select name="yearStart">' + LV_MONTHS.map((m, i) => '<option value="' + (i + 1) + '"' + (st.yearStart === i + 1 ? ' selected' : '') + '>' + m + '</option>').join('') + '</select>') + '</div>' +
    '<div class="label" style="margin-top:var(--sp-2)">Counted against the allowance</div><div class="row-wrap">' +
    ['CL', 'OD', 'ML'].map((t) => check('c' + t, t + ' — ' + st.types[t].label, st.counted[t])).join('') + '</div>' +
    check('excludeSundays', 'Don’t count Sundays inside a leave period', st.excludeSundays) + '</div></div>' +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-amber">' + icon('clock') + '</span><h2>Movement rules</h2></div><div class="card-body"><div class="form-grid">' +
    field('Movements per month', '<input type="number" name="movementsPerMonth" min="0" max="31" value="' + st.movementsPerMonth + '">') +
    field('Longest movement (minutes)', '<input type="number" name="movementMaxMinutes" min="0" max="600" step="15" value="' + st.movementMaxMinutes + '">', '0 = no limit') + '</div></div></div></div>' +
    '<div class="lv-split"><div class="card"><div class="card-head"><span class="i-tile sm tone-green">' + icon('layers') + '</span><div><h2>Leave approval path</h2><div class="xs muted">Stages in order. No approvers = the administrators.</div></div></div><div class="card-body" id="lvPath-leave"></div></div>' +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-green">' + icon('layers') + '</span><div><h2>Movement approval path</h2><div class="xs muted">Stages in order. No approvers = the administrators.</div></div></div><div class="card-body" id="lvPath-movement"></div></div></div>' +
    '<div class="form-actions" style="justify-content:flex-start"><button class="btn btn-primary" type="submit">' + icon('check') + 'Save leave settings</button><span class="xs muted">Changes to the paths apply to new applications; ones already in progress keep their path.</span></div></form>';
}
function lvPathsRender() {
  ['leave', 'movement'].forEach((kind) => {
    const box = $('#lvPath-' + kind); if (!box) return;
    const staff = LV.desk.staffPick || [];
    const list = LV.paths[kind];
    box.innerHTML = '<ol class="lv-stages">' + list.map((st, i) => {
      const names = st.approvers.map((id) => (staff.find((x) => x.id === id) || {}).name).filter(Boolean);
      return '<li><span class="lv-stage-n">' + (i + 1) + '</span><div class="lv-stage-body">' +
        '<input type="text" value="' + esc(st.name) + '" maxlength="60" data-input="lvStageName" data-kind="' + kind + '" data-i="' + i + '" aria-label="Stage name">' +
        '<details class="lv-pick"><summary>' + icon('users', 'i-sm') + (names.length ? esc(names.join(', ')) : '<span class="muted">Administrators (default)</span>') + '</summary><div class="lv-pick-list">' +
        staff.map((u) => '<label class="check"><input type="checkbox" data-change="lvPick" data-kind="' + kind + '" data-i="' + i + '" data-uid="' + esc(u.id) + '"' + (st.approvers.indexOf(u.id) >= 0 ? ' checked' : '') + '><span>' + esc(u.name) + (u.role === 'admin' ? ' <span class="xs muted">admin</span>' : '') + '</span></label>').join('') + '</div></details></div>' +
        '<div class="lv-stage-tools"><button type="button" class="btn-icon sm" data-act="lvStageMove" data-kind="' + kind + '" data-i="' + i + '" data-d="-1" title="Move up"' + (i ? '' : ' disabled') + '>' + icon('up') + '</button>' +
        '<button type="button" class="btn-icon sm" data-act="lvStageDel" data-kind="' + kind + '" data-i="' + i + '" title="Remove stage"' + (list.length > 1 ? '' : ' disabled') + '>' + icon('trash') + '</button></div></li>';
    }).join('') + '</ol>' + (list.length < 6 ? '<button type="button" class="btn btn-sm" data-act="lvStageAdd" data-kind="' + kind + '">' + icon('plus') + 'Add stage</button>' : '');
  });
}
INPUTS.lvStageName = (el) => { LV.paths[el.dataset.kind][Number(el.dataset.i)].name = el.value; };
ACT.lvPick = (d, el) => {
  const st = LV.paths[d.kind][Number(d.i)];
  st.approvers = st.approvers.filter((x) => x !== d.uid);
  if (el.checked) st.approvers.push(d.uid);
  const det = el.closest('details');
  const names = st.approvers.map((id) => (LV.desk.staffPick.find((x) => x.id === id) || {}).name).filter(Boolean);
  det.querySelector('summary').innerHTML = icon('users', 'i-sm') + (names.length ? esc(names.join(', ')) : '<span class="muted">Administrators (default)</span>');
};
ACT.lvStageAdd = (d) => { LV.paths[d.kind].push({ name: 'Stage ' + (LV.paths[d.kind].length + 1), approvers: [] }); lvPathsRender(); };
ACT.lvStageDel = (d) => { LV.paths[d.kind].splice(Number(d.i), 1); lvPathsRender(); };
ACT.lvStageMove = (d) => { const a = LV.paths[d.kind], i = Number(d.i), j = i + Number(d.d); if (j < 0 || j >= a.length) return; [a[i], a[j]] = [a[j], a[i]]; lvPathsRender(); };
FORMS.lvSettings = (f, btn) => busy(btn, async () => {
  $$('input[data-input="lvStageName"]').forEach((el) => { LV.paths[el.dataset.kind][Number(el.dataset.i)].name = el.value; });
  await call('leaveSaveSettings', {
    total: f.total.value, yearStart: f.yearStart.value, excludeSundays: f.excludeSundays.checked,
    counted: { CL: f.cCL.checked, OD: f.cOD.checked, ML: f.cML.checked },
    movementsPerMonth: f.movementsPerMonth.value, movementMaxMinutes: f.movementMaxMinutes.value,
    leavePath: LV.paths.leave, movementPath: LV.paths.movement
  });
  toast('Leave settings saved.');
  lvNavCount();
  await refresh();
});

/* =====================================================================
   STUDENTS — OD / ML applications (Attendance → OD / ML requests)
   Path: Submitted → Class faculty → HOD → Vice Principal → Approved.
   Only a fully approved application changes the student's attendance.
   ===================================================================== */
const SR_TONE = { OD: 'violet', ML: 'pink' };
function srProgress(r) {
  const steps = r.path.length + 2; // Submitted, each stage, Approved
  const done = r.status === 'approved' ? steps : 1 + r.path.filter((p) => p.state === 'done').length;
  const pct = Math.round(done / steps * 100);
  const stage = r.path[Math.min(r.stage, r.path.length - 1)];
  const text = { pending: 'With ' + stage.name + ' · step ' + (done + 1) + ' of ' + steps, query: stage.name + ' asked a question — reply to continue', approved: 'Approved — now in your attendance',
    rejected: 'Not approved by ' + stage.name, cancelled: 'Withdrawn' }[r.status];
  return '<div class="sr-bar ' + r.status + '"><div class="sr-bar-h"><b>' + esc(text) + '</b><span>' + pct + '%</span></div><div class="sr-bar-track"><i style="width:' + pct + '%"></i></div></div>';
}
route(/^\/attendance\/requests$/, async (params) => {
  if (!S.me || S.me.role !== 'student') { go('/attendance'); return null; }
  const d = await call('stuLeaveHome');
  LV.stu = d;
  const card = (r) => '<article class="card sr-card st-' + r.status + '"><div class="sr-top">' + lvTile(r) +
    '<div class="sr-main"><b>' + esc(r.typeLabel) + '</b><span>' + esc(lvWhen(r)) + ' · ' + lvDays(r.days) + '</span></div>' + lvStatus(r.status) + '</div>' +
    '<p class="sr-reason">' + esc(r.reason) + '</p>' + srProgress(r) + lvStepper(r) +
    (r.canReply ? notice('<b>' + esc(r.path[r.stage].name) + ' asked:</b> “' + esc((r.trail.filter((t) => t.action === 'query').slice(-1)[0] || {}).note || '') + '” <button class="link" data-act="lvOpen" data-id="' + esc(r.id) + '">Reply</button>', 'warn', 'message') : '') +
    '<div class="sr-foot"><span class="xs muted">' + esc(r.ref) + ' · applied ' + esc(rel(r.createdAt)) + '</span><span class="spacer"></span><button class="btn btn-sm btn-ghost" data-act="lvOpen" data-id="' + esc(r.id) + '">Details' + icon('arrowRight', 'i-sm') + '</button></div></article>';
  const how = '<ol class="sr-route"><li><span>' + icon('send', 'i-sm') + '</span><div><b>You apply</b><em>OD or ML with dates and a reason</em></div></li>' +
    d.path.map((n, i) => '<li><span>' + icon('user', 'i-sm') + '</span><div><b>' + esc(n) + '</b><em>' + esc(d.approvers[i].join(', ') || 'To be assigned') + '</em></div></li>').join('') +
    '<li class="fin"><span>' + icon('checkCircle', 'i-sm') + '</span><div><b>Shows in your attendance</b><em>' + (d.mlCountsPresent ? 'OD and ML days count as present' : 'OD days count as present') + '</em></div></li></ol>';
  const open = d.requests.filter((r) => r.status === 'pending' || r.status === 'query');
  return {
    title: 'OD / ML requests',
    html: pageHead('OD / ML requests', {
      crumbs: [['Attendance', '/attendance'], ['OD / ML requests']],
      sub: 'Apply for On Duty or Medical Leave. It needs approval from your class faculty, the HOD and the Vice Principal — only then is your attendance updated.',
      actions: '<button class="btn btn-primary" data-act="srApply">' + icon('plus') + 'Apply for OD / ML</button>'
    }) +
      '<div class="lv"><div class="grid-4 kpis lv-kpis">' + kpi('In progress', open.length, open.length ? 'waiting for approval' : 'nothing pending', 'clock') +
      kpi('OD approved', lvNum(d.approvedOD) + '<small> ' + (d.approvedOD === 1 ? 'day' : 'days') + '</small>', 'so far', 'building') + kpi('ML approved', lvNum(d.approvedML) + '<small> ' + (d.approvedML === 1 ? 'day' : 'days') + '</small>', 'so far', 'activity') +
      kpi('Applications', d.requests.length, 'in total', 'list') + '</div>' +
      '<div class="lv-split"><div class="sr-list">' + (d.requests.length ? d.requests.map(card).join('') : '<div class="card card-pad">' + emptyState('send', 'No applications yet', 'Were you on duty for the college, or unwell? Apply so your attendance reflects it.', '<button class="btn btn-primary" data-act="srApply">' + icon('plus') + 'Apply for OD / ML</button>', false) + '</div>') + '</div>' +
      '<div class="card"><div class="card-head"><span class="i-tile sm tone-green">' + icon('layers') + '</span><div><h2>How approval works</h2><div class="xs muted">Every stage must approve, in this order</div></div></div><div class="card-body">' + how + '</div></div></div></div>',
    after: () => { if (params.get('open')) ACT.lvOpen({ id: params.get('open') }); }
  };
});
ACT.srApply = () => {
  const d = LV.stu;
  const t0 = todayStr();
  const opt = (t, desc) => '<label class="lv-type-opt tone-' + SR_TONE[t] + '"><input type="radio" name="type" value="' + t + '"' + (t === 'OD' ? ' checked' : '') + '>' +
    '<span>' + icon(LV_TYPE_ICON[t]) + '<b>' + t + '</b><small>' + esc(d.types[t]) + '</small><em>' + desc + '</em></span></label>';
  formModal('Apply for OD / ML', 'Goes to ' + d.path.map(esc).join(' → '), 'srApply',
    '<div class="lv-type-opts sr-types">' + opt('OD', 'Representing the college: events, sports, NSS…') + opt('ML', 'You were unwell or had treatment') + '</div>' +
    '<div class="form-grid">' + field('From', '<input type="date" name="from" value="' + t0 + '" data-change="srCalc" required>') + field('To', '<input type="date" name="to" value="' + t0 + '" data-change="srCalc" required>') + '</div>' +
    field('Reason', '<textarea name="reason" rows="3" maxlength="500" placeholder="e.g. Represented the college at the inter-collegiate debate, Madras Christian College"></textarea>', 'For ML, mention the doctor or hospital, and keep the medical certificate ready in case you are asked for it.') +
    '<div class="lv-calc" id="srCalc"></div>', 'Submit application');
  ACT.srCalc();
};
ACT.srCalc = () => {
  const f = $('form[data-form="srApply"]'); if (!f) return;
  if (f.from.value && f.to.value && f.to.value < f.from.value) f.to.value = f.from.value;
  let n = 0, sun = 0;
  if (f.from.value && f.to.value) for (let x = new Date(f.from.value + 'T00:00'); toDateInput(x.getTime()) <= f.to.value; x.setDate(x.getDate() + 1)) { if (x.getDay() === 0) sun++; else n++; }
  $('#srCalc').innerHTML = '<div><b>' + lvDays(n) + '</b><span>' + (sun ? plural(sun, 'Sunday') + ' left out' : 'college days') + '</span></div>' +
    '<div><b>' + LV.stu.path.length + ' approvals</b><span>' + esc(LV.stu.path.join(' → ')) + '</span></div>';
};
FORMS.srApply = (f, btn) => busy(btn, async () => {
  const type = (f.querySelector('input[name=type]:checked') || {}).value;
  const r = await call('stuLeaveApply', { type, from: f.from.value, to: f.to.value, reason: f.reason.value });
  closeModal();
  toast(r.request.ref + ' sent to ' + r.request.path[0].name + '.');
  await refresh();
});

/* ---------- admin: who approves student OD / ML ---------- */
function srPickNames(ids) { return ids.map((id) => (LV.desk.staffPick.find((x) => x.id === id) || {}).name).filter(Boolean); }
function srGet(key) { const [a, b] = key.split('|'); return b != null ? (LV.stuCfg[a][b] || []) : LV.stuCfg[a]; }
function srSet(key, ids) { const [a, b] = key.split('|'); if (b != null) { if (ids.length) LV.stuCfg[a][b] = ids; else delete LV.stuCfg[a][b]; } else LV.stuCfg[a] = ids; }
function srPicker(key, fallback) {
  const ids = srGet(key), names = srPickNames(ids);
  return '<details class="lv-pick"><summary>' + icon('users', 'i-sm') + '<span data-sum="' + esc(key) + '">' + (names.length ? esc(names.join(', ')) : '<span class="muted">' + esc(fallback) + '</span>') + '</span></summary><div class="lv-pick-list">' +
    LV.desk.staffPick.map((u) => '<label class="check"><input type="checkbox" data-change="srPick" data-key="' + esc(key) + '" data-fallback="' + esc(fallback) + '" data-uid="' + esc(u.id) + '"' + (ids.indexOf(u.id) >= 0 ? ' checked' : '') + '><span>' + esc(u.name) + (u.role === 'admin' ? ' <span class="xs muted">admin</span>' : '') + '</span></label>').join('') + '</div></details>';
}
function lvStudentSettingsHtml(d) {
  const c = d.student;
  LV.stuCfg = { classFaculty: Object.assign({}, c.classFaculty), hod: Object.assign({}, c.hod), hodDefault: c.hodDefault.slice(), vp: c.vp.slice() };
  return '<form data-form="srSettings" novalidate class="card"><div class="card-head"><span class="i-tile sm tone-violet">' + icon('cap') + '</span><div><h2>Student OD / ML approvals</h2>' +
    '<div class="xs muted">Class faculty → HOD → Vice Principal. Only the last approval changes the student’s attendance.</div></div></div><div class="card-body">' +
    '<div class="form-grid">' + field('Vice Principal', srPicker('vp', 'Administrators (default)')) + field('HOD for every class', srPicker('hodDefault', 'Administrators (default)'), 'Unless a class below names its own HOD.') + '</div>' +
    (c.batches.length ? '<div class="table-wrap"><table class="table sr-classes"><thead><tr><th>Class</th><th>Class faculty</th><th>HOD</th></tr></thead><tbody>' +
      c.batches.map((b) => '<tr><td><b>' + esc(b.label) + '</b></td><td>' + srPicker('classFaculty|' + b.key, 'The student’s course teachers') + '</td><td>' + srPicker('hod|' + b.key, 'HOD for every class') + '</td></tr>').join('') + '</tbody></table></div>'
      : '<p class="small muted">Classes appear here once students have a batch / class set.</p>') +
    check('mlCountsPresent', 'Approved medical leave counts as present', c.mlCountsPresent, 'Approved OD always counts as present. Turn this off to show ML days but still count them as absent.') +
    '<div class="form-actions" style="justify-content:flex-start"><button class="btn btn-primary" type="submit">' + icon('check') + 'Save student approvals</button></div></div></form>';
}
ACT.srPick = (d, el) => {
  const ids = srGet(d.key).filter((x) => x !== d.uid);
  if (el.checked) ids.push(d.uid);
  srSet(d.key, ids);
  const names = srPickNames(ids);
  const sum = document.querySelector('[data-sum="' + d.key + '"]');
  if (sum) sum.innerHTML = names.length ? esc(names.join(', ')) : '<span class="muted">' + esc(d.fallback) + '</span>';
};
FORMS.srSettings = (f, btn) => busy(btn, async () => {
  await call('stuLeaveSettings', Object.assign({}, LV.stuCfg, { mlCountsPresent: f.mlCountsPresent.checked }));
  toast('Student OD / ML approvals saved.');
  lvNavCount();
  await refresh();
});
