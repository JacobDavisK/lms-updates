'use strict';
/* =====================================================================
   STATE
   ===================================================================== */
const S = {
  token: null, me: null, pending: null, seq: 0, flash: null, unread: 0, pollers: [], ctx: {}, lastInput: Date.now(),
  // exam engine
  attempt: null, q: Promise.resolve(), lastV: 0, listeners: [], intervals: [], fsActive: false, examHash: ''
};
const ACT = Object.create(null);    // click handlers:  data-act="name"
const FORMS = Object.create(null);  // submit handlers: data-form="name"
const INPUTS = Object.create(null); // input handlers:  data-input="name"
const app = document.getElementById('app');
const $ = (sel, root) => (root || document).querySelector(sel);
const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

const prefs = {
  get(k, d) { try { const v = localStorage.getItem('oq.' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('oq.' + k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } }
};
// The session token lives only for this browser tab (sessionStorage), so a
// reload keeps you signed in but closing the tab signs you out.
const tokenStore = {
  get() { try { return sessionStorage.getItem('oq.token'); } catch (e) { return null; } },
  set(t) { try { if (t) sessionStorage.setItem('oq.token', t); else sessionStorage.removeItem('oq.token'); } catch (e) { /* unavailable */ } }
};

/* =====================================================================
   FORMATTING
   ===================================================================== */
function esc(v) {
  return String(v == null ? '' : v).replace(/[&<>"'`]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;', '`': '&#96;' }[c]));
}
function fmt(ms) { ms = Number(ms); if (!ms) return '—'; return new Date(ms).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }); }
function fmtDate(ms) { ms = Number(ms); if (!ms) return '—'; return new Date(ms).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }); }
function fmtDay(ms) { return new Date(Number(ms)).toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' }); }
function fmtTime(ms) { return new Date(Number(ms)).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }); }
function rel(ms) {
  const d = Number(ms) - Date.now();
  const a = Math.abs(d);
  const units = [['year', 31536e6], ['month', 2592e6], ['week', 6048e5], ['day', 864e5], ['hour', 36e5], ['minute', 6e4]];
  const rtf = new Intl.RelativeTimeFormat(undefined, { numeric: 'auto' });
  for (const [u, n] of units) if (a >= n) return rtf.format(Math.round(d / n), u);
  return d >= 0 ? 'in a moment' : 'just now';
}
function toLocalInput(ms) {
  if (!ms) return '';
  const d = new Date(Number(ms)); const p = (n) => String(n).padStart(2, '0');
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + 'T' + p(d.getHours()) + ':' + p(d.getMinutes());
}
function fromLocalInput(v) { return v ? new Date(v).getTime() : 0; }
function toDateInput(ms) { return ms ? toLocalInput(ms).slice(0, 10) : ''; }
function fromDateInput(v) { return v ? new Date(v + 'T00:00').getTime() : 0; }
function pct(a, b) { return b ? Math.round(a / b * 1000) / 10 : 0; }
function letter(i) { return 'ABCD'.charAt(i); }
function plural(n, one, many) { return n + ' ' + (n === 1 ? one : (many || one + 's')); }
function fileSize(n) { n = Number(n) || 0; if (n < 1024) return n + ' B'; if (n < 1048576) return (n / 1024).toFixed(1) + ' KB'; return (n / 1048576).toFixed(1) + ' MB'; }
function firstName(n) { return String(n || '').trim().split(/\s+/)[0] || ''; }
function initials(n) { const p = String(n || '?').trim().split(/\s+/); return ((p[0] || '?')[0] + (p.length > 1 ? p[p.length - 1][0] : '')).toUpperCase(); }
function hue(s) { let h = 0; s = String(s || ''); for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360; return h; }
function csv(rows) {
  return rows.map((r) => r.map((v) => {
    v = String(v == null ? '' : v);
    if (/^[=+\-@]/.test(v)) v = "'" + v;
    return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  }).join(',')).join('\n');
}
function downloadText(name, text, type) {
  const url = URL.createObjectURL(new Blob([text], { type: type || 'text/csv;charset=utf-8' }));
  const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}

/* ---------- markdown (escape first, then a small safe subset) ---------- */
function mdInline(t) {
  t = esc(t).replace(/\u0000/g, '');
  const held = [];
  const hold = (html) => { held.push(html); return '\u0000' + (held.length - 1) + '\u0000'; };
  const a = (url, label) => hold('<a href="' + url + '" target="_blank" rel="noopener noreferrer">' + label + '</a>');
  t = t.replace(/&#96;([^\n]+?)&#96;/g, (_, c) => hold('<code>' + c + '</code>'))
    // In-app links such as [Open the essay](#/mod/M123) stay in the same tab.
    .replace(/\[([^\]\n]+)\]\((#\/[A-Za-z0-9/_?=&.-]*)\)/g, (_, label, href) => hold('<a href="' + href + '">' + label + '</a>'))
    .replace(/\[([^\]\n]+)\]\(((?:https?:\/\/|mailto:)[^\s)]+)\)/g, (_, label, url) => a(url, label))
    .replace(/(^|[\s(])(https?:\/\/[^\s<)]+)/g, (_, pre, url) => pre + a(url, url))
    .replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[^*\w])\*([^*\s][^*\n]*?)\*(?!\w)/g, '$1<em>$2</em>')
    .replace(/(^|[^_\w])_([^_\s][^_\n]*?)_(?!\w)/g, '$1<em>$2</em>')
    .replace(/~~([^~\n]+)~~/g, '<del>$1</del>');
  return t.replace(/\u0000(\d+)\u0000/g, (_, n) => held[n]);
}
function md(src) {
  if (!src) return '';
  const lines = String(src).replace(/\r\n?/g, '\n').split('\n');
  const isBlockStart = (l) => /^(#{1,4}\s|```|>|\s*[-*+]\s+|\s*\d+[.)]\s+)/.test(l) || /^\s*([-*_])(\s*\1){2,}\s*$/.test(l);
  let html = '', i = 0;
  while (i < lines.length) {
    const l = lines[i];
    let m;
    if (/^```/.test(l)) {
      const buf = []; i++;
      while (i < lines.length && !/^```/.test(lines[i])) buf.push(lines[i++]);
      i++; html += '<pre><code>' + esc(buf.join('\n')) + '</code></pre>'; continue;
    }
    if ((m = l.match(/^(#{1,4})\s+(.*)$/))) { const n = m[1].length + 1; html += '<h' + n + '>' + mdInline(m[2]) + '</h' + n + '>'; i++; continue; }
    if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(l)) { html += '<hr>'; i++; continue; }
    if (/^>/.test(l)) {
      const buf = [];
      while (i < lines.length && /^>/.test(lines[i])) buf.push(lines[i++].replace(/^>\s?/, ''));
      html += '<blockquote>' + md(buf.join('\n')) + '</blockquote>'; continue;
    }
    if (/^\s*[-*+]\s+/.test(l)) {
      const buf = [];
      while (i < lines.length && /^\s*[-*+]\s+/.test(lines[i])) buf.push('<li>' + mdInline(lines[i++].replace(/^\s*[-*+]\s+/, '')) + '</li>');
      html += '<ul>' + buf.join('') + '</ul>'; continue;
    }
    if (/^\s*\d+[.)]\s+/.test(l)) {
      const buf = [];
      while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i])) buf.push('<li>' + mdInline(lines[i++].replace(/^\s*\d+[.)]\s+/, '')) + '</li>');
      html += '<ol>' + buf.join('') + '</ol>'; continue;
    }
    if (!l.trim()) { i++; continue; }
    const buf = [mdInline(lines[i++])];
    while (i < lines.length && lines[i].trim() && !isBlockStart(lines[i])) buf.push(mdInline(lines[i++]));
    html += '<p>' + buf.join('<br>') + '</p>';
  }
  return html;
}
function mdHelp() { return '<div class="md-help">Formatting: <code>**bold**</code> <code>*italic*</code> <code># Heading</code> <code>- list</code> <code>[link](https://…)</code> <code>`code`</code></div>'; }

/* =====================================================================
   UI PRIMITIVES
   ===================================================================== */
function avatar(name, size) {
  return '<span class="avatar' + (size ? ' ' + size : '') + '" style="--h:' + hue(name) + '" title="' + esc(name) + '">' + esc(initials(name)) + '</span>';
}
function badge(text, tone, ico) { return '<span class="badge ' + (tone || '') + '">' + (ico ? icon(ico) : '') + esc(text) + '</span>'; }
function progressBar(p, cls) { return '<div class="progress ' + (cls || '') + '"><i style="width:' + Math.max(0, Math.min(100, Number(p) || 0)) + '%"></i></div>'; }
function ring(p, size) {
  size = size || 52; const r = (size - 8) / 2; const c = 2 * Math.PI * r;
  const off = c * (1 - Math.max(0, Math.min(100, Number(p) || 0)) / 100);
  return '<span class="ring" style="width:' + size + 'px;height:' + size + 'px"><svg width="' + size + '" height="' + size + '">' +
    
    '<circle class="ring-track" cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke-width="6"/>' +
    '<circle class="ring-val" cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke-width="6" stroke-dasharray="' + c + '" stroke-dashoffset="' + off + '"/></svg><b>' + Math.round(p) + '%</b></span>';
}
function crumbs(list) {
  return '<nav class="crumbs" aria-label="Breadcrumb">' + list.map((c) => c[1] ? '<a href="#' + esc(c[1]) + '">' + esc(c[0]) + '</a>' : '<span>' + esc(c[0]) + '</span>').join(icon('right')) + '</nav>';
}
function pageHead(title, o) {
  o = o || {};
  return '<div class="page-head"><div>' + (o.crumbs ? crumbs(o.crumbs) : '') + '<h1>' + esc(title) + '</h1>' +
    (o.sub ? '<p class="sub">' + o.sub + '</p>' : '') + '</div>' + (o.actions ? '<div class="page-actions">' + o.actions + '</div>' : '') + '</div>';
}
function emptyState(ico, title, text, action, boxed) {
  return '<div class="empty' + (boxed === false ? '' : ' boxed') + '"><div class="e-icon">' + icon(ico) + '</div><h3>' + esc(title) + '</h3>' +
    (text ? '<p>' + text + '</p>' : '') + (action || '') + '</div>';
}
function notice(text, kind, ico) {
  const icons = { warn: 'alert', err: 'alert', ok: 'checkCircle' };
  return '<div class="notice ' + (kind || '') + '">' + icon(ico || icons[kind] || 'info') + '<div>' + text + '</div></div>';
}
function statCard(ico, tone, value, label) {
  return '<div class="card stat"><span class="i-tile tone-' + tone + '">' + icon(ico) + '</span><div><div class="v">' + value + '</div><div class="l">' + esc(label) + '</div></div></div>';
}
function gradeClass(p) { return p == null ? 'gp-none' : p >= 75 ? 'gp-hi' : p >= 50 ? 'gp-mid' : 'gp-lo'; }
function skeleton() {
  return '<div class="sk sk-title"></div><div class="grid-3" style="margin-bottom:1.25rem"><div class="sk sk-card"></div><div class="sk sk-card"></div><div class="sk sk-card"></div></div>' +
    '<div class="card card-pad"><div class="sk sk-line" style="width:60%"></div><div class="sk sk-line"></div><div class="sk sk-line" style="width:85%"></div><div class="sk sk-line" style="width:40%"></div></div>';
}
function errorState(msg) {
  // Refusals from the server get their own state: retrying won't help, so offer a way back instead.
  if (/permission|do not have access|you can only|are for (coordinators|hods|administrators)|only (administrators|coordinators)/i.test(String(msg))) {
    return emptyState('lock', 'You don’t have access to this', esc(msg), '<a class="btn" href="#' + homePath() + '">' + icon('arrowLeft') + 'Go back home</a>');
  }
  if (/cannot reach the server/i.test(String(msg))) return emptyState('alert', 'You appear to be offline', esc(msg), '<button class="btn" data-act="reload">' + icon('refresh') + 'Try again</button>');
  return emptyState('alert', 'Something went wrong', esc(msg), '<button class="btn" data-act="reload">' + icon('refresh') + 'Try again</button>');
}

/* ---------- toast ---------- */
function toast(msg, kind) {
  const t = document.createElement('div');
  t.className = 'toast' + (kind === 'err' ? ' toast-err' : '');
  t.innerHTML = icon(kind === 'err' ? 'alert' : 'checkCircle') + '<span></span>';
  t.querySelector('span').textContent = msg;
  $('#toast').appendChild(t);
  requestAnimationFrame(() => t.classList.add('in'));
  setTimeout(() => { t.classList.remove('in'); setTimeout(() => t.remove(), 260); }, kind === 'err' ? 6000 : 3200);
}

/* ---------- modal ---------- */
function openModal(html, size) {
  const root = $('#modal-root');
  root.innerHTML = '<div class="modal-bg"><div class="modal ' + (size || '') + '" role="dialog" aria-modal="true">' + html + '</div></div>';
  const f = root.querySelector('[autofocus]') || root.querySelector('.modal-body input:not([type=hidden]):not([type=checkbox]):not([type=radio]), .modal-body textarea, .modal-body select');
  if (f) f.focus();
  return root.querySelector('.modal');
}
function modalHead(title, sub) {
  return '<div class="modal-head"><div><h2>' + esc(title) + '</h2>' + (sub ? '<p class="muted">' + sub + '</p>' : '') + '</div>' +
    '<button class="btn-icon sm" type="button" data-act="close" aria-label="Close">' + icon('x') + '</button></div>';
}
function formModal(title, sub, formName, inner, submitLabel, size, danger) {
  return openModal(modalHead(title, sub) + '<div class="modal-body"><form data-form="' + formName + '" novalidate>' + inner +
    '<div class="form-actions"><button class="btn" type="button" data-act="close">Cancel</button>' +
    '<button class="btn ' + (danger ? 'btn-danger-solid' : 'btn-primary') + '" type="submit">' + esc(submitLabel) + '</button></div></form></div>', size);
}
function closeModal() { $('#modal-root').innerHTML = ''; }
function confirmBox(title, body, okLabel, danger) {
  return new Promise((res) => {
    openModal('<div class="modal-body" style="padding-top:1.5rem"><div class="confirm-icon ' + (danger ? 'danger' : '') + '">' + icon(danger ? 'alert' : 'info') + '</div>' +
      '<h2 style="font-size:1.15rem">' + esc(title) + '</h2><div class="muted">' + body + '</div>' +
      '<div class="form-actions"><button class="btn" data-act="mCancel">Cancel</button><button class="btn ' + (danger ? 'btn-danger-solid' : 'btn-primary') + '" data-act="mOk" autofocus>' + esc(okLabel) + '</button></div></div>', 'narrow');
    ACT.mCancel = () => { closeModal(); res(false); };
    ACT.mOk = () => { closeModal(); res(true); };
  });
}
ACT.close = () => closeModal();

/* =====================================================================
   SERVER CALLS
   ===================================================================== */
async function run(fn, ...args) {
  let r;
  try {
    r = await fetch('/rpc', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fn, args }) });
  } catch (e) { throw new Error('Cannot reach the server. Check your connection and try again.'); }
  let j;
  try { j = await r.json(); } catch (e) { throw new Error('The server sent an unexpected response (HTTP ' + r.status + ').'); }
  if (j.error) throw new Error(j.error);
  return j.result;
}
function isExpired(e) { return /SESSION_EXPIRED/.test(e && e.message); }
function call(action, payload) {
  return run('api', S.token, action, payload || {}).catch((e) => {
    if (isExpired(e)) endSession('Your session ended (timed out or signed in on another device). Please sign in again.');
    throw e;
  });
}
async function busy(btn, fn) {
  if (btn) { btn.disabled = true; btn.classList.add('is-busy'); }
  try { return await fn(); } catch (e) { if (!isExpired(e)) toast(e.message, 'err'); return undefined; } finally { if (btn) { btn.disabled = false; btn.classList.remove('is-busy'); } }
}

/* ---------- files ---------- */
function readFileB64(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result).split(',')[1] || '');
    r.onerror = () => rej(new Error('Could not read ' + file.name + '.'));
    r.readAsDataURL(file);
  });
}
async function uploadFile(file) {
  if (file.size > 10 * 1024 * 1024) throw new Error(file.name + ' is larger than 10 MB.');
  if (!file.size) throw new Error(file.name + ' is empty.');
  return call('uploadFile', { name: file.name, mime: file.type || 'application/octet-stream', data: await readFileB64(file) });
}
async function fetchFileBlob(f) {
  const r = await fetch('/file/' + encodeURIComponent(f.id), { headers: { Authorization: 'Bearer ' + S.token } });
  if (!r.ok) throw new Error('This file is not available to you.');
  return r.blob();
}
const PREVIEWABLE = ['image/png', 'image/jpeg', 'image/gif', 'image/webp', 'application/pdf'];
function fileIcon(f) { return /^image\//.test(f.mime) ? 'image' : 'file'; }
function fileChip(f, opts) {
  opts = opts || {};
  return '<span class="file-chip">' + icon(fileIcon(f)) + '<span style="min-width:0"><span class="fname" title="' + esc(f.name) + '">' + esc(f.name) + '</span> <span class="fsize">' + fileSize(f.size) + '</span></span>' +
    (PREVIEWABLE.indexOf(f.mime) >= 0 ? '<button type="button" class="btn-icon sm" title="Preview" data-act="previewFile" data-id="' + esc(f.id) + '" data-name="' + esc(f.name) + '" data-mime="' + esc(f.mime) + '">' + icon('eye') + '</button>' : '') +
    '<button type="button" class="btn-icon sm" title="Download" data-act="downloadFile" data-id="' + esc(f.id) + '" data-name="' + esc(f.name) + '">' + icon('download') + '</button>' +
    (opts.remove ? '<button type="button" class="btn-icon sm danger" title="Remove" data-act="' + opts.remove + '" data-id="' + esc(f.id) + '">' + icon('x') + '</button>' : '') + '</span>';
}
ACT.downloadFile = (d, btn) => busy(btn, async () => {
  const blob = await fetchFileBlob(d);
  const url = URL.createObjectURL(new Blob([blob], { type: 'application/octet-stream' }));
  const a = document.createElement('a'); a.href = url; a.download = d.name || 'download'; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
});
ACT.previewFile = (d, btn) => busy(btn, async () => {
  if (PREVIEWABLE.indexOf(d.mime) < 0) return;
  const blob = await fetchFileBlob(d);
  // The blob gets an explicit, allow-listed type so it can only render as an image or PDF.
  const url = URL.createObjectURL(new Blob([blob], { type: d.mime }));
  const body = d.mime === 'application/pdf' ? '<iframe class="preview-frame" src="' + url + '" title="' + esc(d.name) + '"></iframe>' : '<img class="preview-img" src="' + url + '" alt="' + esc(d.name) + '">';
  openModal(modalHead(d.name) + '<div class="modal-body">' + body + '<div class="form-actions"><button class="btn" data-act="downloadFile" data-id="' + esc(d.id) + '" data-name="' + esc(d.name) + '">' + icon('download') + 'Download</button><button class="btn btn-primary" data-act="close">Close</button></div></div>', 'xwide');
});

/* =====================================================================
   ROUTER
   ===================================================================== */
const ROUTES = [];
function route(re, fn) { ROUTES.push([re, fn]); }
function currentPath() { return location.hash.replace(/^#/, '') || '/dashboard'; }
function go(p) { if (location.hash === '#' + p) render(); else location.hash = p; }
function refresh() { return render({ keep: true }); }
async function render(opts) {
  opts = opts || {};
  if (!S.me || S.attempt) return;
  const main = $('#main');
  if (!main) return;
  // A page that handles its own sub-routes (e.g. switching conversations in Messages) updates in place.
  if (!opts.keep && S.stay) {
    const cur = currentPath().split('?')[0];
    try { if (S.stay(cur)) { highlightNav(cur); return; } } catch (e) { /* fall through to a normal render */ }
  }
  if (S.onLeave) { const leave = S.onLeave; S.onLeave = null; try { leave(); } catch (e) { /* page cleanup must not block navigation */ } }
  const seq = ++S.seq;
  const full = currentPath();
  const qi = full.indexOf('?');
  const p = qi >= 0 ? full.slice(0, qi) : full;
  const params = new URLSearchParams(qi >= 0 ? full.slice(qi + 1) : '');
  let hit = null;
  for (const [re, fn] of ROUTES) { const m = p.match(re); if (m) { hit = [fn, m.slice(1)]; break; } }
  highlightNav(p);
  closeMenus();
  document.body.classList.remove('nav-open');
  main.classList.toggle('keep', !!opts.keep); // refreshes update in place; only navigation animates in
  if (!opts.keep) { main.innerHTML = skeleton(); window.scrollTo(0, 0); }
  if (!hit) { main.innerHTML = emptyState('compass', 'Page not found', 'That page does not exist.', '<a class="btn btn-primary" href="#/dashboard">Go to dashboard</a>'); return; }
  const y = window.scrollY;
  S.ctx = {};
  try {
    const out = await hit[0](...hit[1].map((x) => (x == null ? x : decodeURIComponent(x))), params);
    if (seq !== S.seq || !out) return;
    document.title = (out.title ? out.title + ' · ' : '') + SITE;
    if (typeof chatBadge === 'function') chatBadge(); // keeps the "(3)" unread prefix
    const flash = S.flash; S.flash = null;
    main.innerHTML = (flash ? notice(esc(flash.text || flash), flash.kind || '') : '') + out.html;
    if (opts.keep) window.scrollTo(0, y);
    mountCharts();
    if (out.after) out.after(main);
  } catch (e) {
    if (seq !== S.seq || isExpired(e)) return;
    main.innerHTML = errorState(e.message);
  }
}
ACT.reload = () => render();
window.addEventListener('hashchange', () => {
  if (S.attempt) { // no navigating away mid-exam
    if (location.hash !== S.examHash) history.replaceState(null, '', S.examHash);
    return;
  }
  closeModal();
  render();
});

/* =====================================================================
   EVENT DELEGATION
   ===================================================================== */
function closeMenus(except) { $$('.menu-wrap.open').forEach((m) => { if (m !== except) m.classList.remove('open'); }); }
document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act]');
  if (!e.target.closest('.menu-wrap')) closeMenus();
  if (!el) return;
  const fn = ACT[el.dataset.act];
  if (!fn) return;
  e.preventDefault();
  if (el.closest('.menu')) closeMenus();
  fn(el.dataset, el, e);
});
ACT.menu = (d, el) => {
  const wrap = el.closest('.menu-wrap');
  const open = !wrap.classList.contains('open');
  closeMenus(wrap);
  wrap.classList.toggle('open', open);
  if (open && wrap.dataset.onopen && ACT[wrap.dataset.onopen]) ACT[wrap.dataset.onopen](wrap.dataset, wrap);
};
document.addEventListener('submit', (e) => {
  const f = e.target;
  const fn = FORMS[f.dataset.form];
  if (!fn) return;
  e.preventDefault();
  fn(f, e.submitter && e.submitter.type === 'submit' ? e.submitter : f.querySelector('button[type=submit]'));
});
document.addEventListener('change', (e) => {
  const t = e.target;
  if (t.matches('input[type=radio][data-qid]')) saveChoice(t.dataset.qid, Number(t.value));
  if (t.dataset.change && ACT[t.dataset.change]) ACT[t.dataset.change](t.dataset, t, e);
});
let inputTimer = null;
document.addEventListener('input', (e) => {
  const t = e.target;
  if (!t.dataset || !t.dataset.input || !INPUTS[t.dataset.input]) return;
  clearTimeout(inputTimer);
  inputTimer = setTimeout(() => INPUTS[t.dataset.input](t), Number(t.dataset.delay || 150));
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (S.attempt) return;
    if ($('.modal-bg')) { closeModal(); return; }
    closeMenus(); document.body.classList.remove('nav-open');
  }
  if (!S.attempt && S.me && ((e.key === 'k' && (e.ctrlKey || e.metaKey)) || (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName) && !document.activeElement.isContentEditable))) {
    const s = $('#globalSearch');
    if (s) { e.preventDefault(); s.focus(); s.select(); }
  }
});

/* =====================================================================
   THEME
   ===================================================================== */
function theme() { return document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light'; }
ACT.theme = () => {
  const t = theme() === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', t);
  prefs.set('theme', t);
  $$('.theme-ico').forEach((el) => { el.innerHTML = icon(t === 'dark' ? 'sun' : 'moon'); });
};
