'use strict';
/* =====================================================================
   CHART KIT — small, dependency-free SVG charts.
   Views insert a placeholder with chartSlot(kind, spec); render() then calls
   mountCharts(), which draws each chart at its container's real width and
   redraws on resize. Colours come from the --viz-* / --st-* / --seq-* tokens.
   ===================================================================== */
const VIZ = { seq: 0, pending: {}, live: [] };
const SVGNS = 'http://www.w3.org/2000/svg';

function chartSlot(kind, spec) {
  const id = 'viz' + (++VIZ.seq);
  VIZ.pending[id] = { kind, spec };
  return '<div class="viz" id="' + id + '"></div>';
}
function mountCharts() {
  Object.keys(VIZ.pending).forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    const c = VIZ.pending[id];
    delete VIZ.pending[id];
    c.el = el;
    VIZ.live.push(c);
    drawChart(c);
  });
  VIZ.live = VIZ.live.filter((c) => document.body.contains(c.el));
}
function drawChart(c) {
  const fn = { columns: drawColumns, area: drawArea, scatter: drawScatter, lines: drawLines }[c.kind];
  if (fn) c.el.innerHTML = fn(c.spec, Math.max(260, c.el.clientWidth || 600));
}
let vizResizeTimer = null;
window.addEventListener('resize', () => {
  clearTimeout(vizResizeTimer);
  vizResizeTimer = setTimeout(() => {
    VIZ.live = VIZ.live.filter((c) => document.body.contains(c.el));
    VIZ.live.forEach(drawChart);
  }, 120);
});

/* ---------- helpers ---------- */
function niceScale(max, n) {
  n = n || 4;
  if (!(max > 0)) return { max: n, step: 1 };
  const raw = max / n;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const f = raw / mag;
  const step = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * mag;
  return { max: Math.ceil(max / step) * step, step };
}
/** Nice scale; with unit (e.g. 60 for minutes shown as hours) ticks land on whole units. */
function scaleFor(max, unit) {
  if (!unit || max < unit * 1.5) return niceScale(max);
  const sc = niceScale(max / unit);
  return { max: sc.max * unit, step: sc.step * unit };
}
function compact(v) {
  v = Number(v) || 0;
  const a = Math.abs(v);
  if (a >= 1e6) return (v / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
  if (a >= 1e4) return Math.round(v / 1e3) + 'K';
  if (a >= 1e3) return (v / 1e3).toFixed(1).replace(/\.0$/, '') + 'K';
  return String(Math.round(v * 10) / 10);
}
/** Tooltip payload; rendered later with textContent, so labels are never parsed as HTML. */
function tip(title, rows) { return ' data-tip="' + esc(JSON.stringify({ t: title, r: rows })) + '" tabindex="0"'; }
function roundTop(x, y, w, h, r) {
  r = Math.min(r, h, w / 2);
  if (h <= 0) return '';
  return 'M' + x + ',' + (y + h) + 'V' + (y + r) + 'Q' + x + ',' + y + ' ' + (x + r) + ',' + y + 'H' + (x + w - r) + 'Q' + (x + w) + ',' + y + ' ' + (x + w) + ',' + (y + r) + 'V' + (y + h) + 'Z';
}
function legendHtml(items) {
  return '<div class="legend">' + items.map((it) => '<span><i class="' + (it.line ? 'line ' : '') + 'k-' + it.token + '"></i>' + esc(it.name) + '</span>').join('') + '</div>';
}
function xLabelEvery(n, plotW) { return Math.max(1, Math.ceil(n / Math.max(2, Math.floor(plotW / 58)))); }
function shortDay(key) { const [y, m, d] = key.split('-').map(Number); return new Date(y, m - 1, d).toLocaleDateString(undefined, { day: 'numeric', month: 'short' }); }
function longDay(key) { const [y, m, d] = key.split('-').map(Number); return new Date(y, m - 1, d).toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' }); }
function yAxis(sc, M, W, plotH, fmt) {
  let g = '';
  for (let v = 0; v <= sc.max + 1e-9; v += sc.step) {
    const y = M.t + plotH - (v / sc.max) * plotH;
    g += '<line class="' + (v === 0 ? 'v-base' : 'v-grid') + '" x1="' + M.l + '" x2="' + (W - M.r) + '" y1="' + y + '" y2="' + y + '"/>' +
      '<text x="' + (M.l - 8) + '" y="' + (y + 4) + '" text-anchor="end" class="tnum">' + esc((fmt || compact)(v)) + '</text>';
  }
  return g;
}

/* ---------- columns (single or stacked) ---------- */
function drawColumns(s, W) {
  const H = s.height || 210;
  const M = { l: 40, r: 8, t: 10, b: 26 };
  const n = s.labels.length;
  const plotW = W - M.l - M.r, plotH = H - M.t - M.b;
  const totals = s.labels.map((_, i) => s.series.reduce((a, se) => a + (Number(se.values[i]) || 0), 0));
  const sc = scaleFor(Math.max(...totals, 0), s.unit);
  const bw = plotW / n;
  const w = Math.max(3, Math.min(24, bw * 0.62));
  let g = yAxis(sc, M, W, plotH, s.yFmt);
  const every = xLabelEvery(n, plotW);
  for (let i = 0; i < n; i++) {
    const cx = M.l + bw * i + bw / 2;
    const x = cx - w / 2;
    let yCursor = M.t + plotH;
    let bars = '';
    const top = s.series.map((se) => Number(se.values[i]) || 0).map((v, k) => (v > 0 ? k : -1)).reduce((a, b) => Math.max(a, b), -1);
    s.series.forEach((se, k) => {
      const v = Number(se.values[i]) || 0;
      if (v <= 0) return;
      const h = (v / sc.max) * plotH;
      const gap = k > 0 && yCursor < M.t + plotH ? 2 : 0; // 2px surface gap between stacked segments
      const y = yCursor - h;
      const hh = h - gap;
      if (hh > 0) {
        bars += k === top ? '<path class="s-' + se.token + '" d="' + roundTop(x, y, w, hh, 4) + '"/>'
          : '<rect class="s-' + se.token + '" x="' + x + '" y="' + y + '" width="' + w + '" height="' + hh + '"/>';
      }
      yCursor = y;
    });
    const rows = s.series.map((se) => [se.name, (s.valFmt || compact)(Number(se.values[i]) || 0), se.token]);
    if (s.series.length > 1) rows.push(['Total', (s.valFmt || compact)(totals[i]), '']);
    g += '<g class="band"' + tip(s.tipTitle ? s.tipTitle(i) : s.labels[i], rows) + '><rect class="hl" x="' + (M.l + bw * i) + '" y="' + M.t + '" width="' + bw + '" height="' + plotH + '"/>' + bars +
      '<rect class="hit" x="' + (M.l + bw * i) + '" y="' + M.t + '" width="' + bw + '" height="' + plotH + '"/></g>';
    if (i % every === 0) g += '<text x="' + cx + '" y="' + (H - 8) + '" text-anchor="middle">' + esc(s.xFmt ? s.xFmt(s.labels[i]) : s.labels[i]) + '</text>';
  }
  const legend = s.series.length > 1 ? legendHtml(s.series.map((se) => ({ name: se.name, token: se.token }))) : '';
  return legend + '<svg width="' + W + '" height="' + H + '" role="img" aria-label="' + esc(s.label || 'Column chart') + '">' + g + '</svg>';
}

/* ---------- area / line (single series, crosshair hover) ---------- */
function drawArea(s, W) {
  const H = s.height || 210;
  const M = { l: 40, r: 44, t: 14, b: 26 };
  const n = s.values.length;
  const plotW = W - M.l - M.r, plotH = H - M.t - M.b;
  const sc = scaleFor(Math.max(...s.values, 0), s.unit);
  const X = (i) => M.l + (n === 1 ? plotW / 2 : (i / (n - 1)) * plotW);
  const Y = (v) => M.t + plotH - (v / sc.max) * plotH;
  let g = yAxis(sc, M, W, plotH, s.yFmt);
  const pts = s.values.map((v, i) => [X(i), Y(Number(v) || 0)]);
  const line = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ',' + p[1].toFixed(1)).join('');
  g += '<path class="v-area s-' + s.token + '" style="stroke:none" d="' + line + 'L' + pts[n - 1][0] + ',' + (M.t + plotH) + 'L' + pts[0][0] + ',' + (M.t + plotH) + 'Z"/>';
  g += '<path class="v-line s-' + s.token + '" style="fill:none" d="' + line + '"/>';
  const every = xLabelEvery(n, plotW);
  const step = n > 1 ? plotW / (n - 1) : plotW;
  for (let i = 0; i < n; i++) {
    const x = pts[i][0];
    g += '<g class="band"' + tip(s.tipTitle ? s.tipTitle(i) : s.labels[i], [[s.name, (s.valFmt || compact)(s.values[i]), s.token]]) + '>' +
      '<line class="xhair" x1="' + x + '" x2="' + x + '" y1="' + M.t + '" y2="' + (M.t + plotH) + '"/>' +
      '<circle class="hdot v-dot s-' + s.token + '" cx="' + x + '" cy="' + pts[i][1] + '" r="4"/>' +
      '<rect class="hit" x="' + (x - step / 2) + '" y="' + M.t + '" width="' + step + '" height="' + plotH + '"/></g>';
    if (i % every === 0) g += '<text x="' + x + '" y="' + (H - 8) + '" text-anchor="middle">' + esc(s.xFmt ? s.xFmt(s.labels[i]) : s.labels[i]) + '</text>';
  }
  const last = pts[n - 1];
  g += '<circle class="v-dot s-' + s.token + '" cx="' + last[0] + '" cy="' + last[1] + '" r="4"/>' +
    '<text class="v-endlabel" x="' + (last[0] + 8) + '" y="' + (last[1] + 4) + '">' + esc((s.valFmt || compact)(s.values[n - 1])) + '</text>';
  return '<svg width="' + W + '" height="' + H + '" role="img" aria-label="' + esc(s.label || 'Line chart') + '">' + g + '</svg>';
}

/* ---------- lines: several series (teams) over the same x labels; values may be negative ----------
   spec: { labels, series: [{ name, color, values, strong }], yFmt, valFmt, height, label, target } */
function drawLines(s, W) {
  const H = s.height || 230;
  const M = { l: 52, r: 16, t: 14, b: 26 };
  const n = s.labels.length;
  const plotW = W - M.l - M.r, plotH = H - M.t - M.b;
  const all = s.series.reduce((a, x) => a.concat(x.values.filter((v) => v != null && isFinite(v))), []).concat(s.target != null ? [s.target] : []);
  let lo = Math.min(0, ...all), hi = Math.max(0, ...all);
  if (hi === lo) hi = lo + 1;
  const sc = niceScale(hi - lo, 4);
  const step = sc.step, min = Math.floor(lo / step) * step, max = Math.max(min + step, Math.ceil(hi / step) * step);
  const X = (i) => M.l + (n === 1 ? plotW / 2 : (i / (n - 1)) * plotW);
  const Y = (v) => M.t + plotH - ((v - min) / (max - min)) * plotH;
  const f = s.yFmt || compact, vf = s.valFmt || f;
  let g = '';
  for (let v = min; v <= max + step / 2; v += step) {
    const y = Y(v);
    g += '<line class="' + (Math.abs(v) < step / 1e6 ? 'v-base' : 'v-grid') + '" x1="' + M.l + '" x2="' + (W - M.r) + '" y1="' + y + '" y2="' + y + '"/><text x="' + (M.l - 8) + '" y="' + (y + 4) + '" text-anchor="end" class="tnum">' + esc(f(Math.abs(v) < step / 1e6 ? 0 : v)) + '</text>';
  }
  if (s.target != null) g += '<line class="v-ref" stroke-dasharray="4 4" x1="' + M.l + '" x2="' + (W - M.r) + '" y1="' + Y(s.target) + '" y2="' + Y(s.target) + '"/><text class="v-note" x="' + (W - M.r) + '" y="' + (Y(s.target) - 4) + '" text-anchor="end">target ' + esc(vf(s.target)) + '</text>';
  s.series.forEach((x) => {
    let d = '', pen = false;
    x.values.forEach((v, i) => { if (v == null || !isFinite(v)) { pen = false; return; } d += (pen ? 'L' : 'M') + X(i).toFixed(1) + ',' + Y(v).toFixed(1); pen = true; });
    g += '<path class="v-line" style="stroke:' + esc(x.color) + ';stroke-width:' + (x.strong ? 3 : 2) + (x.dim ? ';opacity:.45' : '') + '" d="' + d + '"/>';
    x.values.forEach((v, i) => { if (v != null && isFinite(v)) g += '<circle class="v-dot" style="fill:' + esc(x.color) + '" cx="' + X(i) + '" cy="' + Y(v) + '" r="' + (x.strong ? 4 : 3) + '"/>'; });
  });
  const stepX = n > 1 ? plotW / (n - 1) : plotW;
  for (let i = 0; i < n; i++) {
    g += '<g class="band"' + tip(s.labels[i], s.series.filter((x) => x.values[i] != null).map((x) => [x.name, vf(x.values[i]), ''])) + '><rect class="hit" x="' + (X(i) - stepX / 2) + '" y="' + M.t + '" width="' + stepX + '" height="' + plotH + '"/></g>';
    g += '<text x="' + X(i) + '" y="' + (H - 8) + '" text-anchor="middle">' + esc(s.labels[i]) + '</text>';
  }
  return '<svg width="' + W + '" height="' + H + '" role="img" aria-label="' + esc(s.label || 'Line chart') + '">' + g + '</svg>' +
    (s.series.length > 1 ? '<div class="sm-legend">' + s.series.map((x) => '<span><i style="background:' + esc(x.color) + '"></i>' + esc(x.name) + '</span>').join('') + '</div>' : '');
}

/* ---------- scatter (time in course vs grade, coloured by risk status) ---------- */
function drawScatter(s, W) {
  const H = s.height || 280;
  const M = { l: 40, r: 16, t: 14, b: 38 };
  const plotW = W - M.l - M.r, plotH = H - M.t - M.b;
  const sx = niceScale(Math.max(...s.points.map((p) => p.x), 1));
  const X = (v) => M.l + (v / sx.max) * plotW;
  const Y = (v) => M.t + plotH - (v / 100) * plotH;
  let g = yAxis({ max: 100, step: 25 }, M, W, plotH, (v) => v + '%');
  for (let v = sx.step; v <= sx.max + 1e-9; v += sx.step) {
    g += '<text x="' + X(v) + '" y="' + (M.t + plotH + 16) + '" text-anchor="middle" class="tnum">' + esc(compact(v)) + '</text>';
  }
  g += '<text x="' + (M.l + plotW / 2) + '" y="' + (H - 4) + '" text-anchor="middle">' + esc(s.xLabel) + '</text>';
  if (s.xAvg != null && s.points.length > 1) {
    const x = X(s.xAvg);
    g += '<line class="v-ref" x1="' + x + '" x2="' + x + '" y1="' + M.t + '" y2="' + (M.t + plotH) + '"/><text class="v-note" x="' + (x + 4) + '" y="' + (M.t + 10) + '">avg time</text>';
  }
  if (s.yAvg != null && s.points.length > 1) {
    const y = Y(s.yAvg);
    g += '<line class="v-ref" x1="' + M.l + '" x2="' + (W - M.r) + '" y1="' + y + '" y2="' + y + '"/><text class="v-note" x="' + (W - M.r) + '" y="' + (y - 4) + '" text-anchor="end">avg grade</text>';
  }
  s.points.forEach((p) => {
    const x = X(p.x), y = Y(p.y);
    g += '<g class="pt" data-act="studentReport" data-id="' + esc(p.id) + '"' + tip(p.name, [['Grade', p.y + '%', ''], ['Time in course', (s.xFmt || compact)(p.x), ''], ['Status', p.statusLabel, '']]) + '>' +
      '<circle class="hit" cx="' + x + '" cy="' + y + '" r="12"/><circle class="v-dot s-' + p.status + '" cx="' + x + '" cy="' + y + '" r="5"/></g>';
  });
  return '<svg width="' + W + '" height="' + H + '" role="img" aria-label="' + esc(s.label || 'Scatter chart') + '">' + g + '</svg>';
}

/* ---------- heatmap (HTML grid, one-hue sequential ramp) ---------- */
function heatmapHtml(values, unit) {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const max = Math.max(...values, 0);
  const level = (v) => (!v || !max ? 0 : Math.max(1, Math.ceil((v / max) * 6)));
  let h = '<div class="heat" role="img" aria-label="Activity by day of week and hour"><span></span>';
  for (let c = 0; c < 24; c++) h += '<span class="hd">' + (c % 6 === 0 ? String(c).padStart(2, '0') : '') + '</span>';
  days.forEach((d, r) => {
    h += '<span class="rl">' + d + '</span>';
    for (let c = 0; c < 24; c++) {
      const v = values[r * 24 + c] || 0;
      h += '<span class="hc l' + level(v) + '"' + tip(d + ' ' + String(c).padStart(2, '0') + ':00–' + String((c + 1) % 24).padStart(2, '0') + ':00', [[unit, compact(v), '']]) + '></span>';
    }
  });
  h += '</div><div class="heat-legend">Less' + [0, 1, 2, 3, 4, 5, 6].map((l) => '<span class="hc l' + l + '" style="background:var(--seq-' + l + ')"></span>').join('') + 'More</div>';
  return h;
}

/* ---------- small pieces ---------- */
function sparkline(values, w, h) {
  w = w || 110; h = h || 30;
  if (!values.length) return '';
  const max = Math.max(...values, 1);
  const pts = values.map((v, i) => [2 + (i / Math.max(1, values.length - 1)) * (w - 6), h - 3 - (v / max) * (h - 7)]);
  const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ',' + p[1].toFixed(1)).join('');
  const l = pts[pts.length - 1];
  return '<svg class="spark" width="' + w + '" height="' + h + '" aria-hidden="true"><path d="' + d + '"/><circle cx="' + l[0] + '" cy="' + l[1] + '" r="3"/></svg>';
}
function meter(pctVal) {
  if (pctVal == null) return '<span class="muted">—</span>';
  return '<div class="meter"><div class="track"><i style="width:' + Math.max(0, Math.min(100, pctVal)) + '%"></i></div><b>' + pctVal + '%</b></div>';
}
function hbars(rows, fmtFn) {
  const max = Math.max(...rows.map((r) => r.value), 1);
  return '<div class="hbars">' + rows.map((r) => '<div class="hbar"><span class="hl" title="' + esc(r.label) + '">' + (r.icon || '') + esc(r.label) + '</span>' +
    '<div class="ht"><i style="width:' + (r.value / max * 100) + '%"></i></div><b>' + esc((fmtFn || compact)(r.value)) + '</b></div>').join('') + '</div>';
}
function deltaHtml(cur, prev, suffix) {
  if (prev == null || cur == null) return '';
  if (!prev && !cur) return '<span class="delta flat">no change</span>';
  if (!prev) return '<span class="delta up">' + icon('trending', 'i-sm') + ' new</span>';
  const ch = Math.round((cur - prev) / prev * 100);
  if (ch === 0) return '<span class="delta flat">no change</span>';
  return '<span class="delta ' + (ch > 0 ? 'up' : 'down') + '">' + icon(ch > 0 ? 'up' : 'down', 'i-sm') + Math.abs(ch) + '%</span>' + (suffix ? ' ' + suffix : '');
}
function tableView(head, rows) {
  return '<details class="viz-table"><summary>View as table</summary><div class="table-wrap"><table class="table"><thead><tr>' +
    head.map((h) => '<th>' + esc(h) + '</th>').join('') + '</tr></thead><tbody>' +
    rows.map((r) => '<tr>' + r.map((c) => '<td>' + esc(c) + '</td>').join('') + '</tr>').join('') + '</tbody></table></div></details>';
}
function hoursFmt(min) { min = Number(min) || 0; return min >= 60 ? (Math.round(min / 6) / 10) + ' h' : Math.round(min) + ' min'; }

/* ---------- tooltip layer ---------- */
const vizTip = document.createElement('div');
vizTip.className = 'viz-tip';
vizTip.setAttribute('role', 'tooltip');
document.body.appendChild(vizTip);
function showTip(el, x, y) {
  let data;
  try { data = JSON.parse(el.getAttribute('data-tip')); } catch (e) { return; }
  vizTip.textContent = '';
  const t = document.createElement('div'); t.className = 'tt'; t.textContent = data.t; vizTip.appendChild(t);
  (data.r || []).forEach((r) => {
    const row = document.createElement('div'); row.className = 'tr';
    if (r[2] && /^[a-z0-9-]+$/.test(r[2])) { const k = document.createElement('i'); k.className = 'k-' + r[2]; row.appendChild(k); }
    const b = document.createElement('b'); b.textContent = r[1];
    const s = document.createElement('span'); s.textContent = r[0];
    row.appendChild(b); row.appendChild(s); vizTip.appendChild(row);
  });
  vizTip.classList.add('on');
  const w = vizTip.offsetWidth, h = vizTip.offsetHeight;
  let left = x + 14, top = y - h - 12;
  if (left + w > window.innerWidth - 8) left = x - w - 14;
  if (top < 8) top = y + 16;
  vizTip.style.left = Math.max(8, left) + 'px';
  vizTip.style.top = top + 'px';
}
function hideTip() { vizTip.classList.remove('on'); }
document.addEventListener('pointermove', (e) => {
  const el = e.target.closest && e.target.closest('[data-tip]');
  if (el) showTip(el, e.clientX, e.clientY); else if (vizTip.classList.contains('on')) hideTip();
});
document.addEventListener('focusin', (e) => {
  const el = e.target.closest && e.target.closest('[data-tip]');
  if (!el) return;
  const r = el.getBoundingClientRect();
  showTip(el, r.left + r.width / 2, r.top);
});
document.addEventListener('focusout', hideTip);
window.addEventListener('scroll', hideTip, { passive: true });
