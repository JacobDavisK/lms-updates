'use strict';
/* =====================================================================
   QUIZ ACTIVITY PAGE
   ===================================================================== */
function fact(label, value) { return '<div class="fact"><small>' + esc(label) + '</small><b>' + value + '</b></div>'; }
const FINISHED_BY = { student: 'Finished', timeout: 'Time expired', violations: 'Auto-submitted', proctor: 'Ended by proctoring' };

function quizStudentBody(r, q) {
  S.quizInfo = q;
  const skew = q.serverNow - Date.now();
  const now = Date.now() + skew;
  const state = q.openAt && now < q.openAt ? 'upcoming' : q.closeAt && now > q.closeAt ? 'closed' : 'open';
  const left = q.maxAttempts ? Math.max(0, q.maxAttempts - q.used) : Infinity;
  let action;
  if (q.inProgressId) action = '<button class="btn btn-grad btn-lg" data-act="resumeQuiz" data-id="' + esc(q.inProgressId) + '">' + icon('play') + 'Continue your attempt</button>';
  else if (state === 'open' && left > 0) action = '<button class="btn btn-grad btn-lg" data-act="startQuiz">' + icon('play') + (q.used ? 'Re-attempt quiz' : 'Attempt quiz now') + '</button>';
  else action = notice(state === 'upcoming' ? 'This quiz opens on <b>' + esc(fmt(q.openAt)) + '</b> (' + esc(rel(q.openAt)) + ').'
    : state === 'closed' ? 'This quiz closed on <b>' + esc(fmt(q.closeAt)) + '</b>.' : 'You have used all your attempts for this quiz.', 'warn', 'lock');
  const scored = q.attempts.filter((a) => a.score != null && a.maxScore);
  const best = scored.reduce((b, a) => (!b || a.score / a.maxScore > b.score / b.maxScore ? a : b), null);
  const attempts = q.attempts.length ? '<div class="card"><div class="card-head"><span class="i-tile sm tone-violet">' + icon('history') + '</span><h2>Your attempts</h2></div>' +
    '<div class="table-wrap"><table class="table"><thead><tr><th>Attempt</th><th>State</th><th>Submitted</th><th class="num">Marks</th><th class="num">Grade</th><th></th></tr></thead><tbody>' +
    q.attempts.slice().reverse().map((a) => '<tr><td><b>#' + a.no + '</b></td><td>' + badge(FINISHED_BY[a.finishedBy] || 'Finished', a.finishedBy === 'student' ? 'success' : 'warning') + '</td>' +
      '<td class="small">' + esc(fmt(a.submittedAt)) + '</td><td class="num">' + (a.score != null ? a.score + ' / ' + a.maxScore : '—') + '</td>' +
      '<td class="num">' + (a.score != null ? '<span class="grade-pill ' + gradeClass(pct(a.score, a.maxScore)) + '">' + pct(a.score, a.maxScore) + '%</span>' : '<span class="muted small">Hidden</span>') + '</td>' +
      '<td class="actions"><a class="btn btn-sm btn-ghost" href="#/review/' + esc(a.id) + '">Review ' + icon('right', 'i-sm') + '</a></td></tr>').join('') +
    '</tbody></table></div></div>' : '';
  const rules = ['The timer keeps running even if you close the page. ' + (q.durationMin ? 'You have <b>' + q.durationMin + ' minutes</b>.' : ''),
    'Every answer is saved the moment you choose it.',
    'The quiz opens in full screen. Leaving the window, switching tabs, copying or pasting is recorded and visible to your teacher.' +
      (q.violationLimit ? ' After <b>' + q.violationLimit + '</b> warnings your attempt is submitted automatically.' : ''),
    'When time runs out, your attempt is submitted automatically.'];
  if (q.negativeMark) rules.push('Negative marking: <b>' + q.negativeMark + '</b> of a question’s marks is deducted for each wrong answer.');
  if (q.needsCode) rules.push('You need an access code from your teacher to start.');
  if (q.proctor) rules.unshift('<b>This exam is proctored.</b> You’ll complete a short check-in first, and your camera' + (q.proctor.microphone ? ', microphone' : '') + (q.proctor.screen ? ', screen' : '') +
    ' and on-device AI supervise the attempt. <a href="#/assessment/check">Run the system check</a> beforehand.' + reqChips(q.proctor));
  return '<div class="split"><div class="stack">' + (r.module.description ? '<div class="card card-pad"><div class="prose">' + md(r.module.description) + '</div></div>' : '') +
    '<div class="card"><div class="card-body" style="text-align:center;padding:2rem 1.5rem">' +
    (best ? '<div class="small muted" style="margin-bottom:.25rem">Your highest grade</div><div style="font-size:2.4rem;font-weight:var(--fw-semibold);letter-spacing:-.03em">' + best.score + '<span class="muted" style="font-size:1.2rem"> / ' + best.maxScore + '</span></div>' +
      '<div style="margin:.35rem 0 1.25rem"><span class="grade-pill ' + gradeClass(pct(best.score, best.maxScore)) + '">' + pct(best.score, best.maxScore) + '%</span>' +
      (q.passPercent ? ' ' + (pct(best.score, best.maxScore) >= q.passPercent ? badge('Passed', 'success', 'check') : badge('Below pass mark of ' + q.passPercent + '%', 'danger')) : '') + '</div>' : '') +
    action + '<div class="small muted" style="margin-top:.9rem">' + (q.maxAttempts ? plural(q.used, 'attempt') + ' used of ' + q.maxAttempts : plural(q.used, 'attempt') + ' used · unlimited attempts') + '</div></div></div>' +
    attempts + '</div>' +
    '<div class="stack"><div class="facts">' + fact('Opens', q.openAt ? esc(fmt(q.openAt)) : 'Open now') + fact('Closes', q.closeAt ? esc(fmt(q.closeAt)) : 'No close time') +
    fact('Time limit', q.durationMin ? q.durationMin + ' minutes' : 'None') + fact('Attempts allowed', q.maxAttempts || 'Unlimited') +
    fact('Grading method', 'Highest grade') + fact('Pass mark', q.passPercent ? q.passPercent + '%' : 'None') + '</div>' +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-amber">' + icon('shield') + '</span><h3>Before you start</h3></div><div class="card-body"><ul class="small" style="padding-left:1.1rem;margin:0;line-height:1.7">' +
    rules.map((x) => '<li>' + x + '</li>').join('') + '</ul></div></div></div></div>';
}

function quizTeacherBody(r) {
  const q = r.quiz;
  if (!q) return notice('The quiz for this activity is missing.', 'err');
  return '<div class="stats">' + statCard('quiz', 'violet', q.questionCount, 'Questions') + statCard('users', 'blue', q.attemptCount, 'Attempts') +
    statCard('clock', 'amber', q.inProgress, 'In progress now') + statCard(q.published ? 'eye' : 'eyeOff', q.published ? 'green' : 'slate', q.published ? 'Visible' : 'Hidden', 'Status') + '</div>' +
    (!q.questionCount ? notice('This quiz has no questions yet. Students cannot start it until you add some.', 'warn') : '') +
    '<div class="card card-pad row-wrap" style="margin-bottom:1.25rem"><a class="btn btn-primary" href="#/quiz/' + esc(q.id) + '/questions">' + icon('list') + 'Questions</a>' +
    '<button class="btn" data-act="qTemplate" data-id="' + esc(q.id) + '">' + icon('download') + 'Excel template</button>' +
    '<a class="btn" href="#/quiz/' + esc(q.id) + '/results">' + icon('users') + 'Results</a><a class="btn" href="#/quiz/' + esc(q.id) + '/analysis">' + icon('chart') + 'Item analysis</a>' +
    '<a class="btn' + (q.proctored ? ' btn-soft' : '') + '" href="#/assessment/exam/' + esc(q.id) + '">' + icon('shield') + (q.proctored ? 'Proctoring · on' : 'Set up proctoring') + '</a>' +
    '<div class="spacer"></div><button class="btn btn-soft" data-act="editMod" data-id="' + esc(r.module.id) + '">' + icon('settings') + 'Quiz settings</button></div>' +
    (r.module.description ? '<div class="card card-pad" style="margin-bottom:1.25rem"><div class="prose">' + md(r.module.description) + '</div></div>' : '') +
    '<div class="facts">' + fact('Opens', q.openAt ? esc(fmt(q.openAt)) : 'Open now') + fact('Closes', q.closeAt ? esc(fmt(q.closeAt)) : 'No close time') +
    fact('Time limit', q.durationMin ? q.durationMin + ' minutes' : 'None') + fact('Attempts allowed', q.maxAttempts || 'Unlimited') +
    fact('Students see', { none: 'Nothing', score: 'Score only', afterclose: 'Answers after close', immediate: 'Answers after last attempt' }[q.reviewMode] || 'Score') + '</div>';
}

/* ---------- quiz settings form ---------- */
function quizForm(q, ctx) {
  ctx = ctx || {};
  const courseId = q.courseId || ctx.courseId || '';
  const sel = (v, opts) => opts.map((o) => '<option value="' + o[0] + '"' + (v === o[0] ? ' selected' : '') + '>' + o[1] + '</option>').join('');
  const f = '<input type="hidden" name="id" value="' + esc(q.id || '') + '"><input type="hidden" name="courseId" value="' + esc(courseId) + '"><input type="hidden" name="sectionId" value="' + esc(ctx.sectionId || '') + '">' +
    field('Name', '<input type="text" name="title" maxlength="200" value="' + esc(q.title || '') + '" autofocus>') +
    field('Instructions for students <span class="muted">(optional)</span>', '<textarea name="description" maxlength="3000" style="min-height:80px">' + esc(q.description || '') + '</textarea>' + mdHelp()) +
    (!courseId ? field('Batches', '<input type="text" name="batches" maxlength="500" value="' + esc(q.batches || '') + '">', 'Comma-separated batch names, or * for everyone.') : '') +
    '<fieldset class="fieldset"><legend>Timing</legend><div class="form-grid">' +
    field('Opens', '<input type="datetime-local" name="openAt" value="' + toLocalInput(q.openAt) + '">') +
    field('Closes', '<input type="datetime-local" name="closeAt" value="' + toLocalInput(q.closeAt) + '">') + '</div><div class="form-grid-3">' +
    field('Time limit (min)', '<input type="number" name="durationMin" min="0" max="600" value="' + (q.durationMin || 0) + '">', '0 = until close time') +
    field('Attempts allowed', '<input type="number" name="maxAttempts" min="0" max="50" value="' + (q.maxAttempts || 0) + '">', '0 = unlimited') +
    field('Questions per attempt', '<input type="number" name="questionsPerAttempt" min="0" max="500" value="' + (q.questionsPerAttempt || 0) + '">', '0 = all; fewer draws a random set') + '</div></fieldset>' +
    '<fieldset class="fieldset"><legend>Grading & review</legend><div class="form-grid-3">' +
    field('Negative marking', '<input type="number" name="negativeMark" min="0" max="1" step="0.05" value="' + (q.negativeMark || 0) + '">', 'Fraction per wrong answer, e.g. 0.25') +
    field('Pass mark (%)', '<input type="number" name="passPercent" min="0" max="100" value="' + (q.passPercent || 0) + '">') +
    field('Warning limit', '<input type="number" name="violationLimit" min="0" max="100" value="' + (q.violationLimit || 0) + '">', 'Auto-submit after this many; 0 = never') + '</div>' +
    field('After submitting, students see', '<select name="reviewMode">' + sel(q.reviewMode || 'score', [['none', 'Nothing'], ['score', 'Their score only'], ['afterclose', 'Score now, answers after the quiz closes'], ['immediate', 'Score now, answers after their last attempt']]) + '</select>') + '</fieldset>' +
    '<fieldset class="fieldset"><legend>Security & order</legend>' +
    field('Access code <span class="muted">(optional)</span>', '<input type="text" name="accessCode" maxlength="50" autocomplete="off" value="' + esc(q.accessCode || '') + '">', 'Students must enter it to start.') +
    check('shuffleQuestions', 'Shuffle question order for each student', q.shuffleQuestions) +
    check('shuffleOptions', 'Shuffle answer options for each student', q.shuffleOptions) + '</fieldset>' +
    proctorFieldset(q.id ? (q.proctorLevel || 'off') : 'standard') +
    check('published', 'Visible to students', q.published, 'Needs a close time or a time limit.');
  formModal(q.id ? 'Quiz settings' : 'Add a quiz', q.id ? esc(q.title) : MOD.quiz.desc, 'quiz', f, q.id ? 'Save changes' : 'Create quiz and add questions', 'wide');
}
/** Proctoring right inside the quiz settings: on by default, with three named levels. */
const PROCTOR_LEVELS = [
  ['practice', 'Practice', 'Camera, face check and AI monitoring. No microphone.'],
  ['standard', 'Standard', 'Camera and microphone, face check with liveness, and AI monitoring for other people, phones, talking and looking away.'],
  ['strict', 'High-stakes', 'Everything in Standard plus screen recording, photo ID and a room scan. The attempt is submitted automatically after 5 serious flags.']
];
function proctorFieldset(level) {
  const on = level !== 'off';
  const cur = on ? level : 'standard';
  const opts = PROCTOR_LEVELS.concat(level === 'custom' ? [['custom', 'Custom', 'Keeps the settings chosen under Assessment → Proctoring.']] : []);
  return '<fieldset class="fieldset"><legend>Online proctoring</legend>' +
    '<label class="px-opt"><span class="switch"><input type="checkbox" name="proctorOn" data-change="quizProctorToggle"' + (on ? ' checked' : '') + '><span class="track"></span></span>' +
    '<span><b>Proctor students while they take this quiz</b><span class="xs muted">Students complete a short camera check-in, then the quiz runs with live AI monitoring. Teachers see flags, snapshots and an integrity score for every attempt.</span></span></label>' +
    '<div id="proctorLevels" class="level-list' + (on ? '' : ' hidden') + '" role="radiogroup" aria-label="Proctoring level">' +
    opts.map(([k, l, d]) => '<label class="level"><input type="radio" name="proctorLevel" value="' + k + '"' + (k === cur ? ' checked' : '') + '><span><b>' + esc(l) + '</b><span class="xs muted">' + esc(d) + '</span></span></label>').join('') +
    '</div><p class="xs muted" style="margin:var(--sp-3) 0 var(--sp-3)">Fine-tune every detector later under Assessment → Proctoring.</p></fieldset>';
}
ACT.quizProctorToggle = (d, el) => { const w = $('#proctorLevels'); if (w) w.classList.toggle('hidden', !el.checked); };

FORMS.quiz = (f, btn) => busy(btn, async () => {
  const e = f.elements;
  const r = await call('saveQuiz', {
    id: e.id.value, courseId: e.courseId.value, sectionId: e.sectionId.value,
    title: e.title.value, description: e.description.value, batches: e.batches ? e.batches.value : '',
    openAt: fromLocalInput(e.openAt.value), closeAt: fromLocalInput(e.closeAt.value),
    durationMin: e.durationMin.value, maxAttempts: e.maxAttempts.value, questionsPerAttempt: e.questionsPerAttempt.value,
    negativeMark: e.negativeMark.value, passPercent: e.passPercent.value, violationLimit: e.violationLimit.value,
    accessCode: e.accessCode.value, reviewMode: e.reviewMode.value,
    shuffleQuestions: e.shuffleQuestions.checked, shuffleOptions: e.shuffleOptions.checked, published: e.published.checked,
    proctoring: e.proctorOn.checked ? e.proctorLevel.value : 'off'
  });
  closeModal();
  toast(e.proctorOn.checked ? 'Quiz saved. Students will be proctored while they take it.' : 'Quiz saved.');
  if (!e.id.value) go('/quiz/' + r.id + '/questions'); else await refresh();
});

/* =====================================================================
   QUIZ ADMIN: QUESTIONS / RESULTS / ITEM ANALYSIS
   ===================================================================== */
async function viewQuizAdmin(qid, tab) {
  let data, body;
  if (tab === 'questions') { data = await call('getQuestions', { quizId: qid }); body = questionsBody(data); }
  else if (tab === 'results') { data = await call('results', { quizId: qid }); body = resultsBody(data); }
  else { data = await call('itemAnalysis', { quizId: qid }); body = analysisBody(data); }
  const q = data.quiz;
  S.qzQuiz = q;
  const label = { questions: 'Questions', results: 'Results', analysis: 'Item analysis' }[tab];
  const trail = [['My courses', '/courses']];
  if (q.courseId) trail.push([q.course || 'Course', '/course/' + q.courseId]);
  if (q.moduleId) trail.push([q.title, '/mod/' + q.moduleId]);
  trail.push([label]);
  const tabs = '<nav class="tabs">' + [['questions', 'Questions', 'list'], ['results', 'Results', 'users'], ['analysis', 'Item analysis', 'chart']].map(([k, l, ico]) =>
    '<a class="tab' + (tab === k ? ' active' : '') + '" href="#/quiz/' + esc(q.id) + '/' + k + '">' + icon(ico, 'i-sm') + l + '</a>').join('') + '</nav>';
  return {
    title: q.title + ' · ' + label,
    html: '<div class="mod-head tone-violet">' + modTile('quiz', 'lg') + '<div class="mh-text">' + crumbs(trail) + '<span class="act-type">Quiz</span><h1>' + esc(q.title) + '</h1>' +
      '<div class="mod-meta">' + (q.published ? badge('Visible', 'success', 'eye') : badge('Hidden from students', 'warning', 'eyeOff')) +
      (q.closeAt ? '<span>' + icon('clock', 'i-sm') + ' Closes ' + esc(fmt(q.closeAt)) + '</span>' : '') + (q.durationMin ? '<span>' + icon('history', 'i-sm') + ' ' + q.durationMin + ' min</span>' : '') + '</div></div>' +
      '<div class="page-actions">' + (q.moduleId ? '<a class="btn" href="#/mod/' + esc(q.moduleId) + '">' + icon('arrowLeft') + 'Quiz page</a>' : '') +
      '<button class="btn btn-soft" data-act="quizSettings" data-id="' + esc(q.id) + '">' + icon('settings') + 'Settings</button></div></div>' + tabs + body
  };
}
ACT.quizSettings = (d, btn) => busy(btn, async () => { const r = await call('getQuestions', { quizId: d.id }); quizForm(r.quiz, {}); });

function questionsBody(r) {
  S.qz = r;
  const total = r.questions.reduce((a, q) => a + (Number(q.marks) || 0), 0);
  const list = r.questions.map((q, i) =>
    '<div class="qbank-item"><div class="qhead"><span class="qn">' + (i + 1) + '.</span>' + badge(plural(q.marks, 'mark'), 'outline') +
    '<div class="spacer"></div><button class="btn btn-sm btn-ghost" data-act="editQ" data-id="' + esc(q.id) + '">' + icon('edit', 'i-sm') + 'Edit</button>' +
    (r.hasAttempts ? '' : '<button class="btn btn-sm btn-ghost btn-danger" data-act="delQ" data-id="' + esc(q.id) + '">' + icon('trash', 'i-sm') + 'Delete</button>') + '</div>' +
    '<div style="white-space:pre-wrap;font-weight:500">' + esc(q.text) + '</div><div class="qbank-opts">' +
    [q.optA, q.optB, q.optC, q.optD].map((o, k) => o ? '<div class="qbank-opt' + (k === q.correct ? ' correct' : '') + '"><b>' + letter(k) + '</b><span>' + esc(o) + (k === q.correct ? ' ' + icon('check', 'i-sm') : '') + '</span></div>' : '').join('') + '</div>' +
    (q.explanation ? '<div class="explain">' + icon('info') + '<div>' + esc(q.explanation) + '</div></div>' : '') + '</div>').join('');
  return (r.hasAttempts ? notice('Students have attempted this quiz. You can edit questions (then regrade), but not delete or replace them.', 'warn') : '') +
    '<div class="split"><div class="card"><div class="card-head"><span class="i-tile sm tone-violet">' + icon('list') + '</span><div><h2>Question bank</h2><div class="xs muted">' +
    plural(r.questions.length, 'question') + ' · ' + plural(total, 'mark') + ' total</div></div><div class="spacer"></div>' +
    (r.hasAttempts ? '<button class="btn btn-sm" data-act="regrade">' + icon('refresh', 'i-sm') + 'Regrade all</button>' : '') +
    '<button class="btn btn-sm btn-primary" data-act="addQ">' + icon('plus', 'i-sm') + 'Add question</button></div>' +
    (list || '<div class="card-body">' + emptyState('quiz', 'No questions yet', 'Download the Excel template, fill it in and upload it — or add questions one at a time.', '<button class="btn btn-primary" data-act="qTemplate">' + icon('download') + 'Download Excel template</button>', false) + '</div>') + '</div>' +
    '<div class="stack"><div class="card"><div class="card-head"><div><h2>Import from Excel</h2><div class="xs muted">The quickest way to add many questions</div></div></div><div class="card-body">' +
    '<ol class="steps"><li><b>Download the template</b><span>An Excel file with columns for the question, options A–D, the correct answer, marks and an explanation.</span></li>' +
    '<li><b>Fill in one question per row</b><span>The “How to fill” sheet explains each column; the “Example” sheet shows finished rows.</span></li>' +
    '<li><b>Upload it here</b><span>You’ll see a preview and any problems before anything is saved.</span></li></ol>' +
    '<button class="btn btn-block" data-act="qTemplate">' + icon('download') + 'Download Excel template</button>' +
    '<label class="dropzone" style="margin-top:var(--sp-3)">' + icon('upload') + '<b>Upload the filled template</b><span class="small">.xlsx or .csv · drop it here or click to choose</span>' +
    '<input type="file" accept=".xlsx,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv" data-change="qFile"></label></div></div>' +
    '<div class="card"><div class="card-head"><div><h2>Paste from a spreadsheet</h2><div class="xs muted">For a few questions at a time</div></div></div><div class="card-body">' +
    '<p class="small muted">Paste one question per line from Google Sheets or Excel (tab-separated), or separate columns with <b>|</b>:</p>' +
    '<p class="xs"><code>Question | A | B | C | D | Correct | Marks | Explanation</code></p>' +
    '<p class="xs muted">Marks and Explanation are optional. C and D may be blank for true/false. Type <code>\\n</code> for a line break.</p>' +
    '<form data-form="import" novalidate><textarea class="mono" name="text" placeholder="Bailment is defined in which section? | Section 124 | Section 148 | Section 172 | Section 182 | B | 1 | Section 148 of the Indian Contract Act." style="min-height:170px"></textarea>' +
    '<label class="check" style="margin:.75rem 0 .35rem"><input type="radio" name="mode" value="append" checked> Add to existing questions</label>' +
    (r.hasAttempts ? '' : '<label class="check"><input type="radio" name="mode" value="replace"> Replace all questions</label>') +
    '<button class="btn btn-block" type="submit" style="margin-top:.5rem">' + icon('upload') + 'Import pasted questions</button></form><div id="importErr"></div></div></div></div></div>';
}

/* ---------- Excel template: download, upload, preview, import ---------- */
function downloadBase64(name, b64, mime) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
  const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
ACT.qTemplate = (d, btn) => busy(btn, async () => {
  const r = await call('questionTemplate', { quizId: d.id || S.qz.quiz.id });
  downloadBase64(r.name, r.data, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  toast('Template downloaded. Fill in the “Questions” sheet, save, and upload it here.');
});
ACT.qFile = (d, el) => {
  const file = el.files && el.files[0];
  if (!file) return;
  if (el.value) el.value = ''; // choosing the same file again should re-trigger
  if (/\.xls$/i.test(file.name)) { toast('Old .xls files are not supported — in Excel use File → Save As → “Excel Workbook (.xlsx)”.', 'err'); return; }
  if (!/\.(xlsx|csv)$/i.test(file.name)) { toast('Upload the .xlsx template (or a .csv file).', 'err'); return; }
  if (file.size > 5 * 1024 * 1024) { toast('The file must be 5 MB or smaller.', 'err'); return; }
  busy(null, async () => {
    const data = await readFileB64(file);
    const r = await call('previewQuestionFile', { quizId: S.qz.quiz.id, name: file.name, data });
    S.qFile = { name: file.name, data, preview: r };
    questionFilePreview();
  });
};
function questionFilePreview() {
  const { name, preview: r } = S.qFile;
  const bad = r.rows.filter((x) => !x.ok);
  const good = r.rows.filter((x) => x.ok);
  const rows = good.map((x, i) => '<div class="qbank-item"><div class="qhead"><span class="qn">' + (i + 1) + '.</span>' + badge(plural(x.marks, 'mark'), 'outline') +
    '<span class="xs muted">' + esc(x.line) + '</span></div><div style="white-space:pre-wrap;font-weight:var(--fw-medium)">' + esc(x.text) + '</div><div class="qbank-opts">' +
    x.opts.map((o, k) => o ? '<div class="qbank-opt' + (k === x.correct ? ' correct' : '') + '"><b>' + letter(k) + '</b><span>' + esc(o) + (k === x.correct ? ' ' + icon('check', 'i-sm') : '') + '</span></div>' : '').join('') + '</div>' +
    (x.explanation ? '<div class="explain">' + icon('info') + '<div>' + esc(x.explanation) + '</div></div>' : '') + '</div>').join('');
  const problems = bad.length ? notice('<b>' + plural(bad.length, 'row has', 'rows have') + ' a problem and will be skipped:</b><ul style="margin:.35rem 0 0;padding-left:1.1rem">' +
    bad.slice(0, 25).map((x) => '<li><b>' + esc(x.line) + '</b>' + (x.text ? ' — “' + esc(x.text.slice(0, 60)) + (x.text.length > 60 ? '…' : '') + '”' : '') + ': ' + esc(x.error) + '</li>').join('') +
    (bad.length > 25 ? '<li>…and ' + (bad.length - 25) + ' more</li>' : '') + '</ul><div class="xs" style="margin-top:.4rem">Fix them in Excel and upload again, or import the valid questions now.</div>', 'warn') : '';
  const canReplace = r.existing > 0 && !r.hasAttempts;
  openModal(modalHead('Check the questions before importing', esc(name) + ' · sheet “' + esc(r.sheet) + '”') +
    '<div class="modal-body"><div class="kpis" style="margin-bottom:var(--sp-5)">' +
    kpi('Ready to import', r.valid, plural(r.marks, 'mark') + ' in total', 'checkCircle') + kpi('With problems', r.invalid, r.invalid ? 'will be skipped' : 'none', 'alert') +
    kpi('Already in the quiz', r.existing, r.hasAttempts ? 'students have attempted it' : 'questions', 'list') + '</div>' + problems +
    (good.length ? '<div class="card" style="max-height:44vh;overflow:auto;margin-bottom:var(--sp-4)">' + rows + '</div>' : '') +
    (good.length ? '<form data-form="qFileImport" novalidate>' +
      (canReplace ? '<div class="level-list" style="margin:0 0 var(--sp-2)" role="radiogroup" aria-label="Import mode">' +
        '<label class="level"><input type="radio" name="mode" value="append" checked><span><b>Add to the existing ' + plural(r.existing, 'question') + '</b><span class="xs muted">The quiz will have ' + (r.existing + r.valid) + ' questions.</span></span></label>' +
        '<label class="level"><input type="radio" name="mode" value="replace"><span><b>Replace the existing questions</b><span class="xs muted">The current ' + plural(r.existing, 'question') + ' are deleted first.</span></span></label></div>'
        : '<input type="hidden" name="mode" value="append">') +
      '<div class="form-actions"><button class="btn" type="button" data-act="close">Cancel</button><button class="btn btn-primary" type="submit">' + icon('upload') + 'Import ' + plural(r.valid, 'question') + '</button></div></form>'
      : '<div class="form-actions"><button class="btn btn-primary" type="button" data-act="close">OK</button></div>') + '</div>', 'wide');
}
FORMS.qFileImport = (f, btn) => busy(btn, async () => {
  const mode = f.elements.mode.value;
  if (mode === 'replace' && !await confirmBox('Replace all questions?', '<p>The quiz’s current questions will be deleted and replaced with the ones from the file.</p>', 'Replace questions', true)) { questionFilePreview(); return; }
  const r = await call('importQuestionFile', { quizId: S.qz.quiz.id, name: S.qFile.name, data: S.qFile.data, mode });
  S.qFile = null;
  closeModal();
  toast(plural(r.added, 'question') + (r.replaced ? ' imported, replacing the old ones.' : ' added.') + (r.skipped ? ' ' + plural(r.skipped, 'row') + ' skipped.' : ''));
  await refresh();
});
FORMS.import = (f, btn) => busy(btn, async () => {
  const mode = f.querySelector('input[name=mode]:checked').value;
  if (mode === 'replace' && !await confirmBox('Replace all questions?', '<p>The current questions in this quiz will be deleted.</p>', 'Replace questions', true)) return;
  const r = await call('importQuestions', { quizId: S.qz.quiz.id, text: f.elements.text.value, mode });
  if (r.errors.length) {
    $('#importErr').innerHTML = '<div style="margin-top:1rem">' + notice('<b>Nothing was imported. Fix these lines and try again:</b><br>' + r.errors.map(esc).join('<br>'), 'err') + '</div>';
    return;
  }
  toast(plural(r.added, 'question') + ' imported.'); await refresh();
});
ACT.addQ = () => questionForm({ marks: 1, correct: 0 });
ACT.editQ = (d) => questionForm(S.qz.questions.find((q) => q.id === d.id));
function questionForm(q) {
  formModal(q.id ? 'Edit question' : 'Add a question', esc(S.qz.quiz.title), 'question',
    '<input type="hidden" name="id" value="' + esc(q.id || '') + '">' +
    field('Question', '<textarea name="text" maxlength="5000" style="min-height:100px" autofocus>' + esc(q.text || '') + '</textarea>') +
    '<div class="form-grid">' + ['A', 'B', 'C', 'D'].map((L, i) => field('Option ' + L + (i > 1 ? ' <span class="muted">(optional)</span>' : ''), '<input type="text" name="opt' + L + '" maxlength="1000" value="' + esc(q['opt' + L] || '') + '">')).join('') + '</div>' +
    '<div class="form-grid">' + field('Correct option', '<select name="correct">' + [0, 1, 2, 3].map((i) => '<option value="' + letter(i) + '"' + (q.correct === i ? ' selected' : '') + '>' + letter(i) + '</option>').join('') + '</select>') +
    field('Marks', '<input type="number" name="marks" min="0.25" max="100" step="0.25" value="' + (q.marks || 1) + '">') + '</div>' +
    field('Explanation <span class="muted">(shown in review)</span>', '<textarea name="explanation" maxlength="2000" style="min-height:70px">' + esc(q.explanation || '') + '</textarea>'),
    'Save question', 'wide');
}
FORMS.question = (f, btn) => busy(btn, async () => {
  const e = f.elements;
  await call('saveQuestion', {
    quizId: S.qz.quiz.id, id: e.id.value, text: e.text.value, optA: e.optA.value, optB: e.optB.value,
    optC: e.optC.value, optD: e.optD.value, correct: e.correct.value, marks: e.marks.value, explanation: e.explanation.value
  });
  closeModal(); toast('Question saved.' + (S.qz.hasAttempts ? ' Use “Regrade all” to update scores.' : '')); await refresh();
});
ACT.delQ = async (d) => {
  if (!await confirmBox('Delete this question?', '<p>This cannot be undone.</p>', 'Delete question', true)) return;
  busy(null, async () => { await call('deleteQuestion', { id: d.id }); toast('Question deleted.'); await refresh(); });
};
ACT.regrade = (d, btn) => busy(btn, async () => { const r = await call('regrade', { quizId: S.qz.quiz.id }); toast(plural(r.regraded, 'attempt') + ' regraded.'); });

const REVIEW_LABEL = { pending: 'Not reviewed', cleared: 'Cleared', suspicious: 'Suspicious', misconduct: 'Misconduct' };
function resultsBody(r) {
  S.results = r;
  const proctored = r.quiz.proctored || r.attempts.some((a) => a.proctor);
  const done = r.attempts.filter((a) => a.status === 'submitted');
  const scores = done.map((a) => pct(a.score, a.maxScore));
  const avg = scores.length ? Math.round(scores.reduce((x, y) => x + y, 0) / scores.length * 10) / 10 : null;
  const tag = (a) => a.status === 'submitted' ? badge('Submitted', 'success') : a.status === 'inprogress' ? badge('In progress', 'warning', 'clock') : badge('Voided');
  const rows = r.attempts.slice().sort((a, b) => a.name.localeCompare(b.name) || a.attemptNo - b.attemptNo).map((a) =>
    '<tr data-text="' + esc((a.name + ' ' + a.username + ' ' + a.batch).toLowerCase()) + '"><td><div class="cell-user">' + avatar(a.name, 'sm') + '<div><b>' + esc(a.name) + '</b><span>' + esc(a.batch || '@' + a.username) + '</span></div></div></td>' +
    '<td class="num">' + a.attemptNo + '</td><td class="small">' + esc(fmt(a.startedAt)) + '<br><span class="muted">' + esc(fmt(a.submittedAt)) + '</span></td>' +
    '<td>' + tag(a) + '<div class="xs muted" style="margin-top:.2rem">' + esc(FINISHED_BY[a.finishedBy] || a.finishedBy || '') + '</div></td>' +
    '<td class="num">' + (a.score != null ? '<span class="grade-pill ' + gradeClass(pct(a.score, a.maxScore)) + '">' + a.score + ' / ' + a.maxScore + '</span><div class="xs muted">' + pct(a.score, a.maxScore) + '%</div>' : '—') + '</td>' +
    '<td>' + (a.violations ? badge(String(a.violations), a.violations >= 3 ? 'danger' : 'warning', 'alert') + '<div class="xs muted" style="margin-top:.2rem;max-width:200px">' + esc(a.violationSummary) + '</div>' : '<span class="muted">0</span>') + '</td>' +
    (proctored ? '<td>' + (a.proctor ? '<a class="integrity ' + a.proctor.band + '" href="#/assessment/session/' + esc(a.proctor.sid) + '" title="Open the proctoring review">' + a.proctor.integrity + '</a>' +
      '<div class="xs muted">' + plural(a.proctor.flags, 'flag') + ' · ' + esc(REVIEW_LABEL[a.proctor.review] || a.proctor.review) + '</div>' : '<span class="muted">—</span>') + '</td>' : '') +
    '<td class="actions">' + (a.status !== 'void' ? '<button class="btn btn-sm btn-ghost btn-danger" data-act="voidA" data-id="' + esc(a.id) + '">Void</button>' : '') + '</td></tr>').join('');
  return '<div class="stats">' + statCard('inbox', 'green', done.length, 'Submitted') + statCard('trending', 'indigo', avg != null ? avg + '%' : '—', 'Average') +
    statCard('award', 'amber', scores.length ? Math.max(...scores) + '%' : '—', 'Highest') + statCard('users', 'red', r.notAttempted.length, 'Not attempted') + '</div>' +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-blue">' + icon('users') + '</span><h2>Attempts</h2><div class="spacer"></div>' +
    '<div class="search-box" style="width:min(220px,40vw)">' + icon('search') + '<input type="search" placeholder="Filter" data-input="filterRows" data-target="#resTable" aria-label="Filter attempts"></div>' +
    '<button class="btn btn-sm" data-act="exportResults">' + icon('download') + 'Export CSV</button><button class="btn btn-sm" data-act="reload">' + icon('refresh') + '</button></div>' +
    (r.attempts.length ? '<div class="table-wrap"><table class="table" id="resTable"><thead><tr><th>Student</th><th class="num">#</th><th>Started / submitted</th><th>Status</th><th class="num">Score</th><th>Warnings</th>' + (proctored ? '<th>Integrity</th>' : '') + '<th></th></tr></thead><tbody>' + rows + '</tbody></table></div>'
      : '<div class="card-body">' + emptyState('users', 'No attempts yet', 'Results appear here as students finish the quiz.', '', false) + '</div>') + '</div>' +
    (r.notAttempted.length ? '<div class="card"><div class="card-head"><span class="i-tile sm tone-red">' + icon('alert') + '</span><h2>Not attempted</h2><span class="badge">' + r.notAttempted.length + '</span></div>' +
      '<div class="card-body row-wrap">' + r.notAttempted.map((u) => '<span class="badge outline" style="padding:.35rem .6rem">' + esc(u.name) + ' <span class="muted">· ' + esc(u.batch || u.username) + '</span></span>').join('') + '</div></div>' : '');
}
ACT.exportResults = () => {
  const r = S.results;
  const text = csv([['Name', 'Username', 'Batch', 'Attempt', 'Started', 'Submitted', 'Status', 'Score', 'Max', 'Percent', 'Warnings', 'Warning details', 'Finished by']]
    .concat(r.attempts.map((a) => [a.name, a.username, a.batch, a.attemptNo, fmt(a.startedAt), fmt(a.submittedAt), a.status, a.score, a.maxScore, a.score != null ? pct(a.score, a.maxScore) : '', a.violations, a.violationSummary, a.finishedBy])));
  downloadText((r.quiz.title || 'quiz').replace(/[^\w-]+/g, '_') + '-results.csv', text);
};
ACT.voidA = async (d) => {
  if (!await confirmBox('Void this attempt?', '<p>It will not count, and the student can try again if they have attempts left.</p>', 'Void attempt', true)) return;
  busy(null, async () => { await call('voidAttempt', { attemptId: d.id }); toast('Attempt voided.'); await refresh(); });
};

function analysisBody(r) {
  if (!r.items.length) return emptyState('chart', 'Nothing to analyse yet', 'Add questions and collect attempts to see how each question performs.');
  const rows = r.items.map((it) => {
    const fac = pct(it.correctCount, it.seen);
    const dist = it.options.map((o, k) => o ? '<div class="xs" style="display:flex;gap:.4rem;align-items:center"><b style="width:12px">' + letter(k) + '</b><div class="bar" style="flex:1;min-width:60px"><i style="width:' + pct(it.dist[k], it.seen) + '%;' + (letter(k) === it.correct ? '' : 'background:var(--faint)') + '"></i></div><span class="tnum" style="width:38px;text-align:right">' + pct(it.dist[k], it.seen) + '%</span></div>' : '').join('');
    const flag = it.seen >= 5 ? (fac < 25 ? badge('Very hard — check the key', 'danger') : fac > 90 ? badge('Very easy') : '') : '';
    return '<tr><td class="num">' + it.n + '</td><td class="small" style="max-width:320px">' + esc(it.text) + '</td><td>' + badge(it.correct, 'success') + '</td><td class="num">' + it.seen + '</td>' +
      '<td style="min-width:150px"><div class="row"><div class="bar" style="flex:1"><i style="width:' + fac + '%"></i></div><b class="small tnum">' + fac + '%</b></div>' + (flag ? '<div style="margin-top:.3rem">' + flag + '</div>' : '') + '</td>' +
      '<td class="num">' + pct(it.seen - it.answered, it.seen) + '%</td><td style="min-width:170px">' + dist + '</td></tr>';
  }).join('');
  return notice('<b>Facility</b> is the share of students who answered correctly. The option spread shows how often each option was chosen — useful for spotting weak distractors and wrong answer keys.') +
    '<div class="card"><div class="table-wrap"><table class="table"><thead><tr><th class="num">#</th><th>Question</th><th>Key</th><th class="num">Seen</th><th>Facility</th><th class="num">Blank</th><th>Option spread</th></tr></thead><tbody>' + rows + '</tbody></table></div></div>';
}

/* =====================================================================
   EXAM ENGINE (student)
   ===================================================================== */
ACT.startQuiz = () => {
  const q = S.quizInfo;
  if (!q) return;
  if (q.proctor) { go('/assessment/checkin/' + q.id); return; }
  openModal(modalHead('Ready to start?', esc(q.title)) + '<div class="modal-body">' +
    '<ul class="small" style="padding-left:1.1rem;margin:0 0 1rem;line-height:1.75">' +
    '<li>The timer keeps running even if you close this page. ' + (q.durationMin ? 'You have <b>' + q.durationMin + ' minutes</b>.' : '') + '</li>' +
    '<li>Each answer is saved as soon as you choose it.</li>' +
    '<li>The quiz opens in full screen. Leaving the window, switching tabs, copying or pasting is recorded.' + (q.violationLimit ? ' After <b>' + q.violationLimit + '</b> warnings your attempt is submitted automatically.' : '') + '</li>' +
    '<li>When time is up, your attempt is submitted automatically.</li></ul>' +
    '<form data-form="startQuiz" novalidate><input type="hidden" name="id" value="' + esc(q.id) + '">' +
    (q.needsCode ? field('Access code', '<input type="text" name="code" maxlength="50" autocomplete="off" autofocus>', 'Your teacher will give you this code.') : '') +
    '<div class="form-actions"><button class="btn" type="button" data-act="close">Cancel</button><button class="btn btn-grad" type="submit">' + icon('play') + 'Start attempt</button></div></form></div>', 'narrow');
};
FORMS.startQuiz = (f, btn) => {
  enterFullscreen(); // must run inside the user's click
  busy(btn, async () => {
    const r = await call('startAttempt', { quizId: f.elements.id.value, accessCode: f.elements.code ? f.elements.code.value : '' });
    closeModal();
    await openAttempt(r.attemptId);
  }).then(() => { if (!S.attempt && document.fullscreenElement) exitFullscreen(); });
};
ACT.resumeQuiz = (d, btn) => {
  if (S.quizInfo && S.quizInfo.proctor) { go('/assessment/checkin/' + S.quizInfo.id); return; }
  enterFullscreen(); busy(btn, () => openAttempt(d.id));
};

async function openAttempt(id) {
  let r;
  try { r = await call('getAttempt', { attemptId: id }); } catch (e) {
    exitFullscreen();
    if (/PROCTOR_CHECKIN/.test(e.message)) { toast('This exam is proctored. Complete the check-in to continue.', 'err'); return; }
    if (!isExpired(e)) toast(e.message, 'err');
    return;
  }
  if (r.finished) {
    exitFullscreen();
    S.flash = { text: 'This attempt has already been submitted.', kind: 'warn' };
    go('/review/' + r.attemptId);
    return;
  }
  S.examHash = location.hash;
  S.attempt = {
    id: r.attemptId, quizId: r.quizId, title: r.title, deadline: Date.now() + r.remainingMs, questions: r.questions,
    answers: {}, flags: {}, violations: r.violations, limit: r.violationLimit, finishing: false, unsaved: {}
  };
  r.questions.forEach((q) => { if (q.selected >= 0) S.attempt.answers[q.qid] = q.selected; });
  closeModal();
  renderExam(r);
  startExam();
}

function renderExam(r) {
  const a = S.attempt;
  const wm = Array.from({ length: 40 }, () => '<span>' + esc(r.watermark) + '</span>').join('');
  const nav = a.questions.map((q) => '<button type="button" data-act="jump" data-n="' + q.n + '" id="nav-' + q.n + '" class="' + (a.answers[q.qid] != null ? 'done' : '') + '" aria-label="Question ' + q.n + '">' + q.n + '</button>').join('');
  const qs = a.questions.map((q) => {
    const opts = q.options.map((o, i) =>
      '<label class="opt"><input type="radio" name="q-' + esc(q.qid) + '" value="' + i + '" data-qid="' + esc(q.qid) + '"' + (q.selected === i ? ' checked' : '') + '>' +
      '<span class="bub">' + letter(i) + '</span><span class="otext">' + esc(o) + '</span></label>').join('');
    return '<article class="card qcard" id="q-' + q.n + '"><div class="qhead"><span class="qn">Question ' + q.n + '</span>' + badge(plural(q.marks, 'mark'), 'outline') +
      '<button type="button" class="link small flagbtn" data-act="flag" data-n="' + q.n + '">' + icon('flag', 'i-sm') + ' Flag for review</button></div>' +
      '<p class="qtext">' + esc(q.text) + '</p><div role="radiogroup" aria-label="Question ' + q.n + ' options">' + opts + '</div>' +
      '<button type="button" class="link small" data-act="clear" data-qid="' + esc(q.qid) + '" data-n="' + q.n + '" style="color:var(--muted)">Clear my choice</button></article>';
  }).join('');
  app.innerHTML = '<div class="exam"><div class="watermark" aria-hidden="true">' + wm + '</div>' +
    '<header class="exam-bar"><div class="exam-bar-in"><span class="brand-mark" style="width:34px;height:34px">' + icon('logo') + '</span>' +
    '<div class="exam-title" style="min-width:0"><small>Quiz in progress</small>' + esc(a.title) + '</div>' +
    '<div class="exam-meta"><span id="saveState" class="save-state">' + icon('checkCircle', 'i-sm') + 'All answers saved</span><span id="vcount" class="vio"></span>' +
    '<span id="timer" class="timer" role="timer">' + icon('clock') + '<span id="timerTxt">--:--</span></span></div></div></header>' +
    '<div class="exam-body"><aside class="card rail"><h3>Questions</h3><div class="navgrid">' + nav + '</div>' +
    '<p class="legend"><i style="background:var(--primary)"></i>Answered<br><i style="border:2px solid var(--warning)"></i>Flagged for review</p>' +
    '<div class="small muted answered-count" style="margin-bottom:.75rem"></div>' +
    '<button class="btn btn-primary btn-block" data-act="finish">' + icon('send') + 'Finish attempt</button></aside>' +
    '<section>' + (r.negativeMark ? notice('Negative marking: ' + r.negativeMark + ' of a question’s marks is deducted for each wrong answer. Unanswered questions score zero.', 'warn') : '') +
    qs + '<div class="submit-row"><span class="small muted answered-count"></span><button class="btn btn-primary btn-lg" data-act="finish">' + icon('send') + 'Finish attempt</button></div></section></div></div>';
  updateCounts(); updateViolations(); tick();
  window.scrollTo(0, 0);
}

function updateCounts() {
  const a = S.attempt; if (!a) return;
  const n = Object.keys(a.answers).length;
  $$('.answered-count').forEach((el) => { el.textContent = n + ' of ' + a.questions.length + ' answered'; });
}
function updateViolations() {
  const a = S.attempt; const el = $('#vcount'); if (!a || !el) return;
  el.textContent = a.violations ? 'Warnings: ' + a.violations + (a.limit ? ' of ' + a.limit : '') : '';
}
function setSave(state) {
  const el = $('#saveState'); if (!el) return;
  el.className = 'save-state' + (state === 'err' ? ' err' : '');
  el.innerHTML = state === 'saving' ? icon('refresh', 'i-sm') + 'Saving…' : state === 'err' ? icon('alert', 'i-sm') + 'Not saved. Retrying…' : icon('checkCircle', 'i-sm') + 'All answers saved';
}
function enqueue(fn) { const p = S.q.then(fn); S.q = p.catch(() => {}); return p; }

function saveChoice(qid, choice) {
  const a = S.attempt; if (!a || a.finishing) return;
  if (choice < 0) delete a.answers[qid]; else a.answers[qid] = choice;
  const q = a.questions.find((x) => x.qid === qid);
  if (q) { const nb = $('#nav-' + q.n); if (nb) nb.classList.toggle('done', choice >= 0); }
  updateCounts();
  a.unsaved[qid] = choice;
  setSave('saving');
  sendSave(qid, choice);
}
function sendSave(qid, choice) {
  const a = S.attempt; const id = a.id;
  return enqueue(() => call('saveAnswer', { attemptId: id, qid, choice })).then(() => {
    if (!S.attempt || S.attempt.id !== id) return;
    if (a.unsaved[qid] === choice) delete a.unsaved[qid];
    if (!Object.keys(a.unsaved).length) setSave('ok');
  }).catch((e) => {
    if (/ATTEMPT_CLOSED/.test(e.message)) return attemptClosed();
    if (/PROCTOR_CHECKIN/.test(e.message)) return pmCheckinAgain();
    if (isExpired(e)) return;
    setSave('err'); setTimeout(flushUnsaved, 4000);
  });
}
function flushUnsaved() {
  const a = S.attempt; if (!a) return Promise.resolve();
  return Promise.all(Object.keys(a.unsaved).map((qid) => sendSave(qid, a.unsaved[qid])));
}
ACT.clear = (d) => {
  if (!S.attempt) return;
  $$('input[data-qid="' + CSS.escape(d.qid) + '"]').forEach((i) => { i.checked = false; });
  saveChoice(d.qid, -1);
};
ACT.jump = (d) => { const el = document.getElementById('q-' + d.n); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); };
ACT.flag = (d, btn) => {
  const a = S.attempt; if (!a) return;
  a.flags[d.n] = !a.flags[d.n];
  $('#nav-' + d.n).classList.toggle('flag', a.flags[d.n]);
  btn.innerHTML = icon('flag', 'i-sm') + (a.flags[d.n] ? ' Remove flag' : ' Flag for review');
};

function tick() {
  const a = S.attempt; if (!a) return;
  const ms = a.deadline - Date.now();
  const el = $('#timer'), txt = $('#timerTxt'); if (!el || !txt) return;
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), sec = s % 60;
  txt.textContent = (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(sec).padStart(2, '0');
  el.classList.toggle('warn', ms <= 60000);
  if (ms <= 0 && !a.finishing) finishAttempt('Time is up. Your attempt was submitted automatically.');
}
async function heartbeat() {
  const a = S.attempt; if (!a || a.finishing) return;
  try {
    const r = await call('heartbeat', { attemptId: a.id });
    if (r.status !== 'inprogress') { attemptClosed(); return; }
    a.deadline = Date.now() + r.remainingMs;
  } catch (e) { /* network hiccup: the server still enforces the deadline */ }
}
function attemptClosed() {
  const a = S.attempt; if (!a) return;
  const id = a.id;
  stopExam();
  restoreApp('/review/' + id, { text: 'This attempt has been closed.', kind: 'warn' });
}
async function finishAttempt(reason) {
  const a = S.attempt; if (!a || a.finishing) return;
  a.finishing = true; setSave('saving');
  await flushUnsaved(); await S.q;
  try { await call('submitAttempt', { attemptId: a.id }); } catch (e) {
    if (!/ATTEMPT_CLOSED|already/.test(e.message) && !reason) { a.finishing = false; toast(e.message, 'err'); setSave('err'); return; }
  }
  const id = a.id;
  stopExam();
  restoreApp('/review/' + id, reason ? { text: reason, kind: 'warn' } : { text: 'Your attempt was submitted.', kind: 'ok' });
}
ACT.finish = async () => {
  const a = S.attempt; if (!a) return;
  const unanswered = a.questions.length - Object.keys(a.answers).length;
  const flagged = Object.values(a.flags).filter(Boolean).length;
  const ok = await confirmBox('Submit your attempt?',
    '<p>' + (unanswered ? '<b>' + plural(unanswered, 'question is', 'questions are') + ' unanswered.</b> ' : 'You have answered every question. ') +
    (flagged ? plural(flagged, 'question is', 'questions are') + ' flagged for review. ' : '') + '</p><p>You cannot change your answers after you submit.</p>',
    'Submit attempt');
  if (ok) finishAttempt('');
};

/* ---------- exam integrity (client side) ---------- */
function on(target, type, fn, opts) { target.addEventListener(type, fn, opts); S.listeners.push([target, type, fn, opts]); }
function enterFullscreen() {
  const el = document.documentElement;
  if (el.requestFullscreen && !document.fullscreenElement) {
    el.requestFullscreen().then(() => { S.fsActive = true; }).catch(() => { S.fsActive = false; });
  }
}
function exitFullscreen() { S.fsActive = false; if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen().catch(() => {}); }

function violation(type) {
  const a = S.attempt; if (!a || a.finishing) return;
  const now = Date.now(); if (now - S.lastV < 2500) return; S.lastV = now;
  a.violations++; updateViolations();
  const id = a.id;
  enqueue(() => call('logViolation', { attemptId: id, type })).then((r) => {
    if (!S.attempt || S.attempt.id !== id) return;
    if (r.closed) { attemptClosed(); return; }
    if (r.autoSubmitted) {
      stopExam();
      restoreApp('/review/' + id, { text: 'Your attempt was submitted automatically because the warning limit was reached.', kind: 'err' });
      return;
    }
    S.attempt.violations = r.violations; updateViolations();
  }).catch(() => {});
  const labels = {
    tab_hidden: 'You switched away from the quiz tab.', focus_lost: 'You left the quiz window.', fullscreen_exit: 'You left full screen.',
    copy: 'Copying is not allowed during the quiz.', paste: 'Pasting is not allowed during the quiz.', shortcut: 'That keyboard shortcut is not allowed during the quiz.'
  };
  if (!$('.modal-bg')) {
    openModal('<div class="modal-body" style="padding-top:1.5rem"><div class="confirm-icon danger">' + icon('alert') + '</div><h2 style="font-size:1.15rem">Warning recorded</h2>' +
      '<p class="muted">' + esc(labels[type] || 'Activity recorded.') + ' Your teacher can see this.</p>' +
      (a.limit ? '<p><b>Warning ' + a.violations + ' of ' + a.limit + '.</b> At ' + a.limit + ' your attempt is submitted automatically.</p>' : '') +
      '<div class="form-actions"><button class="btn btn-primary" data-act="backToQuiz">Return to the quiz</button></div></div>', 'narrow');
  }
}
ACT.backToQuiz = () => { closeModal(); if (!document.fullscreenElement) enterFullscreen(); };

function startExam() {
  stopListenersOnly();
  document.body.classList.add('exam-on');
  on(document, 'visibilitychange', () => { if (document.hidden) violation('tab_hidden'); });
  on(window, 'blur', () => setTimeout(() => { if (!document.hidden) violation('focus_lost'); }, 150));
  on(document, 'fullscreenchange', () => { if (document.fullscreenElement) S.fsActive = true; else if (S.fsActive) { S.fsActive = false; violation('fullscreen_exit'); } });
  ['copy', 'cut'].forEach((t) => on(document, t, (e) => { e.preventDefault(); violation('copy'); }));
  on(document, 'paste', (e) => { e.preventDefault(); violation('paste'); });
  on(document, 'contextmenu', (e) => e.preventDefault());
  on(document, 'dragstart', (e) => e.preventDefault());
  on(document, 'keydown', (e) => {
    const k = (e.key || '').toLowerCase(), mod = e.ctrlKey || e.metaKey;
    const blocked = (mod && ['c', 'x', 'v', 'p', 's', 'u', 'a', 'f'].includes(k)) || k === 'f12' || (mod && e.shiftKey && ['i', 'j', 'c', 'k'].includes(k)) || k === 'printscreen';
    if (blocked) { e.preventDefault(); e.stopPropagation(); if (!(mod && k === 'f')) violation(k === 'v' ? 'paste' : (k === 'c' || k === 'x') ? 'copy' : 'shortcut'); }
  }, true);
  on(window, 'beforeunload', (e) => { if (S.attempt && !S.attempt.finishing) { e.preventDefault(); e.returnValue = ''; } });
  S.intervals.push(setInterval(tick, 1000));
  S.intervals.push(setInterval(heartbeat, 45000));
}
function stopListenersOnly() {
  S.listeners.forEach(([t, ty, fn, o]) => t.removeEventListener(ty, fn, o)); S.listeners = [];
  S.intervals.forEach(clearInterval); S.intervals = [];
}
function stopExam() {
  pmStop(); // proctoring monitor (camera, mic, screen) if running
  stopListenersOnly();
  document.body.classList.remove('exam-on');
  S.attempt = null; S.q = Promise.resolve();
  closeModal(); exitFullscreen();
}

/* =====================================================================
   ATTEMPT REVIEW
   ===================================================================== */
async function viewReview(id) {
  const r = await call('reviewAttempt', { attemptId: id });
  S.ctx = { courseId: r.courseId || '' };
  const trail = [['My courses', '/courses']];
  if (r.courseId) trail.push(['Course', '/course/' + r.courseId]);
  if (r.moduleId) trail.push([r.title, '/mod/' + r.moduleId]);
  trail.push(['Attempt ' + r.attemptNo]);
  const back = r.moduleId ? '<a class="btn" href="#/mod/' + esc(r.moduleId) + '">' + icon('arrowLeft') + 'Back to the quiz</a>' : '';
  const head = pageHead(r.title, { crumbs: trail, sub: 'Attempt ' + r.attemptNo + ' · submitted ' + esc(fmt(r.submittedAt)), actions: back });
  if (r.status === 'void') return { title: 'Review', html: head + notice('Your teacher cancelled this attempt. It does not count toward your result.', 'warn') };
  const taken = r.submittedAt && r.startedAt ? durationText(r.submittedAt - r.startedAt) : '—';
  let score;
  if (r.score != null) {
    const p = pct(r.score, r.maxScore);
    score = '<div class="card"><div class="score-hero">' + ring(p, 96) + '<div><div class="small muted">Your score</div><div class="big">' + r.score + '<span> / ' + r.maxScore + '</span></div>' +
      (r.passPercent ? '<div style="margin-top:.5rem">' + (p >= r.passPercent ? badge('Passed', 'success', 'check') : badge('Below the pass mark of ' + r.passPercent + '%', 'danger')) + '</div>' : '') + '</div>' +
      '<div class="spacer"></div><div class="facts" style="min-width:min(100%,380px)">' + fact('Started', esc(fmt(r.startedAt))) + fact('Time taken', esc(taken)) +
      fact('Finished', esc(FINISHED_BY[r.finishedBy] || '—')) + '</div></div></div>';
  } else {
    score = '<div class="card card-pad">' + notice('Your answers have been recorded. Your teacher will share the results.', 'ok') + '</div>';
  }
  let body = '';
  if (r.details) {
    body = '<div class="section-title"><h2>Your answers</h2></div><div style="max-width:880px">' + r.details.map((q) => {
      const got = q.selected === q.correct;
      const opts = q.options.map((o, i) => {
        const cls = i === q.correct ? ' right' : (i === q.selected ? ' wrong' : '');
        return '<div class="opt review' + cls + '"><span class="bub">' + letter(i) + '</span><span class="otext">' + esc(o) + (i === q.selected ? ' <span class="xs muted">(your answer)</span>' : '') + '</span></div>';
      }).join('');
      return '<article class="card qcard"><div class="qhead"><span class="qn">Question ' + q.n + '</span>' + (q.marks ? badge(plural(q.marks, 'mark'), 'outline') : '') +
        '<span class="verdict ' + (got ? 'ok' : 'no') + '">' + icon(q.selected < 0 ? 'circle' : got ? 'checkCircle' : 'x', 'i-sm') + ' ' + (q.selected < 0 ? 'Not answered' : got ? 'Correct' : 'Incorrect') + '</span></div>' +
        '<p class="qtext">' + esc(q.text) + '</p>' + opts + (q.explanation ? '<div class="explain">' + icon('info') + '<div>' + esc(q.explanation) + '</div></div>' : '') + '</article>';
    }).join('') + '</div>';
  } else if (r.answersLater && r.score != null) {
    body = '<div style="margin-top:1rem">' + notice('The correct answers appear once you have used all your attempts' + (r.closeAt ? ', or after the quiz closes on <b>' + esc(fmt(r.closeAt)) + '</b>' : '') + '.', '', 'lock') + '</div>';
  } else if (r.reviewMode === 'afterclose' && r.score != null) {
    body = '<div style="margin-top:1rem">' + notice('You can see the correct answers after the quiz closes on <b>' + esc(fmt(r.closeAt)) + '</b>.', '', 'lock') + '</div>';
  }
  return { title: 'Review', html: head + score + body };
}
