'use strict';
/* =====================================================================
   MENTORING & STUDENT SUCCESS
   Mentor, HOD, coordinator and administrator pages, the Student 360°
   profile, and the student / parent views. Every list and record comes
   from the server already filtered to what the viewer may see.
   ===================================================================== */
const MT = { opts: null, stu: null, pick: new Set(), alloc: new Set(), cfg: null };
const MT_STATUS = { ok: ['checkCircle', 'ok'], attention: ['alert', 'attention'], priority: ['flag', 'priority'] };
const MT_SEV = { reminder: ['clock', 'Reminder'], attention: ['alert', 'Needs attention'], priority: ['flag', 'Priority intervention'] };
const MT_LEVELS = { 1: ['eye', 'Student visible'], 2: ['lock', 'Mentor only'], 3: ['shield', 'Restricted'] };
const MT_SESSION_STATUS = { scheduled: ['calendar', 'Scheduled', 'info'], requested: ['send', 'Requested', 'warning'], completed: ['checkCircle', 'Completed', 'success'], cancelled: ['x', 'Cancelled', ''], missed: ['alert', 'Missed', 'danger'], declined: ['x', 'Declined', ''] };

function mtIsStaff() { return S.me && (S.me.role === 'teacher' || S.me.role === 'admin'); }
function mtFlags() { return (S.me && S.me.mentoring) || {}; }
function mtStatus(st, label) {
  const x = MT_STATUS[st] || MT_STATUS.ok;
  return '<span class="mt-status mt-' + x[1] + '">' + icon(x[0], 'i-sm') + esc(label || st) + '</span>';
}
function mtSev(sev) { const x = MT_SEV[sev] || MT_SEV.attention; return '<span class="mt-status mt-' + (sev === 'reminder' ? 'reminder' : sev) + '">' + icon(x[0], 'i-sm') + x[1] + '</span>'; }
function mtLevel(l) { const x = MT_LEVELS[l] || MT_LEVELS[2]; return '<span class="mt-level l' + (l || 2) + '" title="Confidentiality">' + icon(x[0], 'i-sm') + x[1] + '</span>'; }
function mtSessStatus(st) { const x = MT_SESSION_STATUS[st] || ['info', st, '']; return badge(x[1], x[2], x[0]); }
function mtProg(p, label) {
  p = Math.max(0, Math.min(100, Math.round(Number(p) || 0)));
  return '<div class="mt-prog" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + p + '" aria-label="' + esc(label || 'Progress') + '"><i style="width:' + p + '%"></i></div>';
}
function mtDate(d) { return d ? fmtDate(fromDateInput(d)) : '—'; }
function mtWhen(ms) { return ms ? fmtDay(ms) + ', ' + fmtTime(ms) : '—'; }
function mtPct(v) { return v == null ? '—' : v + '%'; }
function mtSel(name, list, cur, opt) {
  opt = opt || {};
  return '<select name="' + name + '"' + (opt.id ? ' id="' + opt.id + '"' : '') + (opt.attrs || '') + '>' + (opt.blank !== undefined ? '<option value="">' + esc(opt.blank) + '</option>' : '') +
    list.map((x) => { const v = Array.isArray(x) ? x[0] : x; const l = Array.isArray(x) ? x[1] : x; return '<option value="' + esc(v) + '"' + (String(v) === String(cur) ? ' selected' : '') + '>' + esc(l) + '</option>'; }).join('') + '</select>';
}
function mtLevelSel(cur, name) {
  return field('Confidentiality', mtSel(name || 'level', [['1', 'Level 1 — Student visible'], ['2', 'Level 2 — Mentor only'], ['3', 'Level 3 — Restricted']], String(cur || 2)),
    'Level 1: the student sees it. Level 2: mentor, HOD and coordinators. Level 3: only you and staff with the Restricted grant.');
}
async function mtOptions() { if (!MT.opts) MT.opts = await call('mtOptions'); return MT.opts; }
function mtTabs(active) {
  const f = mtFlags();
  const items = [['/mentoring', 'Dashboard', 'dashboard'], ['/mentoring/mentees', 'Mentees', 'users'], ['/mentoring/sessions', 'Sessions', 'calendar'], ['/mentoring/followups', 'Follow-ups', 'clock'],
    ['/mentoring/concerns', 'Concerns', 'message'], ['/mentoring/goals', 'Goals', 'target'], ['/mentoring/interventions', 'Interventions', 'zap'], ['/mentoring/indicators', 'Indicators', 'flag']];
  if (f.coordinator || f.hod) items.push(['/mentoring/allocation', 'Allocation', 'userPlus']);
  items.push(['/mentoring/analytics', 'Analytics & reports', 'chart']);
  if (f.admin) items.push(['/mentoring/settings', 'Configuration', 'settings']);
  return '<nav class="tabs mt-tabs" aria-label="Mentoring sections">' + items.map((i) => '<a class="tab' + (i[0] === active ? ' active' : '') + '" href="#' + i[0] + '"' + (i[0] === active ? ' aria-current="page"' : '') + '>' + icon(i[2]) + i[1] + '</a>').join('') + '</nav>';
}
function mtHead(title, sub, actions, crumb) {
  return pageHead(title, { crumbs: [['Mentoring', '/mentoring']].concat(crumb ? [[crumb]] : []), sub, actions });
}
function mtPager(r, base) {
  if (r.pages <= 1) return '';
  const link = (p, label, dis) => dis ? '<span class="btn btn-sm" aria-disabled="true" style="opacity:.45">' + label + '</span>' : '<a class="btn btn-sm" href="#' + base + (base.indexOf('?') >= 0 ? '&' : '?') + 'page=' + p + '">' + label + '</a>';
  return '<div class="mt-pager">' + link(r.page - 1, icon('left', 'i-sm') + 'Previous', r.page <= 1) + '<span class="small muted">Page ' + r.page + ' of ' + r.pages + ' · ' + plural(r.total, 'record') + '</span>' + link(r.page + 1, 'Next' + icon('right', 'i-sm'), r.page >= r.pages) + '</div>';
}
function mtQs(params, drop) {
  const q = new URLSearchParams(params);
  (drop || []).forEach((k) => q.delete(k));
  const s = q.toString();
  return s ? '?' + s : '';
}
function mtStudentLink(id, name) { return '<a href="#/mentoring/student/' + esc(id) + '">' + esc(name) + '</a>'; }
function mtFiles(list) { return (list || []).length ? '<div class="mt-files">' + list.map((f) => fileChip(f)).join('') + '</div>' : ''; }
async function mtUploadAll(input) {
  const ids = [];
  const files = input && input.files ? Array.from(input.files) : [];
  for (const f of files.slice(0, 10)) ids.push((await uploadFile(f)).id);
  return ids;
}
const MT_ATTACH_ACCEPT = '.pdf,.png,.jpg,.jpeg,.webp,.gif,.doc,.docx,.xls,.xlsx,.csv,.txt,.ppt,.pptx';

/* =====================================================================
   HOME — mentor / HOD / admin dashboard, student and parent views
   ===================================================================== */
async function viewMtHome() {
  const r = await call('mtHome');
  if (r.role === 'student') return mtStudentHome(r);
  if (r.role === 'parent') return mtParentHome(r);
  return mtStaffHome(r);
}
function mtKpi(ico, tone, value, label, href, statusKey) {
  return '<a class="card mt-kpi" href="#' + href + '"><span class="i-tile tone-' + tone + '">' + icon(ico) + '</span><div><div class="v">' + esc(value) + '</div><div class="l">' +
    (statusKey ? mtStatus(statusKey, label) : esc(label)) + '</div></div></a>';
}
function mtStuRow(c) {
  return '<a class="mt-row" href="#/mentoring/student/' + esc(c.id) + '">' + avatar(c.name) + '<span class="mt-row-main"><b>' + esc(c.name) + '</b><span class="xs muted">' + esc(c.regNo) + ' · ' + esc(c.batch || '—') + '</span>' +
    (c.indicators && c.indicators.length ? '<span class="xs mt-why">' + esc(c.indicators.slice(0, 3).join(' · ')) + '</span>' : c.noContact ? '<span class="xs mt-why">No mentoring contact for ' + esc(c.daysSinceSession) + ' days</span>' : '') + '</span>' +
    '<span class="mt-row-side">' + mtStatus(c.status, c.statusLabel) + (c.noContact ? '<span class="xs muted">' + icon('clock', 'i-sm') + ' no recent contact</span>' : '') + '</span></a>';
}
function mtSessRow(x, opts) {
  opts = opts || {};
  const who = x.students.map((s) => esc(s.name)).join(', ');
  return '<div class="mt-row"><span class="mt-date"><small>' + esc(new Date(x.at).toLocaleDateString(undefined, { month: 'short' })) + '</small><b>' + new Date(x.at).getDate() + '</b></span>' +
    '<span class="mt-row-main"><b>' + esc(x.type) + (x.category ? ' · ' + esc(x.category) : '') + '</b><span class="xs muted">' + esc(x.status === 'requested' ? 'Requested by ' + (x.requestedBy || 'student') : mtWhen(x.at)) + ' · ' + esc(x.mode) + (x.location ? ' · ' + esc(x.location) : '') + '</span>' +
    (opts.people !== false ? '<span class="xs">' + who + '</span>' : '') + (x.agenda ? '<span class="xs muted mt-clip">' + esc(x.agenda) + '</span>' : '') + '</span>' +
    '<span class="mt-row-side">' + mtSessStatus(x.status) + (x.link && x.status === 'scheduled' ? '<a class="btn btn-sm" href="' + esc(x.link) + '" target="_blank" rel="noopener noreferrer">' + icon('video', 'i-sm') + 'Join</a>' : '') +
    (mtIsStaff() && (x.status === 'scheduled' || x.status === 'requested') ? '<span class="row" style="gap:4px">' + (x.status === 'requested' ? '<button class="btn btn-sm btn-soft" data-act="mtSchedule" data-id="' + esc(x.id) + '">Schedule</button>' : '<button class="btn btn-sm btn-soft" data-act="mtRecord" data-id="' + esc(x.id) + '">Record</button>') +
      '<button class="btn-icon sm" title="' + (x.status === 'requested' ? 'Decline' : 'Cancel or mark missed') + '" data-act="mtSessStatus" data-id="' + esc(x.id) + '" data-req="' + (x.status === 'requested' ? 1 : '') + '">' + icon('x') + '</button></span>' : '') + '</span></div>';
}
function mtActRow(x, opts) {
  opts = opts || {};
  return '<div class="mt-row' + (x.overdue ? ' mt-overdue' : '') + '"><span class="mt-row-main"><b>' + esc(x.title) + '</b><span class="xs muted">' + (opts.student !== false ? mtStudentLink(x.studentId, x.student) + ' · ' : '') + esc(x.ownerLabel) +
    (x.followUp || x.due ? ' · ' + (x.overdue ? '<b class="mt-od">' + icon('alert', 'i-sm') + 'overdue since ' + esc(mtDate(x.followUp || x.due)) + '</b>' : 'due ' + esc(mtDate(x.followUp || x.due))) : '') + '</span>' +
    (x.outcome ? '<span class="xs">Outcome: ' + esc(x.outcome) + '</span>' : '') + '</span><span class="mt-row-side">' +
    (x.status === 'open' ? '<button class="btn btn-sm btn-soft" data-act="mtActDone" data-id="' + esc(x.id) + '">' + icon('check', 'i-sm') + 'Done</button>' : badge(x.status === 'done' ? 'Done' : 'Cancelled', x.status === 'done' ? 'success' : '', x.status === 'done' ? 'checkCircle' : 'x')) +
    (mtIsStaff() && x.status === 'open' ? '<button class="btn-icon sm" title="Edit" data-act="mtActEdit" data-id="' + esc(x.id) + '">' + icon('edit') + '</button>' : '') + '</span></div>';
}
function mtCard(title, body, extra) { return '<section class="card mt-card"><div class="card-head"><h2>' + title + '</h2><div class="spacer"></div>' + (extra || '') + '</div><div class="card-body">' + body + '</div></section>'; }
function mtEmpty(text) { return '<p class="small muted mt-empty">' + text + '</p>'; }

function mtStaffHome(r) {
  const k = r.kpis;
  S.mtHome = r;
  MT.stuList = null;
  const g = r.grants;
  const roleLine = [g.admin ? 'Administrator' : '', g.coordinator && !g.admin ? 'Coordinator' : '', g.principal ? 'Principal' : '', g.hod ? 'HOD — ' + g.hodDepts.join(', ') : '', k.mentees ? 'Mentor of ' + plural(k.mentees, 'student') : ''].filter(Boolean).join(' · ');
  const noMentees = !k.mentees;
  const lead = noMentees
    ? '<div class="card card-pad">' + emptyState('users', 'No mentees assigned to you', (r.departmentView ? 'Use Allocation to assign mentors, or the department and institution dashboards below.' : 'When a coordinator or HOD assigns students to you, they appear here with their support status.'), (r.departmentView ? '<a class="btn btn-primary" href="#/mentoring/allocation">' + icon('userPlus') + 'Open allocation</a>' : ''), false) + '</div>'
    : '<div class="mt-kpis">' +
      mtKpi('users', 'indigo', k.mentees, 'Total mentees', '/mentoring/mentees') + mtKpi('checkCircle', 'green', k.ok, r.labels.ok, '/mentoring/mentees?status=ok', 'ok') +
      mtKpi('alert', 'amber', k.attention, r.labels.attention, '/mentoring/mentees?status=attention', 'attention') + mtKpi('flag', 'red', k.priority, r.labels.priority, '/mentoring/mentees?status=priority', 'priority') +
      mtKpi('clock', 'slate', k.noContact, 'No recent interaction', '/mentoring/mentees?status=nocontact') + mtKpi('list', 'blue', k.pendingFollowups, 'Pending follow-ups' + (k.overdue ? ' (' + k.overdue + ' overdue)' : ''), '/mentoring/followups') +
      mtKpi('target', 'violet', k.goalsInProgress, 'Goals in progress', '/mentoring/goals') + mtKpi('message', 'cyan', k.openConcerns, 'Open concerns', '/mentoring/concerns') + '</div>';
  const scopeCard = r.departmentView || r.institutionView ? '<section class="card mt-card mt-scope"><div class="card-body row-wrap" style="gap:.6rem">' + icon('layers') + '<b>Wider view</b><span class="spacer"></span>' +
    (r.departmentView ? '<a class="btn btn-sm" href="#/mentoring/analytics?level=department">' + icon('building', 'i-sm') + 'Department dashboard</a>' : '') +
    (r.institutionView ? '<a class="btn btn-sm" href="#/mentoring/analytics?level=institution">' + icon('chart', 'i-sm') + 'Institution dashboard</a>' : '') +
    (mtFlags().coordinator || mtFlags().hod ? '<a class="btn btn-sm" href="#/mentoring/allocation">' + icon('userPlus', 'i-sm') + 'Mentor allocation</a>' : '') + '</div></section>' : '';
  return {
    title: 'Mentoring',
    html: mtHead('Mentoring & Student Success', esc(roleLine || 'Your mentoring command centre') + (r.cycle ? ' · Cycle: <b>' + esc(r.cycle.name) + '</b>' : ''),
      '<form class="search-box mt-search" data-form="mtSearch" role="search">' + icon('search') + '<input type="search" name="q" placeholder="Search students, goals, concerns…" aria-label="Search mentoring"></form>' +
      (k.mentees ? '<button class="btn btn-primary" data-act="mtSchedule">' + icon('plus') + 'Schedule session</button>' : '')) +
      mtTabs('/mentoring') + (r.demo ? notice('<b>Demo data.</b> The mdemo.* students, mentors and records are fictional, generated for demonstration.', 'warn', 'info') : '') + lead + scopeCard +
      (noMentees ? '' : '<div class="mt-grid">' +
        '<div class="mt-col">' +
        mtCard('Students needing attention', r.attention.length ? '<div class="mt-list">' + r.attention.map(mtStuRow).join('') + '</div>' : mtEmpty(icon('checkCircle', 'i-sm') + ' Every mentee is on track and in regular contact.'), '<a class="btn btn-sm btn-ghost" href="#/mentoring/mentees">All mentees</a>') +
        mtCard('Upcoming meetings', r.upcoming.length ? '<div class="mt-list">' + r.upcoming.map((x) => mtSessRow(x)).join('') + '</div>' : mtEmpty('Nothing scheduled. Plan the next round of sessions.'), '<a class="btn btn-sm btn-ghost" href="#/mentoring/sessions">Sessions</a>') +
        mtCard('Goals', r.goals.length ? '<div class="mt-list">' + r.goals.map((gl) => '<div class="mt-row"><span class="mt-row-main"><b>' + esc(gl.title) + '</b><span class="xs muted">' + mtStudentLink(gl.studentId, gl.student) + ' · ' + esc(gl.category) + (gl.target ? ' · target ' + esc(mtDate(gl.target)) : '') + '</span>' + mtProg(gl.progress, gl.title) + '</span><span class="mt-row-side">' + badge(gl.status, gl.status === 'At Risk' || gl.overdue ? 'warning' : gl.status === 'Completed' ? 'success' : '') + '</span></div>').join('') + '</div>' : mtEmpty('No active goals. Help mentees set one in their next session.')) +
        '</div><div class="mt-col">' +
        mtCard('Overdue follow-ups', r.overdue.length ? '<div class="mt-list">' + r.overdue.map((x) => mtActRow(x)).join('') + '</div>' : mtEmpty(icon('checkCircle', 'i-sm') + ' Nothing overdue.'), '<a class="btn btn-sm btn-ghost" href="#/mentoring/followups">Follow-ups</a>') +
        mtCard('Recent changes', r.changes.length ? '<div class="mt-list">' + r.changes.map((e) => '<a class="mt-row" href="#/mentoring/student/' + esc(e.studentId) + '"><span class="mt-row-main"><b>' + esc(e.student) + '</b><span class="xs">' + esc(e.name) + '</span><span class="xs muted">' + esc(rel(e.at)) + '</span></span><span class="mt-row-side">' + mtSev(e.severity) + '</span></a>').join('') + '</div>' : mtEmpty('No new support indicators.'), '<a class="btn btn-sm btn-ghost" href="#/mentoring/indicators">Indicators</a>') +
        mtCard('Open concerns', r.concerns.length ? '<div class="mt-list">' + r.concerns.map((c) => '<button class="mt-row" data-act="mtConcern" data-id="' + esc(c.id) + '"><span class="mt-row-main"><b>' + esc(c.category) + ' · ' + esc(c.ref) + '</b><span class="xs muted">' + esc(c.student) + ' · ' + esc(rel(c.at)) + '</span></span><span class="mt-row-side">' + badge(c.status, c.status === 'Awaiting Student' ? 'info' : 'warning') + badge(c.priority, c.priority === 'High' ? 'danger' : '') + '</span></button>').join('') + '</div>' : mtEmpty('No open concerns.'), '<a class="btn btn-sm btn-ghost" href="#/mentoring/concerns">Concerns</a>') +
        '</div></div>'),
    after: () => { MT.concernCache = r.concerns; MT.sessCache = r.upcoming; MT.actCache = r.overdue; }
  };
}
FORMS.mtSearch = (f) => { const q = f.elements.q.value.trim(); if (q.length < 2) { toast('Type at least 2 characters.', 'err'); return; } go('/mentoring/search?q=' + encodeURIComponent(q)); };

/* ---------- student ---------- */
function mtStudentHome(r) {
  MT.me = r;
  MT.concernCache = r.concerns; MT.sessCache = r.upcoming.concat(r.recent); MT.actCache = r.actions; MT.goalCache = r.goals;
  const m = r.mentor;
  const fb = r.recent.filter((x) => x.feedbackDue);
  const car = r.career;
  const openActs = r.actions.filter((x) => x.status === 'open');
  return {
    title: 'My mentoring',
    html: pageHead('My mentoring', { crumbs: [['Mentoring']], sub: 'Your mentor, meetings, goals and support — in one place.',
      actions: '<button class="btn" data-act="mtConcernNew">' + icon('message') + 'Raise a concern</button>' + (m ? '<button class="btn btn-primary" data-act="mtRequest">' + icon('send') + 'Request mentoring</button>' : '') }) +
      (fb.length ? notice('You have ' + plural(fb.length, 'session') + ' waiting for your feedback. <button class="link" data-act="mtFeedback" data-id="' + esc(fb[0].id) + '">Give feedback</button>', 'ok', 'smile') : '') +
      '<div class="mt-grid"><div class="mt-col">' +
      '<section class="card mt-card mt-mentor">' + (m
        ? '<div class="card-body row" style="gap:1rem;align-items:center">' + avatar(m.name, 'lg') + '<div style="min-width:0"><div class="xs muted mt-eyebrow">My mentor</div><h2 style="margin:.1rem 0">' + esc(m.name) + '</h2>' +
          '<div class="small muted">' + esc(m.department || 'Faculty') + ' · since ' + esc(fmtDate(m.since)) + '</div>' + (m.email ? '<a class="small" href="mailto:' + esc(m.email) + '">' + icon('mail', 'i-sm') + ' ' + esc(m.email) + '</a>' : '') + '</div>' +
          '<span class="spacer"></span><a class="btn btn-sm" href="#/chat">' + icon('message', 'i-sm') + 'Message</a></div>'
        : '<div class="card-body">' + emptyState('user', 'No mentor assigned yet', 'Your department will assign a faculty mentor. You can still set goals and raise a concern.', '', false) + '</div>') + '</section>' +
      mtCard('Upcoming mentoring', r.upcoming.length ? '<div class="mt-list">' + r.upcoming.map((x) => mtSessRow(x, { people: false })).join('') + '</div>' : mtEmpty('No meetings scheduled.' + (m ? ' Use <b>Request mentoring</b> when you would like to talk.' : ''))) +
      mtCard('My goals', r.goals.length ? '<div class="mt-list">' + r.goals.map(mtGoalRow).join('') + '</div>' : mtEmpty('Set a goal — academic, career or skill — and track your progress.'), '<button class="btn btn-sm btn-soft" data-act="mtGoalEdit">' + icon('plus', 'i-sm') + 'Add goal</button>') +
      mtCard('Recent sessions', r.recent.length ? '<div class="mt-list">' + r.recent.map((x) => '<div class="mt-row"><span class="mt-row-main"><b>' + esc(x.type) + ' · ' + esc(mtWhen(x.at)) + '</b>' +
        (x.summary ? '<span class="small">' + esc(x.summary) + '</span>' : x.notesPrivate ? '<span class="xs muted">' + icon('lock', 'i-sm') + ' Notes for this session are kept by your mentor.</span>' : '') + (x.outcome ? '<span class="xs">Outcome: ' + esc(x.outcome) + '</span>' : '') + mtFiles(x.attachments) + '</span>' +
        '<span class="mt-row-side">' + (x.feedbackDue ? '<button class="btn btn-sm btn-soft" data-act="mtFeedback" data-id="' + esc(x.id) + '">Give feedback</button>' : '') + '</span></div>').join('') + '</div>' : mtEmpty('Your recorded sessions will appear here.')) +
      '</div><div class="mt-col">' +
      mtCard('My action items', openActs.length || r.actions.length ? '<div class="mt-list">' + r.actions.slice(0, 12).map((x) => mtActRow(x, { student: false })).join('') + '</div>' : mtEmpty('No action items right now.')) +
      mtCard('My support requests', r.concerns.length ? '<div class="mt-list">' + r.concerns.map((c) => '<button class="mt-row" data-act="mtConcern" data-id="' + esc(c.id) + '"><span class="mt-row-main"><b>' + esc(c.category) + ' · ' + esc(c.ref) + '</b><span class="xs muted">' + esc(rel(c.at)) + '</span></span><span class="mt-row-side">' + badge(c.status, ['Resolved', 'Closed'].indexOf(c.status) >= 0 ? 'success' : c.status === 'Awaiting Student' ? 'warning' : 'info') + '</span></button>').join('') + '</div>' : mtEmpty('Need help with something? Use <b>Raise a concern</b>. Only your mentor and authorised staff see it.')) +
      mtCard('My development', '<dl class="mt-dl"><dt>Career goal</dt><dd>' + esc(car.careerGoal || 'Not set yet') + '</dd><dt>Placement</dt><dd>' + esc(car.placementStatus || '—') + '</dd>' +
        '<dt>Skills</dt><dd>' + (car.skills.length ? car.skills.slice(0, 8).map((x) => '<span class="badge">' + esc(x) + '</span>').join(' ') : '—') + '</dd><dt>Certifications</dt><dd>' + car.certifications.length + '</dd><dt>Internships</dt><dd>' + car.internships.length + '</dd>' +
        (car.recommendations.length ? '<dt>Mentor recommendations</dt><dd>' + car.recommendations.filter((x) => !x.done).length + ' to do</dd>' : '') + '</dl>', '<a class="btn btn-sm btn-soft" href="#/mentoring/development">' + icon('edit', 'i-sm') + 'Update</a>') +
      '</div></div>'
  };
}
function mtGoalRow(gl) {
  const staff = mtIsStaff();
  return '<div class="mt-row mt-goal"><span class="mt-row-main"><b>' + esc(gl.title) + '</b><span class="xs muted">' + (staff ? mtStudentLink(gl.studentId, gl.student) + ' · ' : '') + esc(gl.category) + ' · ' + esc(gl.priority) + ' priority' + (gl.target ? ' · target ' + esc(mtDate(gl.target)) : '') + (gl.overdue ? ' · <b class="mt-od">past target</b>' : '') + '</span>' +
    '<span class="row" style="gap:.6rem;align-items:center">' + mtProg(gl.progress, gl.title) + '<b class="small tnum">' + gl.progress + '%</b></span>' +
    (gl.comments.length ? '<span class="xs mt-comment">' + icon('message', 'i-sm') + ' ' + esc(gl.comments[gl.comments.length - 1].by) + ': ' + esc(gl.comments[gl.comments.length - 1].text) + '</span>' : '') + '</span>' +
    '<span class="mt-row-side">' + badge(gl.status, gl.status === 'Completed' ? 'success' : gl.status === 'At Risk' ? 'warning' : gl.status === 'In Progress' ? 'info' : '') +
    '<span class="row" style="gap:4px"><button class="btn-icon sm" title="Update goal" data-act="mtGoalEdit" data-id="' + esc(gl.id) + '">' + icon('edit') + '</button>' + (staff ? '<button class="btn-icon sm" title="Comment" data-act="mtGoalComment" data-id="' + esc(gl.id) + '">' + icon('message') + '</button>' : '') + '</span></span></div>';
}
ACT.mtRequest = async () => {
  formModal('Request mentoring', 'Your mentor will pick a time and confirm it.', 'mtRequest',
    field('What would you like to discuss?', '<textarea name="topic" maxlength="1000" required autofocus placeholder="e.g. I am finding Business Law difficult and want to plan how to catch up."></textarea>') +
    '<div class="form-grid">' + field('Preferred time (optional)', '<input type="datetime-local" name="at">') + field('How', mtSel('mode', ['In person', 'Online', 'Phone'], 'In person')) + '</div>', 'Send request');
};
FORMS.mtRequest = (f, btn) => busy(btn, async () => {
  await call('mtSessionRequest', { topic: f.elements.topic.value, at: fromLocalInput(f.elements.at.value), mode: f.elements.mode.value });
  closeModal(); toast('Request sent to your mentor.'); refresh();
});
ACT.mtFeedback = (d) => {
  formModal('Session feedback', 'Your answers are shared with your mentor only as part of anonymous totals.', 'mtFeedback', '<input type="hidden" name="id" value="' + esc(d.id) + '">' +
    '<fieldset class="fieldset"><legend>Was the session useful?</legend><div class="mt-stars" role="radiogroup" aria-label="Rating from 1 to 5">' + [1, 2, 3, 4, 5].map((n) => '<label class="mt-star"><input type="radio" name="rating" value="' + n + '"' + (n === 4 ? ' checked' : '') + '><span>' + n + '</span></label>').join('') + '</div><p class="xs muted">1 = not useful · 5 = very useful</p></fieldset>' +
    field('What was helpful?', '<textarea name="helpful" maxlength="1000"></textarea>') + field('What additional support do you need?', '<textarea name="needs" maxlength="1000"></textarea>') +
    check('another', 'I would like another mentoring session', false), 'Send feedback');
};
FORMS.mtFeedback = (f, btn) => busy(btn, async () => {
  const r = f.querySelector('input[name=rating]:checked');
  await call('mtFeedback', { sessionId: f.elements.id.value, rating: r ? Number(r.value) : 0, useful: r && Number(r.value) >= 3, helpful: f.elements.helpful.value, needs: f.elements.needs.value, another: f.elements.another.checked });
  closeModal(); toast('Thank you for your feedback.'); refresh();
});

/* ---------- parent ---------- */
function mtParentHome(r) {
  return {
    title: 'Mentoring',
    html: pageHead('Mentoring', { crumbs: [['Mentoring']], sub: 'Your child’s mentor, meetings you are part of, and notes the mentor has shared with you.' }) +
      (r.children.length ? r.children.map((k) => '<section class="card mt-card"><div class="card-head">' + avatar(k.name) + '<h2>' + esc(k.name) + '</h2></div><div class="card-body">' +
        '<div class="mt-grid"><div class="mt-col">' +
        '<div class="mt-sub"><h3>Mentor</h3>' + (k.mentor ? '<p><b>' + esc(k.mentor.name) + '</b>' + (k.mentor.email ? ' · <a href="mailto:' + esc(k.mentor.email) + '">' + esc(k.mentor.email) + '</a>' : '') + '</p><p class="xs muted"><a href="#/chat">Message teachers</a></p>' : '<p class="small muted">No mentor has been assigned yet.</p>') + '</div>' +
        '<div class="mt-sub"><h3>Meetings with you</h3>' + (k.meetings.length ? '<div class="mt-list">' + k.meetings.map((x) => mtSessRow(x, { people: false })).join('') + '</div>' : '<p class="small muted">No parent meetings scheduled.</p>') + '</div>' +
        '</div><div class="mt-col">' +
        (k.goals ? '<div class="mt-sub"><h3>Goals</h3>' + (k.goals.length ? k.goals.map((gl) => '<div class="mt-row"><span class="mt-row-main"><b>' + esc(gl.title) + '</b><span class="xs muted">' + esc(gl.category) + (gl.target ? ' · target ' + esc(mtDate(gl.target)) : '') + '</span>' + mtProg(gl.progress, gl.title) + '</span><span class="mt-row-side">' + badge(gl.status) + '</span></div>').join('') : '<p class="small muted">No goals yet.</p>') + '</div>' : '') +
        '<div class="mt-sub"><h3>Shared notes</h3>' + (k.interactions.length ? k.interactions.map((x) => '<div class="mt-note"><div class="xs muted">' + esc(fmtDate(x.at)) + ' · ' + esc(x.mode) + ' · ' + esc(x.by) + '</div><b>' + esc(x.purpose) + '</b>' + (x.discussion ? '<p class="small">' + esc(x.discussion) + '</p>' : '') + (x.action ? '<p class="xs">Agreed: ' + esc(x.action) + '</p>' : '') + (x.followUp ? '<p class="xs muted">Follow-up: ' + esc(mtDate(x.followUp)) + '</p>' : '') + '</div>').join('') : '<p class="small muted">The mentor has not shared any notes yet.</p>') + '</div>' +
        '</div></div></div></section>').join('') : '<div class="card card-pad">' + emptyState('users', 'No linked students', 'Your account is not linked to a student yet. Please contact the college office.', '', false) + '</div>')
  };
}

/* =====================================================================
   MENTEES
   ===================================================================== */
async function viewMtMentees(params) {
  const p = Object.fromEntries(params.entries());
  const r = await call('mtMentees', p);
  const scopes = [['mine', 'My mentees']].concat(r.canDepartment ? [['department', 'My department' + (r.canAll ? 's' : '')]] : []).concat(r.canAll ? [['all', 'All students']] : []);
  const statuses = [['', 'Any status'], ['ok', r.labels.ok], ['attention', r.labels.attention], ['priority', r.labels.priority], ['nocontact', 'No recent interaction']];
  const rows = r.rows.map((c) => '<tr><td><div class="cell-user">' + avatar(c.name) + '<div><a href="#/mentoring/student/' + esc(c.id) + '"><b>' + esc(c.name) + '</b></a><span>' + esc(c.regNo) + '</span></div></div></td>' +
    '<td class="small">' + esc(c.batch || '—') + (c.department ? '<div class="xs muted">' + esc(c.department) + '</div>' : '') + '</td>' + (r.scope !== 'mine' ? '<td class="small">' + esc(c.mentor || '—') + '</td>' : '') +
    '<td>' + mtStatus(c.status, c.statusLabel) + (c.indicators.length ? '<div class="xs muted mt-clip" title="' + esc(c.indicators.join('; ')) + '">' + esc(c.indicators.join(' · ')) + '</div>' : '') + '</td>' +
    '<td class="tnum">' + mtPct(c.attendance) + '</td><td class="tnum">' + mtPct(c.internal) + '</td>' +
    '<td class="small">' + (c.lastSession ? esc(rel(c.lastSession)) : '<span class="muted">Never</span>') + (c.noContact ? '<div class="xs mt-od">' + icon('clock', 'i-sm') + 'due for contact</div>' : '') + '</td>' +
    '<td class="small">' + (c.overdue ? '<span class="mt-od">' + c.overdue + ' overdue</span>' : '') + (c.openConcerns ? '<div>' + plural(c.openConcerns, 'open concern') + '</div>' : '') + (!c.overdue && !c.openConcerns ? '<span class="muted">—</span>' : '') + '</td>' +
    (r.scope === 'mine' && r.canAdd ? '<td class="actions"><button class="btn-icon sm danger" title="Remove from my mentees" aria-label="Remove ' + esc(c.name) + ' from my mentees" data-act="mtRemoveMentee" data-id="' + esc(c.id) + '" data-name="' + esc(c.name) + '">' + icon('x') + '</button></td>' : '') + '</tr>').join('');
  return {
    title: 'Mentees',
    html: mtHead('Mentees', plural(r.total, 'student') + ' in this view.' + (r.scope === 'mine' ? ' You have ' + r.mine + ' of ' + r.maxMentees + ' mentees.' : ''), r.canAdd ? '<button class="btn btn-primary" data-act="mtAddMentees">' + icon('userPlus') + 'Add mentees</button>' : '', 'Mentees') + mtTabs('/mentoring/mentees') +
      '<div class="card"><form class="mt-filters" data-form="mtFilter" data-base="/mentoring/mentees">' +
      '<div class="search-box">' + icon('search') + '<input type="search" name="q" value="' + esc(p.q || '') + '" placeholder="Name, college ID or class" aria-label="Search mentees"></div>' +
      (scopes.length > 1 ? mtSel('scope', scopes, r.scope, { attrs: ' aria-label="Scope"' }) : '') + mtSel('status', statuses, p.status || '', { attrs: ' aria-label="Support status"' }) +
      (r.facets.departments.length ? mtSel('department', r.facets.departments.map((d) => [d.id, d.name]), p.department || '', { blank: 'All departments', attrs: ' aria-label="Department"' }) : '') +
      mtSel('batch', r.facets.batches, p.batch || '', { blank: 'All classes', attrs: ' aria-label="Class"' }) +
      '<button class="btn" type="submit">' + icon('filter', 'i-sm') + 'Apply</button></form>' +
      (r.rows.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Student</th><th>Class</th>' + (r.scope !== 'mine' ? '<th>Mentor</th>' : '') + '<th>Support status</th><th>Attendance</th><th>Internal</th><th>Last session</th><th>Open items</th>' + (r.scope === 'mine' && r.canAdd ? '<th></th>' : '') + '</tr></thead><tbody>' + rows + '</tbody></table></div>' + mtPager(r, '/mentoring/mentees' + mtQs(p, ['page']))
        : '<div class="card-body">' + emptyState('users', r.scope === 'mine' && !p.q && !p.status ? 'No mentees yet' : 'No students match', r.scope === 'mine' && !p.q && !p.status ? (r.canAdd ? 'Add your mentees yourself, or wait for your HOD or coordinator to allocate them.' : 'Students appear here once they are allocated to you.') : 'Try clearing the filters.', r.scope === 'mine' && r.canAdd && !p.q && !p.status ? '<button class="btn btn-primary" data-act="mtAddMentees">' + icon('userPlus') + 'Add mentees</button>' : '', false) + '</div>') + '</div>'
  };
}
/* ---------- Add mentees: the same steps as "Enrol users" in a course ---------- */
ACT.mtAddMentees = () => {
  MT.addPick = new Set();
  openModal(modalHead('Add mentees', 'Add students to your mentee list. Only students without a mentor are listed.') + '<div class="modal-body">' +
    '<div class="search-box" style="margin-bottom:.75rem">' + icon('search') + '<input type="search" id="mtAddQ" placeholder="Search by name, college ID or class" data-input="mtAddSearch" data-delay="200" aria-label="Search students" autofocus></div>' +
    '<div id="mtAddResults" class="card" style="max-height:320px;overflow-y:auto"><div class="card-pad small muted">Loading…</div></div>' +
    '<div class="form-actions" style="position:static;margin:1rem 0 0;padding:1rem 0 0;background:none;border-radius:0">' +
    '<span class="small muted" id="mtAddCount" style="margin-right:auto">No one selected</span><button class="btn" data-act="close">Cancel</button>' +
    '<button class="btn btn-primary" data-act="mtAddSelected" id="mtAddBtn" disabled>' + icon('userPlus') + 'Add selected</button></div>' +
    '<div id="mtAddBatch"></div></div>', 'wide');
  INPUTS.mtAddSearch({ value: '' });
};
INPUTS.mtAddSearch = async (el) => {
  const box = $('#mtAddResults');
  if (!box) return;
  try {
    const r = await call('mtMenteeSearch', { q: el.value || '' });
    if (!$('#mtAddResults')) return;
    box.innerHTML = r.rows.length ? r.rows.map((u) =>
      '<label class="disc-row" style="cursor:pointer"><input type="checkbox" data-change="mtAddPick" data-id="' + esc(u.id) + '"' + (MT.addPick.has(u.id) ? ' checked' : '') + ' style="width:16px;height:16px;accent-color:var(--primary)">' +
      avatar(u.name, 'sm') + '<div class="dr-main"><div class="dr-title">' + esc(u.name) + '</div><div class="dr-meta">@' + esc(u.username) + (u.batch ? ' · ' + esc(u.batch) : '') + '</div></div></label>').join('')
      : '<div class="card-pad small muted">No matching students without a mentor. A student who already has a mentor can be moved by your HOD or the mentoring coordinator.</div>';
    const bb = $('#mtAddBatch');
    if (bb && !bb.innerHTML) bb.innerHTML = (r.batches.length ? '<hr><form data-form="mtAddBatch" class="row-wrap"><div style="flex:1;min-width:200px"><b class="small">Add a whole class</b><div class="xs muted">Adds every student in the class who has no mentor yet.</div></div>' +
      '<select name="batch" style="width:auto;min-width:200px" aria-label="Class">' + r.batches.map((b) => '<option>' + esc(b) + '</option>').join('') + '</select>' +
      '<button class="btn btn-soft" type="submit">' + icon('users') + 'Add class</button></form>' : '') +
      '<p class="xs muted" style="margin-top:.75rem">You have ' + r.mine + ' of ' + r.maxMentees + ' mentees. Each student is told who their mentor is, and the change is kept in the allocation history.</p>';
  } catch (e) { if (!isExpired(e)) box.innerHTML = '<div class="card-pad small muted">' + esc(e.message) + '</div>'; }
};
ACT.mtAddPick = (d, el) => {
  if (el.checked) MT.addPick.add(d.id); else MT.addPick.delete(d.id);
  const n = MT.addPick.size;
  $('#mtAddCount').textContent = n ? n + ' selected' : 'No one selected';
  $('#mtAddBtn').disabled = !n;
};
ACT.mtAddSelected = (d, btn) => busy(btn, async () => {
  const r = await call('mtMenteeAdd', { userIds: Array.from(MT.addPick) });
  closeModal(); toast(plural(r.added, 'mentee') + ' added' + (r.skipped ? '; ' + r.skipped + ' already had a mentor' : '') + '.'); await refresh();
});
FORMS.mtAddBatch = (f, btn) => busy(btn, async () => {
  const r = await call('mtMenteeAdd', { batch: f.elements.batch.value });
  closeModal(); toast(plural(r.added, 'mentee') + ' added from ' + f.elements.batch.value + '.'); await refresh();
});
ACT.mtRemoveMentee = (d) => formModal('Remove ' + d.name + '?', 'They will no longer be your mentee. Their mentoring records and the allocation history are kept.', 'mtRemoveMentee',
  '<input type="hidden" name="id" value="' + esc(d.id) + '">' + field('Reason', '<input type="text" name="reason" maxlength="300" required autofocus placeholder="e.g. Added by mistake">'), 'Remove', 'narrow', true);
FORMS.mtRemoveMentee = (f, btn) => busy(btn, async () => { await call('mtMenteeRemove', { id: f.elements.id.value, reason: f.elements.reason.value }); closeModal(); toast('Removed from your mentees.'); await refresh(); });
FORMS.mtFilter = (f) => {
  const q = new URLSearchParams();
  Array.from(f.elements).forEach((el) => { if (el.name && el.value && el.type !== 'submit') q.set(el.name, el.type === 'checkbox' ? (el.checked ? '1' : '') : el.value); });
  Array.from(f.elements).forEach((el) => { if (el.type === 'checkbox' && !el.checked) q.delete(el.name); });
  go(f.dataset.base + (q.toString() ? '?' + q.toString() : ''));
};

/* =====================================================================
   STUDENT 360°
   ===================================================================== */
const MT_TABS360 = [['overview', 'Overview', 'dashboard'], ['academic', 'Academic', 'chart'], ['sessions', 'Sessions', 'calendar'], ['goals', 'Goals', 'target'], ['concerns', 'Concerns', 'message'],
  ['interventions', 'Interventions', 'zap'], ['followups', 'Follow-ups', 'clock'], ['parents', 'Parents', 'users'], ['career', 'Career', 'award'], ['assistant', 'Assistant', 'sparkle'], ['history', 'History', 'history']];
async function viewMtStudent(id, params) {
  const r = await call('mtStudent', { id });
  MT.stu = r; MT.opts = r.options;
  MT.concernCache = r.concerns; MT.sessCache = r.sessions; MT.actCache = r.actions; MT.goalCache = r.goals; MT.intCache = r.interventions;
  const st = r.student, ac = r.academics || {}, ms = r.mentoring, sup = r.support;
  const tab = MT_TABS360.some((t) => t[0] === params.get('tab')) ? params.get('tab') : 'overview';
  const att = ac.attendance, inn = ac.internal, lm = ac.lms;
  const last30 = att ? mtWindow(att.daily, 30, 0) : null;
  const car = r.career;
  const goalsDone = r.goals.filter((g) => g.status === 'Completed').length;
  const snap = [
    ['cap', 'indigo', 'Academic', inn && inn.avg != null ? inn.avg + '%' : lm && lm.grade != null ? lm.grade + '%' : '—', inn && inn.avg != null ? 'Internal assessment average' + (inn.courses.filter((c) => c.pct < 50).length ? ' · ' + inn.courses.filter((c) => c.pct < 50).length + ' below 50%' : '') : lm && lm.grade != null ? 'Course gradebook average' : 'No marks published yet'],
    ['calendar', 'blue', 'Attendance', att && att.overall != null ? att.overall + '%' : '—', att && att.held ? (last30 != null ? 'Last 30 days: ' + last30 + '%' : plural(att.held, 'period') + ' recorded') + ' · threshold ' + ac.threshold + '%' : 'No attendance recorded'],
    ['activity', 'cyan', 'Engagement', lm && lm.completion != null ? lm.completion + '%' : '—', lm ? (lm.inactiveDays != null ? 'Last active ' + (lm.inactiveDays ? lm.inactiveDays + ' days ago' : 'today') : 'Never opened a course') + (lm.missed ? ' · ' + lm.missed + ' missed deadline' + (lm.missed === 1 ? '' : 's') : '') : 'No course data'],
    ['target', 'violet', 'Goals', r.goals.length ? goalsDone + '/' + r.goals.length : '0', r.goals.length ? ms.goalsInProgress + ' in progress' + (ms.goalsAtRisk ? ' · ' + ms.goalsAtRisk + ' at risk' : '') : 'No goals yet'],
    ['users', 'green', 'Mentoring', String(ms.sessions), ms.daysSinceSession != null ? 'Last contact ' + (ms.lastSession ? rel(ms.lastSession) : ms.daysSinceSession + ' days since allocation') : 'No sessions yet'],
    ['message', 'amber', 'Concerns', String(ms.openConcerns), ms.openConcerns ? 'open' : 'none open'],
    ['zap', 'pink', 'Interventions', String(ms.openInterventions), ms.openInterventions ? 'in progress' : 'none active'],
    ['award', 'slate', 'Career', car.placementStatus || (car.careerGoal ? 'Goal set' : '—'), car.careerGoal ? car.careerGoal : 'Career goal not recorded']
  ];
  const openEvents = r.events.filter((e) => e.status === 'open');
  const tabsHtml = '<div class="tabs mt-360tabs" role="tablist" aria-label="Student record">' + MT_TABS360.map((t) => '<button type="button" class="tab' + (t[0] === tab ? ' active' : '') + '" role="tab" aria-selected="' + (t[0] === tab) + '" data-act="mtTab" data-tab="' + t[0] + '">' + icon(t[2]) + t[1] +
    (t[0] === 'followups' && ms.overdueActions ? '<span class="badge warning">' + ms.overdueActions + '</span>' : '') + (t[0] === 'concerns' && ms.openConcerns ? '<span class="badge">' + ms.openConcerns + '</span>' : '') + '</button>').join('') + '</div>';
  const pane = (k, html) => '<div class="mt-pane" data-pane="' + k + '"' + (k === tab ? '' : ' hidden') + ' role="tabpanel">' + html + '</div>';
  return {
    title: st.name + ' · Mentoring',
    html: '<div class="mt-360">' + pageHead(st.name, { crumbs: [['Mentoring', '/mentoring'], ['Mentees', '/mentoring/mentees'], [st.name]],
      sub: esc(st.regNo) + ' · ' + esc(st.batch || '—') + (st.department ? ' · ' + esc(st.department) : '') + (st.semester ? ' · Semester ' + esc(st.semester) : '') + (st.section ? ' · Section ' + esc(st.section) : '') + ' · Mentor: <b>' + esc(st.mentor || 'not assigned') + '</b>',
      actions: '<button class="btn btn-primary" data-act="mtSchedule" data-stu="' + esc(st.id) + '">' + icon('calendar') + 'Schedule</button>' +
        '<div class="menu-wrap"><button class="btn" data-act="menu" aria-label="More actions">' + icon('plus') + 'Add…</button><div class="menu">' +
        '<button class="menu-item" data-act="mtRecordNew" data-stu="' + esc(st.id) + '">' + icon('edit') + 'Record a session</button>' +
        '<button class="menu-item" data-act="mtGoalEdit" data-stu="' + esc(st.id) + '">' + icon('target') + 'Goal</button>' +
        '<button class="menu-item" data-act="mtActEdit" data-stu="' + esc(st.id) + '">' + icon('list') + 'Action item / follow-up</button>' +
        '<button class="menu-item" data-act="mtIntEdit" data-stu="' + esc(st.id) + '">' + icon('zap') + 'Intervention</button>' +
        '<button class="menu-item" data-act="mtConcernNew" data-stu="' + esc(st.id) + '">' + icon('message') + 'Concern</button>' +
        '<button class="menu-item" data-act="mtParentLog" data-stu="' + esc(st.id) + '">' + icon('users') + 'Parent interaction</button></div></div>' +
        '<div class="menu-wrap"><button class="btn" data-act="menu" aria-label="Reports">' + icon('download') + 'Report</button><div class="menu">' +
        '<a class="menu-item" href="#/mentoring/report/' + esc(st.id) + '">' + icon('printer') + 'Printable report (PDF)</a>' +
        '<button class="menu-item" data-act="mtExport" data-kind="student" data-stu="' + esc(st.id) + '">' + icon('download') + 'Excel workbook</button></div></div>' }) +
      '<section class="card mt-hero"><div class="mt-hero-id">' + avatar(st.name, 'lg') + '<div><div class="mt-eyebrow">Student Success Snapshot</div><div class="row-wrap" style="gap:.5rem;margin-top:.2rem">' + mtStatus(sup.status, sup.label) +
        (sup.noContact ? '<span class="mt-status mt-reminder">' + icon('clock', 'i-sm') + 'No recent interaction</span>' : '') + '</div>' +
        '<div class="xs muted" style="margin-top:.35rem">' + (sup.indicators.length ? plural(sup.indicators.length, 'indicator') + ' currently apply' : 'No indicators currently apply') + ' · these are prompts to review, not a judgement.</div></div></div>' +
        '<div class="mt-snap">' + snap.map((x) => '<div class="mt-snap-t"><span class="i-tile sm tone-' + x[1] + '">' + icon(x[0]) + '</span><div><div class="l">' + esc(x[2]) + '</div><div class="v">' + esc(x[3]) + '</div><div class="xs muted">' + esc(x[4]) + '</div></div></div>').join('') + '</div></section>' +
      (sup.indicators.length || openEvents.length ? '<section class="card mt-card mt-ind"><div class="card-head"><h2>' + esc(r.labels.indicator) + 's</h2><span class="spacer"></span><button class="btn btn-sm btn-soft" data-act="mtIntEdit" data-stu="' + esc(st.id) + '">' + icon('zap', 'i-sm') + 'Create intervention</button></div><div class="card-body"><div class="mt-list">' +
        (openEvents.length ? openEvents : sup.indicators.map((h) => ({ name: h.name, text: h.text, severity: h.severity }))).map((e) => '<div class="mt-row"><span class="mt-row-main"><b>' + esc(e.name) + '</b><span class="xs muted">' + esc(e.text) + '</span></span><span class="mt-row-side">' + mtSev(e.severity) +
          (e.id ? '<span class="row" style="gap:4px"><button class="btn btn-sm btn-soft" data-act="mtIntEdit" data-stu="' + esc(st.id) + '" data-event="' + esc(e.id) + '" data-problem="' + esc(e.name) + '">Plan action</button><button class="btn btn-sm" data-act="mtEventAct" data-id="' + esc(e.id) + '" data-action="review">Reviewed</button></span>' : '') + '</span></div>').join('') + '</div></div></section>' : '') +
      tabsHtml +
      pane('overview', mt360Overview(r)) + pane('academic', mt360Academic(r)) + pane('sessions', mt360Sessions(r)) + pane('goals', mt360Goals(r)) + pane('concerns', mt360Concerns(r)) +
      pane('interventions', mt360Interventions(r)) + pane('followups', mt360Followups(r)) + pane('parents', mt360Parents(r)) + pane('career', mt360Career(r)) + pane('assistant', mt360Assistant(r)) + pane('history', mt360History(r)) + '</div>'
  };
}
function mtWindow(daily, days, offset) {
  const d = (n) => { const x = new Date(); x.setDate(x.getDate() + n); return toDateInput(x.getTime()); };
  const from = d(-(days + offset)), to = d(-offset + 1);
  let h = 0, a = 0;
  (daily || []).forEach((x) => { if (x.date >= from && x.date < to) { h += x.held; a += x.attended; } });
  return h ? Math.round(a / h * 1000) / 10 : null;
}
ACT.mtTab = (d) => {
  $$('.mt-360tabs .tab').forEach((t) => { const on = t.dataset.tab === d.tab; t.classList.toggle('active', on); t.setAttribute('aria-selected', on); });
  $$('.mt-pane').forEach((p) => { p.hidden = p.dataset.pane !== d.tab; });
  history.replaceState(null, '', '#' + currentPath().split('?')[0] + '?tab=' + d.tab);
  mountCharts();
};
const MT_TL = { admission: ['cap', 'slate'], allocation: ['userPlus', 'indigo'], goal: ['target', 'violet'], session: ['users', 'green'], concern: ['message', 'amber'], indicator: ['flag', 'red'], intervention: ['zap', 'pink'], followup: ['check', 'blue'], outcome: ['award', 'green'], parent: ['users', 'cyan'] };
function mt360Overview(r) {
  const upcoming = r.sessions.filter((x) => x.status === 'scheduled' || x.status === 'requested').slice(0, 4);
  const open = r.actions.filter((x) => x.status === 'open').slice(0, 6);
  const id = r.student.identity;
  const tl = r.timeline.length ? '<ol class="mt-timeline">' + r.timeline.map((e) => { const x = MT_TL[e.kind] || ['info', 'slate']; return '<li><span class="mt-tl-dot tone-' + x[1] + '">' + icon(x[0], 'i-sm') + '</span><div><div class="xs muted">' + esc(fmtDate(e.at)) + '</div><b class="small">' + esc(e.title) + '</b>' + (e.detail ? '<div class="xs muted">' + esc(e.detail) + '</div>' : '') + '</div></li>'; }).join('') + '</ol>' : mtEmpty('The student’s mentoring journey will build up here.');
  return '<div class="mt-grid"><div class="mt-col">' + mtCard('Student Success Timeline', tl) + '</div><div class="mt-col">' +
    mtCard('Next meetings', upcoming.length ? '<div class="mt-list">' + upcoming.map((x) => mtSessRow(x, { people: false })).join('') + '</div>' : mtEmpty('Nothing scheduled.'), '<button class="btn btn-sm btn-soft" data-act="mtSchedule" data-stu="' + esc(r.student.id) + '">' + icon('plus', 'i-sm') + 'Schedule</button>') +
    mtCard('Open action items', open.length ? '<div class="mt-list">' + open.map((x) => mtActRow(x, { student: false })).join('') + '</div>' : mtEmpty('No open action items.'), '<button class="btn btn-sm btn-soft" data-act="mtActEdit" data-stu="' + esc(r.student.id) + '">' + icon('plus', 'i-sm') + 'Add</button>') +
    mtCard('Identity & academic record', '<dl class="mt-dl"><dt>College ID</dt><dd>' + esc(r.student.regNo) + '</dd><dt>Programme</dt><dd>' + esc(id.programme || '—') + '</dd><dt>Department</dt><dd>' + esc(id.departmentName || '—') + '</dd>' +
      '<dt>Semester / section</dt><dd>' + esc((id.semester || '—') + ' / ' + (id.section || '—')) + '</dd>' + (id.category ? '<dt>Category</dt><dd>' + esc(id.category) + '</dd>' : '') +
      '<dt>CGPA</dt><dd>' + esc(id.cgpa === '' ? '—' : id.cgpa) + '</dd><dt>Arrears / backlogs</dt><dd>' + esc(id.arrears === '' ? '—' : id.arrears) + '</dd>' + (id.results ? '<dt>Semester results</dt><dd class="small">' + esc(id.results) + '</dd>' : '') +
      '<dt>Email</dt><dd class="small">' + (r.student.email ? '<a href="mailto:' + esc(r.student.email) + '">' + esc(r.student.email) + '</a>' : '—') + '</dd><dt>Mobile</dt><dd class="small">' + esc(r.student.phone || '—') + '</dd></dl>' +
      '<p class="xs muted">CGPA, arrears and semester results are entered by the mentor or office — the LMS has no university results feed.</p>', '<button class="btn btn-sm btn-soft" data-act="mtIdentity">' + icon('edit', 'i-sm') + 'Edit</button>') +
    '</div></div>';
}
function mt360Academic(r) {
  const ac = r.academics || {};
  const att = ac.attendance, inn = ac.internal, lm = ac.lms;
  const weeks = [];
  if (att && att.daily.length) {
    for (let w = 11; w >= 0; w--) { const v = mtWindow(att.daily, 7, w * 7); weeks.push({ label: w ? w + 'w ago' : 'This week', v }); }
  }
  const wk = weeks.filter((x) => x.v != null);
  return '<div class="mt-grid"><div class="mt-col">' +
    mtCard('Attendance', att && att.held ? '<div class="row-wrap" style="gap:1.5rem;margin-bottom:1rem"><div><div class="mt-big">' + mtPct(att.overall) + '</div><div class="xs muted">overall · threshold ' + esc(ac.threshold) + '%</div></div><div><div class="mt-big">' + mtPct(mtWindow(att.daily, 30, 0)) + '</div><div class="xs muted">last 30 days</div></div><div><div class="mt-big">' + mtPct(mtWindow(att.daily, 30, 30)) + '</div><div class="xs muted">previous 30 days</div></div></div>' +
      (wk.length > 1 ? chartSlot('area', { values: wk.map((x) => x.v), labels: wk.map((x) => x.label), name: 'Attendance %', token: '1', label: 'Weekly attendance, last 12 weeks', valFmt: (v) => v + '%', height: 180 }) : '') +
      '<div class="table-wrap"><table class="table"><thead><tr><th>Course</th><th>Attendance</th><th>Periods</th><th></th></tr></thead><tbody>' + att.courses.map((c) => '<tr><td><b>' + esc(c.shortname) + '</b><div class="xs muted">' + esc(c.fullname) + '</div></td><td class="tnum">' + mtPct(c.pct) + '</td><td class="tnum">' + c.attended + '/' + c.held + '</td><td>' + (c.below ? badge('Below ' + ac.threshold + '%', 'warning', 'alert') : '') + '</td></tr>').join('') + '</tbody></table></div>'
      : mtEmpty('No attendance has been recorded for this student.')) +
    '</div><div class="mt-col">' +
    mtCard('Internal assessment', inn && inn.courses.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Course</th><th>Final</th><th>%</th></tr></thead><tbody>' + inn.courses.map((c) => '<tr><td><b>' + esc(c.shortname) + '</b>' + (c.absent ? '<div class="xs muted">absent for ' + plural(c.absent, 'component') + '</div>' : '') + '</td><td class="tnum">' + esc(c.final) + '/' + esc(c.finalMax) + '</td><td class="tnum">' + (c.pct < 50 ? '<b class="mt-od">' + mtPct(c.pct) + '</b>' : mtPct(c.pct)) + '</td></tr>').join('') + '</tbody></table></div><p class="xs muted">From published internal marks (Mark entry).</p>' : mtEmpty('No internal marks have been published yet.')) +
    mtCard('Courses & assignments', lm && lm.courses.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Course</th><th>Grade</th><th>Completion</th><th>Missed</th><th>Late</th></tr></thead><tbody>' + lm.courses.map((c) => '<tr><td><b>' + esc(c.shortname) + '</b></td><td class="tnum">' + mtPct(c.grade) + '</td><td class="tnum">' + mtPct(c.completion) + '</td><td class="tnum">' + (c.missed || 0) + '</td><td class="tnum">' + (c.late || 0) + '</td></tr>').join('') + '</tbody></table></div>' +
      '<p class="xs muted">Last LMS activity: ' + (lm.lastAccess ? esc(rel(lm.lastAccess)) : 'never') + '. Gradebook, completion and deadlines from the student’s courses.</p>' : mtEmpty('The student is not enrolled in any courses.')) +
    '</div></div>';
}
function mtSessCard(x) {
  const staffNotes = [['Student concern', x.concern], ['Mentor observation', x.observation], ['Shared with student', x.summary], ['Outcome', x.outcome]].filter((a) => a[1]);
  const ans = x.answers && Object.keys(x.answers).length ? '<dl class="mt-dl sm">' + Object.keys(x.answers).map((k) => '<dt>' + esc(k) + '</dt><dd>' + esc(x.answers[k]) + '</dd>').join('') + '</dl>' : '';
  return '<article class="mt-sess"><header class="row-wrap" style="gap:.5rem"><b>' + esc(x.type) + (x.category ? ' · ' + esc(x.category) : '') + '</b><span class="xs muted">' + esc(x.ref) + ' · ' + esc(mtWhen(x.at)) + ' · ' + esc(x.duration) + ' min · ' + esc(x.mode) + '</span><span class="spacer"></span>' + mtSessStatus(x.status) + mtLevel(x.level) + '</header>' +
    (x.students.length > 1 ? '<div class="xs muted">Group: ' + x.students.map((s) => esc(s.name)).join(', ') + '</div>' : '') + (x.parents.length ? '<div class="xs muted">Parents: ' + x.parents.map((s) => esc(s.name)).join(', ') + '</div>' : '') +
    (x.agenda ? '<p class="small"><span class="muted">Agenda:</span> ' + esc(x.agenda) + '</p>' : '') + ans +
    staffNotes.map((a) => '<p class="small"><span class="muted">' + a[0] + ':</span> ' + esc(a[1]) + '</p>').join('') +
    (x.privateNote ? '<p class="small mt-private">' + icon('lock', 'i-sm') + ' <span class="muted">Private note:</span> ' + esc(x.privateNote) + '</p>' : '') + (x.cancelReason ? '<p class="xs muted">Reason: ' + esc(x.cancelReason) + '</p>' : '') + mtFiles(x.attachments) +
    (x.canEdit !== false && ['scheduled', 'requested', 'completed'].indexOf(x.status) >= 0 ? '<footer class="row" style="gap:6px">' + (x.status !== 'completed' ? '<button class="btn btn-sm btn-soft" data-act="mtRecord" data-id="' + esc(x.id) + '">' + icon('edit', 'i-sm') + 'Record</button><button class="btn btn-sm" data-act="mtSchedule" data-id="' + esc(x.id) + '">' + icon('calendar', 'i-sm') + (x.status === 'requested' ? 'Schedule' : 'Reschedule') + '</button><button class="btn btn-sm btn-ghost" data-act="mtSessStatus" data-id="' + esc(x.id) + '" data-req="' + (x.status === 'requested' ? 1 : '') + '">' + (x.status === 'requested' ? 'Decline' : 'Cancel / missed') + '</button>' : '<button class="btn btn-sm btn-ghost" data-act="mtRecord" data-id="' + esc(x.id) + '">' + icon('edit', 'i-sm') + 'Edit notes</button>') + '</footer>' : '') + '</article>';
}
function mt360Sessions(r) {
  return mtCard('Mentoring sessions', r.sessions.length ? '<div class="mt-sess-list">' + r.sessions.map(mtSessCard).join('') + '</div>' : emptyState('calendar', 'No sessions yet', 'Schedule the first mentoring session.', '<button class="btn btn-primary" data-act="mtSchedule" data-stu="' + esc(r.student.id) + '">' + icon('calendar') + 'Schedule session</button>', false),
    '<button class="btn btn-sm btn-soft" data-act="mtRecordNew" data-stu="' + esc(r.student.id) + '">' + icon('edit', 'i-sm') + 'Record a past session</button><button class="btn btn-sm btn-soft" data-act="mtSchedule" data-stu="' + esc(r.student.id) + '">' + icon('plus', 'i-sm') + 'Schedule</button>');
}
function mt360Goals(r) {
  return mtCard('Goals & development plan', r.goals.length ? '<div class="mt-list">' + r.goals.map(mtGoalRow).join('') + '</div>' : emptyState('target', 'No goals yet', 'Set a goal together — academic, career, skill or personal development.', '<button class="btn btn-primary" data-act="mtGoalEdit" data-stu="' + esc(r.student.id) + '">' + icon('plus') + 'Add goal</button>', false),
    '<button class="btn btn-sm btn-soft" data-act="mtGoalEdit" data-stu="' + esc(r.student.id) + '">' + icon('plus', 'i-sm') + 'Add goal</button>');
}
function mtConcernRow(c) {
  return '<button class="mt-row" data-act="mtConcern" data-id="' + esc(c.id) + '"><span class="mt-row-main"><b>' + esc(c.category) + ' · ' + esc(c.ref) + '</b><span class="xs muted">' + (mtIsStaff() ? esc(c.student) + ' · ' : '') + esc(fmtDate(c.at)) + ' · raised by ' + esc(c.byStudent ? 'student' : c.raisedBy) + (c.mentor ? ' · with ' + esc(c.mentor) : '') + '</span><span class="xs mt-clip">' + esc(c.description) + '</span></span>' +
    '<span class="mt-row-side">' + badge(c.status, ['Resolved', 'Closed'].indexOf(c.status) >= 0 ? 'success' : c.status === 'Awaiting Student' ? 'warning' : 'info') + badge(c.priority, c.priority === 'High' ? 'danger' : '') + (mtIsStaff() ? mtLevel(c.level) : '') + '</span></button>';
}
function mt360Concerns(r) {
  return mtCard('Concerns & support requests', r.concerns.length ? '<div class="mt-list">' + r.concerns.map(mtConcernRow).join('') + '</div>' : mtEmpty('No concerns recorded.'), '<button class="btn btn-sm btn-soft" data-act="mtConcernNew" data-stu="' + esc(r.student.id) + '">' + icon('plus', 'i-sm') + 'Log concern</button>');
}
function mtIntCard(x) {
  return '<article class="mt-sess"><header class="row-wrap" style="gap:.5rem"><b>' + esc(x.ref) + '</b><span class="xs muted">' + (mtIsStaff() && MT.stu ? '' : esc(x.student) + ' · ') + 'by ' + esc(x.createdBy) + ' · ' + esc(fmtDate(x.at)) + (x.source && x.source.kind !== 'manual' ? ' · from ' + esc(x.source.kind) : '') + '</span><span class="spacer"></span>' +
    badge(x.status === 'completed' ? 'Completed' : x.status === 'cancelled' ? 'Cancelled' : x.status === 'in_progress' ? 'In progress' : 'Open', x.status === 'completed' ? 'success' : x.status === 'cancelled' ? '' : 'info') + (x.outcomeLabel ? badge(x.outcomeLabel, x.outcome === 'improved' ? 'success' : x.outcome === 'partial' ? 'warning' : 'danger', 'award') : '') + mtLevel(x.level) + '</header>' +
    '<p class="small"><span class="muted">Problem:</span> ' + esc(x.problem) + '</p>' + (x.plan ? '<p class="small"><span class="muted">Plan:</span> ' + esc(x.plan) + '</p>' : '') +
    (x.actions.length ? '<div class="mt-plan"><div class="xs muted mt-eyebrow">Action plan</div>' + x.actions.map((a) => mtActRow(a, { student: false })).join('') + '</div>' : '') +
    (x.outcomeNote ? '<p class="small"><span class="muted">Outcome note:</span> ' + esc(x.outcomeNote) + '</p>' : '') + mtFiles(x.attachments) +
    (['open', 'in_progress'].indexOf(x.status) >= 0 ? '<footer class="row" style="gap:6px"><button class="btn btn-sm btn-soft" data-act="mtIntEdit" data-id="' + esc(x.id) + '">' + icon('edit', 'i-sm') + 'Update plan</button><button class="btn btn-sm" data-act="mtIntOutcome" data-id="' + esc(x.id) + '">' + icon('award', 'i-sm') + 'Record outcome</button>' + (MT.stu ? '' : '<a class="btn btn-sm btn-ghost" href="#/mentoring/student/' + esc(x.studentId) + '?tab=interventions">Student</a>') + '</footer>' : '') + '</article>';
}
function mt360Interventions(r) {
  return mtCard('Interventions', r.interventions.length ? '<div class="mt-sess-list">' + r.interventions.map(mtIntCard).join('') + '</div>' : mtEmpty('No interventions. Create one when an indicator or concern needs a structured plan.'), '<button class="btn btn-sm btn-soft" data-act="mtIntEdit" data-stu="' + esc(r.student.id) + '">' + icon('plus', 'i-sm') + 'Create intervention</button>');
}
function mt360Followups(r) {
  const open = r.actions.filter((x) => x.status === 'open'), done = r.actions.filter((x) => x.status !== 'open');
  return mtCard('Action items & follow-ups', (open.length ? '<div class="mt-list">' + open.map((x) => mtActRow(x, { student: false })).join('') + '</div>' : mtEmpty('Nothing open.')) +
    (done.length ? '<details class="mt-more"><summary class="small">' + plural(done.length, 'completed or cancelled item') + '</summary><div class="mt-list">' + done.map((x) => mtActRow(x, { student: false })).join('') + '</div></details>' : ''), '<button class="btn btn-sm btn-soft" data-act="mtActEdit" data-stu="' + esc(r.student.id) + '">' + icon('plus', 'i-sm') + 'Add</button>');
}
function mt360Parents(r) {
  return '<div class="mt-grid"><div class="mt-col">' + mtCard('Parents / guardians', r.parents.length ? '<div class="mt-list">' + r.parents.map((p) => '<div class="mt-row">' + avatar(p.name) + '<span class="mt-row-main"><b>' + esc(p.name) + '</b><span class="xs muted">' + esc(p.phone || 'no mobile') + '</span></span></div>').join('') + '</div>' : mtEmpty('No parent account is linked to this student.'),
    r.parents.length ? '<button class="btn btn-sm btn-soft" data-act="mtSchedule" data-stu="' + esc(r.student.id) + '" data-parent="1">' + icon('calendar', 'i-sm') + 'Parent meeting</button>' : '') + '</div><div class="mt-col">' +
    mtCard('Interaction log', r.interactions.length ? r.interactions.map((x) => '<div class="mt-note"><div class="row-wrap" style="gap:.4rem"><span class="xs muted">' + esc(fmtDate(x.at)) + ' · ' + esc(x.mode) + ' · ' + esc(x.by) + '</span><span class="spacer"></span>' + (x.shared ? badge('Shared with parent', 'info', 'eye') : '') + mtLevel(x.level) + '</div><b>' + esc(x.purpose) + '</b>' +
      (x.parents.length ? '<div class="xs muted">With ' + esc(x.parents.join(', ')) + '</div>' : '') + (x.discussion ? '<p class="small">' + esc(x.discussion) + '</p>' : '') + (x.sharedSummary ? '<p class="small"><span class="muted">Shared summary:</span> ' + esc(x.sharedSummary) + '</p>' : '') +
      (x.action ? '<p class="xs">Action: ' + esc(x.action) + '</p>' : '') + (x.outcome ? '<p class="xs">Outcome: ' + esc(x.outcome) + '</p>' : '') + '</div>').join('') : mtEmpty('No parent or guardian interactions recorded.'),
    '<button class="btn btn-sm btn-soft" data-act="mtParentLog" data-stu="' + esc(r.student.id) + '">' + icon('plus', 'i-sm') + 'Log interaction</button>') + '</div></div>';
}
function mtCareerHtml(c) {
  const li = (arr, fn) => arr.length ? '<ul class="mt-ul">' + arr.map(fn).join('') + '</ul>' : '<span class="muted">—</span>';
  return '<dl class="mt-dl"><dt>Career goal</dt><dd>' + esc(c.careerGoal || '—') + '</dd><dt>Target industry / role</dt><dd>' + esc([c.industry, c.jobRole].filter(Boolean).join(' · ') || '—') + '</dd><dt>Preferred location</dt><dd>' + esc(c.location || '—') + '</dd>' +
    '<dt>Higher education</dt><dd>' + esc(c.higherEd || '—') + '</dd><dt>Placement status</dt><dd>' + esc(c.placementStatus || '—') + '</dd><dt>Entrepreneurship</dt><dd>' + esc(c.entrepreneurship || '—') + '</dd>' +
    '<dt>Skills</dt><dd>' + (c.skills.length ? c.skills.map((x) => '<span class="badge">' + esc(x) + '</span>').join(' ') : '—') + '</dd>' +
    '<dt>Certifications</dt><dd>' + li(c.certifications, (x) => '<li>' + esc(x.name) + (x.issuer ? ' · ' + esc(x.issuer) : '') + (x.date ? ' · ' + esc(mtDate(x.date)) : '') + (x.file ? ' ' + fileChip(x.file) : '') + '</li>') + '</dd>' +
    '<dt>Internships</dt><dd>' + li(c.internships, (x) => '<li>' + esc(x.org) + (x.role ? ' — ' + esc(x.role) : '') + (x.from ? ' · ' + esc(mtDate(x.from)) + (x.to ? ' to ' + esc(mtDate(x.to)) : '') : '') + '</li>') + '</dd>' +
    '<dt>Projects</dt><dd>' + li(c.projects, (x) => '<li><b>' + esc(x.title) + '</b>' + (x.desc ? ' — ' + esc(x.desc) : '') + '</li>') + '</dd></dl>' +
    '<h3 class="mt-h3">Mentor recommendations</h3>' + (c.recommendations.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Skill gap</th><th>Recommended activity</th><th>Target</th><th>Status</th><th>Evidence</th></tr></thead><tbody>' +
      c.recommendations.map((x) => '<tr><td class="small">' + esc(x.skillGap || '—') + '</td><td class="small">' + esc(x.activity) + '<div class="xs muted">' + esc(x.by) + '</div></td><td class="small">' + esc(mtDate(x.target)) + '</td><td>' + (x.done ? badge('Done', 'success', 'checkCircle') : badge('To do')) + '</td><td>' + (x.evidence ? fileChip(x.evidence) : '<span class="muted">—</span>') + '</td></tr>').join('') + '</tbody></table></div>' : mtEmpty('No recommendations yet.'));
}
function mt360Career(r) { return mtCard('Career & professional development', mtCareerHtml(r.career), '<button class="btn btn-sm btn-soft" data-act="mtCareerEdit">' + icon('edit', 'i-sm') + 'Edit</button>'); }
function mt360Assistant(r) {
  const kinds = [['summary', 'Summarise recent activity', 'sparkle'], ['prep', 'Prepare the next meeting', 'list'], ['progress', 'Changes since last session', 'trending'], ['suggest', 'Suggest possible actions', 'target'], ['followups', 'Incomplete follow-ups', 'clock']];
  return mtCard('AI mentoring assistant', notice('Advisory only. It works from this student’s records, never diagnoses, and never decides for you. ' + (r.options.aiExternal ? 'Claude receives pseudonymised records (no name or ID, no restricted notes).' : 'External AI is off: summaries are generated on the server from the records.') + ' Every request is logged.', '', 'shield') +
    '<div class="row-wrap mt-ai-btns">' + kinds.map((k) => '<button class="btn" data-act="mtAi" data-kind="' + k[0] + '">' + icon(k[2], 'i-sm') + k[1] + '</button>').join('') + '</div><div id="mtAiOut">' +
    (r.ai.length ? r.ai.map(mtAiBlock).join('') : '') + '</div>');
}
function mtAiBlock(x) {
  return '<article class="mt-ai"><header class="row-wrap" style="gap:.5rem">' + badge(x.mode === 'claude' ? 'AI-generated' : 'Auto-generated', 'primary', 'sparkle') + '<b class="small">' + esc(x.label || { summary: 'Student summary', prep: 'Meeting preparation', progress: 'Progress since last session', suggest: 'Suggested actions', followups: 'Follow-up summary' }[x.kind] || x.kind) + '</b><span class="xs muted">' + esc(rel(x.at)) + (x.by ? ' · ' + esc(x.by) : '') + '</span></header><div class="prose small">' + md(x.text) + '</div>' + (x.notice ? '<p class="xs muted">' + esc(x.notice) + '</p>' : '') + '</article>';
}
ACT.mtAi = (d, btn) => busy(btn, async () => {
  const r = await call('mtAi', { studentId: MT.stu.student.id, kind: d.kind });
  const el = $('#mtAiOut');
  if (el) el.insertAdjacentHTML('afterbegin', mtAiBlock(r));
});
function mt360History(r) {
  return mtCard('Mentor allocation history', r.allocations.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Mentor</th><th>From</th><th>To</th><th>Changed by</th><th>Reason</th></tr></thead><tbody>' + r.allocations.map((a) => '<tr><td><b>' + esc(a.mentor) + '</b>' + (a.active ? ' ' + badge('Current', 'success') : '') + '</td><td class="small">' + esc(fmtDate(a.from)) + '</td><td class="small">' + (a.to ? esc(fmtDate(a.to)) : '—') + '</td><td class="small">' + esc(a.by) + '</td><td class="small">' + esc(a.reason || '—') + (a.endReason ? '<div class="xs muted">Ended: ' + esc(a.endReason) + '</div>' : '') + '</td></tr>').join('') + '</tbody></table></div>' : mtEmpty('No allocation history.')) +
    mtCard('Session feedback', r.feedback.avg != null ? '<p><b class="mt-big">' + r.feedback.avg + '</b> / 5 average from ' + plural(r.feedback.count, 'response') + '.</p><p class="xs muted">Individual answers are not shown to keep feedback anonymous.</p>' : mtEmpty(r.feedback.count ? 'Feedback is shown once there are enough responses to keep it anonymous.' : 'No feedback yet.'));
}

/* =====================================================================
   SESSION FORMS
   ===================================================================== */
async function mtStudentPicker(sel, onlyOne) {
  const list = await call('mtPeople', {});
  MT.people = list;
  MT.pick = new Set(sel || []);
  return '<fieldset class="fieldset"><legend>Student' + (onlyOne ? '' : 's') + '</legend><div class="search-box" style="margin-bottom:.5rem">' + icon('search') + '<input type="search" data-input="mtPickFilter" data-delay="250" placeholder="Search your students" aria-label="Search students"></div>' +
    '<div class="mt-pick" id="mtPick">' + mtPickList(list) + '</div><p class="xs muted">' + (onlyOne ? 'Choose one student.' : 'Choose one student, or several for a group session.') + '</p></fieldset>';
}
function mtPickList(list) {
  if (!list.length) return '<p class="small muted">No students found.</p>';
  return list.map((u) => '<label class="check"><input type="checkbox" name="stu" value="' + esc(u.id) + '"' + (MT.pick.has(u.id) ? ' checked' : '') + ' data-change="mtPickToggle"><span>' + esc(u.name) + '<span class="hint">' + esc(u.regNo) + ' · ' + esc(u.batch || '') + '</span></span></label>').join('');
}
INPUTS.mtPickFilter = async (el) => { const list = await call('mtPeople', { q: el.value }); MT.people = list; const box = $('#mtPick'); if (box) box.innerHTML = mtPickList(list); };
ACT.mtPickToggle = (d, el) => { if (el.checked) MT.pick.add(el.value); else MT.pick.delete(el.value); };
ACT.mtSchedule = async (d) => {
  const o = await mtOptions();
  const x = d.id ? (MT.sessCache || []).find((s) => s.id === d.id) || null : null;
  const stu = x ? x.students.map((s) => s.id) : d.stu ? [d.stu] : [];
  const parents = MT.stu && d.stu === MT.stu.student.id ? MT.stu.parents : [];
  const at = x ? x.at : (() => { const t = new Date(); t.setDate(t.getDate() + 1); t.setHours(10, 0, 0, 0); return t.getTime(); })();
  const picker = x ? '<input type="hidden" name="stuIds" value="' + esc(stu.join(',')) + '"><p class="small"><b>' + esc(x.students.map((s) => s.name).join(', ')) + '</b></p>' : d.stu ? '<input type="hidden" name="stuIds" value="' + esc(d.stu) + '">' : await mtStudentPicker(stu);
  formModal(x ? (x.status === 'requested' ? 'Schedule requested session' : 'Reschedule session') : 'Schedule mentoring session', x && x.requestNote ? 'Student’s request: ' + esc(x.requestNote) : 'Participants are notified and it appears in their calendar.', 'mtSchedule',
    '<input type="hidden" name="id" value="' + esc(x ? x.id : '') + '">' + picker +
    '<div class="form-grid">' + field('Session type', mtSel('type', o.sessionTypes, x ? x.type : d.parent ? 'Parent/Guardian meeting' : o.sessionTypes[0])) + field('Category', mtSel('category', o.sessionCategories, x ? x.category : o.sessionCategories[0])) + '</div>' +
    '<div class="form-grid-3">' + field('Date and time', '<input type="datetime-local" name="at" required value="' + esc(toLocalInput(at)) + '">') + field('Duration (minutes)', '<input type="number" name="duration" min="5" max="480" value="' + esc(x ? x.duration : 30) + '">') + field('Mode', mtSel('mode', o.modes, x ? x.mode : 'In person')) + '</div>' +
    '<div class="form-grid">' + field('Location', '<input type="text" name="location" maxlength="200" value="' + esc(x ? x.location : '') + '" placeholder="e.g. Staff room 2">') + field('Meeting link (online)', '<input type="url" name="link" maxlength="400" value="' + esc(x ? x.link : '') + '" placeholder="https://…">') + '</div>' +
    field('Agenda', '<textarea name="agenda" maxlength="2000">' + esc(x ? x.agenda : '') + '</textarea>') +
    (parents.length ? '<fieldset class="fieldset"><legend>Invite parents / guardians</legend>' + parents.map((p) => check('par_' + p.id, esc(p.name), !!d.parent)).join('') + '</fieldset>' : '') +
    (!x ? '<div class="form-grid">' + field('Repeat', mtSel('repeat', [['', 'Does not repeat'], ['week', 'Every week'], ['fortnight', 'Every two weeks'], ['month', 'Every month']], '')) + field('Number of sessions', '<input type="number" name="count" min="1" max="12" value="1">') + '</div>' : '') +
    mtLevelSel(x ? x.level : 2), x ? 'Save' : 'Schedule', 'wide');
};
FORMS.mtSchedule = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  const ids = el.stuIds ? el.stuIds.value.split(',').filter(Boolean) : Array.from(MT.pick);
  const parentIds = Array.from(f.querySelectorAll('input[type=checkbox][name^="par_"]')).filter((c) => c.checked).map((c) => c.name.slice(4));
  const r = await call('mtSessionSave', { id: el.id.value, studentIds: ids, type: el.type.value, category: el.category.value, at: fromLocalInput(el.at.value), duration: el.duration.value, mode: el.mode.value, location: el.location.value, link: el.link.value, agenda: el.agenda.value, parentIds, repeat: el.repeat ? el.repeat.value : '', count: el.count ? el.count.value : 1, level: el.level.value });
  closeModal(); toast(r.created > 1 ? r.created + ' sessions scheduled.' : 'Session saved.'); refresh();
});
ACT.mtSessStatus = async (d) => {
  formModal(d.req ? 'Decline request' : 'Cancel or mark missed', 'Participants are told.', 'mtSessStatus', '<input type="hidden" name="id" value="' + esc(d.id) + '">' +
    (d.req ? '<input type="hidden" name="action" value="decline">' : field('What happened?', mtSel('action', [['cancel', 'Cancelled'], ['missed', 'The student did not attend (missed)']], 'cancel'))) +
    field('Reason', '<textarea name="reason" maxlength="500" autofocus></textarea>'), d.req ? 'Decline' : 'Save', 'narrow');
};
FORMS.mtSessStatus = (f, btn) => busy(btn, async () => { await call('mtSessionStatus', { id: f.elements.id.value, action: f.elements.action.value, reason: f.elements.reason.value }); closeModal(); toast('Updated.'); refresh(); });
ACT.mtRecordNew = async (d) => {
  const o = await mtOptions();
  formModal('Record a session', 'For a session that has already happened.', 'mtRecordNew', '<input type="hidden" name="stu" value="' + esc(d.stu) + '">' +
    '<div class="form-grid">' + field('Session type', mtSel('type', o.sessionTypes, o.sessionTypes[0])) + field('Category', mtSel('category', o.sessionCategories, o.sessionCategories[0])) + '</div>' +
    '<div class="form-grid-3">' + field('When', '<input type="datetime-local" name="at" required value="' + esc(toLocalInput(Date.now() - 3600000)) + '">') + field('Duration (minutes)', '<input type="number" name="duration" min="5" max="480" value="30">') + field('Mode', mtSel('mode', o.modes, 'In person')) + '</div>', 'Next: notes', 'wide');
};
FORMS.mtRecordNew = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  const r = await call('mtSessionSave', { studentIds: [el.stu.value], type: el.type.value, category: el.category.value, at: fromLocalInput(el.at.value), duration: el.duration.value, mode: el.mode.value, level: 2 });
  const list = await call('mtSessions', { studentId: el.stu.value, when: 'all', scope: 'all' });
  MT.sessCache = list.rows;
  ACT.mtRecord({ id: r.id });
});
ACT.mtRecord = async (d) => {
  const o = await mtOptions();
  let x = (MT.sessCache || []).find((s) => s.id === d.id);
  if (!x) { const l = await call('mtSessions', { when: 'all', scope: 'all' }); x = l.rows.find((s) => s.id === d.id); }
  if (!x) { toast('Session not found.', 'err'); return; }
  const tpl = o.templates.find((t) => t.id === x.template) || o.templates.find((t) => t.category === x.category) || null;
  const done = x.status === 'completed';
  formModal((done ? 'Edit notes — ' : 'Record session — ') + x.type, esc(x.students.map((s) => s.name).join(', ')) + ' · ' + esc(mtWhen(x.at)), 'mtRecord',
    '<input type="hidden" name="id" value="' + esc(x.id) + '">' +
    field('Template', mtSel('template', o.templates.map((t) => [t.id, t.name]), tpl ? tpl.id : '', { blank: 'No template', attrs: ' data-change="mtTplSwitch"' }), 'Structured prompts for this kind of discussion (administrators can change them).') +
    '<div id="mtTpl">' + mtTplFields(tpl, x.answers) + '</div>' +
    '<div class="form-grid">' + field('Student concern', '<textarea name="concern" maxlength="3000">' + esc(x.concern || '') + '</textarea>') + field('Mentor observation', '<textarea name="observation" maxlength="4000">' + esc(x.observation || '') + '</textarea>') + '</div>' +
    field('Summary shared with the student', '<textarea name="summary" maxlength="3000">' + esc(x.summary || '') + '</textarea>', 'Shown to the student when the session is Level 1 (Student visible).') +
    '<div class="form-grid">' + field('Outcome', '<input type="text" name="outcome" maxlength="1000" value="' + esc(x.outcome || '') + '">') + field('Private note', '<input type="text" name="privateNote" maxlength="4000" value="' + esc(x.privateNote || '') + '">', 'Never shown to students or parents.') + '</div>' +
    '<fieldset class="fieldset"><legend>Action items (action plan)</legend><div class="mt-actrows">' + [0, 1, 2].map((i) => '<div class="mt-actrow"><input type="text" name="a_t' + i + '" maxlength="300" placeholder="Action required" aria-label="Action ' + (i + 1) + '">' +
      mtSel('a_o' + i, Object.keys(o.owners).map((k) => [k, o.owners[k]]), 'student', { attrs: ' aria-label="Action owner"' }) + '<input type="date" name="a_d' + i + '" aria-label="Target date"></div>').join('') + '</div>' +
      field('Follow-up date', '<input type="date" name="followUpDate">', 'Creates a follow-up for you on that date.') + '</fieldset>' +
    field('Attachments', '<input type="file" name="files" multiple accept="' + MT_ATTACH_ACCEPT + '">', 'PDF, images, Office documents, CSV or text — 10 MB each.') + mtFiles(x.attachments) +
    '<div class="form-grid">' + mtLevelSel(x.level) + '<div>' + (done ? '' : check('complete', 'Mark the session as completed', true)) + check('requestFeedback', 'Ask the student for feedback', !done) + '</div></div>', done ? 'Save notes' : 'Save', 'xwide');
};
function mtTplFields(tpl, answers) {
  if (!tpl) return '';
  answers = answers || {};
  return '<div class="mt-tpl"><div class="xs muted mt-eyebrow">' + esc(tpl.name) + '</div>' + tpl.prompts.map((q, i) => field(esc(q), '<textarea name="q_' + i + '" data-q="' + esc(q) + '" rows="2" maxlength="1000">' + esc(answers[q] || '') + '</textarea>')).join('') + '</div>';
}
ACT.mtTplSwitch = (d, el) => { const t = (MT.opts.templates || []).find((x) => x.id === el.value); $('#mtTpl').innerHTML = mtTplFields(t, {}); };
FORMS.mtRecord = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  const answers = {};
  $$('#mtTpl textarea', f).forEach((t) => { if (t.value.trim()) answers[t.dataset.q] = t.value; });
  const actions = [0, 1, 2].map((i) => ({ title: el['a_t' + i].value, owner: el['a_o' + i].value, due: el['a_d' + i].value })).filter((a) => a.title.trim());
  const attachments = await mtUploadAll(el.files);
  await call('mtSessionRecord', { id: el.id.value, template: el.template.value, answers, concern: el.concern.value, observation: el.observation.value, summary: el.summary.value, outcome: el.outcome.value, privateNote: el.privateNote.value, actions, followUpDate: el.followUpDate.value, attachments, level: el.level.value, complete: el.complete ? el.complete.checked : false, requestFeedback: el.requestFeedback.checked });
  closeModal(); toast('Session saved.'); refresh();
});

/* =====================================================================
   GOALS, ACTIONS, INTERVENTIONS, CONCERNS, PARENTS, IDENTITY, CAREER
   ===================================================================== */
ACT.mtGoalEdit = async (d) => {
  const gl = d.id ? (MT.goalCache || []).find((x) => x.id === d.id) : null;
  const o = MT.opts || (mtIsStaff() ? await mtOptions() : { goalCategories: MT.me.goalCategories, goalStatus: ['Not Started', 'In Progress', 'At Risk', 'Completed', 'Deferred', 'Cancelled'], priorities: ['Low', 'Medium', 'High'] });
  formModal(gl ? 'Update goal' : 'New goal', gl ? esc(gl.title) : 'Specific, measurable and with a target date works best.', 'mtGoal',
    '<input type="hidden" name="id" value="' + esc(gl ? gl.id : '') + '"><input type="hidden" name="stu" value="' + esc(d.stu || '') + '">' +
    field('Goal', '<input type="text" name="title" maxlength="200" required value="' + esc(gl ? gl.title : '') + '" placeholder="e.g. Score 60% or more in Financial Accounting">') +
    '<div class="form-grid-3">' + field('Category', mtSel('category', o.goalCategories, gl ? gl.category : o.goalCategories[0])) + field('Priority', mtSel('priority', o.priorities || ['Low', 'Medium', 'High'], gl ? gl.priority : 'Medium')) + field('Status', mtSel('status', o.goalStatus || ['Not Started', 'In Progress', 'At Risk', 'Completed', 'Deferred', 'Cancelled'], gl ? gl.status : 'Not Started')) + '</div>' +
    field('Description', '<textarea name="description" maxlength="3000">' + esc(gl ? gl.description : '') + '</textarea>') +
    field('Success criteria', '<input type="text" name="criteria" maxlength="1000" value="' + esc(gl ? gl.criteria : '') + '" placeholder="How will we know it is achieved?">') +
    '<div class="form-grid-3">' + field('Start date', '<input type="date" name="start" value="' + esc(gl ? gl.start : toDateInput(Date.now())) + '">') + field('Target date', '<input type="date" name="target" value="' + esc(gl ? gl.target : '') + '">') +
    field('Progress', '<input type="range" name="progress" min="0" max="100" step="5" value="' + esc(gl ? gl.progress : 0) + '" data-change="mtRange" aria-describedby="mtProgOut"><output id="mtProgOut" class="small">' + (gl ? gl.progress : 0) + '%</output>') + '</div>' +
    (gl ? field('Update note (optional)', '<input type="text" name="note" maxlength="500">') : ''), gl ? 'Save' : 'Add goal', 'wide');
};
ACT.mtRange = (d, el) => { const o = $('#mtProgOut'); if (o) o.textContent = el.value + '%'; };
document.addEventListener('input', (e) => { if (e.target && e.target.name === 'progress' && e.target.type === 'range') { const o = $('#mtProgOut'); if (o) o.textContent = e.target.value + '%'; } });
FORMS.mtGoal = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  await call('mtGoalSave', { id: el.id.value, studentId: el.stu.value, title: el.title.value, category: el.category.value, priority: el.priority.value, status: el.status.value, description: el.description.value, criteria: el.criteria.value, start: el.start.value, target: el.target.value, progress: el.progress.value, note: el.note ? el.note.value : '' });
  closeModal(); toast('Goal saved.'); refresh();
});
ACT.mtGoalComment = (d) => formModal('Comment on goal', 'The student sees your comment.', 'mtGoalComment', '<input type="hidden" name="id" value="' + esc(d.id) + '">' + field('Comment', '<textarea name="text" maxlength="1000" required autofocus></textarea>'), 'Add comment', 'narrow');
FORMS.mtGoalComment = (f, btn) => busy(btn, async () => { await call('mtGoalComment', { id: f.elements.id.value, text: f.elements.text.value }); closeModal(); toast('Comment added.'); refresh(); });

ACT.mtActEdit = async (d) => {
  const o = await mtOptions();
  const x = d.id ? (MT.actCache || []).find((a) => a.id === d.id) : null;
  formModal(x ? 'Edit action item' : 'Action item / follow-up', 'Who does what, by when — with a date to check back.', 'mtAct', '<input type="hidden" name="id" value="' + esc(x ? x.id : '') + '"><input type="hidden" name="stu" value="' + esc(d.stu || '') + '">' +
    field('Action', '<input type="text" name="title" maxlength="300" required autofocus value="' + esc(x ? x.title : '') + '" placeholder="e.g. Attend remedial sessions twice a week">') +
    field('Details', '<textarea name="detail" maxlength="1000">' + esc(x ? x.detail : '') + '</textarea>') +
    '<div class="form-grid-3">' + field('Responsible', mtSel('owner', Object.keys(o.owners).map((k) => [k, o.owners[k]]), x ? x.owner : 'student')) + field('Target date', '<input type="date" name="due" value="' + esc(x ? x.due : '') + '">') + field('Follow-up date', '<input type="date" name="followUp" value="' + esc(x ? x.followUp : '') + '">') + '</div>' +
    mtLevelSel(x ? x.level : 1) + '<p class="xs muted">Items the student is responsible for always show on their Mentoring page. Reminders go out the day before and when overdue.</p>', 'Save', 'wide');
};
FORMS.mtAct = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  await call('mtActionSave', { id: el.id.value, studentId: el.stu.value, title: el.title.value, detail: el.detail.value, owner: el.owner.value, due: el.due.value, followUp: el.followUp.value, level: el.level.value });
  closeModal(); toast('Saved.'); refresh();
});
ACT.mtActDone = (d) => {
  const x = (MT.actCache || []).find((a) => a.id === d.id);
  formModal('Complete: ' + (x ? x.title : 'action item'), 'Record what happened.', 'mtActDone', '<input type="hidden" name="id" value="' + esc(d.id) + '">' +
    field('Outcome', '<textarea name="outcome" maxlength="1000" autofocus placeholder="e.g. Attended 6 of 8 remedial classes; test score up from 38% to 55%."></textarea>') +
    (mtIsStaff() ? field('Status', mtSel('status', [['done', 'Done'], ['open', 'Still open — reschedule'], ['cancelled', 'No longer needed']], 'done')) + field('New follow-up date (if still open)', '<input type="date" name="followUp">') : '<input type="hidden" name="status" value="done">'), 'Save', 'narrow');
};
FORMS.mtActDone = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  await call('mtActionUpdate', { id: el.id.value, status: el.status.value, outcome: el.outcome.value, followUp: el.followUp && el.followUp.value ? el.followUp.value : undefined });
  closeModal(); toast('Updated.'); refresh();
});

ACT.mtIntEdit = async (d) => {
  const o = await mtOptions();
  const x = d.id ? (MT.intCache || []).find((i) => i.id === d.id) : null;
  formModal(x ? 'Update intervention ' + x.ref : 'Create intervention', 'A structured plan: the problem, the actions, who is responsible, and when to check.', 'mtInt',
    '<input type="hidden" name="id" value="' + esc(x ? x.id : '') + '"><input type="hidden" name="stu" value="' + esc(d.stu || '') + '"><input type="hidden" name="event" value="' + esc(d.event || '') + '"><input type="hidden" name="concern" value="' + esc(d.concern || '') + '">' +
    field('Problem', '<input type="text" name="problem" maxlength="1000" required autofocus value="' + esc(x ? x.problem : d.problem || '') + '" placeholder="e.g. Low performance in Business Law">') +
    field('Plan', '<textarea name="plan" maxlength="3000">' + esc(x ? x.plan : '') + '</textarea>') +
    '<fieldset class="fieldset"><legend>' + (x ? 'Add actions' : 'Actions') + '</legend><div class="mt-actrows">' + [0, 1, 2].map((i) => '<div class="mt-actrow"><input type="text" name="a_t' + i + '" maxlength="300" placeholder="Action" aria-label="Action ' + (i + 1) + '">' +
      mtSel('a_o' + i, Object.keys(o.owners).map((k) => [k, o.owners[k]]), 'student', { attrs: ' aria-label="Responsible"' }) + '<input type="date" name="a_d' + i + '" aria-label="Target date"></div>').join('') + '</div></fieldset>' +
    '<div class="form-grid">' + field('Follow-up date', '<input type="date" name="followUp" value="' + esc(x ? x.followUp : '') + '">') + (x ? field('Status', mtSel('status', [['open', 'Open'], ['in_progress', 'In progress'], ['cancelled', 'Cancelled']], x.status)) : '') + '</div>' +
    field('Attachments (evidence)', '<input type="file" name="files" multiple accept="' + MT_ATTACH_ACCEPT + '">') + mtLevelSel(x ? x.level : 2), x ? 'Save' : 'Create', 'wide');
};
FORMS.mtInt = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  const actions = [0, 1, 2].map((i) => ({ title: el['a_t' + i].value, owner: el['a_o' + i].value, due: el['a_d' + i].value })).filter((a) => a.title.trim());
  const attachments = await mtUploadAll(el.files);
  const source = el.event.value ? { kind: 'indicator', id: el.event.value } : el.concern.value ? { kind: 'concern', id: el.concern.value } : null;
  await call('mtInterventionSave', { id: el.id.value, studentId: el.stu.value, problem: el.problem.value, plan: el.plan.value, actions, followUp: el.followUp.value, status: el.status ? el.status.value : undefined, level: el.level.value, attachments, source });
  closeModal(); toast('Intervention saved.'); refresh();
});
ACT.mtIntOutcome = (d) => formModal('Record outcome', 'Closes the intervention.', 'mtIntOutcome', '<input type="hidden" name="id" value="' + esc(d.id) + '">' +
  '<fieldset class="fieldset"><legend>Outcome</legend>' + [['improved', 'Improved'], ['partial', 'Partially improved'], ['not_improved', 'Not improved']].map((o, i) => '<label class="check"><input type="radio" name="outcome" value="' + o[0] + '"' + (i === 0 ? ' checked' : '') + '><span>' + o[1] + '</span></label>').join('') + '</fieldset>' +
  field('Note', '<textarea name="note" maxlength="2000"></textarea>'), 'Save outcome', 'narrow');
FORMS.mtIntOutcome = (f, btn) => busy(btn, async () => { await call('mtInterventionOutcome', { id: f.elements.id.value, outcome: f.querySelector('input[name=outcome]:checked').value, note: f.elements.note.value }); closeModal(); toast('Outcome recorded.'); refresh(); });

ACT.mtConcernNew = async (d) => {
  const staff = mtIsStaff();
  const cats = staff ? (await mtOptions()).concernCategories : MT.me.categories;
  formModal(staff ? 'Log a concern' : 'Raise a concern', staff ? 'Recorded on the student’s mentoring file.' : 'Only your mentor and authorised staff see this. You can follow its progress here.', 'mtConcernNew',
    '<input type="hidden" name="stu" value="' + esc(d.stu || '') + '">' + '<div class="form-grid">' + field('Category', mtSel('category', cats, cats[0])) + field('Priority', mtSel('priority', ['Low', 'Medium', 'High'], 'Medium')) + '</div>' +
    field('Describe the concern', '<textarea name="description" maxlength="3000" required autofocus></textarea>', staff ? '' : 'Share only what you are comfortable sharing.') +
    field('Attachments (optional)', '<input type="file" name="files" multiple accept="' + MT_ATTACH_ACCEPT + '">') + (staff ? mtLevelSel(2) : ''), staff ? 'Save' : 'Submit', 'wide');
};
FORMS.mtConcernNew = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  const attachments = await mtUploadAll(el.files);
  await call('mtConcernSubmit', { studentId: el.stu.value, category: el.category.value, priority: el.priority.value, description: el.description.value, level: el.level ? el.level.value : 2, attachments });
  closeModal(); toast('Concern submitted.'); refresh();
});
ACT.mtConcern = (d) => {
  const c = (MT.concernCache || []).find((x) => x.id === d.id);
  if (!c) return;
  const staff = mtIsStaff();
  const trail = '<ol class="mt-trail">' + c.trail.map((t) => '<li><div class="xs muted">' + esc(fmt(t.at)) + ' · ' + esc(t.by) + (staff && !t.shared ? ' · ' + icon('lock', 'i-sm') + 'internal' : '') + '</div><b class="small">' + esc(t.action) + '</b>' + (t.note ? '<p class="small">' + esc(t.note) + '</p>' : '') + '</li>').join('') + '</ol>';
  const closed = ['Resolved', 'Closed'].indexOf(c.status) >= 0;
  openModal(modalHead(c.category + ' · ' + c.ref, esc(c.status) + ' · ' + esc(c.priority) + ' priority' + (staff ? ' · ' + esc(c.student) : '')) + '<div class="modal-body">' +
    '<p>' + esc(c.description) + '</p>' + mtFiles(c.attachments) + (c.resolution ? notice('<b>Resolution:</b> ' + esc(c.resolution), 'ok') : '') + trail +
    (staff ? '<form data-form="mtConcernAct" novalidate><input type="hidden" name="id" value="' + esc(c.id) + '">' +
      '<div class="form-grid">' + field('Action', mtSel('action', closed ? [['reopen', 'Reopen'], ['respond', 'Add a note']] : [['respond', 'Respond / add a note'], ['progress', 'Mark in progress'], ['await', 'Waiting for the student'], ['resolve', 'Resolve'], ['close', 'Close']], closed ? 'respond' : 'respond')) +
      field('Follow-up date', '<input type="date" name="followUp">') + '</div>' +
      field('Note', '<textarea name="note" maxlength="2000"></textarea>') + check('shared', 'Share this note with the student', true) +
      '<div class="form-actions">' + (!c.byStudent ? '' : '') + '<a class="btn btn-ghost" href="#/mentoring/student/' + esc(c.studentId) + '?tab=concerns" data-act="close">Student record</a><button class="btn" type="button" data-act="mtIntEdit" data-stu="' + esc(c.studentId) + '" data-concern="' + esc(c.id) + '" data-problem="' + esc(c.category + ' concern ' + c.ref) + '">' + icon('zap', 'i-sm') + 'Create intervention</button><button class="btn btn-primary" type="submit">Save</button></div></form>'
      : c.canReply ? '<form data-form="mtConcernReply" novalidate><input type="hidden" name="id" value="' + esc(c.id) + '">' + field('Reply', '<textarea name="note" maxlength="2000" required></textarea>') + '<div class="form-actions"><button class="btn" type="button" data-act="close">Close</button><button class="btn btn-primary" type="submit">Send reply</button></div></form>'
        : '<div class="form-actions"><button class="btn btn-primary" data-act="close">Close</button></div>') + '</div>', 'wide');
};
FORMS.mtConcernAct = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  await call('mtConcernAct', { id: el.id.value, action: el.action.value, note: el.note.value, followUp: el.followUp.value, shared: el.shared.checked });
  closeModal(); toast('Concern updated.'); refresh();
});
FORMS.mtConcernReply = (f, btn) => busy(btn, async () => { await call('mtConcernAct', { id: f.elements.id.value, note: f.elements.note.value }); closeModal(); toast('Reply sent.'); refresh(); });

ACT.mtParentLog = (d) => {
  const parents = MT.stu ? MT.stu.parents : [];
  formModal('Parent / guardian interaction', 'Recorded on the student’s mentoring file. Share a summary with the parent only if you choose to.', 'mtParentLog', '<input type="hidden" name="stu" value="' + esc(d.stu) + '">' +
    '<div class="form-grid-3">' + field('Type', mtSel('mode', ['Meeting', 'Phone call', 'Online'], 'Meeting')) + field('Topic', mtSel('topic', ['Academic discussion', 'Attendance discussion', 'Progress update', 'Career', 'Other'], 'Progress update')) + field('Date', '<input type="date" name="date" value="' + esc(toDateInput(Date.now())) + '">') + '</div>' +
    (parents.length ? '<fieldset class="fieldset"><legend>Participants</legend>' + parents.map((p) => check('par_' + p.id, esc(p.name), true)).join('') + '</fieldset>' : notice('No parent account is linked — you can still record the interaction.', 'warn')) +
    field('Other participants', '<input type="text" name="others" maxlength="300">') + field('Purpose', '<input type="text" name="purpose" maxlength="300" required>') +
    field('Discussion', '<textarea name="discussion" maxlength="4000"></textarea>', 'Kept on the mentoring file (not shared).') +
    '<div class="form-grid">' + field('Action agreed', '<input type="text" name="action" maxlength="1000">') + field('Follow-up date', '<input type="date" name="followUp">') + '</div>' + field('Outcome', '<input type="text" name="outcome" maxlength="1000">') +
    '<fieldset class="fieldset"><legend>Share with the parent</legend>' + check('shared', 'Share a summary on the parent’s Mentoring page', false) + field('Summary for the parent', '<textarea name="sharedSummary" maxlength="2000"></textarea>') + '</fieldset>' + mtLevelSel(2), 'Save', 'wide');
};
FORMS.mtParentLog = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  const parentIds = Array.from(f.querySelectorAll('input[type=checkbox][name^="par_"]')).filter((c) => c.checked).map((c) => c.name.slice(4));
  await call('mtGuardianLog', { studentId: el.stu.value, parentIds, mode: el.mode.value, topic: el.topic.value, date: el.date.value, others: el.others.value, purpose: el.purpose.value, discussion: el.discussion.value, action: el.action.value, followUp: el.followUp.value, outcome: el.outcome.value, shared: el.shared.checked, sharedSummary: el.sharedSummary.value, level: el.level.value });
  closeModal(); toast('Interaction recorded.'); refresh();
});
ACT.mtIdentity = () => {
  const id = MT.stu.student.identity;
  const f = mtFlags();
  const depts = (MT.stu.options && MT.depts) || [];
  formModal('Identity & academic record', esc(MT.stu.student.name), 'mtIdentity',
    (f.coordinator || f.hod ? '<div class="form-grid">' + field('Programme', '<input type="text" name="programme" maxlength="120" value="' + esc(id.programme) + '">') + field('Category', '<input type="text" name="category" maxlength="60" value="' + esc(id.category) + '">') + '</div>' : '') +
    '<div class="form-grid-3">' + field('Semester', '<input type="text" name="semester" maxlength="20" value="' + esc(id.semester) + '">') + field('Section', '<input type="text" name="section" maxlength="20" value="' + esc(id.section) + '">') + field('CGPA', '<input type="number" name="cgpa" min="0" max="10" step="0.01" value="' + esc(id.cgpa) + '">') + '</div>' +
    '<div class="form-grid">' + field('Arrears / backlogs', '<input type="number" name="arrears" min="0" max="99" value="' + esc(id.arrears) + '">') + '<div></div></div>' +
    field('Semester results (notes)', '<textarea name="results" maxlength="1000" placeholder="e.g. Sem 3: 7.4 SGPA, all cleared">' + esc(id.results) + '</textarea>') + (depts.length ? '' : ''), 'Save', 'wide');
};
FORMS.mtIdentity = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  const p = { studentId: MT.stu.student.id, semester: el.semester.value, section: el.section.value, cgpa: el.cgpa.value, arrears: el.arrears.value, results: el.results.value };
  if (el.programme) { p.programme = el.programme.value; p.category = el.category.value; }
  await call('mtProfileSave', p);
  closeModal(); toast('Saved.'); refresh();
});

/* ---------- career (student page, and mentor modal) ---------- */
function mtCareerForm(c, staff) {
  const rows = (arr, n, fn) => { const out = arr.slice(); while (out.length < n) out.push({}); return out.map(fn).join(''); };
  return '<div class="form-grid">' + field('Career goal', '<input type="text" name="careerGoal" maxlength="300" value="' + esc(c.careerGoal) + '">') + field('Placement status', mtSel('placementStatus', ['Not started', 'Preparing', 'Applying', 'Interviewing', 'Placed', 'Higher studies', 'Entrepreneurship', 'Not seeking'], c.placementStatus, { blank: '—' })) + '</div>' +
    '<div class="form-grid-3">' + field('Target industry', '<input type="text" name="industry" maxlength="120" value="' + esc(c.industry) + '">') + field('Target job role', '<input type="text" name="jobRole" maxlength="120" value="' + esc(c.jobRole) + '">') + field('Preferred location', '<input type="text" name="location" maxlength="120" value="' + esc(c.location) + '">') + '</div>' +
    '<div class="form-grid">' + field('Higher education goal', '<input type="text" name="higherEd" maxlength="300" value="' + esc(c.higherEd) + '">') + field('Entrepreneurial interest', '<input type="text" name="entrepreneurship" maxlength="300" value="' + esc(c.entrepreneurship) + '">') + '</div>' +
    field('Skills', '<input type="text" name="skills" maxlength="1500" value="' + esc(c.skills.join(', ')) + '">', 'Separate with commas.') +
    '<fieldset class="fieldset"><legend>Certifications</legend>' + rows(c.certifications, c.certifications.length + 1, (x, i) => '<div class="mt-actrow"><input type="text" name="c_n' + i + '" maxlength="120" placeholder="Certificate" value="' + esc(x.name || '') + '" aria-label="Certificate name"><input type="text" name="c_i' + i + '" maxlength="120" placeholder="Issuer" value="' + esc(x.issuer || '') + '" aria-label="Issuer"><input type="date" name="c_d' + i + '" value="' + esc(x.date || '') + '" aria-label="Date"><input type="hidden" name="c_f' + i + '" value="' + esc(x.fileId || '') + '"><input type="file" name="c_u' + i + '" accept="' + MT_ATTACH_ACCEPT + '" aria-label="Certificate file"></div>') + '</fieldset>' +
    '<fieldset class="fieldset"><legend>Internships</legend>' + rows(c.internships, c.internships.length + 1, (x, i) => '<div class="mt-actrow"><input type="text" name="i_o' + i + '" maxlength="120" placeholder="Organisation" value="' + esc(x.org || '') + '" aria-label="Organisation"><input type="text" name="i_r' + i + '" maxlength="120" placeholder="Role" value="' + esc(x.role || '') + '" aria-label="Role"><input type="date" name="i_f' + i + '" value="' + esc(x.from || '') + '" aria-label="From"><input type="date" name="i_t' + i + '" value="' + esc(x.to || '') + '" aria-label="To"></div>') + '</fieldset>' +
    '<fieldset class="fieldset"><legend>Projects</legend>' + rows(c.projects, c.projects.length + 1, (x, i) => '<div class="mt-actrow two"><input type="text" name="p_t' + i + '" maxlength="150" placeholder="Project title" value="' + esc(x.title || '') + '" aria-label="Project title"><input type="text" name="p_d' + i + '" maxlength="600" placeholder="Short description" value="' + esc(x.desc || '') + '" aria-label="Description"></div>') + '</fieldset>' +
    '<fieldset class="fieldset"><legend>' + (staff ? 'Recommendations for the student' : 'Recommendations from your mentor') + '</legend>' +
    (staff ? rows(c.recommendations, c.recommendations.length + 1, (x, i) => '<div class="mt-actrow rec"><input type="hidden" name="r_id' + i + '" value="' + esc(x.id || '') + '"><input type="text" name="r_g' + i + '" maxlength="200" placeholder="Skill gap" value="' + esc(x.skillGap || '') + '" aria-label="Skill gap"><input type="text" name="r_a' + i + '" maxlength="300" placeholder="Recommended activity" value="' + esc(x.activity || '') + '" aria-label="Recommended activity"><input type="date" name="r_t' + i + '" value="' + esc(x.target || '') + '" aria-label="Target date"><label class="check"><input type="checkbox" name="r_c' + i + '"' + (x.done ? ' checked' : '') + '><span>Done</span></label></div>')
      : c.recommendations.length ? c.recommendations.map((x, i) => '<div class="mt-actrow rec"><input type="hidden" name="r_id' + i + '" value="' + esc(x.id) + '"><span class="small"><b>' + esc(x.activity) + '</b>' + (x.skillGap ? '<span class="xs muted"> · ' + esc(x.skillGap) + '</span>' : '') + (x.target ? '<span class="xs muted"> · by ' + esc(mtDate(x.target)) + '</span>' : '') + '</span><label class="check"><input type="checkbox" name="r_c' + i + '"' + (x.done ? ' checked' : '') + '><span>Done</span></label><input type="file" name="r_u' + i + '" accept="' + MT_ATTACH_ACCEPT + '" aria-label="Evidence"></div>').join('') : '<p class="small muted">None yet.</p>') + '</fieldset>';
}
async function mtCareerPayload(f, c, staff) {
  const el = f.elements;
  const v = (n) => (el[n] ? el[n].value : '');
  const up = async (n) => { const inp = el[n]; return inp && inp.files && inp.files[0] ? (await uploadFile(inp.files[0])).id : ''; };
  const p = { careerGoal: v('careerGoal'), placementStatus: v('placementStatus'), industry: v('industry'), jobRole: v('jobRole'), location: v('location'), higherEd: v('higherEd'), entrepreneurship: v('entrepreneurship'), skills: v('skills').split(',').map((x) => x.trim()).filter(Boolean), certifications: [], internships: [], projects: [], recommendations: [] };
  for (let i = 0; el['c_n' + i]; i++) p.certifications.push({ name: v('c_n' + i), issuer: v('c_i' + i), date: v('c_d' + i), fileId: (await up('c_u' + i)) || v('c_f' + i) });
  for (let i = 0; el['i_o' + i]; i++) p.internships.push({ org: v('i_o' + i), role: v('i_r' + i), from: v('i_f' + i), to: v('i_t' + i) });
  for (let i = 0; el['p_t' + i]; i++) p.projects.push({ title: v('p_t' + i), desc: v('p_d' + i) });
  for (let i = 0; el['r_id' + i]; i++) p.recommendations.push(staff ? { id: v('r_id' + i), skillGap: v('r_g' + i), activity: v('r_a' + i), target: v('r_t' + i), done: el['r_c' + i].checked, fileId: (c.recommendations[i] || {}).evidence ? c.recommendations[i].evidence.id : '' } : { id: v('r_id' + i), done: el['r_c' + i].checked, fileId: await up('r_u' + i) });
  return p;
}
ACT.mtCareerEdit = () => formModal('Career & professional development', esc(MT.stu.student.name), 'mtCareerStaff', mtCareerForm(MT.stu.career, true), 'Save', 'xwide');
FORMS.mtCareerStaff = (f, btn) => busy(btn, async () => { const p = await mtCareerPayload(f, MT.stu.career, true); p.studentId = MT.stu.student.id; await call('mtCareerSave', p); closeModal(); toast('Saved.'); refresh(); });
async function viewMtDevelopment() {
  const r = await call('mtHome');
  if (r.role !== 'student') { go('/mentoring'); return null; }
  MT.me = r;
  return {
    title: 'My development',
    html: pageHead('My development', { crumbs: [['Mentoring', '/mentoring'], ['My development']], sub: 'Career goals, skills, certifications, internships and projects. Your mentor sees this and can add recommendations.' }) +
      '<div class="card card-pad"><form data-form="mtCareerMine" novalidate>' + mtCareerForm(r.career, false) + '<div class="form-actions"><a class="btn" href="#/mentoring">Cancel</a><button class="btn btn-primary" type="submit">Save</button></div></form></div>'
  };
}
FORMS.mtCareerMine = (f, btn) => busy(btn, async () => { await call('mtCareerSave', await mtCareerPayload(f, MT.me.career, false)); toast('Saved.'); go('/mentoring'); });

/* =====================================================================
   LIST PAGES: sessions, follow-ups, concerns, goals, interventions, indicators, search
   ===================================================================== */
async function viewMtSessions(params) {
  const p = Object.fromEntries(params.entries());
  if (!mtIsStaff()) { const r = await call('mtSessions', { when: p.when || 'all' }); MT.sessCache = r.rows; return { title: 'Mentoring sessions', html: pageHead('Mentoring sessions', { crumbs: [['Mentoring', '/mentoring'], ['Sessions']] }) + '<div class="card card-pad">' + (r.rows.length ? '<div class="mt-list">' + r.rows.map((x) => mtSessRow(x, { people: false })).join('') + '</div>' : emptyState('calendar', 'No sessions', '', '', false)) + '</div>' }; }
  p.when = p.when || 'upcoming';
  const r = await call('mtSessions', p);
  MT.sessCache = r.rows; MT.opts = r.options || MT.opts;
  const tabs = [['upcoming', 'Upcoming'], ['requested', 'Requests'], ['past', 'Past'], ['all', 'All']];
  const f = mtFlags();
  return {
    title: 'Mentoring sessions',
    html: mtHead('Sessions', 'Schedule, record and follow through. Sessions also appear in the calendar.', '<button class="btn btn-primary" data-act="mtSchedule">' + icon('plus') + 'Schedule session</button>', 'Sessions') + mtTabs('/mentoring/sessions') +
      '<div class="card"><div class="card-head row-wrap"><div class="pills">' + tabs.map((t) => '<a class="pill' + (p.when === t[0] ? ' active' : '') + '" href="#/mentoring/sessions' + mtQs(Object.assign({}, p, { when: t[0] }), ['page']) + '">' + t[1] + '</a>').join('') + '</div><span class="spacer"></span>' +
      '<form class="mt-filters" data-form="mtFilter" data-base="/mentoring/sessions"><input type="hidden" name="when" value="' + esc(p.when) + '">' + (f.coordinator || f.hod ? mtSel('scope', [['mine', 'My sessions'], ['all', 'Everyone I can see']], p.scope || 'mine', { attrs: ' aria-label="Scope"' }) : '') +
      (r.options ? mtSel('category', r.options.sessionCategories, p.category || '', { blank: 'All categories', attrs: ' aria-label="Category"' }) : '') + '<input type="date" name="from" value="' + esc(p.from || '') + '" aria-label="From"><input type="date" name="to" value="' + esc(p.to || '') + '" aria-label="To"><button class="btn" type="submit">' + icon('filter', 'i-sm') + 'Apply</button></form></div>' +
      '<div class="card-body">' + (r.rows.length ? (p.when === 'past' || p.when === 'all' ? '<div class="mt-sess-list">' + r.rows.map(mtSessCard).join('') + '</div>' : '<div class="mt-list">' + r.rows.map((x) => mtSessRow(x)).join('') + '</div>') + mtPager(r, '/mentoring/sessions' + mtQs(p, ['page']))
        : emptyState('calendar', p.when === 'requested' ? 'No pending requests' : 'No sessions here', p.when === 'upcoming' ? 'Schedule sessions with your mentees — one-to-one, group or with parents.' : '', p.when === 'upcoming' ? '<button class="btn btn-primary" data-act="mtSchedule">' + icon('plus') + 'Schedule session</button>' : '', false)) + '</div></div>'
  };
}
async function viewMtFollowups(params) {
  const r = await call('mtFollowups', { scope: params.get('scope') || '' });
  MT.actCache = [].concat(r.overdue, r.today, r.tomorrow, r.week, r.later, r.doneRecently);
  const f = mtFlags();
  const col = (title, list, tone, empty) => '<section class="card mt-card mt-fu ' + tone + '"><div class="card-head"><h2>' + title + '</h2><span class="badge">' + list.length + '</span></div><div class="card-body">' + (list.length ? '<div class="mt-list">' + list.map((x) => mtActRow(x)).join('') + '</div>' : mtEmpty(empty)) + '</div></section>';
  return {
    title: 'Follow-ups',
    html: mtHead('Follow-ups', 'Every action with a date: overdue first, then today, tomorrow and this week.', (f.coordinator || f.hod) ? '<div class="pills"><a class="pill' + (r.scope === 'mine' ? ' active' : '') + '" href="#/mentoring/followups">Mine</a><a class="pill' + (r.scope === 'all' ? ' active' : '') + '" href="#/mentoring/followups?scope=all">Everyone I can see</a></div>' : '', 'Follow-ups') + mtTabs('/mentoring/followups') +
      '<div class="mt-board">' + col(icon('alert', 'i-sm') + ' Overdue', r.overdue, 'od', 'Nothing overdue.') + col('Today', r.today, '', 'Nothing due today.') + col('Tomorrow', r.tomorrow, '', 'Nothing due tomorrow.') + col('This week', r.week, '', 'Nothing else this week.') + '</div>' +
      (r.later.length ? '<details class="card mt-card mt-more"><summary class="card-head"><h2>Later or undated (' + r.later.length + ')</h2></summary><div class="card-body"><div class="mt-list">' + r.later.map((x) => mtActRow(x)).join('') + '</div></div></details>' : '') +
      (r.doneRecently.length ? '<details class="card mt-card mt-more"><summary class="card-head"><h2>Completed in the last two weeks (' + r.doneRecently.length + ')</h2></summary><div class="card-body"><div class="mt-list">' + r.doneRecently.map((x) => mtActRow(x)).join('') + '</div></div></details>' : '')
  };
}
async function viewMtConcerns(params) {
  const p = Object.fromEntries(params.entries());
  if (!mtIsStaff()) {
    const home = await call('mtHome'); MT.me = home;
    const r = await call('mtConcerns', {}); MT.concernCache = r.rows;
    return { title: 'Support requests', html: pageHead('My support requests', { crumbs: [['Mentoring', '/mentoring'], ['Support requests']], actions: '<button class="btn btn-primary" data-act="mtConcernNew">' + icon('plus') + 'Raise a concern</button>' }) + '<div class="card card-pad">' + (r.rows.length ? '<div class="mt-list">' + r.rows.map(mtConcernRow).join('') + '</div>' : emptyState('message', 'No requests yet', 'When you need help — academic, attendance, career or anything else — raise a concern. Only your mentor and authorised staff see it.', '', false)) + '</div>' };
  }
  p.status = p.status === undefined ? 'open' : p.status;
  const r = await call('mtConcerns', p);
  MT.concernCache = r.rows;
  const f = mtFlags();
  return {
    title: 'Concerns',
    html: mtHead('Concerns & support requests', 'From students and staff. Respond, resolve, or turn one into an intervention.', '', 'Concerns') + mtTabs('/mentoring/concerns') +
      '<div class="card"><form class="mt-filters" data-form="mtFilter" data-base="/mentoring/concerns"><div class="search-box">' + icon('search') + '<input type="search" name="q" value="' + esc(p.q || '') + '" placeholder="Student, reference or category" aria-label="Search"></div>' +
      mtSel('status', [['open', 'Open'], ['', 'All']].concat(r.statuses.map((x) => [x, x])), p.status, { attrs: ' aria-label="Status"' }) + mtSel('category', r.categories, p.category || '', { blank: 'All categories', attrs: ' aria-label="Category"' }) +
      (f.coordinator || f.hod ? mtSel('scope', [['', 'Assigned to me'], ['all', 'Everyone I can see']], p.scope || '', { attrs: ' aria-label="Scope"' }) : '') + '<button class="btn" type="submit">' + icon('filter', 'i-sm') + 'Apply</button></form>' +
      '<div class="card-body">' + (r.rows.length ? '<div class="mt-list">' + r.rows.map(mtConcernRow).join('') + '</div>' : emptyState('message', 'No concerns', p.status === 'open' ? 'No open concerns right now.' : 'Nothing matches.', '', false)) + '</div></div>'
  };
}
async function viewMtGoals(params) {
  const p = Object.fromEntries(params.entries());
  const staff = mtIsStaff();
  if (!staff) { const home = await call('mtHome'); MT.me = home; }
  const r = await call('mtGoals', p);
  MT.goalCache = r.rows;
  MT.opts = MT.opts || (staff ? null : { goalCategories: r.categories, goalStatus: r.statuses, priorities: r.priorities });
  return {
    title: 'Goals',
    html: (staff ? mtHead('Goals', 'Mentee goals with progress. Update with the student in sessions.', '', 'Goals') + mtTabs('/mentoring/goals') : pageHead('My goals', { crumbs: [['Mentoring', '/mentoring'], ['Goals']], actions: '<button class="btn btn-primary" data-act="mtGoalEdit">' + icon('plus') + 'Add goal</button>' })) +
      '<div class="card">' + (staff ? '<form class="mt-filters" data-form="mtFilter" data-base="/mentoring/goals"><div class="search-box">' + icon('search') + '<input type="search" name="q" value="' + esc(p.q || '') + '" placeholder="Goal or student" aria-label="Search goals"></div>' + mtSel('status', r.statuses, p.status || '', { blank: 'Any status', attrs: ' aria-label="Status"' }) + mtSel('category', r.categories, p.category || '', { blank: 'All categories', attrs: ' aria-label="Category"' }) + '<button class="btn" type="submit">' + icon('filter', 'i-sm') + 'Apply</button></form>' : '') +
      '<div class="card-body">' + (r.rows.length ? '<div class="mt-list">' + r.rows.map(mtGoalRow).join('') + '</div>' : emptyState('target', 'No goals', staff ? 'Goals your mentees set, or that you set with them, appear here.' : 'Add your first goal and track your progress.', '', false)) + '</div></div>'
  };
}
async function viewMtInterventions(params) {
  const p = Object.fromEntries(params.entries());
  p.status = p.status === undefined ? 'open' : p.status;
  const r = await call('mtInterventions', p);
  MT.intCache = r.rows; MT.stu = null;
  MT.actCache = [].concat(...r.rows.map((x) => x.actions));
  const f = mtFlags();
  return {
    title: 'Interventions',
    html: mtHead('Interventions', 'Structured action plans with owners, dates and outcomes.', '', 'Interventions') + mtTabs('/mentoring/interventions') +
      '<div class="card"><form class="mt-filters" data-form="mtFilter" data-base="/mentoring/interventions">' + mtSel('status', [['open', 'Open & in progress'], ['completed', 'Completed'], ['cancelled', 'Cancelled'], ['', 'All']], p.status, { attrs: ' aria-label="Status"' }) +
      (f.coordinator || f.hod ? mtSel('scope', [['', 'My mentees'], ['all', 'Everyone I can see']], p.scope || '', { attrs: ' aria-label="Scope"' }) : '') + '<button class="btn" type="submit">' + icon('filter', 'i-sm') + 'Apply</button></form>' +
      '<div class="card-body">' + (r.rows.length ? '<div class="mt-sess-list">' + r.rows.map((x) => mtIntCard(x).replace('<header class="row-wrap" style="gap:.5rem"><b>', '<header class="row-wrap" style="gap:.5rem"><a href="#/mentoring/student/' + esc(x.studentId) + '?tab=interventions"><b>' + esc(x.student) + '</b></a> · <b>')).join('') + '</div>' : emptyState('zap', 'No interventions', 'Create one from a student’s record when an indicator or concern needs a structured plan.', '', false)) + '</div></div>'
  };
}
async function viewMtIndicators(params) {
  const p = Object.fromEntries(params.entries());
  const r = await call('mtEvents', p);
  const f = mtFlags();
  return {
    title: 'Support indicators',
    html: mtHead(r.labels.indicator + 's', 'Early-warning signals from configurable rules. They prompt a review — they are not a judgement about the student.', r.canRun ? '<button class="btn" data-act="mtRunCheck">' + icon('refresh') + 'Run check now</button>' : '', 'Indicators') + mtTabs('/mentoring/indicators') +
      '<div class="card"><form class="mt-filters" data-form="mtFilter" data-base="/mentoring/indicators">' + mtSel('status', [['open', 'Open'], ['reviewed', 'Reviewed'], ['cleared', 'Cleared'], ['dismissed', 'Dismissed'], ['all', 'All']], p.status || 'open', { attrs: ' aria-label="Status"' }) +
      mtSel('severity', [['', 'Any level'], ['priority', 'Priority intervention'], ['attention', 'Needs attention'], ['reminder', 'Reminder']], p.severity || '', { attrs: ' aria-label="Level"' }) + (f.coordinator || f.hod ? mtSel('scope', [['', 'My mentees'], ['all', 'Everyone I can see']], p.scope || '', { attrs: ' aria-label="Scope"' }) : '') + '<button class="btn" type="submit">' + icon('filter', 'i-sm') + 'Apply</button></form>' +
      (r.rows.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Student</th><th>Indicator</th><th>Level</th><th>Since</th><th>Status</th><th></th></tr></thead><tbody>' + r.rows.map((e) => '<tr><td>' + mtStudentLink(e.studentId, e.student) + '<div class="xs muted">' + esc(e.batch) + (r.scope === 'all' ? ' · ' + esc(e.mentor) : '') + '</div></td><td><b class="small">' + esc(e.name) + '</b><div class="xs muted">' + esc(e.text) + '</div>' + (e.note ? '<div class="xs">Note: ' + esc(e.note) + (e.reviewedBy ? ' — ' + esc(e.reviewedBy) : '') + '</div>' : '') + '</td><td>' + mtSev(e.severity) + '</td><td class="small nowrap">' + esc(fmtDate(e.at)) + '</td><td>' + badge(e.status) + '</td>' +
        '<td class="actions nowrap">' + (e.status === 'open' ? '<button class="btn btn-sm btn-soft" data-act="mtIntEdit" data-stu="' + esc(e.studentId) + '" data-event="' + esc(e.id) + '" data-problem="' + esc(e.name) + '">Plan action</button><button class="btn btn-sm" data-act="mtEventAct" data-id="' + esc(e.id) + '" data-action="review">Reviewed</button><button class="btn btn-sm btn-ghost" data-act="mtEventAct" data-id="' + esc(e.id) + '" data-action="dismiss">Dismiss</button>' : e.status !== 'cleared' ? '<button class="btn btn-sm btn-ghost" data-act="mtEventAct" data-id="' + esc(e.id) + '" data-action="reopen">Reopen</button>' : '') + '</td></tr>').join('') + '</tbody></table></div>'
        : '<div class="card-body">' + emptyState('checkCircle', 'Nothing to review', 'No support indicators match these filters.', '', false) + '</div>') + '</div>'
  };
}
ACT.mtRunCheck = (d, btn) => busy(btn, async () => { const r = await call('mtRunCheck'); toast('Checked ' + plural(r.checked, 'student') + ': ' + r.created + ' new, ' + r.cleared + ' cleared.'); refresh(); });
ACT.mtEventAct = (d) => {
  formModal(d.action === 'dismiss' ? 'Dismiss indicator' : d.action === 'reopen' ? 'Reopen indicator' : 'Mark as reviewed', d.action === 'dismiss' ? 'Say why no action is needed.' : 'Optional note for the record.', 'mtEventAct', '<input type="hidden" name="id" value="' + esc(d.id) + '"><input type="hidden" name="action" value="' + esc(d.action) + '">' +
    field('Note', '<textarea name="note" maxlength="1000" autofocus' + (d.action === 'dismiss' ? ' required' : '') + '></textarea>'), 'Save', 'narrow');
};
FORMS.mtEventAct = (f, btn) => busy(btn, async () => { await call('mtEventAct', { id: f.elements.id.value, action: f.elements.action.value, note: f.elements.note.value }); closeModal(); toast('Updated.'); refresh(); });
async function viewMtSearch(params) {
  const q = params.get('q') || '';
  const r = await call('mtSearch', { q });
  const sec = (title, list, fn) => list.length ? mtCard(title, '<div class="mt-list">' + list.map(fn).join('') + '</div>') : '';
  const any = r.students.length + r.sessions.length + r.goals.length + r.concerns.length;
  return {
    title: 'Mentoring search',
    html: mtHead('Search: ' + q, plural(any, 'result'), '<form class="search-box mt-search" data-form="mtSearch" role="search">' + icon('search') + '<input type="search" name="q" value="' + esc(q) + '" aria-label="Search mentoring"></form>', 'Search') + mtTabs('') +
      (any ? sec('Students', r.students, (c) => '<a class="mt-row" href="#/mentoring/student/' + esc(c.id) + '">' + avatar(c.name) + '<span class="mt-row-main"><b>' + esc(c.name) + '</b><span class="xs muted">' + esc(c.regNo) + ' · ' + esc(c.batch) + (c.mentor ? ' · mentor ' + esc(c.mentor) : '') + '</span></span></a>') +
        sec('Sessions', r.sessions, (x) => '<a class="mt-row" href="#/mentoring/student/' + esc(x.studentId) + '?tab=sessions"><span class="mt-row-main"><b>' + esc(x.type) + ' · ' + esc(x.ref) + '</b><span class="xs muted">' + esc(x.student) + ' · ' + esc(mtWhen(x.at)) + '</span></span></a>') +
        sec('Goals', r.goals, (x) => '<a class="mt-row" href="#/mentoring/student/' + esc(x.studentId) + '?tab=goals"><span class="mt-row-main"><b>' + esc(x.title) + '</b><span class="xs muted">' + esc(x.student) + ' · ' + esc(x.status) + '</span></span></a>') +
        sec('Concerns', r.concerns, (x) => '<a class="mt-row" href="#/mentoring/student/' + esc(x.studentId) + '?tab=concerns"><span class="mt-row-main"><b>' + esc(x.category) + ' · ' + esc(x.ref) + '</b><span class="xs muted">' + esc(x.student) + ' · ' + esc(x.status) + '</span></span></a>')
        : '<div class="card card-pad">' + emptyState('search', 'No results', 'Search by student name, college ID, class, department, mentor, goal, concern or session.', '', false) + '</div>')
  };
}

/* =====================================================================
   ALLOCATION (coordinators, administrators, HODs)
   ===================================================================== */
async function viewMtAllocation(params) {
  const p = Object.fromEntries(params.entries());
  const show = ['unassigned', 'assigned', 'all'].indexOf(p.show) >= 0 ? p.show : 'unassigned';
  const [h, list] = await Promise.all([call('mtAllocHome'), call('mtMentees', Object.assign({}, p, { scope: mtFlags().coordinator ? 'all' : 'department', unassigned: show === 'unassigned' ? 1 : '', assigned: show === 'assigned' ? 1 : '' }))]);
  MT.allocHome = h;
  MT.alloc = new Set();
  const k = h.kpis;
  const rows = list.rows;
  const mentorRows = h.mentors.map((m) => '<tr><td><b>' + esc(m.name) + '</b><div class="xs muted">' + esc(m.username) + (m.department ? ' · ' + esc(m.department) : '') + '</div></td><td style="min-width:160px"><div class="row" style="gap:.5rem;align-items:center">' + mtProg(Math.min(100, m.mentees / h.maxMentees * 100), 'Load') + '<b class="small tnum">' + m.mentees + '/' + h.maxMentees + '</b></div></td>' +
    '<td>' + (m.overloaded ? badge('Over maximum', 'danger', 'alert') : '') + (m.inactive ? badge('No recent sessions', 'warning', 'clock') : '') + (!m.overloaded && !m.inactive && m.mentees ? badge('Active', 'success') : '') + '</td><td class="small">' + (m.lastSession ? esc(rel(m.lastSession)) : '—') + '</td>' +
    '<td><a class="btn btn-sm btn-ghost" href="#/mentoring/allocation?show=assigned&mentorId=' + esc(m.id) + '">Mentees</a></td></tr>').join('');
  return {
    title: 'Mentor allocation',
    html: mtHead('Mentor allocation', 'Assign, reassign and balance mentees. Every change is kept in the allocation history.',
      '<button class="btn" data-act="mtAllocTemplate">' + icon('download') + 'Template</button><button class="btn" data-act="mtAllocImport">' + icon('upload') + 'Import Excel/CSV</button><button class="btn btn-primary" data-act="mtAllocAuto">' + icon('sparkle') + 'Rule-based allocation</button>', 'Allocation') + mtTabs('/mentoring/allocation') +
      '<div class="mt-kpis sm">' + statCard('cap', 'indigo', k.students, 'Total students') + statCard('users', 'blue', k.mentors, 'Total mentors') + statCard('checkCircle', 'green', k.assigned, 'Students assigned') + statCard('alert', 'amber', k.unassigned, 'Students unassigned') +
      statCard('pie', 'violet', k.avg, 'Avg mentees / mentor') + statCard('flag', 'red', k.overloaded, 'Overloaded mentors') + statCard('clock', 'slate', k.inactive, 'Inactive mentors') + '</div>' +
      '<section class="card mt-card"><div class="card-head row-wrap"><h2>Students</h2><div class="pills">' + [['unassigned', 'Unassigned'], ['assigned', 'Assigned'], ['all', 'All']].map((t) => '<a class="pill' + (show === t[0] ? ' active' : '') + '" href="#/mentoring/allocation' + mtQs(Object.assign({}, p, { show: t[0] }), ['page', 'mentorId']) + '">' + t[1] + '</a>').join('') + '</div><span class="spacer"></span>' +
      '<button class="btn btn-sm btn-soft" data-act="mtAllocAssign">' + icon('userPlus', 'i-sm') + 'Assign selected…</button><button class="btn btn-sm btn-ghost" data-act="mtAllocUnassign">Remove mentor…</button></div>' +
      '<form class="mt-filters" data-form="mtFilter" data-base="/mentoring/allocation"><input type="hidden" name="show" value="' + esc(show) + '"><div class="search-box">' + icon('search') + '<input type="search" name="q" value="' + esc(p.q || '') + '" placeholder="Name, college ID or class" aria-label="Search students"></div>' +
      (h.departments.length ? mtSel('department', h.departments.map((d) => [d.id, d.name]), p.department || '', { blank: 'All departments', attrs: ' aria-label="Department"' }) : '') + mtSel('batch', h.batches, p.batch || '', { blank: 'All classes', attrs: ' aria-label="Class"' }) + (p.mentorId ? '<input type="hidden" name="mentorId" value="' + esc(p.mentorId) + '">' : '') + '<button class="btn" type="submit">' + icon('filter', 'i-sm') + 'Apply</button></form>' +
      (rows.length ? '<div class="table-wrap"><table class="table"><thead><tr><th style="width:36px"><input type="checkbox" data-change="mtAllocAll" aria-label="Select all on this page"></th><th>Student</th><th>Class</th><th>Department</th><th>Mentor</th></tr></thead><tbody>' +
        rows.map((c) => '<tr><td><input type="checkbox" class="mt-allocbox" value="' + esc(c.id) + '" data-change="mtAllocToggle" aria-label="Select ' + esc(c.name) + '"></td><td><a href="#/mentoring/student/' + esc(c.id) + '"><b>' + esc(c.name) + '</b></a><div class="xs muted">' + esc(c.regNo) + '</div></td><td class="small">' + esc(c.batch || '—') + '</td><td class="small">' + esc(c.department || '—') + '</td><td class="small">' + (c.mentor ? esc(c.mentor) : '<span class="muted">Unassigned</span>') + '</td></tr>').join('') + '</tbody></table></div>' + mtPager(list, '/mentoring/allocation' + mtQs(p, ['page']))
        : '<div class="card-body">' + emptyState('checkCircle', show === 'unassigned' ? 'Every student has a mentor' : 'No students here', '', '', false) + '</div>') + '</section>' +
      '<section class="card mt-card"><div class="card-head"><h2>Mentor workload</h2></div>' + (h.mentors.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Mentor</th><th>Load</th><th>Status</th><th>Last session</th><th></th></tr></thead><tbody>' + mentorRows + '</tbody></table></div>' : '<div class="card-body">' + mtEmpty('No faculty accounts found.') + '</div>') + '</section>' +
      '<section class="card mt-card"><div class="card-head"><h2>Allocation history</h2></div>' + (h.history.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Student</th><th>Mentor</th><th>From</th><th>To</th><th>Changed by</th><th>Reason</th></tr></thead><tbody>' + h.history.map((a) => '<tr><td>' + mtStudentLink(a.studentId, a.student) + '</td><td><b class="small">' + esc(a.mentor) + '</b>' + (a.active ? ' ' + badge('Current', 'success') : '') + '</td><td class="small nowrap">' + esc(fmtDate(a.at)) + '</td><td class="small nowrap">' + (a.endedAt ? esc(fmtDate(a.endedAt)) : '—') + '</td><td class="small">' + esc(a.by) + (a.endedBy ? '<div class="xs muted">ended by ' + esc(a.endedBy) + '</div>' : '') + '</td><td class="small">' + esc(a.reason || '—') + (a.endReason ? '<div class="xs muted">' + esc(a.endReason) + '</div>' : '') + '</td></tr>').join('') + '</tbody></table></div>' : '<div class="card-body">' + mtEmpty('No allocations yet.') + '</div>') + '</section>'
  };
}
ACT.mtAllocToggle = (d, el) => { if (el.checked) MT.alloc.add(el.value); else MT.alloc.delete(el.value); };
ACT.mtAllocAll = (d, el) => { $$('.mt-allocbox').forEach((b) => { b.checked = el.checked; if (el.checked) MT.alloc.add(b.value); else MT.alloc.delete(b.value); }); };
function mtMentorSelect(name, multiple) {
  const h = MT.allocHome;
  return '<select name="' + name + '"' + (multiple ? ' multiple size="8"' : ' required') + '>' + (multiple ? '' : '<option value="">Choose a mentor…</option>') + h.mentors.map((m) => '<option value="' + esc(m.id) + '">' + esc(m.name) + ' — ' + m.mentees + '/' + h.maxMentees + (m.department ? ' · ' + esc(m.department) : '') + '</option>').join('') + '</select>';
}
ACT.mtAllocAssign = () => {
  if (!MT.alloc.size) { toast('Tick the students to assign first.', 'err'); return; }
  formModal('Assign mentor', plural(MT.alloc.size, 'student') + ' selected. Reassigning keeps the previous mentor in the history.', 'mtAllocAssign',
    field('Mentor', mtMentorSelect('mentorId')) + field('Reason', '<input type="text" name="reason" maxlength="300" placeholder="e.g. Start of year allocation">') + (MT.allocHome.coordinator ? check('override', 'Allow above the maximum number of mentees', false) : ''), 'Assign', 'wide');
};
FORMS.mtAllocAssign = (f, btn) => busy(btn, async () => { const r = await call('mtAllocAssign', { mentorId: f.elements.mentorId.value, studentIds: Array.from(MT.alloc), reason: f.elements.reason.value, override: f.elements.override ? f.elements.override.checked : false }); closeModal(); toast(plural(r.assigned, 'student') + ' assigned.'); refresh(); });
ACT.mtAllocUnassign = () => {
  if (!MT.alloc.size) { toast('Tick the students first.', 'err'); return; }
  formModal('Remove mentor', plural(MT.alloc.size, 'student') + ' will have no mentor. The history is kept.', 'mtAllocUnassign', field('Reason', '<input type="text" name="reason" maxlength="300" required autofocus>'), 'Remove', 'narrow', true);
};
FORMS.mtAllocUnassign = (f, btn) => busy(btn, async () => { const r = await call('mtAllocUnassign', { studentIds: Array.from(MT.alloc), reason: f.elements.reason.value }); closeModal(); toast(plural(r.unassigned, 'student') + ' updated.'); refresh(); });
ACT.mtAllocAuto = () => {
  const h = MT.allocHome;
  formModal('Rule-based allocation', 'Filter the students, pick the mentors, preview — then apply. Mentees are shared evenly up to the maximum (' + h.maxMentees + ').', 'mtAllocAuto',
    '<div class="form-grid-3">' + field('Department', mtSel('department', h.departments.map((d) => [d.id, d.name]), '', { blank: 'Any' })) + field('Class / batch', mtSel('batch', h.batches, '', { blank: 'Any' })) + field('Programme', '<input type="text" name="programme" maxlength="120">') + '</div>' +
    '<div class="form-grid-3">' + field('Semester', '<input type="text" name="semester" maxlength="20">') + field('Section', '<input type="text" name="section" maxlength="20">') + field('Student category', '<input type="text" name="category" maxlength="60">') + '</div>' +
    field('Mentors', mtMentorSelect('mentorIds', true), 'Hold Ctrl (Cmd on Mac) to choose several.') + check('onlyUnassigned', 'Only students without a mentor', true) + field('Reason', '<input type="text" name="reason" maxlength="300" value="Rule-based allocation">') + '<div id="mtAutoOut"></div>', 'Preview', 'wide');
};
FORMS.mtAllocAuto = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  const p = { department: el.department.value, batch: el.batch.value, programme: el.programme.value, semester: el.semester.value, section: el.section.value, category: el.category.value, mentorIds: Array.from(el.mentorIds.selectedOptions).map((o) => o.value), onlyUnassigned: el.onlyUnassigned.checked, reason: el.reason.value };
  if (f.dataset.ready === '1') { const r = await call('mtAllocAuto', Object.assign(p, { apply: true })); closeModal(); toast(plural(r.applied, 'student') + ' allocated' + (r.left ? '; ' + r.left + ' left (mentors full)' : '') + '.'); refresh(); return; }
  const r = await call('mtAllocAuto', p);
  $('#mtAutoOut').innerHTML = notice('<b>' + plural(r.count, 'student') + '</b> will be allocated (' + r.matched + ' matched' + (r.left ? ', ' + r.left + ' left over because the mentors are full' : '') + '). Press <b>Apply</b> to confirm.', r.count ? 'ok' : 'warn') +
    (r.plan.length ? '<div class="table-wrap" style="max-height:240px;overflow:auto"><table class="table"><thead><tr><th>Student</th><th>Class</th><th>Mentor</th></tr></thead><tbody>' + r.plan.map((x) => '<tr><td class="small">' + esc(x.student) + ' <span class="muted">' + esc(x.regNo) + '</span></td><td class="small">' + esc(x.batch) + '</td><td class="small"><b>' + esc(x.mentor) + '</b></td></tr>').join('') + '</tbody></table></div>' : '');
  if (r.count) { f.dataset.ready = '1'; btn.textContent = 'Apply'; }
  $$('select, input', f).forEach((i) => { if (i.type !== 'hidden') i.addEventListener('change', () => { f.dataset.ready = ''; btn.textContent = 'Preview'; }, { once: true }); });
});
ACT.mtAllocTemplate = (d, btn) => busy(btn, async () => { const r = await call('mtAllocTemplate'); downloadBase64(r.name, r.data, r.mime); });
ACT.mtAllocImport = () => {
  openModal(modalHead('Import allocations', 'Excel (.xlsx) or CSV: College ID, Mentor staff ID — and optionally Department, Programme, Semester, Section, Category, Reason.') + '<div class="modal-body" id="mtImpBody">' +
    '<label class="dropzone" style="padding:1.5rem">' + icon('upload') + '<b>Choose the allocation file</b><span class="small">You will see a preview before anything changes.</span><input type="file" accept=".xlsx,.csv" data-change="mtAllocFile"></label>' +
    (MT.allocHome.coordinator ? check('mtImpOverride', 'Allow mentors above the maximum', false) : '') + '<div class="form-actions"><button class="btn" data-act="mtAllocTemplate">' + icon('download') + 'Template</button><button class="btn" data-act="close">Cancel</button></div></div>', 'wide');
};
ACT.mtAllocFile = (d, el) => {
  const file = el.files && el.files[0];
  if (!file) return;
  busy(null, async () => {
    const data = await readFileB64(file);
    const ov = $('input[name=mtImpOverride]');
    MT.imp = { name: file.name, data, override: !!(ov && ov.checked) };
    const r = await call('mtAllocImport', MT.imp);
    $('#mtImpBody').innerHTML = notice('<b>' + r.ok + '</b> row(s) ready' + (r.errors ? ', <b>' + r.errors + '</b> with problems (skipped)' : '') + '.', r.errors ? 'warn' : 'ok') +
      '<div class="table-wrap" style="max-height:320px;overflow:auto"><table class="table"><thead><tr><th>Row</th><th>Student</th><th>Mentor</th><th>Status</th></tr></thead><tbody>' + r.rows.map((x) => '<tr><td class="xs muted">' + x.line + '</td><td class="small">' + esc(x.student || x.regNo) + '<div class="xs muted">' + esc(x.regNo) + '</div></td><td class="small">' + esc(x.mentor || '—') + '</td><td>' + (x.status === 'ok' ? badge('Ready', 'success') : '<span class="xs mt-od">' + esc(x.error) + '</span>') + '</td></tr>').join('') + '</tbody></table></div>' +
      '<div class="form-actions"><button class="btn" data-act="close">Cancel</button>' + (r.ok ? '<button class="btn btn-primary" data-act="mtAllocImportApply">Apply ' + plural(r.ok, 'row') + '</button>' : '') + '</div>';
  });
};
ACT.mtAllocImportApply = (d, btn) => busy(btn, async () => { const r = await call('mtAllocImport', Object.assign({}, MT.imp, { apply: true })); closeModal(); toast(plural(r.assigned, 'allocation') + ' and ' + plural(r.profiles, 'profile') + ' updated.'); refresh(); });

/* =====================================================================
   ANALYTICS & REPORTS (mentor, department, institution)
   ===================================================================== */
async function viewMtAnalytics(params) {
  const p = Object.fromEntries(params.entries());
  p.level = p.level || 'mentor';
  const r = await call('mtAnalytics', p);
  const k = r.kpis;
  const fl = r.filters;
  const levels = [['mentor', 'My mentees']].concat(fl.canDepartment ? [['department', 'Department']] : []).concat(fl.canInstitution ? [['institution', 'Institution']] : []);
  const hb = (list) => list.length && list.some((x) => x.value) ? hbars(list.filter((x) => x.value)) : mtEmpty('No data in this period.');
  const tiles = [['users', 'indigo', k.students, 'Students'], ['id', 'blue', k.mentors, 'Mentors'], ['checkCircle', 'green', k.allocationPct + '%', 'Allocated (' + k.allocated + ')'], ['calendar', 'cyan', k.sessions, 'Sessions held'],
    ['clock', 'amber', k.pendingFollowups, 'Pending follow-ups' + (k.overdueFollowups ? ' · ' + k.overdueFollowups + ' overdue' : '')], ['check', 'green', k.followupCompliance == null ? '—' : k.followupCompliance + '%', 'Follow-ups done on time'],
    ['message', 'pink', k.openConcerns, 'Open concerns'], ['zap', 'violet', k.openInterventions, 'Active interventions'], ['target', 'slate', k.goalCompletion == null ? '—' : k.goalCompletion + '%', 'Goals completed (' + k.goalsCompleted + '/' + k.goals + ')']];
  const exportBtns = '<div class="menu-wrap"><button class="btn" data-act="menu">' + icon('download') + 'Export</button><div class="menu">' +
    '<button class="menu-item" data-act="mtExport" data-kind="mentor" data-mentor="' + esc(p.mentorId || '') + '">' + icon('file') + 'Mentor report (Excel)</button>' +
    (fl.canDepartment ? '<button class="menu-item" data-act="mtExport" data-kind="department" data-dept="' + esc(p.department || '') + '">' + icon('building') + 'Department report (Excel)</button>' : '') +
    (fl.canInstitution ? '<button class="menu-item" data-act="mtExport" data-kind="institution" data-dept="' + esc(p.department || '') + '">' + icon('chart') + 'Institutional report (Excel)</button>' : '') +
    '<button class="menu-item" data-act="mtExport" data-kind="' + esc(p.level) + '" data-dept="' + esc(p.department || '') + '" data-format="csv">' + icon('download') + 'Mentee list (CSV)</button></div></div>';
  return {
    title: 'Mentoring analytics',
    html: mtHead(p.level === 'institution' ? 'Institution dashboard' : p.level === 'department' ? 'Department dashboard' + (r.department ? ' — ' + r.department : '') : 'My mentoring analytics', 'Workload, activity and outcomes · ' + esc(fmtDate(r.from)) + ' to ' + esc(fmtDate(r.to - 86400000)), exportBtns, 'Analytics') + mtTabs('/mentoring/analytics') +
      '<div class="card"><form class="mt-filters" data-form="mtFilter" data-base="/mentoring/analytics">' + (levels.length > 1 ? mtSel('level', levels, p.level, { attrs: ' aria-label="Level"' }) : '<input type="hidden" name="level" value="mentor">') +
      (p.level !== 'mentor' && fl.departments.length ? mtSel('department', fl.departments.map((d) => [d.id, d.name]), p.department || '', { blank: p.level === 'institution' ? 'All departments' : 'Department', attrs: ' aria-label="Department"' }) : '') +
      (p.level !== 'mentor' && fl.mentors.length ? mtSel('mentorId', fl.mentors.map((m) => [m.id, m.name]), p.mentorId || '', { blank: 'All mentors', attrs: ' aria-label="Mentor"' }) : '') +
      (fl.cycles.length ? mtSel('cycleId', fl.cycles.map((c) => [c.id, c.name]), p.cycleId || '', { blank: 'All cycles', attrs: ' aria-label="Mentoring cycle"' }) : '') +
      '<input type="text" name="batch" value="' + esc(p.batch || '') + '" placeholder="Batch" aria-label="Batch" style="width:120px"><input type="text" name="programme" value="' + esc(p.programme || '') + '" placeholder="Programme" aria-label="Programme" style="width:130px"><input type="text" name="semester" value="' + esc(p.semester || '') + '" placeholder="Sem" aria-label="Semester" style="width:70px"><input type="text" name="section" value="' + esc(p.section || '') + '" placeholder="Sec" aria-label="Section" style="width:70px">' +
      '<input type="date" name="from" value="' + esc(p.from || '') + '" aria-label="From date"><input type="date" name="to" value="' + esc(p.to || '') + '" aria-label="To date"><button class="btn" type="submit">' + icon('filter', 'i-sm') + 'Apply</button></form></div>' +
      '<div class="mt-kpis sm">' + tiles.map((t) => statCard(t[0], t[1], t[2], t[3])).join('') + '</div>' +
      '<div class="mt-grid"><div class="mt-col">' +
      mtCard('Mentoring activity over time', r.sessionsByMonth.some(Boolean) || r.concernsByMonth.some(Boolean) ? chartSlot('columns', { labels: r.months, series: [{ name: 'Sessions', token: '1', values: r.sessionsByMonth }, { name: 'Concerns', token: '3', values: r.concernsByMonth }], xFmt: (m) => new Date(m + '-01T00:00').toLocaleDateString(undefined, { month: 'short' }), label: 'Sessions and concerns per month' }) + tableView(['Month', 'Sessions', 'Concerns'], r.months.map((m, i) => [m, r.sessionsByMonth[i], r.concernsByMonth[i]])) : mtEmpty('No sessions or concerns in this period.')) +
      mtCard('Students by support status', hbars([{ label: r.labels.ok, value: k.ok, icon: icon('checkCircle', 'i-sm') }, { label: r.labels.attention, value: k.attention, icon: icon('alert', 'i-sm') }, { label: r.labels.priority, value: k.priority, icon: icon('flag', 'i-sm') }]) + '<p class="xs muted">Support status summarises configurable indicators. It is a prompt for review, not a judgement.</p>') +
      mtCard('Sessions by category', hb(r.sessionsByCategory)) + mtCard('Intervention outcomes', hb(r.interventionOutcomes)) +
      '</div><div class="mt-col">' +
      mtCard('Concern categories', hb(r.concernCategories)) + mtCard('Goal completion', hb(r.goalStatus)) +
      mtCard('Student feedback', r.feedback.hidden ? mtEmpty(r.feedback.count ? 'Shown once there are at least ' + r.feedback.min + ' responses, to keep feedback anonymous (' + r.feedback.count + ' so far).' : 'No feedback yet.') :
        '<p><b class="mt-big">' + r.feedback.avg + '</b> / 5 average · ' + plural(r.feedback.count, 'response') + ' · ' + r.feedback.useful + '% found sessions useful · ' + r.feedback.another + ' asked for another session</p>' + hbars(r.feedback.dist.map((v, i) => ({ label: (i + 1) + ' ★', value: v }))) +
        (r.feedback.comments.length ? '<details class="mt-more"><summary class="small">Anonymous comments (' + r.feedback.comments.length + ')</summary><ul class="mt-ul">' + r.feedback.comments.map((c) => '<li class="small">' + esc(c) + '</li>').join('') + '</ul></details>' : '')) +
      '</div></div>' +
      (r.departments ? mtCard('Departments', '<div class="table-wrap"><table class="table"><thead><tr><th>Department</th><th>Students</th><th>Allocated</th><th>Sessions</th><th>Open concerns</th></tr></thead><tbody>' + r.departments.map((d) => '<tr><td><a href="#/mentoring/analytics?level=department&department=' + esc(d.id) + '"><b>' + esc(d.name) + '</b></a></td><td class="tnum">' + d.students + '</td><td class="tnum">' + d.allocated + (d.students ? ' (' + Math.round(d.allocated / d.students * 100) + '%)' : '') + '</td><td class="tnum">' + d.sessions + '</td><td class="tnum">' + d.openConcerns + '</td></tr>').join('') + '</tbody></table></div>') : '') +
      (r.mentors ? mtCard('Mentor workload & activity', r.mentors.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Mentor</th><th>Mentees</th><th>Sessions</th>' + (r.mentors[0].pending !== undefined ? '<th>Pending follow-ups</th><th>Overdue</th><th>Open concerns</th>' : '') + '</tr></thead><tbody>' + r.mentors.map((m) => '<tr><td><b>' + esc(m.name) + '</b></td><td class="tnum">' + m.mentees + '</td><td class="tnum">' + m.sessions + '</td>' + (m.pending !== undefined ? '<td class="tnum">' + m.pending + '</td><td class="tnum">' + (m.overdue ? '<span class="mt-od">' + m.overdue + '</span>' : 0) + '</td><td class="tnum">' + m.openConcerns + '</td>' : '') + '</tr>').join('') + '</tbody></table></div><p class="xs muted">Listed alphabetically. These figures describe workload and activity — they are not a ranking.</p>' : mtEmpty('No mentors with mentees in this view.')) : '') +
      (r.mentees ? mtCard('Mentees', r.mentees.length ? '<div class="mt-list">' + r.mentees.map(mtStuRow).join('') + '</div>' : mtEmpty('No mentees.')) : '')
  };
}
ACT.mtExport = (d, btn) => busy(btn, async () => {
  const r = await call('mtReport', { kind: d.kind === 'mentor' || d.kind === 'department' || d.kind === 'institution' || d.kind === 'student' ? d.kind : 'mentor', studentId: d.stu || '', mentorId: d.mentor || '', department: d.dept || '', format: d.format || 'xlsx' });
  downloadBase64(r.name, r.data, r.mime);
  toast('Report downloaded. It contains confidential student information — store it securely.');
});

/* ---------- printable student report (browser "Save as PDF") ---------- */
async function viewMtPrint(id) {
  const r = await call('mtStudent', { id });
  const st = r.student, ac = r.academics || {}, id2 = st.identity;
  const row = (a, b) => '<tr><th>' + esc(a) + '</th><td>' + b + '</td></tr>';
  const lvlOk = (x) => x.level !== 3;
  return {
    title: 'Mentoring report — ' + st.name,
    html: '<div class="mt-print"><div class="mt-noprint row" style="gap:.5rem;margin-bottom:1rem"><a class="btn" href="#/mentoring/student/' + esc(st.id) + '">' + icon('arrowLeft') + 'Back</a><span class="spacer"></span><button class="btn btn-primary" data-act="mtPrint">' + icon('printer') + 'Print / Save as PDF</button></div>' +
      '<article class="mt-doc"><header><div class="mt-eyebrow">Student Mentoring Report · Confidential</div><h1>' + esc(st.name) + '</h1><p class="small muted">' + esc(st.regNo) + ' · ' + esc(st.batch) + (st.department ? ' · ' + esc(st.department) : '') + ' · Mentor: ' + esc(st.mentor || '—') + ' · Generated ' + esc(fmt(Date.now())) + ' by ' + esc(S.me.name) + '</p></header>' +
      '<h2>Student profile</h2><table class="kv">' + row('Programme', esc(id2.programme || '—')) + row('Semester / section', esc((id2.semester || '—') + ' / ' + (id2.section || '—'))) + row('CGPA', esc(id2.cgpa === '' ? '—' : id2.cgpa)) + row('Arrears', esc(id2.arrears === '' ? '—' : id2.arrears)) + row('Support status', esc(r.support.label) + (r.support.indicators.length ? ' — ' + esc(r.support.indicators.map((h) => h.name).join('; ')) : '')) + '</table>' +
      '<h2>Academic summary</h2><table class="kv">' + row('Attendance', mtPct(ac.attendance && ac.attendance.overall) + (ac.attendance ? ' (' + ac.attendance.attended + '/' + ac.attendance.held + ' periods)' : '')) + row('Internal assessment', mtPct(ac.internal && ac.internal.avg)) + row('Course gradebook', mtPct(ac.lms && ac.lms.grade)) + row('Missed deadlines', esc(ac.lms ? ac.lms.missed : '—')) + '</table>' +
      '<h2>Mentoring sessions</h2>' + (r.sessions.filter((x) => x.status === 'completed' && lvlOk(x)).map((x) => '<div class="mt-doc-item"><b>' + esc(fmtDate(x.at)) + ' · ' + esc(x.type) + ' · ' + esc(x.category) + '</b>' + (x.observation ? '<p>' + esc(x.observation) + '</p>' : '') + (x.summary ? '<p><i>Shared:</i> ' + esc(x.summary) + '</p>' : '') + (x.outcome ? '<p><i>Outcome:</i> ' + esc(x.outcome) + '</p>' : '') + '</div>').join('') || '<p class="muted">None recorded.</p>') +
      '<h2>Goals & progress</h2>' + (r.goals.length ? '<table class="table"><thead><tr><th>Goal</th><th>Category</th><th>Target</th><th>Progress</th><th>Status</th></tr></thead><tbody>' + r.goals.map((g) => '<tr><td>' + esc(g.title) + '</td><td>' + esc(g.category) + '</td><td>' + esc(mtDate(g.target)) + '</td><td>' + g.progress + '%</td><td>' + esc(g.status) + '</td></tr>').join('') + '</tbody></table>' : '<p class="muted">None.</p>') +
      '<h2>Concerns</h2>' + (r.concerns.filter(lvlOk).length ? '<table class="table"><thead><tr><th>Ref</th><th>Category</th><th>Raised</th><th>Status</th><th>Resolution</th></tr></thead><tbody>' + r.concerns.filter(lvlOk).map((c) => '<tr><td>' + esc(c.ref) + '</td><td>' + esc(c.category) + '</td><td>' + esc(fmtDate(c.at)) + '</td><td>' + esc(c.status) + '</td><td>' + esc(c.resolution || '') + '</td></tr>').join('') + '</tbody></table>' : '<p class="muted">None.</p>') +
      '<h2>Interventions</h2>' + (r.interventions.filter(lvlOk).length ? r.interventions.filter(lvlOk).map((x) => '<div class="mt-doc-item"><b>' + esc(x.ref) + ' — ' + esc(x.problem) + '</b><p>' + esc(x.plan || '') + '</p><p><i>Outcome:</i> ' + esc(x.outcomeLabel || 'In progress') + (x.outcomeNote ? ' — ' + esc(x.outcomeNote) : '') + '</p></div>').join('') : '<p class="muted">None.</p>') +
      '<h2>Follow-ups</h2>' + (r.actions.filter(lvlOk).length ? '<table class="table"><thead><tr><th>Action</th><th>Responsible</th><th>Date</th><th>Status</th><th>Outcome</th></tr></thead><tbody>' + r.actions.filter(lvlOk).map((a) => '<tr><td>' + esc(a.title) + '</td><td>' + esc(a.ownerLabel) + '</td><td>' + esc(mtDate(a.followUp || a.due)) + '</td><td>' + esc(a.status) + '</td><td>' + esc(a.outcome) + '</td></tr>').join('') + '</tbody></table>' : '<p class="muted">None.</p>') +
      '<h2>Career development</h2>' + mtCareerHtml(r.career).replace(/<button[^>]*>[\s\S]*?<\/button>/g, '') +
      '<h2>Mentor remarks</h2><div class="mt-remarks"></div><p class="xs muted">Restricted (level 3) records are not included in this report.</p></article></div>'
  };
}
ACT.mtPrint = () => window.print();

/* =====================================================================
   CONFIGURATION (administrators) & AUDIT
   ===================================================================== */
const MT_CFG_TABS = [['general', 'General'], ['rules', 'Support indicator rules'], ['lists', 'Lists & templates'], ['departments', 'Departments & roles'], ['cycles', 'Cycles'], ['privacy', 'Notifications & privacy'], ['audit', 'Audit log']];
async function viewMtSettings(params) {
  const tab = MT_CFG_TABS.some((t) => t[0] === params.get('tab')) ? params.get('tab') : 'general';
  if (!mtFlags().admin) return { title: 'Mentoring configuration', html: mtHead('Mentoring configuration', '', '', 'Configuration') + '<div class="card card-pad">' + emptyState('lock', 'Administrators only', 'Mentoring configuration is managed by the site administrators.', '<a class="btn" href="#/mentoring">Back to mentoring</a>', false) + '</div>' };
  const c = await call('mtConfig');
  MT.cfg = c;
  let body = '';
  if (tab === 'general') body = mtCfgGeneral(c);
  if (tab === 'rules') body = mtCfgRules(c);
  if (tab === 'lists') body = mtCfgLists(c);
  if (tab === 'departments') body = mtCfgDepts(c);
  if (tab === 'cycles') body = mtCfgCycles(c);
  if (tab === 'privacy') body = mtCfgPrivacy(c);
  if (tab === 'audit') body = await mtCfgAudit(params);
  return {
    title: 'Mentoring configuration',
    html: mtHead('Mentoring configuration', 'Policies, thresholds and roles for your institution. Nothing here is hard-coded.', '', 'Configuration') + mtTabs('/mentoring/settings') +
      '<div class="pills mt-cfgtabs" role="tablist">' + MT_CFG_TABS.map((t) => '<a class="pill' + (t[0] === tab ? ' active' : '') + '" href="#/mentoring/settings?tab=' + t[0] + '">' + t[1] + '</a>').join('') + '</div>' + body
  };
}
function mtCfgGeneral(c) {
  return '<div class="card card-pad"><form data-form="mtCfg" data-part="general" novalidate><div class="form-grid">' +
    field('Maximum mentees per mentor', '<input type="number" name="maxMentees" min="1" max="500" value="' + c.maxMentees + '">') + field('Minimum mentoring frequency (days)', '<input type="number" name="minFrequencyDays" min="1" max="365" value="' + c.minFrequencyDays + '">', 'Mentees without contact for longer show as "No recent interaction".') + '</div><div class="form-grid">' +
    field('Default follow-up period (days)', '<input type="number" name="followUpDays" min="1" max="180" value="' + c.followUpDays + '">') + field('"Needs attention" indicators that make a Priority intervention', '<input type="number" name="priorityCount" min="1" max="10" value="' + c.priorityCount + '">') + '</div>' +
    '<fieldset class="fieldset"><legend>Wording</legend><p class="xs muted">Neutral terms are used by default. Change them only if your institution’s policy uses different language.</p><div class="form-grid">' +
    field('On track', '<input type="text" name="l_ok" maxlength="60" value="' + esc(c.labels.ok) + '">') + field('Needs attention', '<input type="text" name="l_attention" maxlength="60" value="' + esc(c.labels.attention) + '">') + '</div><div class="form-grid">' +
    field('Priority intervention', '<input type="text" name="l_priority" maxlength="60" value="' + esc(c.labels.priority) + '">') + field('Name for an indicator', '<input type="text" name="l_indicator" maxlength="60" value="' + esc(c.labels.indicator) + '">') + '</div></fieldset>' +
    check('mentorsAddMentees', 'Mentors can add their own mentees (My mentees → Add mentees)', c.mentorsAddMentees, 'Only students without a mentor, up to the maximum. Reassigning stays with HODs and coordinators.') +
    field('Retention period (years)', '<input type="number" name="retentionYears" min="1" max="30" value="' + c.retentionYears + '">', 'Records are never deleted automatically. ' + (c.pastRetention ? '<b>' + c.pastRetention + '</b> sessions/concerns are older than this — review them with your records policy.' : 'No records are past the retention period.')) +
    '<div class="form-actions"><button class="btn btn-primary" type="submit">Save</button></div></form></div>';
}
function mtCfgRules(c) {
  const metricOpts = Object.keys(c.metrics).map((k) => [k, c.metrics[k].label]);
  const rowHtml = (r, i) => '<tr data-i="' + i + '"><td><input type="hidden" name="r_id" value="' + esc(r.id || '') + '"><input type="text" name="r_name" maxlength="100" value="' + esc(r.name || '') + '" aria-label="Rule name"></td>' +
    '<td>' + mtSel('r_metric', metricOpts, r.metric || 'attendance_pct', { attrs: ' aria-label="Metric"' }) + '</td><td>' + mtSel('r_op', c.ops, r.op || '<', { attrs: ' aria-label="Operator"' }) + '</td>' +
    '<td><input type="number" name="r_threshold" step="0.1" value="' + esc(r.threshold == null ? '' : r.threshold) + '" style="width:80px" aria-label="Threshold"></td><td><input type="number" name="r_period" min="0" max="365" value="' + esc(r.periodDays || '') + '" style="width:70px" aria-label="Time period in days" placeholder="—"></td>' +
    '<td>' + mtSel('r_severity', Object.keys(c.severities).map((k) => [k, c.severities[k]]), r.severity || 'attention', { attrs: ' aria-label="Severity"' }) + '</td>' +
    '<td><label class="check"><input type="checkbox" name="r_enabled"' + (r.enabled !== false ? ' checked' : '') + '><span>On</span></label></td><td><label class="check"><input type="checkbox" name="r_hod"' + (r.notifyHod ? ' checked' : '') + '><span>HOD</span></label></td>' +
    '<td><button type="button" class="btn-icon sm danger" title="Remove rule" data-act="mtRuleDel">' + icon('trash') + '</button></td></tr>';
  MT.ruleRow = rowHtml;
  return '<div class="card"><div class="card-body">' + notice('Rules flag <b>indicators</b> for mentors to review. Missing data never triggers a rule. The time period applies to metrics that compare periods (attendance in the period, attendance fall, concerns in the period). Mentors are notified of new indicators (except reminders); tick HOD to escalate.', '', 'info') + '</div>' +
    '<form data-form="mtCfg" data-part="rules" novalidate><div class="table-wrap"><table class="table mt-rules"><thead><tr><th>Rule name</th><th>Metric</th><th>Op</th><th>Threshold</th><th>Period (days)</th><th>Severity</th><th>Enabled</th><th>Escalate</th><th></th></tr></thead><tbody id="mtRules">' + c.rules.map(rowHtml).join('') + '</tbody></table></div>' +
    '<div class="card-body form-actions" style="justify-content:space-between"><button class="btn" type="button" data-act="mtRuleAdd">' + icon('plus') + 'Add rule</button><button class="btn btn-primary" type="submit">Save rules</button></div></form></div>';
}
ACT.mtRuleAdd = () => { $('#mtRules').insertAdjacentHTML('beforeend', MT.ruleRow({ severity: 'attention', enabled: true }, Date.now())); };
ACT.mtRuleDel = (d, el) => { el.closest('tr').remove(); };
function mtCfgLists(c) {
  const ta = (name, label, list) => field(label, '<textarea name="' + name + '" rows="6">' + esc(list.join('\n')) + '</textarea>', 'One per line.');
  return '<div class="card card-pad"><form data-form="mtCfg" data-part="lists" novalidate><div class="form-grid">' + ta('sessionTypes', 'Session types', c.sessionTypes) + ta('sessionCategories', 'Session / discussion categories', c.sessionCategories) + '</div><div class="form-grid">' +
    ta('goalCategories', 'Goal categories', c.goalCategories) + ta('concernCategories', 'Concern categories', c.concernCategories) + '</div>' +
    '<h3 class="mt-h3">Session templates</h3><div id="mtTpls">' + c.templates.map(mtTplEditor).join('') + '</div><button class="btn" type="button" data-act="mtTplAdd">' + icon('plus') + 'Add template</button>' +
    '<div class="form-actions"><button class="btn btn-primary" type="submit">Save</button></div></form></div>';
}
function mtTplEditor(t) {
  return '<fieldset class="fieldset mt-tpledit"><legend>Template</legend><input type="hidden" name="t_id" value="' + esc(t.id || '') + '"><div class="form-grid">' + field('Name', '<input type="text" name="t_name" maxlength="80" value="' + esc(t.name || '') + '">') + field('Category', '<input type="text" name="t_cat" maxlength="60" value="' + esc(t.category || '') + '">') + '</div>' +
    field('Prompts', '<textarea name="t_prompts" rows="5">' + esc((t.prompts || []).join('\n')) + '</textarea>', 'One per line. Clear all prompts to remove the template.') + '</fieldset>';
}
ACT.mtTplAdd = () => { $('#mtTpls').insertAdjacentHTML('beforeend', mtTplEditor({})); };
function mtStaffOptions(sel) { return MT.cfg.staff.map((u) => '<option value="' + esc(u.id) + '"' + (sel.indexOf(u.id) >= 0 ? ' selected' : '') + '>' + esc(u.name) + (u.department ? ' — ' + esc(u.department) : '') + (u.role === 'admin' ? ' (admin)' : '') + '</option>').join(''); }
function mtCfgDepts(c) {
  const dept = (d) => '<fieldset class="fieldset mt-deptedit"><legend>Department</legend><input type="hidden" name="d_id" value="' + esc(d.id || '') + '"><div class="form-grid">' + field('Name', '<input type="text" name="d_name" maxlength="80" value="' + esc(d.name || '') + '">') + field('Code', '<input type="text" name="d_code" maxlength="20" value="' + esc(d.code || '') + '">', 'Faculty whose Department field matches the name or code belong here.') + '</div><div class="form-grid">' +
    field('Classes (batches) in this department', '<textarea name="d_batches" rows="4" list="mtBatchList">' + esc((d.batches || []).join('\n')) + '</textarea>', 'One per line, exactly as in the Users list.') +
    field('Head(s) of department', '<select name="d_hods" multiple size="5">' + mtStaffOptions((d.hods || []).map((h) => h.id)) + '</select>', 'HODs see this department’s students and dashboard.') + '</div></fieldset>';
  MT.deptRow = dept;
  const g = c.grants;
  const unmapped = c.batches.filter((b) => !c.departments.some((d) => d.batches.some((x) => x.trim().toLowerCase() === b.trim().toLowerCase())));
  return '<div class="card card-pad"><form data-form="mtCfg" data-part="departments" novalidate>' +
    '<h3 class="mt-h3">Mentoring roles</h3><p class="small muted">Administrators always have full mentoring access (except Restricted records). Any faculty member with mentees is a mentor.</p><div class="form-grid-3">' +
    field('Coordinators', '<select name="g_coordinators" multiple size="7">' + mtStaffOptions(g.coordinators.map((x) => x.id)) + '</select>', 'Manage allocations, cycles and reports for every student.') +
    field('Principal / Director', '<select name="g_principals" multiple size="7">' + mtStaffOptions(g.principals.map((x) => x.id)) + '</select>', 'Institution dashboards — counts only, no individual records.') +
    field('Restricted-record access', '<select name="g_restricted" multiple size="7">' + mtStaffOptions(g.restricted.map((x) => x.id)) + '</select>', 'May open Level 3 records of students already in their scope. Every view is logged.') + '</div>' +
    '<h3 class="mt-h3">Departments</h3>' + (unmapped.length ? notice(plural(unmapped.length, 'class') + ' not in any department: ' + esc(unmapped.slice(0, 12).join(', ')) + (unmapped.length > 12 ? '…' : ''), 'warn') : '') +
    '<datalist id="mtBatchList">' + c.batches.map((b) => '<option value="' + esc(b) + '">').join('') + '</datalist><div id="mtDepts">' + c.departments.map(dept).join('') + '</div><button class="btn" type="button" data-act="mtDeptAdd">' + icon('plus') + 'Add department</button>' +
    '<div class="form-actions"><button class="btn btn-primary" type="submit">Save roles & departments</button></div></form></div>';
}
ACT.mtDeptAdd = () => { $('#mtDepts').insertAdjacentHTML('beforeend', MT.deptRow({})); };
function mtCfgCycles(c) {
  const row = (x) => '<tr><td><b>' + esc(x.name) + '</b><div class="xs muted">' + esc(x.year || '') + (x.term ? ' · ' + esc(x.term) : '') + '</div></td><td class="small">' + esc(mtDate(x.start)) + ' – ' + esc(mtDate(x.end)) + '</td><td>' + badge(x.status, x.status === 'active' ? 'success' : x.status === 'archived' ? '' : 'info') + '</td><td class="tnum">' + x.sessions + '</td><td class="actions nowrap">' +
    (x.status === 'planned' || x.status === 'closed' ? '<button class="btn btn-sm btn-soft" data-act="mtCycleAct" data-id="' + esc(x.id) + '" data-action="start">Start</button>' : '') + (x.status === 'active' ? '<button class="btn btn-sm" data-act="mtCycleAct" data-id="' + esc(x.id) + '" data-action="close">Close</button>' : '') +
    (x.status === 'closed' ? '<button class="btn btn-sm btn-ghost" data-act="mtCycleAct" data-id="' + esc(x.id) + '" data-action="archive">Archive</button>' : '') + (x.status === 'archived' ? '<button class="btn btn-sm btn-ghost" data-act="mtCycleAct" data-id="' + esc(x.id) + '" data-action="reopen">Reopen</button>' : '') +
    '<button class="btn-icon sm" title="Edit" data-act="mtCycleEdit" data-id="' + esc(x.id) + '">' + icon('edit') + '</button></td></tr>';
  return '<div class="card"><div class="card-head"><h2>Mentoring cycles</h2><span class="spacer"></span><button class="btn btn-sm btn-primary" data-act="mtCycleEdit">' + icon('plus', 'i-sm') + 'New cycle</button></div><div class="card-body"><p class="small muted">New sessions, goals, concerns and interventions are stamped with the active cycle. Archived cycles become read-only; their records stay available for reports and history.</p></div>' +
    (c.cycles.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Cycle</th><th>Dates</th><th>Status</th><th>Sessions</th><th></th></tr></thead><tbody>' + c.cycles.map(row).join('') + '</tbody></table></div>' : '<div class="card-body">' + emptyState('calendar', 'No cycles yet', 'Create one for the academic year, e.g. "2026–27 Semester 1".', '', false) + '</div>') + '</div>';
}
ACT.mtCycleEdit = (d) => {
  const x = d.id ? MT.cfg.cycles.find((c) => c.id === d.id) : null;
  formModal(x ? 'Edit cycle' : 'New mentoring cycle', '', 'mtCycle', '<input type="hidden" name="id" value="' + esc(x ? x.id : '') + '">' +
    '<div class="form-grid-3">' + field('Name', '<input type="text" name="name" maxlength="80" required value="' + esc(x ? x.name : '') + '" placeholder="2026–27 Semester 1">') + field('Academic year', '<input type="text" name="year" maxlength="20" value="' + esc(x ? x.year : '') + '" placeholder="2026–27">') + field('Semester / term', '<input type="text" name="term" maxlength="40" value="' + esc(x ? x.term : '') + '">') + '</div>' +
    '<div class="form-grid">' + field('Start', '<input type="date" name="start" required value="' + esc(x ? x.start : '') + '">') + field('End', '<input type="date" name="end" required value="' + esc(x ? x.end : '') + '">') + '</div>' +
    field('Objectives', '<textarea name="objectives" maxlength="2000">' + esc(x ? x.objectives : '') + '</textarea>') + (!x ? check('start', 'Start this cycle now', true) : ''), 'Save', 'wide');
};
FORMS.mtCycle = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  await call('mtCycleSave', { id: el.id.value, name: el.name.value, year: el.year.value, term: el.term.value, start: el.start.value, end: el.end.value, objectives: el.objectives.value, action: el.start && el.start.checked ? 'start' : '' });
  closeModal(); toast('Cycle saved.'); refresh();
});
ACT.mtCycleAct = async (d) => {
  const x = MT.cfg.cycles.find((c) => c.id === d.id);
  if (d.action === 'archive' && !await confirmBox('Archive ' + x.name + '?', '<p>Records from this cycle become read-only. They stay available in reports and history.</p>', 'Archive')) return;
  busy(null, async () => { await call('mtCycleSave', Object.assign({}, x, { action: d.action })); toast('Cycle updated.'); refresh(); });
};
function mtCfgPrivacy(c) {
  const n = c.notifications;
  return '<div class="card card-pad"><form data-form="mtCfg" data-part="privacy" novalidate>' +
    '<fieldset class="fieldset"><legend>Notifications</legend>' + check('n_email', 'Also send mentoring notifications by email (when email is set up under Settings → Email & SMS)', n.email) + check('n_hod', 'Escalate indicators marked "HOD" to the head of department', n.escalateToHod) +
    '<div class="form-grid">' + field('Session reminder (hours before)', '<input type="number" name="n_hours" min="1" max="168" value="' + n.sessionReminderHours + '">') + field('Goal deadline reminder (days before)', '<input type="number" name="n_goal" min="1" max="60" value="' + n.goalDeadlineDays + '">') + '</div></fieldset>' +
    '<fieldset class="fieldset"><legend>Parents</legend>' + check('p_mentor', 'Parents see their child’s mentor', c.parents.seeMentor) + check('p_goals', 'Parents see their child’s goals and progress', c.parents.seeGoals) + '<p class="xs muted">Parents never see mentor notes, concerns or interventions — only meetings they are invited to and notes a mentor explicitly shares.</p></fieldset>' +
    '<fieldset class="fieldset"><legend>Student feedback</legend>' + check('f_on', 'Ask students for feedback after sessions', c.feedback.enabled) + field('Minimum responses before results are shown', '<input type="number" name="f_min" min="1" max="20" value="' + c.feedback.anonymousMin + '">', 'Keeps individual feedback anonymous.') + '</fieldset>' +
    '<fieldset class="fieldset"><legend>AI mentoring assistant</legend>' + check('ai_ext', 'Allow sending pseudonymised records to Claude (no names, IDs, contact details or restricted notes)', c.ai.external) +
    '<p class="xs muted">' + (c.ai.keySet ? 'A Claude API key is configured under Settings → AI guide.' : 'No Claude API key is configured, so the assistant uses built-in summaries.') + ' With this off, nothing leaves your server. Every assistant request is logged.</p></fieldset>' +
    '<div class="form-actions"><button class="btn btn-primary" type="submit">Save</button></div></form></div>';
}
async function mtCfgAudit(params) {
  const p = { page: params.get('page') || 1, entity: params.get('entity') || '', q: params.get('q') || '' };
  const r = await call('mtAudit', p);
  return '<div class="card"><form class="mt-filters" data-form="mtFilter" data-base="/mentoring/settings"><input type="hidden" name="tab" value="audit"><div class="search-box">' + icon('search') + '<input type="search" name="q" value="' + esc(p.q) + '" placeholder="Person, action or student" aria-label="Search audit log"></div>' + mtSel('entity', r.entities, p.entity, { blank: 'All records', attrs: ' aria-label="Record type"' }) + '<button class="btn" type="submit">' + icon('filter', 'i-sm') + 'Apply</button></form>' +
    (r.rows.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Record</th><th>Student</th><th>Changed</th></tr></thead><tbody>' + r.rows.map((e) => '<tr><td class="small nowrap">' + esc(fmt(e.at)) + '</td><td class="small">' + esc(e.by) + '<div class="xs muted">' + esc(e.role) + '</div></td><td><code class="xs">' + esc(e.action) + '</code></td><td class="small">' + esc(e.entity) + (e.entityId ? '<div class="xs muted">' + esc(e.entityId) + '</div>' : '') + '</td><td class="small">' + esc(e.student || '—') + '</td><td class="xs">' + esc(e.changes.join(', ') || e.extra || '—') + '</td></tr>').join('') + '</tbody></table></div>' + mtPager({ page: r.page, pages: r.pages, total: r.total }, '/mentoring/settings?tab=audit' + (p.entity ? '&entity=' + encodeURIComponent(p.entity) : '') + (p.q ? '&q=' + encodeURIComponent(p.q) : ''))
      : '<div class="card-body">' + emptyState('shield', 'No audit entries', '', '', false) + '</div>') + '</div>';
}
FORMS.mtCfg = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  const part = f.dataset.part;
  const lines = (v) => v.split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
  const multi = (sel) => Array.from(sel.selectedOptions).map((o) => o.value);
  let p = {};
  if (part === 'general') p = { mentorsAddMentees: el.mentorsAddMentees.checked, maxMentees: el.maxMentees.value, minFrequencyDays: el.minFrequencyDays.value, followUpDays: el.followUpDays.value, priorityCount: el.priorityCount.value, retentionYears: el.retentionYears.value, labels: { ok: el.l_ok.value, attention: el.l_attention.value, priority: el.l_priority.value, indicator: el.l_indicator.value } };
  if (part === 'rules') p = { rules: $$('#mtRules tr').map((tr) => { const q = (n) => tr.querySelector('[name=' + n + ']'); return { id: q('r_id').value, name: q('r_name').value, metric: q('r_metric').value, op: q('r_op').value, threshold: q('r_threshold').value, periodDays: q('r_period').value, severity: q('r_severity').value, enabled: q('r_enabled').checked, notifyHod: q('r_hod').checked, notifyMentor: true }; }) };
  if (part === 'lists') p = { sessionTypes: lines(el.sessionTypes.value), sessionCategories: lines(el.sessionCategories.value), goalCategories: lines(el.goalCategories.value), concernCategories: lines(el.concernCategories.value), templates: $$('.mt-tpledit', f).map((fs) => ({ id: fs.querySelector('[name=t_id]').value, name: fs.querySelector('[name=t_name]').value || 'Template', category: fs.querySelector('[name=t_cat]').value, prompts: lines(fs.querySelector('[name=t_prompts]').value) })) };
  if (part === 'departments') p = { grants: { coordinators: multi(el.g_coordinators), principals: multi(el.g_principals), restricted: multi(el.g_restricted) }, departments: $$('.mt-deptedit', f).filter((fs) => fs.querySelector('[name=d_name]').value.trim()).map((fs) => ({ id: fs.querySelector('[name=d_id]').value, name: fs.querySelector('[name=d_name]').value, code: fs.querySelector('[name=d_code]').value, batches: lines(fs.querySelector('[name=d_batches]').value), hodIds: multi(fs.querySelector('[name=d_hods]')) })) };
  if (part === 'privacy') p = { notifications: { email: el.n_email.checked, escalateToHod: el.n_hod.checked, sessionReminderHours: el.n_hours.value, goalDeadlineDays: el.n_goal.value }, parents: { seeMentor: el.p_mentor.checked, seeGoals: el.p_goals.checked }, feedback: { enabled: el.f_on.checked, anonymousMin: el.f_min.value }, ai: { external: el.ai_ext.checked } };
  await call('mtSaveConfig', p);
  MT.opts = null;
  toast('Configuration saved.'); refresh();
});
