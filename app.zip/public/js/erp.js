'use strict';
/* =====================================================================
   ERP — ATTENDANCE and MARK ENTRY
   /attendance              staff: courses · students/parents: my attendance
   /attendance/c/:id        take attendance · register · sessions
   /attendance/reports      Excel reports, settings (admin)
   /marks                   staff: INTERNAL MARK ENTRY - LOCF Based (ERP layout)
                            students/parents: my internal marks
   ===================================================================== */
const ERP = { att: null, take: null };
// Attendance is Present / Absent. Older records may hold L / OD (shown as present) or ML (shown as absent).
const ATT_SHORT = { P: 'P', A: 'A' };
const attPA = (m) => (m === 'P' || m === 'L' ? 'P' : m === 'OD' || m === 'ML' ? m : m ? 'A' : '');
const attTake = (m) => (m === 'A' || m === 'ML' ? 'A' : m ? 'P' : '');
const periodLabel = (n, st) => 'Period ' + n + (st && st.periodMinutes ? ' · ' + st.periodMinutes + ' min' : '');
const isStaffRole = () => S.me && (S.me.role === 'teacher' || S.me.role === 'admin');
function todayStr() { return toDateInput(Date.now()); }
function niceD(d) { if (!d) return ''; const x = new Date(d + 'T00:00'); return x.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }); }
function shortD(d) { const x = new Date(d + 'T00:00'); return x.toLocaleDateString(undefined, { day: 'numeric', month: 'short' }); }
function pctTone(p, t) { return p == null ? '' : p < t ? 'bad' : p < t + 5 ? 'warn' : 'ok'; }
function daysAgo(n) { const d = new Date(); d.setDate(d.getDate() - n); return toDateInput(d.getTime()); }
function monthStart() { const d = new Date(); return toDateInput(new Date(d.getFullYear(), d.getMonth(), 1).getTime()); }
async function erpDownload(action, payload, btn) {
  return busy(btn, async () => { const r = await call(action, payload); downloadBase64(r.name, r.data, r.mime); toast('Downloaded ' + r.name); });
}

/* ---------- printable pages (statements, attendance reports) ---------- */
function erpPrint(title, pages) {
  erpPrintClose();
  const ov = document.createElement('div');
  ov.id = 'erpPrint'; ov.className = 'erp-print';
  ov.innerHTML = '<div class="erp-print-bar"><button class="btn btn-sm" data-act="erpPrintClose">' + icon('arrowLeft') + 'Back</button><b>' + esc(title) + '</b><span class="small muted">' + plural(pages.length, 'page') + '</span>' +
    '<span class="spacer"></span><button class="btn btn-sm btn-primary" data-act="erpPrintGo">' + icon('printer') + 'Print / Save as PDF</button></div>' +
    '<div class="erp-print-scroll"><div class="erp-pages">' + pages.map((p) => '<section class="erp-page">' + p + '</section>').join('') + '</div></div>';
  document.body.appendChild(ov);
  document.body.classList.add('qp-noscroll');
}
function erpPrintClose() { const o = $('#erpPrint'); if (o) o.remove(); document.body.classList.remove('qp-noscroll', 'erp-printing'); }
ACT.erpPrintClose = erpPrintClose;
ACT.erpPrintGo = () => {
  document.body.classList.add('erp-printing');
  const done = () => { document.body.classList.remove('erp-printing'); window.removeEventListener('afterprint', done); };
  window.addEventListener('afterprint', done);
  window.print();
};
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && $('#erpPrint') && !$('.modal-bg')) erpPrintClose(); });
function printHead(title, sub) {
  return '<header class="erp-ph"><div class="erp-ph-inst">' + esc(SITE) + '</div><h1>' + esc(title) + '</h1>' + (sub ? '<div class="erp-ph-sub">' + sub + '</div>' : '') + '</header>';
}
function signLines(list) { return '<div class="erp-sign">' + list.map((l) => '<div><span></span>' + esc(l) + '</div>').join('') + '</div>'; }

/* =====================================================================
   ATTENDANCE
   ===================================================================== */
route(/^\/attendance$/, async () => {
  if (!isStaffRole()) return attMineView();
  const d = await call('attHome');
  ERP.home = d;
  const t = d.settings.threshold;
  const takenToday = d.courses.reduce((n, c) => n + c.today.length, 0);
  const withAvg = d.courses.filter((c) => c.avg != null);
  const avg = withAvg.length ? Math.round(withAvg.reduce((n, c) => n + c.avg, 0) / withAvg.length * 10) / 10 : null;
  const card = (c) => '<div class="card erp-course"><div class="erp-course-top"><span class="erp-dot cc-' + esc(c.color) + '"></span><div style="min-width:0;flex:1"><b>' + esc(c.shortname) + '</b><div class="small muted erp-ell">' + esc(c.fullname) + '</div></div>' +
    (c.avg != null ? ring(c.avg, 52) : '<span class="erp-noring">—</span>') + '</div>' +
    '<div class="erp-course-meta"><span>' + icon('users', 'i-sm') + plural(c.students, 'student') + '</span><span>' + icon('calendar', 'i-sm') + plural(c.sessions, 'session') + '</span>' +
    (c.below ? '<span class="erp-bad">' + icon('alert', 'i-sm') + c.below + ' below ' + t + '%</span>' : '') + '</div>' +
    '<div class="erp-today">' + (c.today.length ? 'Today: ' + c.today.map((p) => '<span class="badge success">P' + p + '</span>').join(' ') : '<span class="muted small">Not taken today</span>') + '</div>' +
    '<div class="erp-course-foot"><a class="btn btn-sm btn-primary" href="#/attendance/c/' + esc(c.id) + '">' + icon('check') + 'Take attendance</a>' +
    '<a class="btn btn-sm" href="#/attendance/c/' + esc(c.id) + '?tab=register">' + icon('list') + 'Register</a>' +
    '<button class="btn btn-sm btn-ghost" data-act="attDl" data-kind="register" data-course="' + esc(c.id) + '" title="Download register (.xlsx)">' + icon('download') + '</button></div></div>';
  return {
    title: 'Attendance',
    html: pageHead('Attendance', {
      sub: 'Take attendance period by period (' + d.settings.periods + ' periods of ' + d.settings.periodMinutes + ' minutes a day), catch shortages early, and download registers in one click.',
      actions: '<a class="btn" href="#/attendance/reports">' + icon('download') + 'Reports</a>'
    }) +
      '<div class="grid-4 kpis" style="margin-bottom:var(--sp-6)">' + kpi('Courses', d.courses.length, 'you take attendance for', 'book') + kpi('Taken today', takenToday, 'of ' + d.courses.length * d.settings.periods + ' periods · ' + d.settings.periods + ' a day', 'check') +
      kpi('Average attendance', avg == null ? '—' : avg + '%', 'across your courses', 'activity') + kpi('Below ' + t + '%', d.courses.reduce((n, c) => n + c.below, 0), 'students with a shortage', 'alert') + '</div>' +
      (d.courses.length ? '<div class="erp-grid">' + d.courses.map(card).join('') + '</div>' : emptyState('calendar', 'No courses yet', 'Courses you teach appear here.', ''))
  };
});
ACT.attDl = (d, btn) => erpDownload('attReport', { kind: d.kind, courseId: d.course || '', from: d.from || '', to: d.to || '' }, btn);

/* ---------- course: take · register · sessions ---------- */
route(/^\/attendance\/c\/([A-Za-z0-9]+)$/, async (id, params) => {
  const tab = params.get('tab') || 'take';
  const date = params.get('date') || todayStr();
  const period = Number(params.get('h')) || 0;
  const [c, sess] = await Promise.all([call('attCourse', { courseId: id, from: params.get('from') || '', to: params.get('to') || '' }), tab === 'take' ? call('attSession', { courseId: id, date, period: period || 1 }) : null]);
  ERP.att = c;
  if (tab === 'take') {
    // Default hour: the next hour not yet taken today.
    let h = period;
    if (!h) { const taken = c.sessions.filter((x) => x.date === date).map((x) => x.period); h = 1; while (taken.indexOf(h) >= 0 && h < c.settings.periods) h++; }
    const s2 = h === 1 ? sess : await call('attSession', { courseId: id, date, period: h });
    ERP.take = { courseId: id, date, period: h, data: s2, marks: {} };
    s2.roster.forEach((u) => { ERP.take.marks[u.id] = attTake(s2.session && s2.session.marks[u.id]) || 'P'; });
  }
  const t = c.settings.threshold;
  const tabs = [['take', 'Take attendance', 'check'], ['register', 'Register', 'list'], ['sessions', 'Sessions (' + c.summary.sessions + ')', 'calendar']];
  const head = pageHead(c.course.shortname + ' · Attendance', {
    crumbs: [['Attendance', '/attendance'], [c.course.shortname]],
    sub: esc(c.course.fullname) + ' · ' + plural(c.summary.students, 'student') + ' · ' + plural(c.summary.sessions, 'session') + (c.summary.avg != null ? ' · average ' + c.summary.avg + '%' : '') + (c.summary.below ? ' · <span class="erp-bad">' + c.summary.below + ' below ' + t + '%</span>' : ''),
    actions: '<div class="menu-wrap"><button class="btn" data-act="menu">' + icon('download') + 'Download</button><div class="menu">' +
      '<button class="menu-item" data-act="attDl" data-kind="register" data-course="' + esc(id) + '">' + icon('table') + 'Attendance register (.xlsx)</button>' +
      '<button class="menu-item" data-act="attDl" data-kind="shortage" data-course="' + esc(id) + '">' + icon('alert') + 'Shortage list (.xlsx)</button>' +
      '<button class="menu-item" data-act="attDl" data-kind="absentees" data-course="' + esc(id) + '" data-from="' + todayStr() + '" data-to="' + todayStr() + '">' + icon('userPlus') + 'Today’s absentees (.xlsx)</button>' +
      '<button class="menu-item" data-act="attDl" data-kind="absentees" data-course="' + esc(id) + '" data-from="' + monthStart() + '" data-to="' + todayStr() + '">' + icon('calendar') + 'This month’s absentees (.xlsx)</button>' +
      '<div class="menu-sep"></div><button class="menu-item" data-act="attPrintCourse">' + icon('printer') + 'Print student reports</button></div></div>'
  });
  const pills = '<div class="pills" style="margin-bottom:var(--sp-5)">' + tabs.map(([k, l, ic]) => '<a class="pill' + (tab === k ? ' active' : '') + '" href="#/attendance/c/' + esc(id) + (k === 'take' ? '' : '?tab=' + k) + '">' + icon(ic) + esc(l) + '</a>').join('') + '</div>';
  let body = '';
  if (tab === 'take') body = takeHtml();
  else if (tab === 'register') body = registerHtml(c);
  else body = sessionsHtml(c);
  return { title: c.course.shortname + ' attendance', html: head + pills + body, after: tab === 'take' ? takeMount : tab === 'register' ? registerMount : null };
});

function takeHtml() {
  const T = ERP.take, d = T.data;
  const periods = d.settings.periods;
  const existing = d.session;
  if (!d.roster.length) return emptyState('users', 'No students enrolled', 'Enrol students in this course to take attendance.', '');
  const opts = []; for (let i = 1; i <= periods; i++) opts.push('<option value="' + i + '"' + (i === T.period ? ' selected' : '') + '>' + periodLabel(i, d.settings) + '</option>');
  const prevA = new Set(d.prevAbsent || []);
  const rows = d.roster.map((u, i) => {
    const m = T.marks[u.id];
    return '<div class="att-row code-' + m + '" data-uid="' + esc(u.id) + '" data-search="' + esc((u.regNo + ' ' + u.name).toLowerCase()) + '">' +
      '<button type="button" class="att-main" data-act="attToggle" data-uid="' + esc(u.id) + '" aria-label="Toggle present/absent for ' + esc(u.name) + '">' +
      '<span class="att-no">' + (i + 1) + '</span>' + avatar(u.name, 'sm') + '<span class="att-who"><b>' + esc(u.name) + '</b><span>' + esc(u.regNo) + (prevA.has(u.id) ? ' · <em>absent last period</em>' : '') + (u.excused ? ' · <span class="badge ' + (u.excused === 'OD' ? 'info' : 'warning') + '" title="Approved by Class faculty, HOD and Vice Principal — an absence today counts as ' + u.excused + '">' + u.excused + ' approved</span>' : '') + '</span></span></button>' +
      '<div class="att-codes" role="radiogroup" aria-label="Status">' + Object.keys(ATT_SHORT).map((k) => '<button type="button" role="radio" aria-checked="' + (m === k) + '" class="att-code c-' + k + (m === k ? ' on' : '') + '" data-act="attSet" data-uid="' + esc(u.id) + '" data-code="' + k + '" title="' + esc(d.settings.codes[k].label) + '">' + k + '</button>').join('') + '</div></div>';
  }).join('');
  return '<div class="att-take">' +
    '<div class="card att-bar"><div class="att-bar-row">' +
    field('Date', '<input type="date" id="attDate" value="' + esc(T.date) + '" max="' + todayStr() + '" data-change="attWhen">') +
    field('Period', '<select id="attHour" data-change="attWhen">' + opts.join('') + '</select>') +
    field('Topic covered (optional)', '<input type="text" id="attTopic" maxlength="200" value="' + esc(existing ? existing.topic : '') + '" placeholder="e.g. Offer and acceptance">') + '</div>' +
    (existing ? notice('Editing the attendance already taken for this period (saved ' + esc(fmt(existing.at)) + '). Saving replaces it.', 'warn', 'edit') : '') +
    '<div class="att-quick"><div class="att-quick-l"><button class="btn btn-sm" data-act="attAll" data-code="P">' + icon('checkCircle') + 'All present</button><button class="btn btn-sm" data-act="attAll" data-code="A">' + icon('x') + 'All absent</button>' +
    '<input type="search" class="att-search" id="attSearch" placeholder="Find a student…" data-input="attFilter" data-delay="80"></div>' +
    '<form class="att-fast" data-form="attFast"><input type="text" name="nos" placeholder="Quick entry: absentees’ Reg. Nos or last digits, e.g. 12, 15, 21" aria-label="Absentees"><button class="btn btn-sm">Mark absent</button></form></div></div>' +
    '<div class="card att-list" id="attList">' + rows + '</div>' +
    '<div class="att-save"><div class="att-counts" id="attCounts"></div><button class="btn btn-primary btn-lg" data-act="attSave" id="attSaveBtn">' + icon('check') + (existing ? 'Update attendance' : 'Save attendance') + '</button></div></div>';
}
function takeMount() { attCounts(); }
function attCounts() {
  const T = ERP.take; if (!T) return;
  const n = { P: 0, A: 0 };
  Object.values(T.marks).forEach((m) => { n[m === 'A' ? 'A' : 'P']++; });
  const total = Object.keys(T.marks).length;
  const el = $('#attCounts');
  if (el) el.innerHTML = '<b>' + n.P + '</b> / ' + total + ' present <span class="muted">(' + (total ? Math.round(n.P / total * 100) : 0) + '%)</span>' +
    (n.A ? ' · <span class="att-c c-A">' + n.A + ' absent</span>' : '');
}
function attSetCode(uid, code) {
  ERP.take.marks[uid] = code;
  const row = $('.att-row[data-uid="' + uid + '"]'); if (!row) return;
  row.className = 'att-row code-' + code;
  $$('.att-code', row).forEach((b) => { const on = b.dataset.code === code; b.classList.toggle('on', on); b.setAttribute('aria-checked', on); });
  attCounts();
}
ACT.attToggle = (d) => attSetCode(d.uid, ERP.take.marks[d.uid] === 'P' ? 'A' : 'P');
ACT.attSet = (d) => attSetCode(d.uid, d.code);
ACT.attAll = (d) => Object.keys(ERP.take.marks).forEach((uid) => attSetCode(uid, d.code));
INPUTS.attFilter = (el) => { const q = el.value.trim().toLowerCase(); $$('.att-row').forEach((r) => r.classList.toggle('hidden', !!q && r.dataset.search.indexOf(q) < 0)); };
FORMS.attFast = (f) => {
  const parts = f.nos.value.split(/[\s,;]+/).map((x) => x.trim().toLowerCase()).filter(Boolean);
  if (!parts.length) return;
  const roster = ERP.take.data.roster;
  const missing = [];
  parts.forEach((p) => {
    // "22BCS015", or just "15": the number at the end of the register number.
    const hits = roster.filter((u) => { const r = u.regNo.toLowerCase(); const tail = r.match(/(\d+)$/); return r === p || (/^\d+$/.test(p) && tail && Number(tail[1]) === Number(p)); });
    if (hits.length === 1) attSetCode(hits[0].id, 'A');
    else missing.push(p + (hits.length > 1 ? ' (matches ' + hits.length + ')' : ''));
  });
  f.nos.value = '';
  if (missing.length) toast('Not matched: ' + missing.join(', '), 'err'); else toast(plural(parts.length, 'student') + ' marked absent.');
};
ACT.attWhen = () => {
  const date = $('#attDate').value || todayStr();
  go('/attendance/c/' + ERP.take.courseId + '?date=' + date + '&h=' + $('#attHour').value);
};
ACT.attSave = (d, btn) => busy(btn, async () => {
  const T = ERP.take;
  const r = await call('attSave', { courseId: T.courseId, date: T.date, period: T.period, topic: $('#attTopic').value, marks: T.marks });
  toast('Saved: ' + r.present + '/' + r.total + ' present' + (r.alerted ? ' · ' + plural(r.alerted, 'alert') + ' sent to parents' : '') + '.');
  // Move on to the next hour.
  const next = Math.min(T.period + 1, T.data.settings.periods);
  go('/attendance/c/' + T.courseId + '?date=' + T.date + '&h=' + (next === T.period ? T.period : next));
});

function registerHtml(c) {
  const t = c.settings.threshold;
  const grid = c.grid;
  const rng = c.range || {};
  const rows = c.roster.map((u, i) => '<tr class="' + (u.below ? 'is-short' : '') + '" data-short="' + (u.below ? 1 : 0) + '"><td class="num">' + (i + 1) + '</td><td class="nowrap">' + esc(u.regNo) + '</td><td class="nowrap"><b>' + esc(u.name) + '</b></td>' +
    grid.map((g) => { const m = attPA(g.marks[u.id]); return '<td class="att-cell">' + (m ? '<span class="att-c c-' + m + '">' + m + '</span>' : '<span class="faint">·</span>') + '</td>'; }).join('') +
    '<td class="num">' + u.held + '</td><td class="num">' + u.attended + '</td><td class="num"><span class="erp-pct ' + pctTone(u.pct, t) + '">' + (u.pct == null ? '—' : u.pct + '%') + '</span></td>' +
    '<td class="small">' + (u.pct == null ? '' : u.below ? '<span class="erp-bad">Needs ' + plural(u.need, 'class', 'classes') + '</span>' : '<span class="muted">Can miss ' + u.canMiss + '</span>') + '</td></tr>').join('');
  return '<div class="card"><div class="card-head erp-reg-head"><form class="row-wrap" data-form="attRange">' +
    '<label class="small muted">From</label><input type="date" name="from" value="' + esc(rng.from || '') + '" style="width:auto"><label class="small muted">to</label><input type="date" name="to" value="' + esc(rng.to || '') + '" style="width:auto">' +
    '<button class="btn btn-sm">Apply</button>' + (rng.from || rng.to ? '<a class="btn btn-sm btn-ghost" href="#/attendance/c/' + esc(c.course.id) + '?tab=register">Clear</a>' : '') + '</form><span class="spacer"></span>' +
    '<label class="check small" style="margin:0"><input type="checkbox" data-change="attShortOnly"><span>Only below ' + t + '%</span></label>' +
    '<button class="btn btn-sm btn-primary" data-act="attDl" data-kind="register" data-course="' + esc(c.course.id) + '" data-from="' + esc(rng.from || '') + '" data-to="' + esc(rng.to || '') + '">' + icon('download') + 'Register (.xlsx)</button></div>' +
    (grid.length < c.summary.sessions ? '<p class="small muted" style="padding:0 var(--sp-6)">Showing the last ' + grid.length + ' of ' + c.summary.sessions + ' sessions; the downloaded register has all of them.</p>' : '') +
    '<div class="table-wrap erp-reg"><table class="table"><thead><tr><th>#</th><th>Reg. No.</th><th>Name</th>' + grid.map((g) => '<th class="att-cell" title="' + esc(niceD(g.date)) + ' · period ' + g.period + '">' + esc(shortD(g.date)) + '<br><span class="faint">P' + g.period + '</span></th>').join('') +
    '<th class="num">Held</th><th class="num">Att.</th><th class="num">%</th><th></th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
    '<div class="card-foot small muted">P present · A absent · OD / ML approved On Duty / Medical Leave · P1–P' + c.settings.periods + ' = period of the day (' + c.settings.periodMinutes + ' min each). Threshold ' + t + '%.</div></div>';
}
function registerMount() {}
ACT.attShortOnly = (d, el) => $$('.erp-reg tbody tr').forEach((r) => r.classList.toggle('hidden', el.checked && r.dataset.short !== '1'));
FORMS.attRange = (f) => { go('/attendance/c/' + ERP.att.course.id + '?tab=register' + (f.from.value ? '&from=' + f.from.value : '') + (f.to.value ? '&to=' + f.to.value : '')); };

function sessionsHtml(c) {
  if (!c.sessions.length) return emptyState('calendar', 'No attendance taken yet', 'Sessions appear here once you save attendance.', '<a class="btn btn-primary" href="#/attendance/c/' + esc(c.course.id) + '">Take attendance</a>');
  return '<div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>Date</th><th>Period</th><th>Topic</th><th class="num">Present</th><th class="num">Absent</th><th>Taken by</th><th class="actions"></th></tr></thead><tbody>' +
    c.sessions.map((x) => '<tr><td class="nowrap">' + esc(niceD(x.date)) + '</td><td>P' + x.period + '</td><td>' + esc(x.topic || '—') + '</td><td class="num">' + x.present + ' / ' + x.total + '</td><td class="num">' + (x.absent ? '<span class="erp-bad">' + x.absent + '</span>' : '0') + '</td><td class="small muted">' + esc(x.takenBy) + '</td>' +
      '<td class="actions"><a class="btn btn-sm" href="#/attendance/c/' + esc(c.course.id) + '?date=' + esc(x.date) + '&h=' + x.period + '">' + icon('edit') + 'Edit</a>' +
      '<button class="btn-icon sm danger" data-act="attDel" data-id="' + esc(x.id) + '" data-label="' + esc(niceD(x.date) + ', period ' + x.period) + '" aria-label="Delete">' + icon('trash') + '</button></td></tr>').join('') + '</tbody></table></div></div>';
}
ACT.attDel = async (d) => {
  if (!(await confirmBox('Delete this session?', 'Attendance for ' + esc(d.label) + ' will be removed from every student’s record.', 'Delete', true))) return;
  await busy(null, async () => { await call('attDelete', { courseId: ERP.att.course.id, id: d.id }); toast('Session deleted.'); refresh(); });
};
ACT.attPrintCourse = () => {
  const c = ERP.att; const t = c.settings.threshold;
  erpPrint(c.course.shortname + ' — attendance reports', c.roster.map((u) => printHead('Attendance report', esc(c.course.shortname + ' — ' + c.course.fullname)) +
    '<table class="erp-pt-info"><tr><th>Name</th><td>' + esc(u.name) + '</td><th>Reg. No.</th><td>' + esc(u.regNo) + '</td></tr><tr><th>Class</th><td>' + esc(u.batch || '—') + '</td><th>Date</th><td>' + esc(niceD(todayStr())) + '</td></tr></table>' +
    '<table class="erp-pt"><thead><tr><th>Periods held</th><th>Present</th><th>Absent</th><th>Attendance</th></tr></thead><tbody><tr><td>' + u.held + '</td><td>' + u.attended + '</td><td>' + u.A + '</td><td><b>' + (u.pct == null ? '—' : u.pct + '%') + '</b></td></tr></tbody></table>' +
    '<p class="erp-pt-note">' + (u.pct == null ? 'No attendance recorded yet.' : u.below ? 'Attendance is below the required ' + t + '%. The student must attend the next ' + plural(u.need, 'period') + ' without absence to reach it.' : 'Attendance meets the required ' + t + '%.') + '</p>' +
    signLines(['Course teacher', 'Head of the department', 'Parent / guardian'])));
};

/* ---------- reports hub ---------- */
route(/^\/attendance\/reports$/, async () => {
  if (!isStaffRole()) { go('/attendance'); return null; }
  const d = await call('attHome');
  ERP.home = d;
  const t = d.settings.threshold;
  const opts = '<option value="">All my courses</option>' + d.courses.map((c) => '<option value="' + esc(c.id) + '">' + esc(c.shortname + ' — ' + c.fullname) + '</option>').join('');
  const rep = (kind, ico, title, text, needsCourse) => '<div class="card erp-rep"><span class="i-tile tone-' + ({ register: 'blue', consolidated: 'violet', shortage: 'red', absentees: 'amber' }[kind]) + '">' + icon(ico) + '</span><div><h3>' + esc(title) + '</h3><p class="small muted">' + text + '</p></div>' +
    '<button class="btn btn-primary btn-sm" data-act="attRep" data-kind="' + kind + '"' + (needsCourse ? ' data-need="1"' : '') + '>' + icon('download') + 'Download .xlsx</button></div>';
  return {
    title: 'Attendance reports',
    html: pageHead('Attendance reports', { crumbs: [['Attendance', '/attendance'], ['Reports']], sub: 'Choose a course and period, then download. Every report opens in Excel with the shortages highlighted.' }) +
      '<div class="card card-pad erp-filters"><div class="form-grid-3">' + field('Course', '<select id="repCourse">' + opts + '</select>') +
      field('From', '<input type="date" id="repFrom">') + field('To', '<input type="date" id="repTo" value="' + todayStr() + '">') + '</div>' +
      '<div class="row-wrap"><span class="small muted">Quick range:</span>' + [['Today', todayStr(), todayStr()], ['Last 7 days', daysAgo(6), todayStr()], ['This month', monthStart(), todayStr()], ['Last 30 days', daysAgo(29), todayStr()], ['All dates', '', todayStr()]]
        .map(([l, f, to]) => '<button class="pill" data-act="repRange" data-from="' + f + '" data-to="' + to + '">' + l + '</button>').join('') + '</div></div>' +
      '<div class="erp-reps">' +
      rep('register', 'table', 'Attendance register', 'Day-by-day P/A grid for one course with held, attended, % and status, plus a summary and the list of sessions.', true) +
      rep('consolidated', 'layers', 'Consolidated attendance', 'Every student × every course: percentages side by side, overall %, and a course-wise sheet.') +
      rep('shortage', 'alert', 'Shortage list', 'Students below ' + t + '% in any course, with the number of periods each needs to recover.') +
      rep('absentees', 'userPlus', 'Absentees', 'Everyone absent in the chosen dates — date, period, course and student. Pick “Today” for the daily absentee list.') + '</div>' +
      (d.isAdmin ? '<div class="card card-pad" style="margin-top:var(--sp-6)"><h2 style="margin:0 0 var(--sp-4);font-size:var(--fs-body-lg)">Attendance settings</h2><form data-form="attSettings"><div class="form-grid-3">' +
        field('Minimum attendance (%)', '<input type="number" name="threshold" min="1" max="100" value="' + t + '">', 'Below this is a shortage') +
        field('Periods per day', '<input type="number" name="periods" min="1" max="12" value="' + d.settings.periods + '">') +
        field('Minutes per period', '<input type="number" name="periodMinutes" min="20" max="180" step="5" value="' + d.settings.periodMinutes + '">') + '</div>' +
        check('notifyParents', 'Tell parents when their child is marked absent (in-app, plus email/SMS when set up)', d.settings.notifyParents) +
        '<div class="form-actions" style="justify-content:flex-start"><button class="btn btn-primary">Save settings</button></div></form></div>' : '')
  };
});
ACT.repRange = (d) => { $('#repFrom').value = d.from; $('#repTo').value = d.to; };
ACT.attRep = (d, btn) => {
  const courseId = $('#repCourse').value;
  if (d.need && !courseId) { toast('Choose a course for the register.', 'err'); $('#repCourse').focus(); return; }
  erpDownload('attReport', { kind: d.kind, courseId, from: $('#repFrom').value, to: $('#repTo').value }, btn);
};
FORMS.attSettings = (f, btn) => busy(btn, async () => { await call('attSettings', { threshold: Number(f.threshold.value), periods: Number(f.periods.value), periodMinutes: Number(f.periodMinutes.value), notifyParents: f.notifyParents.checked }); toast('Attendance settings saved.'); refresh(); });

/* ---------- students & parents ---------- */
/** "67 h 50 min" from minutes. */
function hm(mins) { const h = Math.floor(mins / 60), m = mins % 60; return (h ? h + ' h' : '') + (h && m ? ' ' : '') + (m || !h ? m + ' min' : ''); }
const DAY_WORD = { present: 'Present all day', partial: 'Partly present', absent: 'Absent' };
function attDayCell(x) {
  const d = new Date(x.date + 'T00:00');
  const tip = d.toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' }) + ' — ' + DAY_WORD[x.status] + ' (' + x.attended + '/' + x.held + ' periods)' +
    (x.periods ? '\n' + x.periods.map((p) => 'P' + p.period + ' ' + p.course + ': ' + (p.code === 'OD' ? 'on duty (approved)' : p.code === 'ML' ? 'medical leave (approved)' : p.present ? 'present' : 'absent')).join('\n') : '');
  return '<span class="sd-day ' + x.status + (x.excused ? ' ex' : '') + '" title="' + esc(tip) + '"><b>' + d.getDate() + '</b><i>' + (x.excused ? esc(x.excused) : esc(d.toLocaleDateString(undefined, { weekday: 'narrow' }))) + '</i>' +
    '<span class="sd-dots">' + Array.from({ length: x.held }, (_, i) => '<em class="' + (i < x.attended ? 'on' : '') + '"></em>').join('') + '</span></span>';
}
async function attMineView() {
  const d = await call('attMine');
  const t = d.threshold;
  if (!d.students.length) return { title: 'Attendance', html: pageHead('Attendance') + emptyState('users', 'No linked students', 'Ask the college to link your child to your account.', '') };
  ERP.mine = d;
  const parent = S.me.role === 'parent';
  const one = (st) => {
    const D = st.days, first = firstName(st.name);
    const you = parent ? first : 'You';
    const tone = st.overall == null ? 'none' : st.below ? 'bad' : st.overall < t + 5 ? 'warn' : 'ok';
    const advice = st.overall == null ? 'No attendance has been recorded yet.'
      : st.below ? icon('alert', 'i-sm') + ' Below the required ' + t + '%. ' + you + (parent ? ' needs' : ' need') + ' to attend the next <b>' + plural(st.need, 'period') + '</b> without a break to recover.'
        : icon('checkCircle', 'i-sm') + ' On track. ' + (st.canMiss ? you + ' could miss ' + plural(st.canMiss, 'period') + ' and still stay above ' + t + '%.' : 'Don’t miss the next period — ' + (parent ? 'the margin' : 'your margin') + ' is thin.');
    const tile = (v, l, sub, cls) => '<div class="sd-tile ' + (cls || '') + '"><b>' + v + '</b><span>' + l + '</span>' + (sub ? '<em>' + sub + '</em>' : '') + '</div>';
    const since = D.first ? 'since ' + niceD(D.first) : 'none yet';
    const hero = '<div class="card sd-hero tone-' + tone + '"><div class="sd-ring">' + (st.overall == null ? '<span class="erp-noring">—</span>' : ring(st.overall, 132)) +
      '<div class="sd-ring-l">' + (st.overall == null ? 'No classes yet' : st.below ? 'Shortage' : 'On track') + '</div></div>' +
      '<div class="sd-hero-body"><div class="sd-eyebrow">Attendance · minimum ' + t + '%</div><h2>' + (st.overall == null ? 'No classes yet' : st.overall + '% attendance') + '</h2>' +
      '<div class="sd-advice ' + tone + '">' + advice + '</div>' +
      '<div class="sd-tiles">' + tile(D.workingDays, 'Working days', since, 'main') + tile(D.presentDays, 'Days present', 'all ' + d.periods + ' periods', 'ok') +
      tile(D.partialDays, 'Partly present', 'missed some periods', D.partialDays ? 'warn' : '') + tile(D.absentDays, 'Days absent', 'missed every period', D.absentDays ? 'bad' : '') +
      tile(st.attended + '<small>/' + st.held + '</small>', 'Periods attended', (st.absent ? st.absent + ' missed' : 'none missed') + (st.od || st.ml ? ' · incl. ' + [st.od ? st.od + ' OD' : '', st.ml ? st.ml + ' ML' : ''].filter(Boolean).join(', ') : '')) +
      tile(hm(st.minutesAttended), 'Class time attended', 'of ' + hm(st.minutesHeld) + ' · ' + d.periodMinutes + ' min a period') + '</div></div>' +
      '<button class="btn btn-sm sd-print" data-act="attMinePrint" data-id="' + esc(st.id) + '">' + icon('printer') + 'Print</button></div>';
    const cal = D.recent.length ? '<div class="card"><div class="card-head"><span class="i-tile sm tone-green">' + icon('calendar') + '</span><div><h2>Day by day</h2><div class="xs muted">Last ' + plural(D.recent.length, 'working day') + ' · each dot is one of the ' + d.periods + ' periods</div></div><span class="spacer"></span>' +
      (D.streak ? '<span class="badge success">' + icon('zap', 'i-sm') + plural(D.streak, 'full day') + ' in a row</span>' : '') + '</div><div class="card-body">' +
      '<div class="sd-cal">' + D.recent.map(attDayCell).join('') + '</div>' +
      '<div class="sd-legend"><span><i class="present"></i>Present all day</span><span><i class="partial"></i>Partly present</span><span><i class="absent"></i>Absent</span></div></div></div>' : '';
    const months = D.months.length ? '<div class="card"><div class="card-head"><span class="i-tile sm tone-blue">' + icon('chart') + '</span><div><h2>Month by month</h2><div class="xs muted">Working days and attendance each month</div></div></div><div class="card-body"><div class="sd-months">' +
      D.months.map((m) => { const p = m.held ? Math.round(m.attended / m.held * 1000) / 10 : 0; return '<div class="sd-month"><div class="sd-m-h"><b>' + esc(new Date(m.month + '-01T00:00').toLocaleDateString(undefined, { month: 'long', year: 'numeric' })) + '</b><span class="erp-pct ' + pctTone(p, t) + '">' + p + '%</span></div>' +
        '<div class="sd-m-bar"><i class="present" style="flex:' + m.present + '"></i><i class="partial" style="flex:' + m.partial + '"></i><i class="absent" style="flex:' + m.absent + '"></i></div>' +
        '<div class="xs muted">' + plural(m.days, 'working day') + ' · ' + m.present + ' present' + (m.partial ? ' · ' + m.partial + ' partly' : '') + (m.absent ? ' · ' + m.absent + ' absent' : '') + ' · ' + m.attended + '/' + m.held + ' periods</div></div>'; }).join('') + '</div></div></div>' : '';
    const courses = st.courses.length ? '<h3 class="sd-h3">By course</h3><div class="erp-grid">' + st.courses.map((c) => '<div class="card erp-mine' + (c.below ? ' is-short' : '') + '"><div class="erp-course-top"><span class="erp-dot cc-' + esc(c.color) + '"></span><div style="flex:1;min-width:0"><b>' + esc(c.shortname) + '</b><div class="small muted erp-ell">' + esc(c.fullname) + '</div></div>' + (c.pct == null ? '<span class="erp-noring">—</span>' : ring(c.pct, 56)) + '</div>' +
      '<div class="erp-course-meta"><span>' + c.attended + ' / ' + c.held + ' periods attended</span>' + (c.A ? '<span class="erp-bad">' + c.A + ' absent</span>' : '') + '</div>' +
      '<div class="erp-advice ' + (c.pct == null ? 'none' : c.below ? 'bad' : 'ok') + '">' + (c.pct == null ? 'No classes recorded yet.' : c.below ? icon('alert', 'i-sm') + 'Below ' + t + '%. Attend the next <b>' + plural(c.need, 'period') + '</b> to recover.' : icon('checkCircle', 'i-sm') + (c.canMiss ? 'On track — ' + plural(c.canMiss, 'period') + ' to spare above ' + t + '%.' : 'On track, but don’t miss the next class.')) + '</div>' +
      (c.absences.length ? '<details class="erp-abs"><summary>Recent absences (' + c.absences.length + ')</summary><ul>' + c.absences.map((x) => '<li><span class="att-c c-' + esc(x.code) + '">' + esc(x.code) + '</span>' + esc(niceD(x.date)) + ' · period ' + x.period + (x.topic ? ' · <span class="muted">' + esc(x.topic) + '</span>' : '') + '</li>').join('') + '</ul></details>' : '') +
      '</div>').join('') + '</div>' : emptyState('calendar', 'No courses', '', '');
    return (d.students.length > 1 || parent ? '<h2 class="erp-child">' + avatar(st.name) + '<span>' + esc(st.name) + '<span class="small muted"> · ' + esc(st.regNo) + (st.batch ? ' · ' + esc(st.batch) : '') + '</span></span></h2>' : '') +
      '<div class="sd">' + hero + '<div class="sd-split">' + cal + months + '</div>' + courses + '</div>';
  };
  return { title: 'Attendance', html: pageHead(parent ? 'Attendance' : 'My attendance', { actions: parent ? '' : '<a class="btn" href="#/attendance/requests">' + icon('send') + 'Apply for OD / ML</a>', sub: d.periods + ' periods of ' + d.periodMinutes + ' minutes a day. Attendance counts towards eligibility for examinations — the minimum is ' + t + '%.' }) + d.students.map(one).join('<div style="height:var(--sp-8)"></div>') };
}
ACT.attMinePrint = (d) => {
  const st = ERP.mine.students.find((x) => x.id === d.id); if (!st) return;
  const t = ERP.mine.threshold, D = st.days;
  erpPrint('Attendance report — ' + st.name, [printHead('Attendance report', esc(st.name) + ' · ' + esc(st.regNo) + (st.batch ? ' · ' + esc(st.batch) : '') + ' · as on ' + esc(niceD(todayStr()))) +
    '<table class="erp-pt"><thead><tr><th>Working days</th><th>Days present</th><th>Partly present</th><th>Days absent</th><th>Periods attended</th><th>Attendance</th></tr></thead><tbody><tr><td>' + D.workingDays + '</td><td>' + D.presentDays + '</td><td>' + D.partialDays + '</td><td>' + D.absentDays + '</td><td>' + st.attended + ' / ' + st.held + '</td><td><b>' + (st.overall == null ? '—' : st.overall + '%') + '</b></td></tr></tbody></table>' +
    '<table class="erp-pt"><thead><tr><th>Course</th><th>Periods held</th><th>Present</th><th>Absent</th><th>%</th><th>Status</th></tr></thead><tbody>' +
    st.courses.map((c) => '<tr><td><b>' + esc(c.shortname) + '</b> ' + esc(c.fullname) + '</td><td>' + c.held + '</td><td>' + c.attended + '</td><td>' + c.A + '</td><td><b>' + (c.pct == null ? '—' : c.pct + '%') + '</b></td><td>' + (c.pct == null ? '' : c.below ? 'Shortage' : 'OK') + '</td></tr>').join('') +
    '</tbody><tfoot><tr><td><b>Overall</b></td><td>' + st.held + '</td><td>' + st.attended + '</td><td>' + st.absent + '</td><td><b>' + (st.overall == null ? '—' : st.overall + '%') + '</b></td><td>' + (st.overall == null ? '' : st.below ? 'Shortage' : 'OK') + '</td></tr></tfoot></table>' +
    '<p class="erp-pt-note">' + ERP.mine.periods + ' periods of ' + ERP.mine.periodMinutes + ' minutes a day. A working day is a day on which classes were held. Minimum attendance required: ' + t + '%.</p>' + signLines(['Class teacher', 'Head of the department'])]);
};

/* =====================================================================
   MARK ENTRY — "INTERNAL MARK ENTRY - LOCF Based"
   Laid out like the college ERP screen: exam date and test component,
   the subject table (click a row), then the student grid with one box per
   part (K1&K2 / K3&K4 / K5&K6) and an Absent tick. The report reproduces
   the Continuous Assessment Mark Statement.
   ===================================================================== */
const LC = { home: null, sheet: null, dirty: {}, timer: null, saving: false };
const f1 = (v) => (v === null || v === undefined || v === '' ? '' : v === 'A' ? 'A' : Number(v).toFixed(1));
const f2 = (n) => Number(n).toFixed(2);

route(/^\/marks$/, async (params) => {
  if (!isStaffRole()) return marksMineView();
  const home = await call('mkHome');
  LC.home = home;
  const L = home.scheme;
  const comp = L.components.find((c) => c.code === params.get('comp')) || L.components[0];
  const courseId = params.get('c') && home.courses.some((c) => c.id === params.get('c')) ? params.get('c') : (home.courses[0] && home.courses[0].id);
  LC.sheet = courseId ? await call('mkSheet', { courseId, comp: comp.code }) : null;
  LC.dirty = {};
  return { title: 'Internal mark entry', html: lcPageHtml(comp), after: lcMount };
});

function lcSubjectRows(comp) {
  const sel = LC.sheet && LC.sheet.course.id;
  return LC.home.courses.map((c) => {
    const cs = c.comps[comp.code] || { entered: 0, status: 'draft' };
    const pctDone = c.students ? Math.round(cs.entered / c.students * 100) : 0;
    return '<button type="button" class="lc-subj-card' + (c.id === sel ? ' sel' : '') + (cs.status === 'submitted' ? ' done' : '') + '" data-act="lcPick" data-id="' + esc(c.id) + '" data-total="' + c.students + '" style="--p:' + pctDone + '" aria-pressed="' + (c.id === sel) + '">' +
      '<span class="lc-ring" aria-label="' + cs.entered + ' of ' + c.students + ' students entered"><b data-entered="' + esc(c.id) + '">' + cs.entered + '</b><small>/' + c.students + '</small></span>' +
      '<span class="lc-subj-body"><span class="lc-code">' + esc(c.meta.code) + (cs.status === 'submitted' ? '<span class="lc-pill ok">' + icon('lock', 'i-sm') + 'Submitted</span>' : cs.entered ? '<span class="lc-pill">Draft</span>' : '') + '</span>' +
      '<span class="lc-name">' + esc(c.meta.name.toUpperCase()) + '</span>' +
      '<span class="lc-prog">' + esc(c.meta.programme || 'Program & section not set') + ' · ' + esc(c.meta.kind) + ' – Internal</span></span>' +
      '<span class="lc-maxes" title="Conducting → converting maximum marks"><span><b>' + numS(comp.conduct) + '</b><small>Conducting</small></span><i>' + icon('arrowRight', 'i-sm') + '</i><span><b>' + numS(comp.convert) + '</b><small>Converting</small></span></span></button>';
  }).join('');
}
function lcPageHtml(comp) {
  const L = LC.home.scheme, sh = LC.sheet;
  const locked = sh && sh.entry.status === 'submitted';
  const hero = '<section class="lc-hero"><div class="lc-hero-text"><span class="lc-eyebrow">' + icon('sparkle', 'i-sm') + esc(L.title) + '</span>' +
    '<h1>Mark Entry</h1><p>Continuous assessment · <b>' + esc(L.session) + '</b></p></div><div class="lc-hero-actions">' +
    (LC.home.isAdmin ? '<button class="lc-glass-btn" data-act="lcScheme">' + icon('settings', 'i-sm') + 'LOCF scheme</button>' : '') +
    '<button class="lc-glass-btn" data-act="lcConsolidated">' + icon('download', 'i-sm') + 'Consolidated</button></div></section>';
  if (!LC.home.courses.length) return '<div class="lc">' + hero + '<div class="lc-empty">' + icon('book') + '<b>No courses to enter marks for</b><span>Courses you teach appear here.</span></div></div>';
  return '<div class="lc">' + hero +
    '<section class="lc-controls lc-card">' +
    '<div class="lc-field"><label class="lc-label" for="lcDate">Exam Date<sup>*</sup></label><input type="date" id="lcDate" class="lc-date" value="' + esc(sh ? sh.entry.date : todayStr()) + '"' + (locked ? ' disabled' : '') + ' data-change="lcDateChange"></div>' +
    '<div class="lc-field grow"><span class="lc-label" id="lcCompLbl">Test Component<sup>*</sup></span>' +
    '<div class="lc-seg" role="radiogroup" aria-labelledby="lcCompLbl">' + L.components.map((c) => '<button type="button" role="radio" aria-checked="' + (c.code === comp.code) + '" class="' + (c.code === comp.code ? 'on' : '') + '" data-act="lcSeg" data-code="' + esc(c.code) + '"><b>' + esc(c.code) + '</b><small>' + numS(c.conduct) + ' → ' + numS(c.convert) + '</small></button>').join('') + '</div>' +
    '<input type="hidden" id="lcComp" value="' + esc(comp.code) + '"></div></section>' +
    '<div class="lc-sec-h"><span>Subjects</span><small>' + plural(LC.home.courses.length, 'course') + ' · tap one to enter marks</small></div>' +
    '<div class="lc-subjects" id="lcSubjects">' + lcSubjectRows(comp) + '</div>' +
    '<div id="lcSheet">' + lcSheetHtml() + '</div></div>';
}
function lcSheetHtml() {
  const sh = LC.sheet;
  if (!sh) return '<div class="lc-empty">' + icon('edit') + '<b>Select a subject</b><span>Choose a subject above to enter marks.</span></div>';
  const comp = sh.comp, locked = sh.entry.status === 'submitted';
  if (!sh.roster.length) return '<div class="lc-empty">' + icon('users') + '<b>No students enrolled</b><span>Enrol students in ' + esc(sh.course.meta.code) + ' to enter marks.</span></div>';
  const rows = sh.roster.map((u, i) => {
    const m = sh.entry.marks[u.id] || null;
    const ab = !!(m && m.ab);
    return '<tr data-uid="' + esc(u.id) + '" class="' + (ab ? 'is-ab' : '') + '"><td class="lc-no">' + (i + 1) + '</td>' +
      '<td class="lc-who"><span class="lc-av" style="--h:' + hue(u.name) + '">' + esc(initials(u.name)) + '</span><span><b>' + esc(u.name.toUpperCase()) + '</b><small>' + esc(u.regNo) + '</small></span></td>' +
      '<td class="lc-tc"><span class="lc-tag">' + esc(comp.code) + '</span></td><td class="lc-reg">' + esc(u.regNo) + '</td>' +
      comp.parts.map((p, k) => '<td class="lc-mk"><label class="lc-cap"><input class="lc-in" type="text" inputmode="decimal" autocomplete="off" data-uid="' + esc(u.id) + '" data-k="' + k + '" data-max="' + p.max + '" value="' + esc(m && !ab && m.p[k] != null ? m.p[k] : '') + '"' + (locked || ab ? ' disabled' : '') + ' aria-label="' + esc(p.label + ' — ' + u.name) + '"><span>/ ' + f2(p.max) + '</span></label></td>').join('') +
      '<td class="lc-ab"><label class="lc-switch" title="Absent"><input type="checkbox" class="lc-abx" data-uid="' + esc(u.id) + '"' + (ab ? ' checked' : '') + (locked ? ' disabled' : '') + ' aria-label="Absent — ' + esc(u.name) + '"><i></i></label></td>' +
      '<td class="lc-sum" data-sum="' + esc(u.id) + '">' + lcRowSums(comp, m) + '</td></tr>';
  }).join('');
  const entered = sh.roster.filter((u) => lcHas(sh.entry.marks[u.id])).length;
  const btn = (act, ico, label, cls) => '<button class="lc-tb' + (cls ? ' ' + cls : '') + '" data-act="' + act + '">' + icon(ico, 'i-sm') + '<span>' + label + '</span></button>';
  return '<section class="lc-sheet lc-card">' +
    '<header class="lc-sheet-h"><div><h2>' + esc(sh.course.meta.code) + ' <span>·</span> ' + esc(comp.code) + '</h2><p>' + comp.parts.map((p) => esc(p.label) + ' ' + numS(p.max)).join(' · ') + ' — conducted for ' + numS(comp.conduct) + ', converted to ' + numS(comp.convert) + '</p></div>' +
    '<span class="lc-state ' + (locked ? 'ok' : '') + '">' + (locked ? icon('lock', 'i-sm') + 'Submitted' : icon('edit', 'i-sm') + 'Draft') + '</span></header>' +
    '<div class="lc-list"><table class="lc-stu" id="lcGrid"><thead><tr><th class="lc-no">SL.No.</th><th class="lc-who">Student Name</th><th class="lc-tc">Test Component</th><th class="lc-reg">Register No.</th>' +
    comp.parts.map((p) => '<th class="lc-mk">' + esc(p.label) + '</th>').join('') + '<th class="lc-ab">Absent</th><th class="lc-sum">Total ' + numS(comp.conduct) + ' → ' + numS(comp.convert) + '</th></tr></thead><tbody>' + rows + '</tbody></table></div></section>' +
    '<div class="lc-dock"><div class="lc-status" id="lcStatus">' + lcStatusText(entered) + '</div><div class="lc-btns">' +
    (locked ? (sh.isAdmin ? btn('lcUnlock', 'key', 'Unlock') : '')
      : '<div class="lc-group">' + btn('lcImportOpen', 'upload', 'Import') + btn('lcTemplate', 'file', 'Template') + btn('lcClear', 'eraser', 'Clear') + '</div>' +
        '<div class="lc-group">' + btn('lcSave', 'check', 'Save', 'primary') + btn('lcSubmit', 'send', 'Submit', 'go') + '</div>') +
    '<div class="lc-group">' + btn('lcMeta', 'edit', 'Course details') + btn('lcReport', 'printer', 'Mark Statement') + btn('lcExcel', 'download', 'Excel') + '</div></div></div>';
}
function lcHas(m) { return !!m && (m.ab || (m.p || []).some((v) => v !== null && v !== undefined && v !== '')); }
function lcRowSums(comp, m) {
  if (!lcHas(m)) return '<span class="faint">—</span>';
  if (m.ab) return '<b class="lc-a">A</b>';
  const t = (m.p || []).reduce((n, v) => n + (Number(v) || 0), 0);
  const partial = (m.p || []).some((v) => v === null || v === undefined || v === '');
  return '<b>' + numS(Math.round(t * 100) / 100) + '</b> → ' + f1(Math.round(t / comp.conduct * comp.convert * 100) / 100) + (partial ? ' <span class="lc-warn" title="Some parts are empty">!</span>' : '');
}
function lcStatusText(entered) {
  const sh = LC.sheet;
  const total = sh.roster.length;
  if (sh.entry.status === 'submitted') return icon('lock', 'i-sm') + ' <b>Submitted</b>' + (sh.entry.submittedAt ? ' on ' + esc(fmt(sh.entry.submittedAt)) : '') + ' — locked and visible to students. ' + entered + ' / ' + total + ' entered.';
  return '<span id="lcSaveState">' + (Object.keys(LC.dirty).length ? 'Unsaved changes' : 'Draft') + '</span> · ' + entered + ' / ' + total + ' students entered';
}
function lcMount() {
  const grid = $('#lcGrid'); if (!grid) return;
  grid.addEventListener('input', (e) => { if (e.target.matches('.lc-in')) lcEdit(e.target); });
  grid.addEventListener('change', (e) => { if (e.target.matches('.lc-abx')) lcAbsent(e.target); });
  grid.addEventListener('keydown', lcKey);
  grid.addEventListener('paste', lcPaste);
  grid.addEventListener('focusin', (e) => { if (e.target.matches('.lc-in')) e.target.select(); });
  const onUnload = (e) => { if (Object.keys(LC.dirty).length || LC.saving) { e.preventDefault(); e.returnValue = ''; } };
  window.addEventListener('beforeunload', onUnload);
  S.onLeave = () => { window.removeEventListener('beforeunload', onUnload); if (Object.keys(LC.dirty).length) lcFlush(); };
}
function lcValid(el) {
  const t = el.value.trim();
  const ok = !t || (/^\d+(\.\d{1,2})?$/.test(t) && Number(t) <= Number(el.dataset.max));
  el.classList.toggle('bad', !ok);
  el.title = ok ? '' : /^\d/.test(t) ? 'More than ' + el.dataset.max : 'Enter a number';
  return ok;
}
function lcRowState(uid) {
  const tr = $('#lcGrid tr[data-uid="' + uid + '"]');
  const ab = $('.lc-abx', tr).checked;
  return ab ? { ab: true } : { p: $$('.lc-in', tr).map((i) => i.value.trim()) };
}
function lcRefreshRow(uid) {
  const st = lcRowState(uid);
  const m = st.ab ? { ab: true, p: [] } : { p: st.p.map((v) => (v === '' ? null : Number(v))) };
  const cell = $('[data-sum="' + uid + '"]'); if (cell) cell.innerHTML = lcRowSums(LC.sheet.comp, m);
}
function lcEdit(el) {
  const ok = lcValid(el);
  lcRefreshRow(el.dataset.uid);
  if (!ok) return;
  LC.dirty[el.dataset.uid] = true;
  lcDirtyState();
}
function lcAbsent(cb) {
  const tr = cb.closest('tr');
  $$('.lc-in', tr).forEach((i) => { i.disabled = cb.checked; if (cb.checked) { i.value = ''; i.classList.remove('bad'); } });
  tr.classList.toggle('is-ab', cb.checked);
  LC.dirty[cb.dataset.uid] = true;
  lcRefreshRow(cb.dataset.uid);
  lcDirtyState();
}
function lcDirtyState() {
  const s = $('#lcSaveState'); if (s) s.textContent = 'Unsaved changes…';
  clearTimeout(LC.timer);
  LC.timer = setTimeout(() => lcFlush(), 1800);
}
async function lcFlush(showToast) {
  clearTimeout(LC.timer);
  const sh = LC.sheet; if (!sh) return true;
  const uids = Object.keys(LC.dirty);
  const bad = $$('#lcGrid .lc-in.bad');
  const date = ($('#lcDate') || {}).value;
  if (!date) { toast('Enter the exam date.', 'err'); return false; }
  if (!uids.length && !LC.dateDirty) { if (showToast) toast(bad.length ? 'Fix the marks shown in red.' : 'All marks are saved.', bad.length ? 'err' : undefined); return !bad.length; }
  const marks = {};
  uids.forEach((uid) => { const tr = $('#lcGrid tr[data-uid="' + uid + '"]'); if (tr && !$$('.lc-in.bad', tr).length) marks[uid] = lcRowState(uid); });
  Object.keys(marks).forEach((uid) => delete LC.dirty[uid]);
  LC.saving = true;
  const s = $('#lcSaveState'); if (s) s.textContent = 'Saving…';
  try {
    const r = await call('mkSave', { courseId: sh.course.id, comp: sh.comp.code, date, marks });
    LC.dateDirty = false;
    Object.keys(marks).forEach((uid) => { const v = marks[uid]; sh.entry.marks[uid] = v.ab ? { ab: true, p: [] } : { ab: false, p: v.p.map((x) => (x === '' ? null : Number(x))) }; if (!lcHas(sh.entry.marks[uid])) delete sh.entry.marks[uid]; });
    r.errors.forEach((e) => { LC.dirty[e.uid] = true; toast(e.message, 'err'); });
    const st = $('#lcStatus'); if (st) st.innerHTML = lcStatusText(r.entered);
    const en = $('[data-entered="' + sh.course.id + '"]'); if (en) { en.textContent = r.entered; const card = en.closest('[data-total]'); if (card && r.total) card.style.setProperty('--p', Math.round(r.entered / r.total * 100)); }
    const s2 = $('#lcSaveState'); if (s2) s2.textContent = bad.length ? 'Saved (fix the marks in red)' : 'Saved ' + fmtTime(Date.now());
    if (showToast) toast(bad.length ? 'Saved, except the marks shown in red.' : 'Marks saved.', bad.length ? 'err' : undefined);
    return !bad.length && !r.errors.length;
  } catch (e) {
    uids.forEach((uid) => { LC.dirty[uid] = true; });
    const s3 = $('#lcSaveState'); if (s3) s3.textContent = 'Not saved';
    if (!isExpired(e)) toast(e.message, 'err');
    return false;
  } finally { LC.saving = false; }
}
function lcCell(el, dr, dc) {
  const tr = el.closest('tr');
  const rows = $$('#lcGrid tbody tr');
  const row = rows[rows.indexOf(tr) + dr]; if (!row) return null;
  const ins = $$('.lc-in', row);
  return ins[Number(el.dataset.k) + dc] || null;
}
function lcKey(e) {
  const el = e.target; if (!el.matches('.lc-in')) return;
  let next = null;
  if (e.key === 'Enter' || e.key === 'ArrowDown') next = lcCell(el, e.shiftKey && e.key === 'Enter' ? -1 : 1, 0);
  else if (e.key === 'ArrowUp') next = lcCell(el, -1, 0);
  else if (e.key === 'ArrowRight' && el.selectionStart === el.value.length) next = lcCell(el, 0, 1);
  else if (e.key === 'ArrowLeft' && el.selectionStart === 0) next = lcCell(el, 0, -1);
  else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); lcFlush(true); return; }
  else return;
  e.preventDefault();
  if (next) { if (next.disabled) { const again = lcCell(next, e.key === 'ArrowUp' || (e.shiftKey && e.key === 'Enter') ? -1 : 1, 0); if (again) again.focus(); } else next.focus(); }
}
function lcPaste(e) {
  const el = e.target; if (!el.matches('.lc-in')) return;
  const text = (e.clipboardData.getData('text/plain') || '').replace(/\r/g, '');
  if (!/[\n\t]/.test(text.trim())) return;
  e.preventDefault();
  let row = el, n = 0;
  text.replace(/\n$/, '').split('\n').forEach((line, li, all) => {
    if (!row) return;
    let cell = row;
    line.split('\t').forEach((v) => { if (!cell) return; if (!cell.disabled) { cell.value = v.trim(); lcEdit(cell); n++; } cell = lcCell(cell, 0, 1); });
    row = li < all.length - 1 ? lcCell(row, 1, 0) : null;
  });
  toast('Pasted ' + plural(n, 'mark') + '.');
}

ACT.lcPick = async (d) => {
  if (Object.keys(LC.dirty).length && !(await lcFlush())) return;
  go('/marks?c=' + d.id + '&comp=' + encodeURIComponent($('#lcComp').value));
};
ACT.lcComp = async (d, sel) => {
  if (Object.keys(LC.dirty).length && !(await lcFlush())) { sel.value = LC.sheet.comp.code; return; }
  go('/marks?' + (LC.sheet ? 'c=' + LC.sheet.course.id + '&' : '') + 'comp=' + encodeURIComponent(sel.value));
};
ACT.lcSeg = (d) => { if (LC.sheet && d.code === LC.sheet.comp.code) return; ACT.lcComp(d, { value: d.code }); };
ACT.lcDateChange = () => { LC.dateDirty = true; lcDirtyState(); };
ACT.lcSave = (d, btn) => busy(btn, () => lcFlush(true));
ACT.lcClear = async () => {
  if (!(await confirmBox('Clear all marks for ' + esc(LC.sheet.comp.code) + '?', 'Every mark and absent tick in this component for ' + esc(LC.sheet.course.meta.code) + ' is removed (you can undo only by entering them again).', 'Clear', true))) return;
  $$('#lcGrid tbody tr').forEach((tr) => { $$('.lc-in', tr).forEach((i) => { i.value = ''; i.disabled = false; i.classList.remove('bad'); }); $('.lc-abx', tr).checked = false; tr.classList.remove('is-ab'); LC.dirty[tr.dataset.uid] = true; lcRefreshRow(tr.dataset.uid); });
  lcFlush(true);
};
ACT.lcSubmit = async (d, btn) => {
  if (!(await lcFlush())) { toast('Fix the marks shown in red before submitting.', 'err'); return; }
  const sh = LC.sheet;
  if (!(await confirmBox('Submit ' + esc(sh.comp.code) + ' for ' + esc(sh.course.meta.code) + '?', 'Submitted marks are locked and shown to students and parents. Only an administrator can unlock them.', 'Submit'))) return;
  const doIt = (force) => call('mkSubmit', { courseId: sh.course.id, comp: sh.comp.code, force });
  await busy(btn, async () => {
    try { await doIt(false); } catch (e) {
      const m = /^PENDING:(\d+):(\d+)/.exec(e.message);
      if (!m) throw e;
      const msg = (Number(m[1]) ? plural(Number(m[1]), 'student') + ' have no marks and are not marked absent. ' : '') + (Number(m[2]) ? plural(Number(m[2]), 'student') + ' have some parts empty. ' : '') + 'Submit anyway?';
      if (!(await confirmBox('Some marks are missing', esc(msg), 'Submit anyway'))) return;
      await doIt(true);
    }
    toast(sh.comp.code + ' submitted.'); refresh();
  });
};
ACT.lcUnlock = async () => {
  if (!(await confirmBox('Unlock ' + esc(LC.sheet.comp.code) + '?', 'Teachers will be able to change these marks again.', 'Unlock'))) return;
  await busy(null, async () => { await call('mkUnlock', { courseId: LC.sheet.course.id, comp: LC.sheet.comp.code }); toast('Unlocked.'); refresh(); });
};
ACT.lcTemplate = (d, btn) => erpDownload('mkTemplate', { courseId: LC.sheet.course.id, comp: LC.sheet.comp.code }, btn);
ACT.lcExcel = async (d, btn) => { await lcFlush(); erpDownload('mkReport', { kind: 'statement', courseId: LC.sheet.course.id }, btn); };
ACT.lcConsolidated = (d, btn) => erpDownload('mkReport', { kind: 'consolidated' }, btn);
ACT.lcImportOpen = () => {
  formModal('Import ' + LC.sheet.comp.code + ' marks', 'Download the template, fill it in Excel and upload it here. You’ll see a preview first.', 'lcImportF',
    field('Excel file (.xlsx)', '<input type="file" name="file" accept=".xlsx" required>') + '<div id="lcImpPrev"></div>', 'Preview', 'wide');
  LC.impReady = false;
};
FORMS.lcImportF = (f, btn) => busy(btn, async () => {
  const file = f.file.files[0]; if (!file) { toast('Choose a file.', 'err'); return; }
  const payload = { courseId: LC.sheet.course.id, comp: LC.sheet.comp.code, name: file.name, data: await readFileB64(file) };
  if (LC.impReady && LC.impFile === file) {
    const r = await call('mkImport', Object.assign({ apply: true }, payload));
    closeModal(); toast('Imported ' + plural(r.imported, 'mark') + '.'); refresh(); return;
  }
  const r = await call('mkImport', payload);
  LC.impFile = file; LC.impReady = !r.errorCount && !r.locked;
  $('#lcImpPrev').innerHTML = (r.locked ? notice('This component is submitted and locked.', 'err') : '') +
    '<p class="small">' + plural(r.rows, 'student') + ' with marks in the file · <b>' + plural(r.changes, 'change') + '</b> to make.</p>' +
    (r.unknownCount ? notice(plural(r.unknownCount, 'Register No.', 'Register Nos') + ' not in this course (ignored): ' + esc(r.unknown.join(', ')), 'warn') : '') +
    (r.errorCount ? notice('<b>' + plural(r.errorCount, 'problem') + ' to fix:</b><br>' + r.errors.slice(0, 12).map((e) => 'Row ' + e.row + ' · ' + esc(e.regNo) + ': ' + esc(e.message)).join('<br>'), 'err') : (r.locked ? '' : notice('Ready. Click “Import” to save these marks.', 'ok')));
  const b = f.querySelector('button[type=submit]'); if (b) b.textContent = LC.impReady ? 'Import' : 'Preview again';
});
ACT.lcMeta = () => {
  const m = LC.sheet.course.meta;
  const inp = (n, l, v, ph) => field(l, '<input type="text" name="' + n + '" value="' + esc(v || '') + '" placeholder="' + esc(ph || '') + '">');
  formModal('Course details — ' + m.code, 'Printed on the mark statement.', 'lcMetaF',
    '<div class="form-grid">' + inp('teacher', 'Course teacher', m.teacher, 'Mr. / Dr. …') + inp('department', 'Department', m.department, 'Corporate Secretaryship') +
    inp('semester', 'Semester', m.semester, '5') + inp('credits', 'Credits', m.credits, '5') +
    field('Type', '<select name="kind">' + ['Theory', 'Practical', 'Theory cum Practical'].map((k) => '<option' + (k === m.kind ? ' selected' : '') + '>' + k + '</option>').join('') + '</select>') +
    inp('programme', 'Program & Section', m.programme, '24UBC - B.Com. Corporate Secretaryship 5th Semester-Shift II C') + '</div>', 'Save', 'wide');
};
FORMS.lcMetaF = (f, btn) => busy(btn, async () => {
  await call('mkMeta', { courseId: LC.sheet.course.id, teacher: f.teacher.value, department: f.department.value, semester: f.semester.value, credits: f.credits.value, kind: f.kind.value, programme: f.programme.value });
  closeModal(); toast('Course details saved.'); refresh();
});

/* ---------- the Continuous Assessment Mark Statement (print / PDF) ---------- */
ACT.lcReport = async (d, btn) => {
  await lcFlush();
  await busy(btn, async () => {
    const r = await call('mkStatement', { courseId: LC.sheet.course.id });
    const L = r.scheme, m = r.meta;
    // Laid out like the college ERP print: the heading box and column titles on the
    // first page only, 18 students on page 1 and 26 on each following page, and a
    // "Draft Printout" band with the two signature lines under every page's rows.
    const n = L.components.length;
    const compW = n ? Math.min(15.5, 62 / n) : 0;
    const cg = '<colgroup><col style="width:9mm"><col style="width:20mm"><col>' + L.components.map(() => '<col style="width:' + compW + 'mm">').join('') +
      '<col style="width:11.6mm"><col style="width:11mm"><col style="width:12.5mm"><col style="width:11.3mm"><col style="width:16.6mm"></colgroup>';
    const head = '<thead><tr><th>Sl.<br>No.</th><th>Dept. No.</th><th>Name of the Candidate</th>' +
      L.components.map((c) => '<th>' + esc(c.code).replace(/^COMP (\S+)$/, 'COMP<br>$1') + '<br>(' + numS(c.convert) + ')</th>').join('') +
      '<th>Total<br>(' + numS(L.totalMax) + ')</th><th>Final<br>(' + numS(L.finalMax) + ')</th><th>Att.<br>Marks</th><th>Total<br>Final<br>(' + numS(L.finalMax) + ')</th><th>Student\'s<br>Signature</th></tr></thead>';
    const row = (x) => '<tr><td>' + x.sno + '</td><td>' + esc(x.regNo) + '</td><td class="l">' + esc(x.name) + '</td>' +
      L.components.map((c) => '<td>' + f1(x.comps[c.code]) + '</td>').join('') +
      '<td>' + (x.total == null ? '' : x.total) + '</td><td>' + (x.final == null ? '' : x.final) + '</td><td>' + (x.total == null ? '' : x.att) + '</td><td>' + (x.totalFinal == null ? '' : x.totalFinal) + '</td><td></td></tr>';
    const foot = '<table class="lcr-end">' + (r.draft ? '<tr><td class="lcr-draft">Draft Printout</td></tr>' : '') +
      '<tr><td class="lcr-signbox"><span>Signature of the H.O.D. With Date</span><span>Signature of the Teacher With Date</span></td></tr></table>';
    const first = 18, next = 26;
    const chunks = [r.rows.slice(0, first)];
    for (let i = first; i < r.rows.length; i += next) chunks.push(r.rows.slice(i, i + next));
    const cols = n + 8;
    const pages = chunks.map((rows, pi) => '<div class="lcr' + (pi ? ' cont' : '') + '">' +
      (pi === 0 ? '<table class="lcr-top"><colgroup><col style="width:23%"><col><col style="width:12%"><col style="width:30%"></colgroup>' +
        '<tr><td colspan="4" class="lcr-session">' + esc(L.session) + '</td></tr>' +
        '<tr><th>Course Code</th><td>' + esc(m.code) + '</td><th>Semester</th><td>' + esc(m.semester) + '</td></tr>' +
        '<tr><th>Course Name</th><td>' + esc(m.name.toUpperCase()) + '</td><th>Credits</th><td>' + esc(m.credits) + '</td></tr>' +
        '<tr><th>Course Teacher</th><td>' + esc(m.teacher) + '</td><th>Department</th><td>' + esc(m.department) + '</td></tr></table>' : '') +
      '<table class="lcr-table">' + cg + (pi === 0 ? head : '') + '<tbody>' + (pi === 0 ? '<tr class="lcr-subj"><td colspan="' + cols + '">' + esc(m.code + '-' + m.name.toUpperCase()) + '</td></tr>' : '') +
      rows.map(row).join('') + '</tbody></table>' + foot + '</div>');
    erpPrint(m.code + ' — Continuous Assessment Mark Statement', pages.length ? pages : ['<p>No students.</p>']);
  });
};

/* ---------- LOCF scheme (administrators) ---------- */
ACT.lcScheme = () => busy(null, async () => {
  const r = await call('mkScheme');
  const L = r.scheme;
  const parts = (c) => c.parts.map((p) => p.label + ':' + numS(p.max)).join(', ');
  formModal('LOCF scheme', 'Components, their breakup, and how the final internal mark is worked out. Applies to every course.', 'lcSchemeF',
    '<div class="form-grid">' + field('Screen title', '<input type="text" name="title" value="' + esc(L.title) + '">') + field('Report title', '<input type="text" name="reportTitle" value="' + esc(L.reportTitle) + '">') +
    field('Examination session', '<input type="text" name="session" value="' + esc(r.sessionSet ? L.session : '') + '" placeholder="Automatic: ' + esc(L.session) + '">', 'Printed on the statement, e.g. NOVEMBER - 2026') +
    field('Final out of', '<input type="number" name="finalMax" min="1" value="' + L.finalMax + '">', 'Total (' + numS(L.totalMax) + ') is scaled to this') + '</div>' +
    '<label class="label">Components <span class="hint">Parts as “label:max, label:max” — e.g. K1&K2:10, K3&K4:20, K5&K6:20</span></label>' +
    '<div class="lc-scheme" id="lcSchemeRows">' + L.components.map((c, i) => lcSchemeRow(c.code, c.convert, parts(c), i)).join('') + '</div>' +
    '<button type="button" class="btn btn-sm" data-act="lcSchemeAdd">' + icon('plus') + 'Add component</button>' +
    '<div class="form-grid" style="margin-top:var(--sp-5)">' + field('Attendance marks (max)', '<input type="number" name="attMax" min="0" max="100" value="' + L.attMax + '">', '0 = none (the column shows 0)') +
    field('Attendance bands', '<input type="text" name="attBands" value="' + esc((L.attBands || []).map((b) => b[0] + '%:' + b[1]).join(', ')) + '">', 'e.g. 95%:5, 90%:4 — from the Attendance module') + '</div>' +
    check('notifyPublish', 'Tell students and parents when a component is submitted', r.notifyPublish) +
    '<button type="button" class="btn btn-sm btn-ghost" data-act="lcSchemeReset">Reset to the standard LOCF scheme</button>', 'Save scheme', 'xwide');
});
function lcSchemeRow(code, convert, parts, i) {
  return '<div class="lc-scheme-row" data-i="' + i + '"><input type="text" class="sc-code" value="' + esc(code) + '" placeholder="COMP.1" aria-label="Component">' +
    '<input type="text" class="sc-parts" value="' + esc(parts) + '" placeholder="K1&K2:10, K3&K4:20, K5&K6:20" aria-label="Parts">' +
    '<label class="small muted">→</label><input type="number" class="sc-conv" value="' + convert + '" min="1" aria-label="Converting max"><button type="button" class="btn-icon sm" data-act="lcSchemeDel" aria-label="Remove">' + icon('x') + '</button></div>';
}
ACT.lcSchemeAdd = () => { const box = $('#lcSchemeRows'); box.insertAdjacentHTML('beforeend', lcSchemeRow('', 20, 'Marks:20', box.children.length)); };
ACT.lcSchemeDel = (d, btn) => btn.closest('.lc-scheme-row').remove();
ACT.lcSchemeReset = async () => {
  if (!(await confirmBox('Reset the scheme?', 'COMP.1 and COMP.2 (K1&K2 10, K3&K4 20, K5&K6 20 → 30), COMP 3a and 3b (20 → 20), final out of 50, no attendance marks.', 'Reset'))) return;
  await busy(null, async () => { await call('mkSaveScheme', { reset: true }); closeModal(); toast('Scheme reset.'); refresh(); });
};
FORMS.lcSchemeF = (f, btn) => busy(btn, async () => {
  const components = $$('#lcSchemeRows .lc-scheme-row').map((row) => ({
    code: $('.sc-code', row).value.trim(), convert: Number($('.sc-conv', row).value),
    parts: $('.sc-parts', row).value.split(',').map((x) => x.trim()).filter(Boolean).map((x) => { const i = x.lastIndexOf(':'); return { label: (i > 0 ? x.slice(0, i) : 'Marks').trim(), max: Number(i > 0 ? x.slice(i + 1) : x) }; })
  })).filter((c) => c.code);
  const attBands = f.attBands.value.split(',').map((x) => x.trim()).filter(Boolean).map((x) => { const [a, b] = x.replace('%', '').split(':'); return [Number(a), Number(b)]; });
  await call('mkSaveScheme', { title: f.title.value, reportTitle: f.reportTitle.value, session: f.session.value, finalMax: Number(f.finalMax.value), attMax: Number(f.attMax.value), attBands, components, notifyPublish: f.notifyPublish.checked });
  closeModal(); toast('LOCF scheme saved.'); refresh();
});

/* ---------- students & parents ---------- */
async function marksMineView() {
  const d = await call('mkMine');
  ERP.mkMine = d;
  const L = d.scheme;
  if (!d.students.length) return { title: 'Marks', html: pageHead('Marks') + emptyState('users', 'No linked students', '', '') };
  const card = (c) => '<div class="card mk-mine"><div class="erp-course-top"><span class="erp-dot cc-' + esc(c.color) + '"></span><div style="flex:1;min-width:0"><b>' + esc(c.shortname) + '</b><div class="small muted erp-ell">' + esc(c.fullname) + '</div></div>' +
    (c.totalFinal != null ? '<div class="mk-final"><b>' + c.totalFinal + '</b><span>of ' + numS(L.finalMax) + (c.allPublished ? '' : ' so far') + '</span></div>' : '') + '</div>' +
    '<table class="mk-mine-t"><thead><tr><th>Component</th><th>Breakup</th><th class="num">Marks</th><th class="num">Converted</th></tr></thead><tbody>' +
    c.comps.map((x) => '<tr><td><b>' + esc(x.code) + '</b>' + (x.published && x.date ? '<div class="xs muted">' + esc(niceD(x.date)) + '</div>' : '') + '</td>' +
      (!x.published ? '<td colspan="3" class="muted small">Not published yet</td>'
        : x.converted === null ? '<td colspan="3" class="muted small">No mark entered</td>'
          : x.absent ? '<td class="small">Absent</td><td class="num"><b class="erp-bad">A</b></td><td class="num">0</td>'
            : '<td class="xs muted">' + x.parts.map((p) => esc(p.label) + ' ' + (p.v == null ? '—' : numS(p.v)) + '/' + numS(p.max)).join(' · ') + '</td><td class="num"><b>' + numS(x.conducted) + '</b><span class="muted"> / ' + numS(x.conduct) + '</span></td><td class="num"><b>' + f1(x.converted) + '</b><span class="muted"> / ' + numS(x.convert) + '</span></td>') + '</tr>').join('') +
    '</tbody></table>' +
    (c.total != null ? '<div class="mk-sofar">Total <b>' + c.total + '</b> / ' + numS(L.totalMax) + ' · Final <b>' + c.final + '</b> / ' + numS(L.finalMax) + (L.attMax ? ' · Attendance marks <b>' + c.att + '</b>' : '') + ' · <b>Total Final ' + c.totalFinal + ' / ' + numS(L.finalMax) + '</b>' + (c.allPublished ? '' : ' <span class="muted">(so far)</span>') + '</div>' : '') + '</div>';
  const one = (st) => (d.students.length > 1 || S.me.role === 'parent' ? '<h2 class="erp-child">' + avatar(st.name) + '<span>' + esc(st.name) + '<span class="small muted"> · ' + esc(st.regNo) + '</span></span>' +
    '<button class="btn btn-sm" data-act="mkMinePrint" data-id="' + esc(st.id) + '" style="margin-left:auto">' + icon('printer') + 'Print statement</button></h2>'
    : '<div class="row" style="justify-content:flex-end;margin-bottom:var(--sp-4)"><button class="btn btn-sm" data-act="mkMinePrint" data-id="' + esc(st.id) + '">' + icon('printer') + 'Print my statement</button></div>') +
    '<div class="erp-grid wide">' + st.courses.map(card).join('') + '</div>';
  return { title: 'Marks', html: pageHead(S.me.role === 'parent' ? 'Internal marks' : 'My internal marks', { sub: esc(L.session) + ' · marks appear once your teachers submit them.' }) + d.students.map(one).join('<div style="height:var(--sp-8)"></div>') };
}
ACT.mkMinePrint = (d) => {
  const st = ERP.mkMine.students.find((x) => x.id === d.id); if (!st) return;
  const L = ERP.mkMine.scheme;
  erpPrint('Internal marks — ' + st.name, ['<div class="lcr"><table class="lcr-top"><colgroup><col style="width:23%"><col><col style="width:14%"><col style="width:26%"></colgroup>' +
    '<tr><td colspan="4" class="lcr-session">' + esc(L.session) + '</td></tr>' +
    '<tr><th>Name</th><td>' + esc(st.name.toUpperCase()) + '</td><th>Dept. No.</th><td>' + esc(st.regNo) + '</td></tr><tr><th>Class</th><td colspan="3">' + esc(st.batch || '—') + '</td></tr></table>' +
    '<table class="lcr-table"><colgroup><col style="width:20mm"><col></colgroup><thead><tr><th>Course Code</th><th>Course Name</th>' + L.components.map((c) => '<th>' + esc(c.code) + '<br>(' + numS(c.convert) + ')</th>').join('') +
    '<th class="c-num">Total<br>(' + numS(L.totalMax) + ')</th><th class="c-num">Final<br>(' + numS(L.finalMax) + ')</th><th class="c-num">Att.<br>Marks</th><th class="c-num">Total<br>Final<br>(' + numS(L.finalMax) + ')</th></tr></thead><tbody>' +
    st.courses.map((c) => '<tr><td>' + esc(c.shortname) + '</td><td class="l">' + esc(c.fullname.toUpperCase()) + '</td>' + c.comps.map((x) => '<td>' + (x.published ? f1(x.converted) : '') + '</td>').join('') +
      '<td>' + (c.total == null ? '' : c.total) + '</td><td>' + (c.final == null ? '' : c.final) + '</td><td>' + (c.total == null ? '' : c.att) + '</td><td>' + (c.totalFinal == null ? '' : c.totalFinal) + '</td></tr>').join('') +
    '</tbody></table><table class="lcr-end"><tr><td class="lcr-signbox"><span>Signature of the Class Teacher</span><span>Signature of the H.O.D.</span></td></tr></table></div>']);
};
