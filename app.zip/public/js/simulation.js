'use strict';
/* =====================================================================
   BUSINESS SIMULATION STUDIO — faculty side
   Dashboard, simulation library and templates, the Simulation Builder
   (multi-step, no code), the run console (teams, rounds, live view),
   analytics, assessment and the printable report.
   The game itself (students and preview) is in sim-play.js.
   All calculations happen on the server; this file only presents them.
   ===================================================================== */
const SM = { cfg: null, sim: null, step: 'basics', vocab: null, dirty: false, tplCache: null };
const SM_AREAS = ['Strategy', 'Marketing', 'Finance', 'Operations', 'Human resources', 'Entrepreneurship', 'Business law', 'Sustainability'];

/* ---------- formatting ---------- */
function smMoney(v, cur) {
  v = Number(v) || 0; cur = cur || '₹';
  const a = Math.abs(v), sign = v < 0 ? '−' : '';
  if (cur === '₹') {
    if (a >= 1e7) return sign + cur + (a / 1e7).toLocaleString('en-IN', { maximumFractionDigits: a >= 1e9 ? 0 : 2 }) + ' Cr';
    if (a >= 1e5) return sign + cur + (a / 1e5).toLocaleString('en-IN', { maximumFractionDigits: 2 }) + ' L';
    return sign + cur + Math.round(a).toLocaleString('en-IN');
  }
  if (a >= 1e9) return sign + cur + (a / 1e9).toFixed(2) + 'B';
  if (a >= 1e6) return sign + cur + (a / 1e6).toFixed(2) + 'M';
  if (a >= 1e4) return sign + cur + (a / 1e3).toFixed(1) + 'K';
  return sign + cur + Math.round(a).toLocaleString();
}
function smNum(v, d) { v = Number(v) || 0; return v.toLocaleString('en-IN', { maximumFractionDigits: d == null ? (Math.abs(v) < 10 ? 2 : 0) : d }); }
function smFmt(v, format, cur) {
  if (v == null || v === '' || !isFinite(Number(v))) return '—';
  switch (format) {
    case 'money': return smMoney(v, cur);
    case 'pct': return (Math.round(Number(v) * 1000) / 10).toLocaleString('en-IN') + '%';
    case 'ratio': return (Math.round(Number(v) * 100) / 100).toLocaleString('en-IN');
    case 'index': return (Math.round(Number(v) * 10) / 10).toLocaleString('en-IN');
    default: return smNum(v);
  }
}
function smUnitFmt(v, unit, basics) {
  if (unit === 'money') return smMoney(v, basics.currency);
  if (unit === '%') return smNum(v, 1) + '%';
  if (unit === 'units') return smNum(v, 0) + ' ' + (basics.unitName || 'units');
  if (unit === 'people') return smNum(v, 0) + ' people';
  if (unit === 'toggle') return Number(v) ? 'Yes' : 'No';
  return smNum(v);
}
const SM_STATUS = { draft: ['Draft', ''], published: ['Published', 'success'], archived: ['Archived', ''], setup: ['Setting up', 'warning'], running: ['Running', 'primary'], paused: ['Paused', 'warning'], completed: ['Completed', 'success'] };
function smStatus(st) { const x = SM_STATUS[st] || [st, '']; return badge(x[0], x[1]); }
function smScoreRing(score, size) {
  size = size || 64; const r = (size - 8) / 2, c = 2 * Math.PI * r, v = Math.max(0, Math.min(100, Number(score) || 0));
  return '<svg class="sm-ring" width="' + size + '" height="' + size + '" viewBox="0 0 ' + size + ' ' + size + '" role="img" aria-label="Score ' + Math.round(v) + ' out of 100"><circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" class="t"/><circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" class="f" stroke-dasharray="' + c + '" stroke-dashoffset="' + (c * (1 - v / 100)) + '" transform="rotate(-90 ' + size / 2 + ' ' + size / 2 + ')"/><text x="50%" y="50%" dy=".35em" text-anchor="middle">' + Math.round(v) + '</text></svg>';
}
function smNav(active) {
  const staff = S.me.role !== 'student';
  const items = [['/sim', staff ? 'Dashboard' : 'My simulations', 'dashboard']];
  if (staff) items.push(['/sim/library', 'Simulations', 'layers'], ['/sim/new', 'Templates', 'template']);
  if (S.me.role === 'admin') items.push(['/sim/settings', 'Settings', 'settings']);
  return '<nav class="tabs sm-tabs" aria-label="Business simulations">' + items.map((i) => '<a class="tab' + (i[0] === active ? ' active' : '') + '" href="#' + i[0] + '"' + (i[0] === active ? ' aria-current="page"' : '') + '>' + icon(i[2]) + i[1] + '</a>').join('') + '</nav>';
}
function smDeadline(ms) {
  if (!ms) return '';
  const left = ms - Date.now();
  if (left <= 0) return badge('Deadline passed', 'danger', 'clock');
  const h = Math.floor(left / 3600000), m = Math.floor((left % 3600000) / 60000);
  return badge((h >= 48 ? Math.floor(h / 24) + ' days' : h ? h + ' h ' + m + ' min' : m + ' min') + ' left', h < 6 ? 'warning' : '', 'clock');
}

/* =====================================================================
   DASHBOARD
   ===================================================================== */
async function viewSmHome() {
  const h = await call('smHome');
  if (!h.staff) return smStudentHome(h);
  const c = h.counts;
  const runCard = (r) => '<a class="card sm-runcard" href="#/sim/run/' + esc(r.id) + '"><div class="sm-runcard-top"><b>' + esc(r.title) + '</b>' + smStatus(r.status) + '</div>' +
    '<div class="xs muted">' + esc(r.course) + ' · ' + r.teams + ' teams · ' + r.participants + ' students</div>' +
    (r.status === 'setup' ? '<p class="small">Not launched yet — set up teams and launch.</p>' : '<div class="sm-progress"><div class="progress"><i style="width:' + Math.round((r.status === 'completed' ? r.rounds : r.round - 1) / r.rounds * 100) + '%"></i></div><span class="xs muted">' + (r.status === 'completed' ? 'All ' + r.rounds + ' rounds done' : 'Round ' + r.round + ' of ' + r.rounds + (r.roundOpen ? ' · ' + r.submitted + '/' + r.teams + ' submitted' : '')) + '</span></div>') +
    (r.avgScore != null ? '<div class="xs">Class average score <b>' + r.avgScore + '</b></div>' : '') + '</a>';
  const active = h.runs.filter((r) => r.manage && r.status !== 'completed');
  return {
    title: 'Business simulations',
    html: '<section class="sm-hero"><div><div class="sm-eyebrow">Business Simulation Studio</div><h1>Decide. Simulate. Compete. Learn.</h1><p class="muted">Create a business, define the market and the scenario — your students run the company round by round, see the consequences and learn from them.</p></div>' +
      '<div class="sm-hero-acts"><a class="btn btn-primary" href="#/sim/new">' + icon('plus') + 'New simulation</a><a class="btn" href="#/sim/library">' + icon('layers') + 'My simulations</a></div></section>' + smNav('/sim') +
      '<div class="grid-4 sm-kpis">' + statCard('live', 'indigo', c.active, 'Active runs') + statCard('edit', 'amber', c.drafts, 'Draft simulations') + statCard('checkCircle', 'green', c.completed, 'Completed runs') + statCard('users', 'cyan', c.participants, 'Participants') +
      statCard('award', 'violet', c.avgScore == null ? '—' : c.avgScore, 'Average student score') + statCard('trending', 'blue', c.completion == null ? '—' : c.completion + '%', 'Simulation completion') + statCard('layers', 'pink', c.published, 'Published simulations') + statCard('briefcase', 'green', h.runs.filter((r) => r.manage).length, 'Class runs') + '</div>' +
      '<div class="sm-cols"><section class="sm-col"><div class="row"><h2 class="sm-h2">Active and upcoming runs</h2></div>' + (active.length ? '<div class="sm-runs">' + active.map(runCard).join('') + '</div>' : '<div class="card card-pad">' + emptyState('live', 'No active runs', 'Publish a simulation, then choose “Run with a class”.', '<a class="btn btn-primary" href="#/sim/library">Open my simulations</a>', false) + '</div>') +
      (h.runs.filter((r) => r.manage && r.status === 'completed').length ? '<h2 class="sm-h2">Completed</h2><div class="sm-runs">' + h.runs.filter((r) => r.manage && r.status === 'completed').slice(0, 6).map(runCard).join('') + '</div>' : '') + '</section>' +
      '<aside class="sm-col side"><section class="card"><div class="card-head"><h2>My simulations</h2><a class="btn btn-sm btn-ghost" href="#/sim/library">All</a></div><div class="card-body sm-simlist">' + (h.sims.length ? h.sims.map((x) => '<a class="sm-simrow" href="#/sim/build/' + esc(x.id) + '"><span><b>' + esc(x.title) + '</b><span class="xs muted">' + esc(x.industry) + ' · ' + x.rounds + ' rounds' + (x.version ? ' · v' + esc(x.version) : '') + '</span></span>' + smStatus(x.status) + '</a>').join('') : '<p class="small muted">Start from a template.</p>') + '</div></section>' +
      '<section class="card"><div class="card-head"><h2>Recent activity</h2></div><div class="card-body">' + (h.activity && h.activity.length ? '<ul class="sm-activity">' + h.activity.map((a) => '<li><span class="xs muted">' + esc(rel(a.at)) + '</span> ' + esc(a.who || '') + ' · ' + esc(SM_ACTIONS[a.action] || a.action.toLowerCase().replace(/_/g, ' ')) + (a.title ? ' — <i>' + esc(a.title) + '</i>' : '') + '</li>').join('') + '</ul>' : '<p class="small muted">Nothing yet.</p>') + '</div></section></aside></div>'
  };
}
const SM_ACTIONS = { CREATE: 'created a simulation', PUBLISH: 'published', RUN_CREATE: 'created a run', RUN_LAUNCH: 'launched', ROUND_RUN: 'ran a round', DECISION_SUBMIT: 'submitted decisions', GRADES_PUSH: 'sent grades', PREVIEW: 'previewed', REFLECTION: 'wrote a reflection', ANNOUNCE: 'posted an announcement', RUN_TEAMS: 'updated teams', DUPLICATE: 'duplicated', EXPORT: 'exported', ROUND_UNDO: 'rolled back a round' };
function smStudentHome(h) {
  const card = (r) => '<a class="card sm-runcard' + (r.pending ? ' pending' : '') + '" href="#/sim/play/' + esc(r.id) + '"><div class="sm-runcard-top"><b>' + esc(r.title) + '</b>' + smStatus(r.status) + '</div>' +
    '<div class="xs muted">' + esc(r.course) + (r.team ? ' · ' + esc(r.team) : ' · not in a team yet') + '</div>' +
    (r.status === 'completed' ? '<div class="small">Final score <b>' + (r.score == null ? '—' : r.score) + '</b>' + (r.rank ? ' · rank ' + r.rank.rank : '') + '</div>' : '<div class="small">Round ' + r.round + ' of ' + r.rounds + (r.pending ? ' · ' + badge('Decisions due', 'warning', 'alert') : r.roundOpen ? ' · ' + badge('Submitted', 'success', 'check') : '') + ' ' + smDeadline(r.deadline) + '</div>' + (r.score != null ? '<div class="xs">Score so far <b>' + r.score + '</b>' + (r.rank ? ' · rank ' + r.rank.rank : '') + '</div>' : '')) + '</a>';
  const active = h.runs.filter((r) => r.status !== 'completed'), done = h.runs.filter((r) => r.status === 'completed');
  return {
    title: 'My simulations',
    html: pageHead('Business simulations', { sub: 'Run a company with your team: make decisions each round, see what happens, and learn from the results.' }) +
      (active.some((r) => r.pending) ? notice('<b>Decisions are due</b> in ' + active.filter((r) => r.pending).map((r) => esc(r.title)).join(', ') + '.', 'warn') : '') +
      (active.length ? '<h2 class="sm-h2">Active</h2><div class="sm-runs">' + active.map(card).join('') + '</div>' : '<div class="card card-pad">' + emptyState('briefcase', 'No active simulations', 'When your teacher launches a business simulation in one of your courses, it appears here.', '', false) + '</div>') +
      (done.length ? '<h2 class="sm-h2">Completed</h2><div class="sm-runs">' + done.map(card).join('') + '</div>' : '')
  };
}

/* =====================================================================
   LIBRARY AND TEMPLATES
   ===================================================================== */
async function viewSmLibrary(params) {
  const view = params.get('view') || 'mine';
  const rows = await call('smList', { view });
  const U = S.me;
  const card = (x) => '<article class="card sm-simcard"><div class="sm-simcard-top"><span class="i-tile tone-indigo">' + icon('briefcase') + '</span><div><b>' + esc(x.title) + '</b><div class="xs muted">' + esc(x.subject) + ' · ' + esc(x.industry) + ' · ' + x.rounds + ' × ' + esc(x.period) + (x.mine ? '' : ' · by ' + esc(x.owner)) + '</div></div></div>' +
    '<div class="sm-simcard-tags">' + smStatus(x.status) + (x.version ? badge('v' + x.version + (x.dirty ? ' + edits' : ''), 'outline') : '') + (x.library ? badge('Library', 'info', 'book') : '') + (x.active ? badge(x.active + ' running', 'primary', 'live') : '') + '</div>' +
    '<div class="sm-simcard-acts">' + (x.mine || U.role === 'admin' ? '<a class="btn btn-sm" href="#/sim/build/' + esc(x.id) + '">' + icon('edit', 'i-sm') + 'Build</a>' : '') +
    (x.version ? '<button class="btn btn-sm btn-primary" data-act="smRunNew" data-id="' + esc(x.id) + '">' + icon('play', 'i-sm') + 'Run with a class</button>' : '') +
    '<div class="menu-wrap"><button class="btn-icon sm" data-act="menu" aria-label="More actions">' + icon('more') + '</button><div class="menu">' +
    '<button class="menu-item" data-act="smDup" data-id="' + esc(x.id) + '">' + icon('copy') + 'Duplicate</button><button class="menu-item" data-act="smExport" data-id="' + esc(x.id) + '">' + icon('download') + 'Export (JSON)</button>' +
    (x.mine ? '<button class="menu-item" data-act="smArchive" data-id="' + esc(x.id) + '">' + icon('folder') + (x.status === 'archived' ? 'Restore' : 'Archive') + '</button><button class="menu-item danger" data-act="smDel" data-id="' + esc(x.id) + '">' + icon('trash') + 'Delete</button>' : '') + '</div></div></div></article>';
  const views = [['mine', 'My simulations'], ['library', 'Shared library']].concat(S.me.role === 'admin' || (S.me.sim && S.me.sim.inst) ? [['all', 'All (institution)']] : []);
  return {
    title: 'Simulations',
    html: pageHead('Simulations', { crumbs: [['Business simulations', '/sim'], ['Simulations']], actions: '<button class="btn" data-act="smImport">' + icon('upload') + 'Import</button><a class="btn btn-primary" href="#/sim/new">' + icon('plus') + 'New simulation</a>' }) + smNav('/sim/library') +
      '<div class="pills" style="margin-bottom:1rem">' + views.map((v) => '<a class="pill' + (v[0] === view ? ' active' : '') + '" href="#/sim/library?view=' + v[0] + '">' + v[1] + '</a>').join('') + '</div>' +
      (rows.length ? '<div class="sm-grid">' + rows.map(card).join('') + '</div>' : '<div class="card card-pad">' + emptyState('layers', 'No simulations here', view === 'library' ? 'Simulations colleagues share with the institution appear here.' : 'Start from one of the templates — every part can be edited.', '<a class="btn btn-primary" href="#/sim/new">Browse templates</a>', false) + '</div>')
  };
}
async function viewSmNew() {
  const tpls = SM.tplCache || (SM.tplCache = await call('smTemplates'));
  const tcard = (t) => '<button class="card sm-tpl' + (t.demo ? ' demo' : '') + '" data-act="smFromTpl" data-id="' + esc(t.id) + '"><div class="sm-tpl-top"><span class="xs sm-eyebrow">' + esc(t.area) + '</span>' + (t.demo ? badge('Demo', 'primary', 'sparkle') : '') + '</div><b>' + esc(t.name) + '</b><span class="xs muted">' + esc(t.industry) + ' · ' + t.rounds + ' × ' + esc(t.period) + '</span><span class="small muted sm-tpl-desc">' + esc(t.description) + '</span></button>';
  return {
    title: 'New simulation',
    html: pageHead('New simulation', { crumbs: [['Business simulations', '/sim'], ['New']], sub: 'Every template is a complete, working simulation. Pick one and change anything — market, companies, decisions, events, scoring.', actions: '<button class="btn" data-act="smBlank">' + icon('plus') + 'Blank simulation</button><button class="btn" data-act="smImport">' + icon('upload') + 'Import JSON</button>' }) + smNav('/sim/new') +
      '<h2 class="sm-h2">Demo simulations</h2><div class="sm-tpls">' + tpls.filter((t) => t.demo).map(tcard).join('') + '</div>' +
      SM_AREAS.map((a) => { const xs = tpls.filter((t) => t.area === a && !t.demo); return xs.length ? '<h2 class="sm-h2">' + esc(a) + '</h2><div class="sm-tpls">' + xs.map(tcard).join('') + '</div>' : ''; }).join('')
  };
}
ACT.smFromTpl = (d, btn) => busy(btn, async () => { const r = await call('smCreate', { templateId: d.id }); toast('Simulation created from the template.'); go('/sim/build/' + r.id); });
ACT.smBlank = (d, btn) => busy(btn, async () => { const r = await call('smCreate', {}); go('/sim/build/' + r.id); });
ACT.smImport = () => formModal('Import a simulation', 'A .simulation.json file exported from this platform (or another copy of it).', 'smImport', '<label class="dropzone" style="padding:1.25rem">' + icon('upload') + '<b>Choose a file</b><span class="small">.json</span><input type="file" name="file" accept=".json,application/json" required></label>', 'Import', 'narrow');
FORMS.smImport = (f, btn) => busy(btn, async () => { const file = f.elements.file.files[0]; if (!file) throw new Error('Choose a file.'); if (file.size > 2e6) throw new Error('The file is too large.'); const r = await call('smCreate', { import: await file.text() }); closeModal(); toast('Imported.'); go('/sim/build/' + r.id); });
ACT.smDup = (d, btn) => busy(btn, async () => { const r = await call('smDuplicate', { id: d.id, v: d.v || '' }); toast('Copy created.'); go('/sim/build/' + r.id); });
ACT.smExport = (d, btn) => busy(btn, async () => { const r = await call('smExport', { id: d.id, v: d.v || '' }); downloadBase64(r.name, r.data, r.mime); });
ACT.smArchive = (d, btn) => busy(btn, async () => { await call('smDelete', { id: d.id, archive: true }); refresh(); });
ACT.smDel = async (d) => { if (!await confirmBox('Delete this simulation?', '<p>Finished runs keep their results. This cannot be undone.</p>', 'Delete', true)) return; busy(null, async () => { await call('smDelete', { id: d.id }); toast('Deleted.'); refresh(); }); };

/* =====================================================================
   SIMULATION BUILDER
   ===================================================================== */
const SM_STEPS = [
  ['basics', 'Basic information', 'info'], ['market', 'Business environment', 'globe'], ['segments', 'Customer segments', 'users'], ['companies', 'Companies', 'building'],
  ['competitors', 'Competitors', 'target'], ['decisions', 'Decisions', 'sliders'], ['finance', 'Financial model', 'chart'], ['formulas', 'Formulas', 'sigma'], ['events', 'Scenarios & events', 'zap'],
  ['rounds', 'Rounds', 'layers'], ['kpis', 'KPIs', 'trending'], ['scoring', 'Scoring', 'award'], ['settings', 'Gameplay & assessment', 'settings'], ['health', 'Health, preview & publish', 'checkCircle']
];
const SM_INDUSTRIES = ['Banking', 'Retail', 'FMCG', 'Automobile', 'Electric vehicles', 'Healthcare', 'Hospitality', 'Logistics', 'Technology', 'Manufacturing', 'E-commerce', 'EdTech', 'FinTech', 'Aviation', 'Renewable energy', 'Food & beverage retail', 'SaaS (software as a service)', 'Banking / FinTech'];
const SM_FIN = [
  ['unitCost', 'Variable cost per unit', 'money', 'Materials and direct labour for one unit at the start.'], ['fixedCost', 'Fixed costs per period', 'money', 'Rent, administration and other overheads.'],
  ['salary', 'Salary per employee per period', 'money'], ['productivity', 'Units per employee per period', 'number', 'Staffing limit on production.'], ['capexPerUnit', 'Investment per unit of new capacity', 'money'],
  ['capacityLag', 'Rounds before new capacity is ready', 'number'], ['depRate', 'Depreciation rate per period', 'pct'], ['interestRate', 'Interest rate (per year)', 'pct'], ['taxRate', 'Tax rate', 'pct'],
  ['holdingRate', 'Inventory holding cost per period', 'pct', 'Share of inventory value.'], ['arDays', 'Customer credit (days)', 'number'], ['apDays', 'Supplier credit (days)', 'number'], ['periodDays', 'Days per period', 'number'],
  ['periodsPerYear', 'Periods per year', 'number'], ['hiringCost', 'Cost per hire', 'money'], ['layoffCost', 'Cost per layoff', 'money'], ['learningRate', 'Learning curve (cost saving per doubling)', 'pct'],
  ['qualityCostPremium', 'Extra unit cost at quality 100', 'pct'], ['techSaving', 'Unit cost saving at technology 100', 'pct'], ['makeToOrder', 'Make to order (services: no finished stock)', 'bool'],
  ['minCash', 'Minimum cash (emergency loan below this)', 'money'], ['emergencyPremium', 'Emergency loan penalty (per year)', 'pct'], ['maxDebtToEquity', 'Lenders\' debt-to-equity limit', 'number'],
  ['rdCostPerPoint', 'R&D spend per technology point', 'money'], ['qualityCostPerPoint', 'Quality spend per quality point', 'money'], ['mktScale', 'Marketing scale (spend for a strong brand effect)', 'money'],
  ['brandGain', 'Brand gain from marketing', 'number'], ['brandDecay', 'Brand decay per period', 'pct'], ['distCostPerPoint', 'Distribution spend per reach point', 'money'], ['sustCostPerPoint', 'Sustainability spend per point', 'money'],
  ['trainingCostPerPoint', 'Training spend per satisfaction point', 'money'], ['promoWeight', 'Short-term promotion effect', 'number'], ['obsolescence', 'Technology loss per period (points)', 'number']
];
const SM_ROWS = {
  segments: () => ({ id: 'seg' + Date.now().toString(36).slice(-4), name: 'New segment', size: 10000, growth: 0.02, refPrice: 1000, maxPrice: 1800, priceSens: 0.6, qualitySens: 0.4, brandSens: 0.4, sustainSens: 0.1, distSens: 0.3, switching: 0.5, locked: false, entryCost: 0 }),
  companies: () => ({ id: 'co' + Date.now().toString(36).slice(-4), name: 'New company', color: '#3563d9', foundingYear: 2026, employees: 100, cash: 1e7, assets: 1e7, debt: 0, capacity: 5000, inventory: 0, brand: 40, quality: 50, tech: 50, sustainability: 40, distribution: 40, satisfaction: 60, morale: 60, marketShare: 0.05 }),
  competitors: () => ({ id: 'comp' + Date.now().toString(36).slice(-4), name: 'New competitor', price: 1000, quality: 50, brand: 50, marketing: 1e6, distribution: 50, sustainability: 40, tech: 50, share: 0.2, behavior: 'follower', reaction: 0.5, costFloor: 0, segments: [] }),
  decisions: () => ({ key: 'decision' + Date.now().toString(36).slice(-3), label: 'New decision', category: 'strategy', driver: 'marketing', type: 'number', min: 0, max: 1e7, step: 1e5, default: 1e6, unit: 'money', role: '', help: '', efficiency: 1, enabledFrom: 1, effects: [] }),
  formulas: () => ({ key: 'f' + Date.now().toString(36).slice(-4), label: 'New formula', expr: 'metric.revenue - metric.opex', format: 'money' }),
  events: () => ({ id: 'ev' + Date.now().toString(36).slice(-4), name: 'New event', category: 'market', trigger: 'random', rounds: [], probability: 0.2, condition: '', duration: 1, severity: 'medium', once: true, message: '', modifiers: [{ target: 'demand', op: 'mul', value: 0.9 }] }),
  rounds: () => ({ title: 'New round', focus: '', brief: '', decisions: [] }),
  kpis: () => ({ key: 'revenue', label: 'Revenue', category: 'financial', dir: 'up', floor: 0, target: 1e7, weight: 1, format: 'money', formula: '' }),
  'scoring.categories': () => ({ key: 'cat' + Date.now().toString(36).slice(-3), label: 'New category', weight: 10 }),
  effects: () => ({ target: 'brand', expr: 'state.brand + value / 1000000', when: 'after' }),
  modifiers: () => ({ target: 'demand', op: 'mul', value: 1.1 })
};

async function viewSmBuild(id, params) {
  const sim = await call('smGet', { id });
  SM.sim = sim; SM.cfg = JSON.parse(JSON.stringify(sim.config)); SM.vocab = sim.vocab; SM.dirty = false;
  SM.step = params.get('step') || SM.step || 'basics';
  if (!SM_STEPS.some((x) => x[0] === SM.step)) SM.step = 'basics';
  S.onLeave = () => { if (SM.dirty && SM.sim && SM.sim.canEdit) smSaveStep(true); };
  const ro = !sim.canEdit;
  return {
    title: 'Build: ' + sim.title,
    html: pageHead(sim.title, { crumbs: [['Business simulations', '/sim'], ['Simulations', '/sim/library'], ['Builder']], sub: smStatus(sim.status) + ' ' + (sim.version ? badge('v' + sim.version + (sim.dirty ? ' + unpublished edits' : ''), 'outline') : badge('Not published yet', 'outline')) + (ro ? ' ' + badge('View only') : ''),
      actions: (ro ? '' : '<button class="btn" data-act="smPreviewStart">' + icon('play') + 'Preview as student</button>') + (sim.version ? '<button class="btn btn-primary" data-act="smRunNew" data-id="' + esc(sim.id) + '">' + icon('live') + 'Run with a class</button>' : '') }) +
      '<div class="sm-builder' + (ro ? ' is-ro' : '') + '"><nav class="sm-steps" aria-label="Builder steps">' + SM_STEPS.map((s, i) => '<a class="sm-step' + (s[0] === SM.step ? ' active' : '') + '" href="#/sim/build/' + esc(sim.id) + '?step=' + s[0] + '" data-act="smGoStep" data-step="' + s[0] + '"><span class="n">' + (i + 1) + '</span>' + icon(s[2]) + '<span>' + s[1] + '</span>' + smStepFlag(s[0]) + '</a>').join('') + '</nav>' +
      '<section class="sm-stepbody card"><form id="smStep" data-form="smStepSave" autocomplete="off">' + smStepHtml(ro) + '</form></section></div>',
    after: () => { mountCharts(); }
  };
}
function smStepFlag(step) {
  const v = SM.sim && SM.sim.validation; if (!v) return '';
  const map = { basics: 'config', market: 'market', segments: 'market', companies: 'market', competitors: 'market', decisions: 'decisions', finance: 'financial', formulas: 'formulas', events: 'events', rounds: 'rounds', kpis: 'scoring', scoring: 'scoring', settings: 'scoring' };
  const c = v.checks.find((x) => x.key === map[step]);
  if (!c || c.status === 'ok') return '';
  return '<span class="sm-flag ' + c.status + '" title="' + esc(c.messages[0] || '') + '">' + icon(c.status === 'error' ? 'alert' : 'info', 'i-sm') + '</span>';
}
ACT.smGoStep = async (d) => { if (SM.dirty) await smSaveStep(true); go('/sim/build/' + SM.sim.id + '?step=' + d.step); };

/* ---------- generic field rendering, bound to config paths ---------- */
function smInput(p, val, f, ro) {
  f = f || {};
  const t = f.t || 'text', dis = ro ? ' disabled' : '';
  const attr = ' data-p="' + esc(p) + '" data-t="' + t + '" id="f_' + esc(p.replace(/\./g, '_')) + '"' + dis;
  let ctl;
  if (t === 'textarea' || t === 'lines' || t === 'formula') ctl = '<textarea' + attr + ' rows="' + (f.rows || (t === 'formula' ? 2 : 3)) + '"' + (t === 'formula' ? ' spellcheck="false" class="sm-mono"' : '') + '>' + esc(t === 'lines' ? (val || []).join('\n') : (val == null ? '' : val)) + '</textarea>';
  else if (t === 'select') ctl = '<select' + attr + '>' + f.options.map((o) => { const ov = Array.isArray(o) ? o[0] : o, ol = Array.isArray(o) ? o[1] : o; return '<option value="' + esc(ov) + '"' + (String(val) === String(ov) ? ' selected' : '') + '>' + esc(ol) + '</option>'; }).join('') + '</select>';
  else if (t === 'bool') return '<label class="check sm-check"><input type="checkbox"' + attr + (val ? ' checked' : '') + '><span>' + esc(f.label) + '</span></label>';
  else if (t === 'color') ctl = '<input type="color"' + attr + ' value="' + esc(val || '#3563d9') + '">';
  else if (t === 'list' || t === 'rounds') ctl = '<input type="text"' + attr + ' value="' + esc((val || []).join(', ')) + '" placeholder="' + esc(f.ph || (t === 'rounds' ? 'e.g. 2, 3' : 'comma separated')) + '">';
  else if (t === 'pct') ctl = '<span class="sm-suffix"><input type="number" step="any"' + attr + ' value="' + esc(val == null ? '' : Math.round(Number(val) * 100000) / 1000) + '"><i>%</i></span>';
  else if (t === 'money') ctl = '<input type="number" step="any"' + attr + ' value="' + esc(val == null ? '' : val) + '" data-input="smMoneyHint" data-delay="150"><span class="xs muted sm-hint" data-hint="' + esc(p) + '">' + esc(smMoney(val, SM.cfg.basics.currency)) + '</span>';
  else if (t === 'number') ctl = '<input type="number" step="any"' + attr + ' value="' + esc(val == null ? '' : val) + '"' + (f.min != null ? ' min="' + f.min + '"' : '') + (f.max != null ? ' max="' + f.max + '"' : '') + '>';
  else ctl = '<input type="text"' + attr + ' value="' + esc(val == null ? '' : val) + '"' + (f.list ? ' list="' + f.list + '"' : '') + (f.max ? ' maxlength="' + f.max + '"' : '') + '>';
  return '<label class="sm-field' + (f.wide ? ' wide' : '') + (f.full ? ' full' : '') + '" for="f_' + esc(p.replace(/\./g, '_')) + '"><span class="sm-lbl">' + esc(f.label || '') + '</span>' + ctl + (f.help ? '<span class="xs muted">' + esc(f.help) + '</span>' : '') + '</label>';
}
INPUTS.smMoneyHint = (el) => { const h = document.querySelector('[data-hint="' + CSS.escape(el.dataset.p) + '"]'); if (h) h.textContent = smMoney(el.value, SM.cfg.basics.currency); };
document.addEventListener('input', (e) => { if (e.target.closest && e.target.closest('#smStep')) { SM.dirty = true; const s2 = document.getElementById('smSaveState'); if (s2) s2.textContent = 'Unsaved changes'; } });
document.addEventListener('change', (e) => { if (e.target.closest && e.target.closest('#smStep')) SM.dirty = true; });
function smGet(obj, p) { return p.split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj); }
function smSet(obj, p, v) { const ks = p.split('.'); let o = obj; for (let i = 0; i < ks.length - 1; i++) { if (o[ks[i]] == null) o[ks[i]] = /^\d+$/.test(ks[i + 1]) ? [] : {}; o = o[ks[i]]; } o[ks[ks.length - 1]] = v; }
/** Reads every bound input of the current step back into the working config. */
function smCollect() {
  const form = document.getElementById('smStep'); if (!form) return;
  form.querySelectorAll('[data-p]').forEach((el) => {
    const t = el.dataset.t, raw = el.type === 'checkbox' ? el.checked : el.value;
    let v = raw;
    if (t === 'number' || t === 'money') v = raw === '' ? null : Number(raw);
    else if (t === 'pct') v = raw === '' ? null : Number(raw) / 100;
    else if (t === 'bool') v = !!raw;
    else if (t === 'list') v = String(raw).split(',').map((x) => x.trim()).filter(Boolean);
    else if (t === 'rounds') v = String(raw).split(',').map((x) => Number(x.trim())).filter((x) => x > 0);
    else if (t === 'lines') v = String(raw).split('\n').map((x) => x.trim()).filter(Boolean);
    smSet(SM.cfg, el.dataset.p, v);
  });
}
async function smSaveStep(quiet) {
  if (!SM.sim || !SM.sim.canEdit) return;
  smCollect();
  const section = SM.step === 'health' ? null : SM.step;
  if (!section) return;
  const top = section.split('.')[0];
  try {
    const r = await call('smSave', { id: SM.sim.id, rev: SM.sim.rev, section: top, data: SM.cfg[top] });
    SM.sim.rev = r.rev; SM.sim.validation = r.validation; SM.cfg = JSON.parse(JSON.stringify(r.config)); SM.sim.config = r.config; SM.dirty = false;
    if (!quiet) { toast('Saved.'); smRerender(); }
    return true;
  } catch (e) { if (!quiet) throw e; toast(e.message, 'err'); return false; }
}
FORMS.smStepSave = (f, btn) => busy(btn, async () => { await smSaveStep(false); });
ACT.smNext = (d, btn) => busy(btn, async () => { if (SM.sim.canEdit) await smSaveStep(true); const i = SM_STEPS.findIndex((x) => x[0] === SM.step); go('/sim/build/' + SM.sim.id + '?step=' + SM_STEPS[Math.min(SM_STEPS.length - 1, i + 1)][0]); });
function smRerender() { const f = document.getElementById('smStep'); if (f) { f.innerHTML = smStepHtml(!SM.sim.canEdit); mountCharts(); } $$('.sm-step').forEach((a) => { const k = a.dataset.step; const fl = a.querySelector('.sm-flag'); if (fl) fl.remove(); a.insertAdjacentHTML('beforeend', smStepFlag(k)); }); }
/** Row operations on lists (add, duplicate, move, delete), keeping unsaved edits. */
ACT.smRow = (d) => {
  smCollect();
  const list = smGet(SM.cfg, d.list) || [];
  const i = Number(d.i);
  const kind = d.kind || d.list.split('.').pop();
  if (d.op === 'add') list.push(SM_ROWS[kind] ? SM_ROWS[kind]() : {});
  else if (d.op === 'dup') { const c = JSON.parse(JSON.stringify(list[i])); if (c.id) c.id += '2'; if (c.key) c.key += '2'; list.splice(i + 1, 0, c); }
  else if (d.op === 'del') list.splice(i, 1);
  else if (d.op === 'up' && i > 0) [list[i - 1], list[i]] = [list[i], list[i - 1]];
  else if (d.op === 'down' && i < list.length - 1) [list[i + 1], list[i]] = [list[i], list[i + 1]];
  smSet(SM.cfg, d.list, list);
  SM.dirty = true;
  smRerender();
};
function smRowActs(list, i, ro, kind) {
  if (ro) return '';
  const k = kind ? ' data-kind="' + kind + '"' : '';
  return '<span class="sm-rowacts"><button type="button" class="btn-icon sm" data-act="smRow" data-op="up" data-list="' + list + '" data-i="' + i + '"' + k + ' aria-label="Move up">' + icon('up') + '</button><button type="button" class="btn-icon sm" data-act="smRow" data-op="down" data-list="' + list + '" data-i="' + i + '"' + k + ' aria-label="Move down">' + icon('down') + '</button><button type="button" class="btn-icon sm" data-act="smRow" data-op="dup" data-list="' + list + '" data-i="' + i + '"' + k + ' aria-label="Duplicate">' + icon('copy') + '</button><button type="button" class="btn-icon sm danger" data-act="smRow" data-op="del" data-list="' + list + '" data-i="' + i + '"' + k + ' aria-label="Remove">' + icon('trash') + '</button></span>';
}
const smAdd = (list, label, ro, kind) => (ro ? '' : '<button type="button" class="btn btn-sm sm-add" data-act="smRow" data-op="add" data-list="' + list + '"' + (kind ? ' data-kind="' + kind + '"' : '') + '>' + icon('plus', 'i-sm') + label + '</button>');
function smStepFoot(ro) {
  const i = SM_STEPS.findIndex((x) => x[0] === SM.step);
  return '<div class="sm-stepfoot"><span class="xs muted" id="smSaveState">' + (ro ? 'View only' : 'All changes saved') + '</span><span class="spacer"></span>' + (ro ? '' : '<button class="btn" type="submit">' + icon('check') + 'Save</button>') + (i < SM_STEPS.length - 1 ? '<button class="btn btn-primary" type="button" data-act="smNext">Save and continue' + icon('right') + '</button>' : '') + '</div>';
}
const smSensOpts = [[0, 'None (0)'], [0.15, 'Very low (0.15)'], [0.3, 'Low (0.3)'], [0.5, 'Medium (0.5)'], [0.7, 'High (0.7)'], [0.9, 'Very high (0.9)'], [1.2, 'Extreme (1.2)']];
function smStepHtml(ro) {
  const c = SM.cfg, st = SM.step, V = SM.vocab || {};
  const title = SM_STEPS.find((x) => x[0] === st);
  let h = '<div class="sm-stephead"><h2>' + icon(title[2]) + ' ' + esc(title[1]) + '</h2></div>';
  const I = (p, f) => smInput(p, smGet(c, p), f, ro);
  const grid = (inner) => '<div class="sm-fields">' + inner + '</div>';
  if (st === 'basics') {
    h += grid(I('basics.title', { label: 'Simulation name', wide: true, max: 160 }) + I('basics.subject', { label: 'Subject', t: 'select', options: ['Strategy', 'Marketing', 'Finance', 'Operations', 'Human resource management', 'Entrepreneurship', 'Economics', 'Business law', 'Sustainability', 'International business'] }) +
      I('basics.course', { label: 'Course (for your reference)' }) + I('basics.level', { label: 'Academic level', t: 'select', options: ['Undergraduate', 'Undergraduate (B.Com / BBA) and MBA', 'Undergraduate and MBA', 'MBA', 'MBA and B.Com (Hons)', 'Executive education', 'Corporate training'] }) +
      I('basics.industry', { label: 'Industry', list: 'smIndustries' }) + I('basics.difficulty', { label: 'Difficulty', t: 'select', options: ['Introductory', 'Intermediate', 'Advanced'] }) + I('basics.duration', { label: 'Duration (e.g. 6 weeks)' }) +
      I('basics.teamSize', { label: 'Team size', t: 'number', min: 1, max: 12 }) + I('basics.period', { label: 'Each round is a', t: 'select', options: ['Quarter', 'Year', 'Half-year', 'Month'] }) + I('basics.currency', { label: 'Currency', t: 'select', options: ['₹', '$', '€', '£'] }) +
      I('basics.unitName', { label: 'What the company sells (unit name)', help: 'e.g. vehicles, cups, loans, subscriptions' }) + I('basics.description', { label: 'Description (students see this)', t: 'textarea', rows: 4, full: true }) +
      I('basics.objectives', { label: 'Learning objectives (one per line)', t: 'lines', rows: 4, full: true }) + I('basics.tags', { label: 'Tags', t: 'list', wide: true })) + '<datalist id="smIndustries">' + SM_INDUSTRIES.map((x) => '<option value="' + esc(x) + '">').join('') + '</datalist>' +
      '<p class="xs muted">Number of rounds is set in the Rounds step (currently ' + c.rounds.length + ').</p>';
  } else if (st === 'market') {
    h += '<p class="small muted">The market grows each round; in every segment customers compare all offers, and some buy nothing (the "outside option"). Higher outside option = more customers walk away when offers are unattractive.</p>' +
      grid(I('market.name', { label: 'Market name', wide: true }) + I('market.growth', { label: 'Market growth per round', t: 'pct' }) + I('market.volatility', { label: 'Demand volatility (random noise)', t: 'pct' }) +
        I('market.entryBarrier', { label: 'Entry barriers', t: 'select', options: ['Low', 'Medium', 'High'] }) + I('market.outsideOption', { label: 'Outside option (customers not buying)', t: 'number', help: '0.25 = most customers buy; 1 = many walk away' }) +
        '<h3 class="sm-h3 full">Economy</h3>' + I('market.economy.inflation', { label: 'Inflation (per year)', t: 'pct', help: 'Raises costs every round' }) + I('market.economy.interestRate', { label: 'Interest rate (reference)', t: 'pct' }) + I('market.economy.gdpGrowth', { label: 'GDP growth', t: 'pct' }));
  } else if (st === 'segments') {
    h += '<p class="small muted">Each segment weighs price, quality, brand, sustainability and distribution differently. "Switching" is how many customers reconsider each round (low = loyal). Locked segments must be entered with a decision (driver: enter segment).</p>' +
      c.segments.map((sg, i) => '<fieldset class="sm-card"><legend><b>' + esc(sg.name) + '</b>' + smRowActs('segments', i, ro) + '</legend>' + grid(
        I('segments.' + i + '.name', { label: 'Name' }) + I('segments.' + i + '.id', { label: 'ID (used in formulas)' }) + I('segments.' + i + '.size', { label: 'Potential customers (' + c.basics.unitName + ' per period)', t: 'number' }) + I('segments.' + i + '.growth', { label: 'Growth per round', t: 'pct' }) +
        I('segments.' + i + '.refPrice', { label: 'Reference price', t: 'money' }) + I('segments.' + i + '.maxPrice', { label: 'Maximum price (purchasing power)', t: 'money' }) +
        I('segments.' + i + '.priceSens', { label: 'Price sensitivity', t: 'select', options: smSensOpts.concat([[sg.priceSens, 'Custom (' + sg.priceSens + ')']]) }) + I('segments.' + i + '.qualitySens', { label: 'Quality sensitivity', t: 'select', options: smSensOpts.concat([[sg.qualitySens, 'Custom (' + sg.qualitySens + ')']]) }) +
        I('segments.' + i + '.brandSens', { label: 'Brand sensitivity', t: 'select', options: smSensOpts.concat([[sg.brandSens, 'Custom (' + sg.brandSens + ')']]) }) + I('segments.' + i + '.sustainSens', { label: 'Sustainability sensitivity', t: 'select', options: smSensOpts.concat([[sg.sustainSens, 'Custom (' + sg.sustainSens + ')']]) }) +
        I('segments.' + i + '.distSens', { label: 'Distribution sensitivity', t: 'select', options: smSensOpts.concat([[sg.distSens, 'Custom (' + sg.distSens + ')']]) }) + I('segments.' + i + '.switching', { label: 'Switching probability', t: 'pct' }) +
        I('segments.' + i + '.locked', { label: 'Locked (must be entered)', t: 'bool' }) + I('segments.' + i + '.entryCost', { label: 'Entry cost', t: 'money' })) + '</fieldset>').join('') + smAdd('segments', 'Add segment', ro);
  } else if (st === 'companies') {
    h += '<p class="small muted">Starting conditions. With several companies, teams are given them in turn (Team 1 → first company…), so you can create strategic variation — e.g. different starting cash.</p>' +
      c.companies.map((co, i) => '<fieldset class="sm-card"><legend><span class="sm-dot" style="background:' + esc(co.color) + '"></span><b>' + esc(co.name) + '</b>' + smRowActs('companies', i, ro) + '</legend>' + grid(
        I('companies.' + i + '.name', { label: 'Company name' }) + I('companies.' + i + '.color', { label: 'Colour', t: 'color' }) + I('companies.' + i + '.foundingYear', { label: 'Founded', t: 'number' }) + I('companies.' + i + '.employees', { label: 'Employees', t: 'number' }) +
        I('companies.' + i + '.cash', { label: 'Starting cash', t: 'money' }) + I('companies.' + i + '.assets', { label: 'Fixed assets (plant, equipment)', t: 'money' }) + I('companies.' + i + '.debt', { label: 'Debt', t: 'money' }) +
        I('companies.' + i + '.capacity', { label: 'Production capacity (per period)', t: 'number' }) + I('companies.' + i + '.inventory', { label: 'Inventory (units)', t: 'number' }) + I('companies.' + i + '.marketShare', { label: 'Starting market share', t: 'pct' }) +
        I('companies.' + i + '.brand', { label: 'Brand (0–100)', t: 'number', min: 0, max: 100 }) + I('companies.' + i + '.quality', { label: 'Quality (0–100)', t: 'number', min: 0, max: 100 }) + I('companies.' + i + '.tech', { label: 'Technology (0–100)', t: 'number', min: 0, max: 100 }) +
        I('companies.' + i + '.sustainability', { label: 'Sustainability (0–100)', t: 'number', min: 0, max: 100 }) + I('companies.' + i + '.distribution', { label: 'Distribution reach (0–100)', t: 'number', min: 0, max: 100 }) +
        I('companies.' + i + '.satisfaction', { label: 'Customer satisfaction (0–100)', t: 'number', min: 0, max: 100 }) + I('companies.' + i + '.morale', { label: 'Employee satisfaction (0–100)', t: 'number', min: 0, max: 100 })) + '</fieldset>').join('') + smAdd('companies', 'Add company profile', ro);
  } else if (st === 'competitors') {
    h += '<p class="small muted"><b>Static</b>: fixed (or scripted). <b>Follower</b>: matches your price cuts and marketing. <b>Aggressive</b>: undercuts the lowest price. <b>Premium</b>: moves up-market. Reaction strength 0–1. Leave segments empty to compete everywhere.</p>' +
      c.competitors.map((cp, i) => '<fieldset class="sm-card"><legend><b>' + esc(cp.name) + '</b> ' + badge(cp.behavior) + smRowActs('competitors', i, ro) + '</legend>' + grid(
        I('competitors.' + i + '.name', { label: 'Name' }) + I('competitors.' + i + '.behavior', { label: 'Behaviour', t: 'select', options: [['static', 'Static'], ['follower', 'Follower (reacts)'], ['aggressive', 'Aggressive'], ['premium', 'Premium'], ['scripted', 'Scripted']] }) +
        I('competitors.' + i + '.reaction', { label: 'Reaction strength (0–1)', t: 'number', min: 0, max: 1 }) + I('competitors.' + i + '.price', { label: 'Price', t: 'money' }) + I('competitors.' + i + '.costFloor', { label: 'Lowest price it will go to', t: 'money' }) +
        I('competitors.' + i + '.marketing', { label: 'Marketing per period', t: 'money' }) + I('competitors.' + i + '.share', { label: 'Starting share in its segments', t: 'pct' }) + I('competitors.' + i + '.quality', { label: 'Quality', t: 'number' }) + I('competitors.' + i + '.brand', { label: 'Brand', t: 'number' }) +
        I('competitors.' + i + '.distribution', { label: 'Distribution', t: 'number' }) + I('competitors.' + i + '.sustainability', { label: 'Sustainability', t: 'number' }) + I('competitors.' + i + '.tech', { label: 'Technology', t: 'number' }) +
        I('competitors.' + i + '.segments', { label: 'Segments (IDs)', t: 'list', ph: c.segments.map((x) => x.id).join(', ') })) + '</fieldset>').join('') + smAdd('competitors', 'Add competitor', ro);
  } else if (st === 'decisions') {
    const drv = Object.keys(V.drivers || {}).map((k) => [k, V.drivers[k].label]);
    const roles = [['', 'Any member']].concat((c.settings.teamRoles || []).map((r) => [r, r]));
    h += '<p class="small muted">Each decision drives part of the model. <b>Standard drivers</b> (price, production, marketing, R&D…) have built-in economics; several decisions can share a driver (e.g. digital and TV marketing with different efficiency). <b>Custom</b> decisions use formulas: a cost, and effects before the market (demand, unitCost, utility) or after it (company attributes or custom.&lt;name&gt;).</p>' +
      c.decisions.map((d, i) => { const P = 'decisions.' + i + '.'; return '<fieldset class="sm-card"><legend><b>' + esc(d.label) + '</b> ' + badge((V.drivers[d.driver] || {}).label || d.driver, 'outline') + (d.role ? ' ' + badge(d.role) : '') + smRowActs('decisions', i, ro) + '</legend>' + grid(
        I(P + 'label', { label: 'Label' }) + I(P + 'key', { label: 'Key (formulas: value / decision key)' }) + I(P + 'category', { label: 'Category', t: 'select', options: (V.categories || []) }) + I(P + 'driver', { label: 'Drives', t: 'select', options: drv }) +
        I(P + 'type', { label: 'Input', t: 'select', options: [['number', 'Number / slider'], ['percent', 'Percent'], ['select', 'Choice'], ['toggle', 'Yes / no']] }) + I(P + 'unit', { label: 'Unit', t: 'select', options: [['money', 'Money'], ['units', c.basics.unitName], ['people', 'People'], ['%', '%'], ['index', 'Index'], ['toggle', 'Yes/no'], ['number', 'Number']] }) +
        I(P + 'min', { label: 'Minimum', t: d.unit === 'money' ? 'money' : 'number' }) + I(P + 'max', { label: 'Maximum', t: d.unit === 'money' ? 'money' : 'number' }) + I(P + 'step', { label: 'Step', t: d.unit === 'money' ? 'money' : 'number' }) + I(P + 'default', { label: 'Default', t: d.unit === 'money' ? 'money' : 'number' }) +
        I(P + 'role', { label: 'Team role', t: 'select', options: roles }) + I(P + 'segment', { label: 'Segment (price per segment / entry)', t: 'select', options: [['', '—']].concat(c.segments.map((x) => [x.id, x.name])) }) +
        I(P + 'efficiency', { label: 'Efficiency multiplier', t: 'number', help: 'e.g. capacity per outlet' }) + I(P + 'enabledFrom', { label: 'Available from round', t: 'number', min: 1 }) + I(P + 'weight', { label: 'Scoring weight (decision quality)', t: 'number' }) +
        I(P + 'help', { label: 'Help for students', t: 'textarea', rows: 2, full: true }) +
        (d.driver === 'custom' ? I(P + 'cost', { label: 'Cost formula (e.g. value)', t: 'formula', full: true }) : '')) +
        (d.driver === 'custom' ? '<div class="sm-sub"><b class="small">Effects</b>' + (d.effects || []).map((e, j) => '<div class="sm-subrow">' + smInput(P + 'effects.' + j + '.when', e.when, { label: 'When', t: 'select', options: [['before', 'Before the market'], ['after', 'After the round']] }, ro) +
          smInput(P + 'effects.' + j + '.target', e.target, { label: 'Changes', list: 'smTargets' }, ro) + smInput(P + 'effects.' + j + '.expr', e.expr, { label: 'Formula (value, state.*, round)', t: 'formula', wide: true }, ro) + smRowActs(P + 'effects', j, ro, 'effects') + '</div>').join('') + smAdd(P + 'effects', 'Add effect', ro, 'effects') + '</div>' : '') + '</fieldset>'; }).join('') + smAdd('decisions', 'Add decision', ro) +
      '<datalist id="smTargets"><option value="demand"><option value="unitCost"><option value="utility">' + (V.stateKeys || []).map((k) => '<option value="' + k + '">').join('') + '<option value="custom.name"></datalist>';
  } else if (st === 'finance') {
    h += '<p class="small muted">The financial model turns decisions into an income statement, cash flow and balance sheet every round. These parameters set the economics — teams never see them directly.</p>' +
      grid(SM_FIN.map((f) => I('finance.' + f[0], { label: f[1], t: f[2], help: f[3] })).join(''));
  } else if (st === 'formulas') {
    const metrics = Object.keys(V.metrics || {});
    h += '<p class="small muted">Derived metrics you can show as KPIs, use in events and scoring. Safe formula language: numbers, + − × ÷ ^, comparisons, a ? b : c, and min, max, abs, round, floor, ceil, sqrt, log, exp, pow, clamp, avg. Names: <code>metric.revenue</code>, <code>state.brand</code>, <code>state.custom.name</code>, <code>formula.otherKey</code>, <code>round</code>.</p>' +
      c.formulas.map((fx, i) => '<fieldset class="sm-card"><legend><b>' + esc(fx.label) + '</b>' + smRowActs('formulas', i, ro) + '</legend>' + grid(I('formulas.' + i + '.label', { label: 'Label' }) + I('formulas.' + i + '.key', { label: 'Key' }) + I('formulas.' + i + '.format', { label: 'Format', t: 'select', options: [['money', 'Money'], ['pct', 'Percent'], ['num', 'Number'], ['index', 'Index'], ['ratio', 'Ratio']] }) + I('formulas.' + i + '.expr', { label: 'Formula', t: 'formula', full: true })) + '</fieldset>').join('') + smAdd('formulas', 'Add formula', ro) +
      '<details class="sm-ref"><summary class="small">Available metrics (' + metrics.length + ')</summary><div class="sm-chips">' + metrics.map((k) => '<code title="' + esc(V.metrics[k].label) + '">metric.' + k + '</code>').join(' ') + '</div></details>';
  } else if (st === 'events') {
    const targets = Object.keys(V.targets || {}).map((k) => [k, V.targets[k]]);
    h += '<p class="small muted"><b>Scheduled</b> events happen in the listed rounds. <b>Random</b> events happen with a probability (seeded, so a run can be reproduced). <b>Condition</b> events hit only the teams whose previous round matches a formula (e.g. <code>metric.quality &lt; 45</code>).</p>' +
      c.events.map((e, i) => { const P = 'events.' + i + '.'; return '<fieldset class="sm-card"><legend><b>' + esc(e.name) + '</b> ' + badge(e.trigger) + ' ' + badge(e.severity, e.severity === 'high' ? 'danger' : e.severity === 'medium' ? 'warning' : '') + smRowActs('events', i, ro) + '</legend>' + grid(
        I(P + 'name', { label: 'Name' }) + I(P + 'id', { label: 'ID' }) + I(P + 'category', { label: 'Type', t: 'select', options: [['economic', 'Economic'], ['market', 'Market'], ['supply', 'Supply'], ['technology', 'Technology'], ['regulatory', 'Regulatory'], ['social', 'Social']] }) +
        I(P + 'trigger', { label: 'Trigger', t: 'select', options: [['scheduled', 'Scheduled'], ['random', 'Random (probability)'], ['condition', 'Condition (per team)']] }) + I(P + 'rounds', { label: 'Rounds', t: 'rounds', help: 'Scheduled: when. Random/condition: window (empty = any round).' }) +
        I(P + 'probability', { label: 'Probability', t: 'pct' }) + I(P + 'duration', { label: 'Duration (rounds)', t: 'number', min: 1 }) + I(P + 'severity', { label: 'Severity', t: 'select', options: ['low', 'medium', 'high'] }) + I(P + 'once', { label: 'Only once', t: 'bool' }) +
        I(P + 'condition', { label: 'Condition (formula)', t: 'formula', wide: true }) + I(P + 'message', { label: 'News message for students', t: 'textarea', rows: 2, full: true })) +
        '<div class="sm-sub"><b class="small">Impact</b>' + e.modifiers.map((m, j) => '<div class="sm-subrow">' + smInput(P + 'modifiers.' + j + '.target', m.target, { label: 'Changes', t: 'select', options: targets }, ro) + smInput(P + 'modifiers.' + j + '.op', m.op, { label: 'How', t: 'select', options: [['mul', '× multiply'], ['add', '+ add'], ['set', '= set to']] }, ro) + smInput(P + 'modifiers.' + j + '.value', m.value, { label: 'Value', t: 'number' }, ro) + smRowActs(P + 'modifiers', j, ro, 'modifiers') + '</div>').join('') + smAdd(P + 'modifiers', 'Add impact', ro, 'modifiers') + '</div></fieldset>'; }).join('') + smAdd('events', 'Add event', ro);
  } else if (st === 'rounds') {
    h += '<p class="small muted">' + c.rounds.length + ' rounds of one ' + esc(c.basics.period.toLowerCase()) + ' each. Briefs set the scene; leave "decisions" empty to offer every decision.</p>' +
      c.rounds.map((r, i) => '<fieldset class="sm-card"><legend><span class="sm-roundno">' + (i + 1) + '</span><b>' + esc(r.title) + '</b>' + smRowActs('rounds', i, ro) + '</legend>' + grid(I('rounds.' + i + '.title', { label: 'Title' }) + I('rounds.' + i + '.focus', { label: 'Focus', wide: true }) + I('rounds.' + i + '.brief', { label: 'Brief for students', t: 'textarea', rows: 3, full: true }) +
        I('rounds.' + i + '.decisions', { label: 'Decisions in this round (keys; empty = all)', t: 'list', full: true, ph: c.decisions.map((x) => x.key).join(', ') }) + '<p class="xs muted full">Events this round: ' + (c.events.filter((e) => e.rounds.indexOf(i + 1) >= 0).map((e) => esc(e.name) + ' (' + e.trigger + ')').join(', ') || 'none scheduled') + '</p>') + '</fieldset>').join('') + smAdd('rounds', 'Add round', ro);
  } else if (st === 'kpis') {
    const opts = Object.keys(V.metrics || {}).map((k) => [k, V.metrics[k].label + ' (' + k + ')']).concat(c.formulas.map((f) => [f.key, f.label + ' (formula)']));
    const cats = c.scoring.categories.map((x) => [x.key, x.label]);
    h += '<p class="small muted">Each KPI scores 0 at its floor and 100 at its target (for "lower is better", the floor is the high value). Category scores are weighted averages of their KPIs.</p>' +
      c.kpis.map((k, i) => { const P = 'kpis.' + i + '.'; return '<fieldset class="sm-card"><legend><b>' + esc(k.label) + '</b> ' + badge((c.scoring.categories.find((x) => x.key === k.category) || {}).label || k.category, 'outline') + smRowActs('kpis', i, ro) + '</legend>' + grid(
        I(P + 'label', { label: 'Label' }) + I(P + 'key', { label: 'Measure', t: 'select', options: opts.some((o) => o[0] === k.key) ? opts : opts.concat([[k.key, k.key]]) }) + I(P + 'category', { label: 'Scoring category', t: 'select', options: cats.some((o) => o[0] === k.category) ? cats : cats.concat([[k.category, k.category]]) }) +
        I(P + 'dir', { label: 'Better when', t: 'select', options: [['up', 'Higher'], ['down', 'Lower']] }) + I(P + 'floor', { label: 'Floor (scores 0)', t: k.format === 'money' ? 'money' : 'number' }) + I(P + 'target', { label: 'Target (scores 100)', t: k.format === 'money' ? 'money' : 'number' }) +
        I(P + 'weight', { label: 'Weight in category', t: 'number' }) + I(P + 'format', { label: 'Format', t: 'select', options: [['money', 'Money'], ['pct', 'Percent (0.12 = 12%)'], ['num', 'Number'], ['index', 'Index 0–100'], ['ratio', 'Ratio']] }) + I(P + 'formula', { label: 'Own formula (optional)', t: 'formula', wide: true })) + '</fieldset>'; }).join('') + smAdd('kpis', 'Add KPI', ro);
  } else if (st === 'scoring') {
    const tot = c.scoring.categories.reduce((a, x) => a + (Number(x.weight) || 0), 0);
    h += '<p class="small muted">Weights are yours to set — they are not built in. Relative scoring blends each KPI\'s target score with the team\'s position in the class.</p>' +
      '<div class="sm-weights">' + c.scoring.categories.map((x, i) => '<div class="sm-weightrow">' + smInput('scoring.categories.' + i + '.label', x.label, { label: 'Category' }, ro) + smInput('scoring.categories.' + i + '.key', x.key, { label: 'Key' }, ro) + smInput('scoring.categories.' + i + '.weight', x.weight, { label: 'Weight %', t: 'number', min: 0, max: 100 }, ro) +
        '<div class="sm-weightbar"><i style="width:' + (tot ? Math.round(x.weight / tot * 100) : 0) + '%"></i></div>' + smRowActs('scoring.categories', i, ro, 'scoring.categories') + '</div>').join('') + '</div>' + smAdd('scoring.categories', 'Add category', ro, 'scoring.categories') +
      '<p class="small ' + (Math.abs(tot - 100) > 0.5 ? 'sm-warn' : 'muted') + '">Total: ' + tot + '%' + (Math.abs(tot - 100) > 0.5 ? ' — weights are used in proportion; 100% is easier to explain to students.' : '') + '</p>' +
      grid(smInput('scoring.relative', c.scoring.relative, { label: 'Relative scoring share', t: 'pct', help: '0% = targets only; 30% = blend with class position' }, ro) + smInput('scoring.final', c.scoring.final, { label: 'Final score', t: 'select', options: [['weighted', 'Weighted average (later rounds count more)'], ['average', 'Average of all rounds'], ['final', 'Last round only']] }, ro));
  } else if (st === 'settings') {
    h += '<h3 class="sm-h3">Gameplay</h3>' + grid(I('settings.leaderboard', { label: 'Students see', t: 'select', options: [['full', 'Full leaderboard'], ['anonymous', 'Anonymous ranking'], ['own', 'Own rank only'], ['none', 'No ranking']] }) +
      I('settings.leaderboardMetric', { label: 'Rank by', t: 'select', options: [['score', 'Overall score'], ['netProfit', 'Profit'], ['revenue', 'Revenue'], ['marketShare', 'Market share'], ['roi', 'ROI'], ['satisfaction', 'Customer satisfaction'], ['sustainability', 'Sustainability']] }) +
      I('settings.roleMode', { label: 'Role-based decisions (CFO, CMO… edit their own areas; the CEO submits)', t: 'bool' }) + I('settings.requireApprovals', { label: 'Each role approves its area before the CEO submits', t: 'bool' }) +
      I('settings.teamRoles', { label: 'Team roles', t: 'list', wide: true }) + I('settings.carryForward', { label: 'Teams that do not submit keep last round\'s decisions', t: 'bool' }) + I('settings.whatIf', { label: 'What-if analysis for students', t: 'bool' }) + I('settings.selfTeams', { label: 'Students may pick their own team', t: 'bool' })) +
      '<h3 class="sm-h3">Debrief</h3>' + grid(I('settings.learningPoints', { label: 'Key learning points (one per line)', t: 'lines', rows: 4, full: true }) + I('settings.reflectionQuestions', { label: 'Reflection questions (one per line)', t: 'lines', rows: 4, full: true }) + I('settings.debriefNotes', { label: 'Notes for the debrief', t: 'textarea', rows: 3, full: true })) +
      '<h3 class="sm-h3">Assessment</h3><p class="small muted">How the simulation contributes to the course grade (sent to the gradebook from the run).</p>' + grid(I('settings.assessment.simulation', { label: 'Simulation score %', t: 'number' }) + I('settings.assessment.team', { label: 'Team performance (rank) %', t: 'number' }) + I('settings.assessment.decision', { label: 'Decision quality %', t: 'number' }) +
        I('settings.assessment.participation', { label: 'Participation %', t: 'number' }) + I('settings.assessment.reflection', { label: 'Reflection %', t: 'number' }) + I('settings.assessment.maxGrade', { label: 'Grade out of', t: 'number' }));
  } else if (st === 'health') return smHealthHtml(ro);
  return h + smStepFoot(ro);
}
function smHealthHtml(ro) {
  const v = SM.sim.validation, sim = SM.sim;
  const ic = { ok: 'checkCircle', warn: 'info', error: 'alert' };
  return '<div class="sm-stephead"><h2>' + icon('checkCircle') + ' Simulation health</h2></div>' +
    '<ul class="sm-health">' + v.checks.map((c) => '<li class="' + c.status + '">' + icon(ic[c.status]) + '<div><b>' + esc(c.label) + '</b>' + (c.messages.length ? '<ul>' + c.messages.map((m) => '<li class="small">' + esc(m) + '</li>').join('') + '</ul>' : '') + '</div></li>').join('') + '</ul>' +
    (ro ? '' : '<div class="sm-publish card-pad"><h3 class="sm-h3" style="margin-top:0">Preview and publish</h3><p class="small muted">Play it yourself first: Preview runs every round with the current settings against the computer competitors and shows the calculations. Publishing freezes a version that classes can run; later edits never change a run in progress.</p>' +
      '<div class="row-wrap" style="gap:.5rem"><button class="btn" type="button" data-act="smPreviewStart"' + (v.ok ? '' : ' disabled') + '>' + icon('play') + 'Preview as student</button>' +
      '<button class="btn btn-primary" type="button" data-act="smPublishAsk"' + (v.ok ? '' : ' disabled title="Fix the errors first"') + '>' + icon('send') + (sim.version ? 'Publish new version' : 'Publish v1.0') + '</button>' +
      (sim.version ? '<button class="btn" type="button" data-act="smRunNew" data-id="' + esc(sim.id) + '">' + icon('live') + 'Run with a class</button>' : '') + '</div>' + (v.ok ? '' : '<p class="small sm-warn">Fix the errors above to preview and publish.</p>') + '</div>') +
    '<div class="card-pad"><h3 class="sm-h3" style="margin-top:0">Versions</h3>' + (sim.versions.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Version</th><th>Published</th><th>By</th><th>Note</th><th></th></tr></thead><tbody>' + sim.versions.slice().reverse().map((x) => '<tr><td><b>v' + esc(x.v) + '</b></td><td class="small">' + esc(fmt(x.at)) + '</td><td class="small">' + esc(x.by) + '</td><td class="small">' + esc(x.note || '') + '</td><td class="actions nowrap">' + (ro ? '' : '<button class="btn btn-sm btn-ghost" type="button" data-act="smRestoreV" data-v="' + esc(x.v) + '">Restore</button>') + '<button class="btn btn-sm btn-ghost" type="button" data-act="smDup" data-id="' + esc(sim.id) + '" data-v="' + esc(x.v) + '">Copy</button><button class="btn btn-sm btn-ghost" type="button" data-act="smExport" data-id="' + esc(sim.id) + '" data-v="' + esc(x.v) + '">Export</button></td></tr>').join('') + '</tbody></table></div>' : '<p class="small muted">Not published yet.</p>') +
    '<div class="row-wrap" style="gap:.5rem;margin-top:.75rem"><button class="btn btn-sm" type="button" data-act="smExport" data-id="' + esc(sim.id) + '">' + icon('download', 'i-sm') + 'Export current draft</button>' + (ro ? '' : '<label class="check inline"><input type="checkbox" data-change="smShareLib"' + (sim.library ? ' checked' : '') + '><span>Share with the institution library</span></label>') + '</div></div>';
}
ACT.smPreviewStart = (d, btn) => busy(btn, async () => { if (SM.dirty) await smSaveStep(true); const r = await call('smPreview', { id: SM.sim.id }); go('/sim/play/' + r.id); });
ACT.smPublishAsk = () => formModal('Publish a version', 'Classes run a published version. You can keep editing and publish again later.', 'smPublish', field('Version note', '<input type="text" name="note" maxlength="300" placeholder="e.g. First class, Section A">') + (SM.sim.version ? check('major', 'Major change (new version ' + (Number(String(SM.sim.version).split('.')[0]) + 1) + '.0)', false) : ''), 'Publish', 'narrow');
FORMS.smPublish = (f, btn) => busy(btn, async () => { const r = await call('smPublish', { id: SM.sim.id, note: f.elements.note.value, major: f.elements.major ? f.elements.major.checked : false }); closeModal(); toast('Published v' + r.version + '.'); go('/sim/build/' + SM.sim.id + '?step=health'); });
ACT.smRestoreV = async (d) => { if (!await confirmBox('Restore version ' + d.v + '?', '<p>The current draft is replaced by version ' + esc(d.v) + '. Publish again to use it in new runs.</p>', 'Restore')) return; busy(null, async () => { await call('smRestoreVersion', { id: SM.sim.id, v: d.v }); toast('Restored.'); go('/sim/build/' + SM.sim.id + '?step=basics'); }); };
ACT.smShareLib = (d, el) => busy(null, async () => { await call('smShare', { id: SM.sim.id, library: el.checked }); toast(el.checked ? 'Shared with the institution library.' : 'Removed from the library.'); });

/* =====================================================================
   RUN: CREATE AND CONSOLE (faculty)
   ===================================================================== */
ACT.smRunNew = (d) => busy(null, async () => {
  const sim = await call('smGet', { id: d.id });
  const courses = (await call('stCourses')).courses.filter((c) => c.editor);
  if (!courses.length) { toast('You do not teach any courses yet.', 'err'); return; }
  formModal('Run with a class', 'Choose the course (class), the version and how teams are formed. Students are notified when you launch.', 'smRunNew',
    '<input type="hidden" name="simId" value="' + esc(sim.id) + '"><div class="form-grid">' + field('Course', '<select name="courseId" required>' + courses.map((c) => '<option value="' + esc(c.id) + '">' + esc(c.shortname + ' · ' + c.fullname) + '</option>').join('') + '</select>') +
    field('Version', '<select name="v">' + sim.versions.slice().reverse().map((x) => '<option value="' + esc(x.v) + '">v' + esc(x.v) + (x.note ? ' — ' + esc(x.note) : '') + '</option>').join('') + '</select>') + '</div>' +
    field('Run title', '<input type="text" name="title" maxlength="160" value="' + esc(sim.title + ' — ' + new Date().toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })) + '">') +
    '<div class="form-grid">' + field('Teams', '<select name="method"><option value="random">Random teams from the class</option><option value="empty">Empty teams (I will assign)</option><option value="individual">Individual play (one student = one company)</option></select>') + field('Number of teams', '<input type="number" name="teams" min="1" max="20" value="4">') + '</div>' +
    '<div class="form-grid">' + field('Time per round (hours, 0 = no deadline)', '<input type="number" name="roundHours" min="0" max="1440" value="0">') + '<div>' + check('autoRun', 'Run each round automatically at the deadline', false) + '</div></div>', 'Create run', 'wide');
});
FORMS.smRunNew = (f, btn) => busy(btn, async () => { const el = f.elements; const r = await call('smRunCreate', { simId: el.simId.value, courseId: el.courseId.value, v: el.v.value, title: el.title.value, teams: el.method.value === 'individual' ? 0 : el.teams.value, method: el.method.value === 'individual' ? 'random' : el.method.value, mode: el.method.value === 'individual' ? 'individual' : 'team', roundHours: el.roundHours.value, autoRun: el.autoRun.checked }); closeModal(); toast('Run created. Check the teams, then launch.'); go('/sim/run/' + r.id + '?tab=teams'); });

async function viewSmRun(id, params) {
  const r = await call('smRunGet', { id });
  if (!r.manage && !r.observe) { go('/sim/play/' + id); return null; }
  if (r.preview) { go('/sim/play/' + id); return null; }
  const tab = params.get('tab') || (r.status === 'setup' ? 'teams' : 'live');
  SM.run = r;
  S.onLeave = () => { clearInterval(SM.runPoll); SM.runPoll = null; };
  clearInterval(SM.runPoll);
  if (r.status === 'running') SM.runPoll = setInterval(async () => { try { const x = await call('smRunGet', { id }); if (x.round !== SM.run.round || x.status !== SM.run.status || JSON.stringify(x.teams.map((t) => t.submitted)) !== JSON.stringify(SM.run.teams.map((t) => t.submitted))) refresh(); } catch (e) { /* offline */ } }, 20000);
  const tabs = [['live', 'Live', 'live'], ['teams', 'Teams', 'users'], ['analytics', 'Analytics', 'trending'], ['assessment', 'Assessment', 'award'], ['settings', 'Settings', 'settings']].filter((t) => r.manage || ['live', 'analytics'].indexOf(t[0]) >= 0);
  let body = '';
  if (tab === 'live') body = smRunLive(r);
  else if (tab === 'teams') body = smRunTeams(r);
  else if (tab === 'analytics') body = await smRunAnalytics(r, params);
  else if (tab === 'assessment') body = await smRunAssessment(r);
  else if (tab === 'settings') body = await smRunSettings(r);
  return {
    title: r.title,
    html: pageHead(r.title, { crumbs: [['Business simulations', '/sim'], [r.title]], sub: smStatus(r.status) + ' ' + esc(r.course) + ' · ' + esc(r.simTitle) + ' v' + esc(r.version) + (r.observe ? ' ' + badge('Observer — read only', 'info', 'eye') : ''), actions: r.manage ? smRunActions(r) : '' }) +
      smRunStepper(r) + '<nav class="tabs" aria-label="Run">' + tabs.map((t) => '<a class="tab' + (t[0] === tab ? ' active' : '') + '" href="#/sim/run/' + esc(r.id) + '?tab=' + t[0] + '">' + icon(t[2]) + t[1] + '</a>').join('') + '</nav>' + body,
    after: () => mountCharts()
  };
}
function smRunStepper(r) {
  return '<ol class="sm-stepper" aria-label="Rounds">' + r.roundPlan.map((p) => { const done = p.n < r.round || (r.status === 'completed' && p.n <= r.round); const cur = p.n === r.round && r.status !== 'completed'; return '<li class="' + (done ? 'done' : cur ? 'current' : '') + '"><span class="n">' + (done ? icon('check', 'i-sm') : p.n) + '</span><span class="t">' + esc(p.title) + '</span></li>'; }).join('') + '</ol>';
}
function smRunActions(r) {
  const submitted = r.teams.filter((t) => t.submitted).length;
  if (r.status === 'setup') return '<button class="btn btn-primary" data-act="smLaunch">' + icon('play') + 'Launch simulation</button>';
  if (r.status === 'completed') return '<a class="btn" href="#/sim/report/' + esc(r.id) + '">' + icon('printer') + 'Report (PDF)</a><button class="btn" data-act="smReport" data-f="xlsx">' + icon('download') + 'Excel</button><div class="menu-wrap"><button class="btn-icon" data-act="menu" aria-label="More">' + icon('more') + '</button><div class="menu"><button class="menu-item" data-act="smUndo">' + icon('undo') + 'Re-open the last round</button></div></div>';
  return (r.status === 'paused' ? '<button class="btn btn-primary" data-act="smCtl" data-a="resume">' + icon('play') + 'Resume</button>' :
    '<button class="btn btn-primary" data-act="smRunRound">' + icon('zap') + 'Run round ' + r.round + ' (' + submitted + '/' + r.teams.length + ' submitted)</button><button class="btn" data-act="smCtl" data-a="pause">' + icon('clock') + 'Pause</button>') +
    '<div class="menu-wrap"><button class="btn-icon" data-act="menu" aria-label="More round controls">' + icon('more') + '</button><div class="menu"><button class="menu-item" data-act="smDeadline">' + icon('clock') + 'Set deadline</button><button class="menu-item" data-act="smCtl" data-a="autorun" data-on="' + (r.autoRun ? '' : '1') + '">' + icon('zap') + (r.autoRun ? 'Stop running rounds at the deadline' : 'Run rounds automatically at the deadline') + '</button>' +
    (r.round > 1 ? '<button class="menu-item" data-act="smUndo">' + icon('undo') + 'Roll back the last round</button>' : '') + '<button class="menu-item danger" data-act="smEnd">' + icon('flag') + 'End the simulation now</button></div></div>';
}
ACT.smLaunch = (d, btn) => busy(btn, async () => { await call('smLaunch', { id: SM.run.id }); toast('Launched — students have been notified.'); go('/sim/run/' + SM.run.id + '?tab=live'); });
ACT.smRunRound = async (d, btn) => {
  const missing = SM.run.teams.filter((t) => !t.submitted).length;
  if (missing && !await confirmBox('Run round ' + SM.run.round + ' now?', '<p>' + missing + ' team(s) have not submitted. They will play with their saved draft, or last round\'s decisions.</p>', 'Run round')) return;
  busy(btn, async () => { await call('smControl', { id: SM.run.id, action: 'run' }); toast('Round ' + SM.run.round + ' complete — results sent to students.'); refresh(); });
};
ACT.smCtl = (d, btn) => busy(btn, async () => { await call('smControl', { id: SM.run.id, action: d.a, on: !!d.on }); refresh(); });
ACT.smUndo = async () => { if (!await confirmBox('Roll back the last round?', '<p>The round\'s results are removed and the round re-opens with the decisions teams made. Use this to fix a mistake (e.g. a team was missing).</p>', 'Roll back', true)) return; busy(null, async () => { await call('smControl', { id: SM.run.id, action: 'undo', confirm: true }); toast('Round re-opened.'); refresh(); }); };
ACT.smEnd = async () => { if (!await confirmBox('End the simulation now?', '<p>Remaining rounds will not be played. Results so far are kept and the debrief opens.</p>', 'End simulation', true)) return; busy(null, async () => { await call('smControl', { id: SM.run.id, action: 'complete' }); refresh(); }); };
ACT.smDeadline = () => formModal('Round deadline', 'Applies to the open round and every later round.', 'smDeadline', field('Hours per round (0 = no deadline)', '<input type="number" name="hours" min="0" max="1440" value="' + (SM.run.roundHours || 24) + '">') + check('autoRun', 'Run the round automatically when the deadline passes', SM.run.autoRun), 'Save', 'narrow');
FORMS.smDeadline = (f, btn) => busy(btn, async () => { await call('smControl', { id: SM.run.id, action: 'deadline', hours: f.elements.hours.value }); await call('smControl', { id: SM.run.id, action: 'autorun', on: f.elements.autoRun.checked }); closeModal(); refresh(); });
ACT.smReport = (d, btn) => busy(btn, async () => { const x = await call('smReport', { id: SM.run.id, format: d.f }); downloadBase64(x.name, x.data, x.mime); });

function smRunLive(r) {
  const c = r.console, cur = r.basics.currency;
  const lb = r.leaderboard.rows;
  const statusBadge = (t) => (t.status === 'submitted' ? badge('Submitted', 'success', 'check') : t.status === 'draft' ? badge('Working (' + t.edits + ' edits)', 'warning') : badge('Not started'));
  return '<div class="sm-cols"><section class="sm-col">' +
    (r.status === 'setup' ? notice('Not launched yet. Check the <a href="#/sim/run/' + esc(r.id) + '?tab=teams">teams</a>, then press <b>Launch simulation</b>.', 'warn') : '') +
    (r.roundInfo && r.status !== 'completed' ? '<section class="card"><div class="card-head"><h2>Round ' + r.round + ': ' + esc(r.roundInfo.title) + '</h2>' + (r.roundOpen ? badge('Open', 'primary') : '') + ' ' + smDeadline(r.deadline) + (r.autoRun ? ' ' + badge('Runs at deadline', 'info', 'zap') : '') + '</div><div class="card-body"><p class="small">' + esc(r.roundInfo.brief) + '</p>' +
      '<div class="table-wrap"><table class="table"><thead><tr><th>Team</th><th>Members</th><th>Decisions</th><th>Last change</th><th class="tnum">Score</th></tr></thead><tbody>' + c.teams.map((t) => '<tr><td><span class="sm-dot" style="background:' + esc(t.color) + '"></span><b>' + esc(t.name) + '</b></td><td class="small">' + t.members.map((m) => esc(m.name) + (m.role ? ' <span class="xs muted">' + esc(m.role) + '</span>' : '')).join(', ') + '</td><td>' + statusBadge(t) + '</td><td class="small">' + (t.lastEdit ? esc(rel(t.lastEdit)) : '—') + '</td><td class="tnum">' + (t.score == null ? '—' : t.score) + '</td></tr>').join('') + '</tbody></table></div></div></section>' : '') +
    (c.roundsRun.length ? '<section class="card"><div class="card-head"><h2>Class average score by round</h2></div><div class="card-body">' + chartSlot('lines', { labels: c.roundsRun.map((x) => 'R' + x.n), series: [{ name: 'Class average', color: 'var(--accent)', values: c.roundsRun.map((x) => x.avgScore), strong: true }], label: 'Class average score by round', yFmt: (v) => Math.round(v) }) + '</div></section>' : '') +
    '<section class="card"><div class="card-head"><h2>Announcement</h2></div><form class="card-body" data-form="smAnnounce"><textarea name="text" rows="2" maxlength="1000" placeholder="e.g. Round 3 runs on Friday at 5 pm. Watch your cash!"></textarea><div class="form-actions"><button class="btn btn-sm btn-primary">' + icon('megaphone', 'i-sm') + 'Send to all teams</button></div>' +
    (r.announcements.length ? '<ul class="sm-activity">' + r.announcements.map((a) => '<li><span class="xs muted">' + esc(rel(a.at)) + '</span> ' + esc(a.text) + '</li>').join('') + '</ul>' : '') + '</form></section></section>' +
    '<aside class="sm-col side"><section class="card"><div class="card-head"><h2>Leaderboard</h2></div><div class="card-body">' + (lb.length ? '<ol class="sm-lb">' + lb.map((x) => '<li><span class="rk">' + x.rank + '</span><span class="sm-dot" style="background:' + esc(x.color || '#888') + '"></span><span class="nm">' + esc(x.name) + '</span><b class="tnum">' + x.score + '</b><span class="xs muted">' + smMoney(x.netProfit, cur) + ' · ' + smFmt(x.marketShare, 'pct') + '</span></li>').join('') + '</ol>' : '<p class="small muted">After the first round.</p>') + '</div></section>' +
    '<section class="card"><div class="card-head"><h2>Events</h2></div><div class="card-body">' + (r.events.length ? r.events.map((e) => '<div class="sm-news ' + esc(e.severity || '') + '"><b>' + esc(e.name) + '</b> <span class="xs muted">R' + e.start + (e.until > e.start ? '–' + e.until : '') + (e.teamOnly ? ' · some teams' : '') + '</span><p class="small">' + esc(e.message || '') + '</p></div>').join('') : '<p class="small muted">None yet.</p>') + '</div></section></aside></div>';
}
FORMS.smAnnounce = (f, btn) => busy(btn, async () => { await call('smAnnounce', { id: SM.run.id, text: f.elements.text.value }); toast('Sent.'); refresh(); });

function smRunTeams(r) {
  const c = r.console, ro = !r.manage, setup = r.status === 'setup';
  const roles = r.settings.teamRoles;
  SM.teamDraft = r.teams.map((t) => ({ id: t.id, name: t.name, company: t.company, members: t.members.map((m) => ({ uid: m.uid, role: m.role })) }));
  const unassigned = c.students.filter((u) => !u.team);
  return (setup && !ro ? '<section class="card"><div class="card-head"><h2>Form teams</h2></div><div class="card-body row-wrap" style="gap:.5rem;align-items:flex-end"><label class="sm-field"><span class="sm-lbl">Teams</span><input type="number" id="smTeamCount" min="1" max="20" value="' + Math.max(1, r.teams.length) + '" style="width:90px"></label>' +
      '<button class="btn" data-act="smAutoTeams" data-m="random">' + icon('rotate', 'i-sm') + 'Random teams</button><button class="btn" data-act="smAutoTeams" data-m="empty">Empty teams</button><button class="btn" data-act="smAutoTeams" data-m="individual">One student per company</button><span class="xs muted">' + c.students.length + ' students in the course</span></div></section>' : '') +
    (unassigned.length ? notice(unassigned.length + ' student(s) not in a team: ' + unassigned.map((u) => esc(u.name)).join(', ') + '.', 'warn') : '') +
    '<div class="sm-teamgrid">' + r.teams.map((t, i) => '<section class="card sm-teamcard"><div class="card-head"><span class="sm-dot" style="background:' + esc(t.color) + '"></span>' + (ro ? '<h2>' + esc(t.name) + '</h2>' : '<input type="text" class="sm-teamname" value="' + esc(t.name) + '" data-input="smTeamName" data-i="' + i + '" data-delay="300" aria-label="Team name" maxlength="60">') + '</div><div class="card-body">' +
      '<ul class="sm-members">' + t.members.map((m) => '<li>' + avatar(m.name, 'sm') + '<span>' + esc(m.name) + '</span>' + (ro ? '<span class="xs muted">' + esc(m.role) + '</span>' : '<select data-change="smTeamRole" data-i="' + i + '" data-uid="' + esc(m.uid) + '" aria-label="Role"><option value="">—</option>' + roles.map((x) => '<option' + (x === m.role ? ' selected' : '') + '>' + esc(x) + '</option>').join('') + '</select><button class="btn-icon sm" data-act="smTeamRemove" data-i="' + i + '" data-uid="' + esc(m.uid) + '" aria-label="Remove from team">' + icon('x') + '</button>') + '</li>').join('') + '</ul>' +
      (ro ? '' : '<select data-change="smTeamAdd" data-i="' + i + '" aria-label="Add a student"><option value="">+ Add student…</option>' + c.students.filter((u) => !t.members.some((m) => m.uid === u.uid)).map((u) => '<option value="' + esc(u.uid) + '">' + esc(u.name) + (u.team ? ' (' + esc(u.team) + ')' : '') + '</option>').join('') + '</select>') + '</div></section>').join('') + '</div>' +
    (ro ? '' : '<div class="form-actions"><button class="btn btn-primary" data-act="smTeamsSave">' + icon('check') + 'Save teams</button></div>');
}
ACT.smAutoTeams = (d, btn) => busy(btn, async () => { await call('smRunTeams', { id: SM.run.id, auto: d.m, count: Number($('#smTeamCount').value) || 4 }); refresh(); });
INPUTS.smTeamName = (el) => { SM.teamDraft[Number(el.dataset.i)].name = el.value; };
ACT.smTeamRole = (d, el) => { const m = SM.teamDraft[Number(d.i)].members.find((x) => x.uid === d.uid); if (m) m.role = el.value; };
ACT.smTeamAdd = (d, el) => { if (!el.value) return; SM.teamDraft.forEach((t) => { t.members = t.members.filter((m) => m.uid !== el.value); }); SM.teamDraft[Number(d.i)].members.push({ uid: el.value, role: '' }); smTeamsSave(); };
ACT.smTeamRemove = (d) => { const t = SM.teamDraft[Number(d.i)]; t.members = t.members.filter((m) => m.uid !== d.uid); smTeamsSave(); };
function smTeamsSave() { return busy(null, async () => { await call('smRunTeams', { id: SM.run.id, teams: SM.teamDraft }); refresh(); }); }
ACT.smTeamsSave = (d, btn) => busy(btn, async () => { await call('smRunTeams', { id: SM.run.id, teams: SM.teamDraft }); toast('Teams saved.'); refresh(); });

async function smRunAnalytics(r, params) {
  if (!r.console.roundsRun.length) return '<div class="card card-pad">' + emptyState('trending', 'No results yet', 'Analytics appear after the first round.', '', false) + '</div>';
  const a = await call('smAnalytics', { id: r.id });
  const cur = r.basics.currency;
  const labels = a.classAverage.map((x) => 'R' + x.n);
  const kpiKey = params.get('kpi') || (a.kpiTrends[0] || {}).key;
  const kt = a.kpiTrends.find((k) => k.key === kpiKey) || a.kpiTrends[0];
  const kfmt = (v) => smFmt(v, kt.format, cur);
  const teamDebrief = params.get('debrief');
  return '<div class="grid-4 sm-kpis">' + statCard('users', 'indigo', a.teams.length, 'Teams') + statCard('layers', 'blue', a.roundsRun + ' / ' + a.rounds, 'Rounds run') + statCard('award', 'violet', a.classAverage[a.classAverage.length - 1].avg, 'Class average (last round)') + statCard('alert', 'amber', a.mistakes.reduce((x, m) => x + m.count, 0), 'Strategic mistakes') + '</div>' +
    '<section class="card"><div class="card-head"><h2>Team scores by round</h2></div><div class="card-body">' + chartSlot('lines', { labels, series: a.teams.map((t) => ({ name: t.name, color: t.color, values: t.scores })).concat([{ name: 'Class average', color: 'var(--muted)', values: a.classAverage.map((x) => x.avg), dim: true }]), label: 'Team scores by round', yFmt: (v) => Math.round(v) }) + '</div></section>' +
    '<section class="card"><div class="card-head"><h2>Rankings</h2></div><div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>Team</th><th class="tnum">Final</th>' + r.categories.map((c) => '<th class="tnum" title="' + esc(c.label) + '">' + esc(c.label.split(' ')[0]) + '</th>').join('') + '<th></th></tr></thead><tbody>' +
    a.teams.map((t) => '<tr><td>' + t.rank + '</td><td><span class="sm-dot" style="background:' + esc(t.color) + '"></span><b>' + esc(t.name) + '</b><div class="xs muted">' + esc(t.members.join(', ')) + '</div></td><td class="tnum"><b>' + t.final + '</b></td>' + r.categories.map((c) => '<td class="tnum">' + (t.categories[c.key] == null ? '—' : Math.round(t.categories[c.key])) + '</td>').join('') + '<td><a class="btn btn-sm btn-ghost" href="#/sim/run/' + esc(r.id) + '?tab=analytics&debrief=' + esc(t.id) + '">Debrief</a></td></tr>').join('') + '</tbody></table></div></section>' +
    '<section class="card"><div class="card-head"><h2>KPI trends</h2><select data-change="smKpiPick" aria-label="KPI">' + a.kpiTrends.map((k) => '<option value="' + esc(k.key) + '"' + (k.key === kt.key ? ' selected' : '') + '>' + esc(k.label) + '</option>').join('') + '</select></div><div class="card-body">' + chartSlot('lines', { labels, series: kt.series.map((x) => ({ name: x.team, color: x.color, values: x.values })), target: kt.target, label: kt.label + ' by team', yFmt: kfmt, valFmt: kfmt }) + '</div></section>' +
    '<div class="grid-2"><section class="card"><div class="card-head"><h2>Learning outcomes</h2></div><div class="card-body">' + a.outcomes.map((o) => '<div class="sm-outcome"><div class="row"><b class="small">' + esc(o.label) + '</b><span class="spacer"></span><span class="small tnum">avg ' + (o.average == null ? '—' : o.average) + ' · ' + (o.achieved == null ? '—' : o.achieved + '% of teams ≥ 60') + '</span></div><div class="progress"><i style="width:' + (o.achieved || 0) + '%"></i></div></div>').join('') +
    (a.objectives.length ? '<div class="sm-sub"><b class="small">Objectives</b><ul class="small">' + a.objectives.map((o) => '<li>' + esc(o) + '</li>').join('') + '</ul></div>' : '') + '</div></section>' +
    '<section class="card"><div class="card-head"><h2>Strategic mistakes</h2></div><div class="card-body">' + (a.mistakes.length ? '<ul class="sm-mistakes">' + a.mistakes.map((m) => '<li><b class="tnum">' + m.count + '×</b> ' + esc(m.text) + '<div class="xs muted">' + esc(m.teams.join(', ')) + '</div></li>').join('') + '</ul>' : '<p class="small muted">None detected.</p>') + '</div></section></div>' +
    '<section class="card"><div class="card-head"><h2>Decision patterns</h2><span class="xs muted">mean (min–max) across teams</span></div><div class="table-wrap"><table class="table"><thead><tr><th>Decision</th>' + labels.map((l) => '<th class="tnum">' + l + '</th>').join('') + '</tr></thead><tbody>' +
    a.decisionPatterns.map((d) => '<tr><td><b class="small">' + esc(d.label) + '</b></td>' + d.rounds.map((x) => '<td class="tnum small nowrap">' + (x.mean == null ? '—' : d.type === 'toggle' ? x.yes + '% yes' : smUnitFmt(x.mean, d.unit, r.basics) + '<div class="xs muted">' + smUnitFmt(x.min, d.unit, r.basics) + '–' + smUnitFmt(x.max, d.unit, r.basics) + '</div>') + '</td>').join('') + '</tr>').join('') + '</tbody></table></div></section>' +
    '<section class="card"><div class="card-head"><h2>Individual performance</h2></div><div class="table-wrap"><table class="table"><thead><tr><th>Student</th><th>Team</th><th>Role</th><th class="tnum">Actions</th><th class="tnum">Rounds active</th><th class="tnum">Notes</th><th>Reflection</th><th class="tnum">Grade %</th></tr></thead><tbody>' +
    a.individuals.map((i) => '<tr><td>' + esc(i.name) + '</td><td class="small">' + esc(i.team) + '</td><td class="small">' + esc(i.role || '') + '</td><td class="tnum">' + i.actions + '</td><td class="tnum">' + i.roundsActive + '</td><td class="tnum">' + i.journal + '</td><td>' + (i.reflection ? badge('Done', 'success') : badge('—')) + '</td><td class="tnum">' + (i.grade ? i.grade.total : '—') + '</td></tr>').join('') + '</tbody></table></div></section>' +
    (teamDebrief ? '<section class="card" id="smDebrief"><div class="card-head"><h2>Team debrief</h2></div><div class="card-body">' + smDebriefHtml(await call('smDebrief', { id: r.id, teamId: teamDebrief }), r, true) + '</div></section>' : '');
}
ACT.smKpiPick = (d, el) => go('/sim/run/' + SM.run.id + '?tab=analytics&kpi=' + encodeURIComponent(el.value));

async function smRunAssessment(r) {
  if (!r.console.roundsRun.length) return '<div class="card card-pad">' + emptyState('award', 'Nothing to assess yet', 'Grades appear after the first round.', '', false) + '</div>';
  const a = await call('smAssessment', { id: r.id });
  SM.assess = a;
  const w = a.weights;
  return '<section class="card"><div class="card-head"><h2>Grade components</h2><span class="xs muted">Simulation ' + w.simulation + '% · Team ' + w.team + '% · Decisions ' + w.decision + '% · Participation ' + w.participation + '% · Reflection ' + w.reflection + '% · out of ' + w.maxGrade + '</span></div>' +
    '<div class="table-wrap"><table class="table"><thead><tr><th>Student</th><th>Team</th><th class="tnum">Simulation</th><th class="tnum">Team</th><th class="tnum">Decisions</th><th class="tnum">Participation</th><th>Reflection</th><th class="tnum">Total %</th><th class="tnum">Grade</th></tr></thead><tbody>' +
    a.rows.map((x) => '<tr><td>' + esc(x.name) + '</td><td class="small">' + esc(x.teamName) + '</td><td class="tnum">' + (x.simulation == null ? '—' : x.simulation) + '</td><td class="tnum">' + (x.team == null ? '—' : x.team) + '</td><td class="tnum">' + (x.decision == null ? '—' : x.decision) + '</td><td class="tnum">' + (x.participation == null ? '—' : x.participation) + '</td><td>' +
      (x.reflection ? '<button class="btn btn-sm ' + (x.reflectionGraded ? 'btn-ghost' : 'btn-soft') + '" data-act="smReadRefl" data-uid="' + esc(x.uid) + '">' + (x.reflectionGraded ? x.reflection.grade + ' · edit' : 'Read & grade') + '</button>' : '<span class="xs muted">not submitted</span>') + '</td><td class="tnum"><b>' + (x.total == null ? '—' : x.total) + '</b></td><td class="tnum">' + (x.grade == null ? '—' : x.grade) + '</td></tr>').join('') + '</tbody></table></div>' +
    '<div class="card-body form-actions" style="justify-content:flex-start"><button class="btn btn-primary" data-act="smPushGrades">' + icon('send') + (a.gradeModuleId ? 'Update the gradebook' : 'Send grades to the gradebook') + '</button><button class="btn" data-act="smReport" data-f="xlsx">' + icon('download') + 'Excel</button><button class="btn" data-act="smReport" data-f="csv">' + icon('download') + 'CSV</button><a class="btn" href="#/sim/report/' + esc(r.id) + '">' + icon('printer') + 'PDF report</a>' +
    (a.gradeModuleId ? '<a class="btn btn-ghost" href="#/mod/' + esc(a.gradeModuleId) + '">Open the grade item</a>' : '') + '</div></section>';
}
ACT.smReadRefl = (d) => {
  const x = SM.assess.rows.find((y) => y.uid === d.uid); if (!x || !x.reflection) return;
  formModal('Reflection — ' + x.name, x.teamName, 'smGradeRefl', '<input type="hidden" name="uid" value="' + esc(x.uid) + '">' + SM.assess.questions.map((q, i) => '<div class="sm-qa"><b class="small">' + esc(q) + '</b><p>' + esc(x.reflection.answers[i] || '—') + '</p></div>').join('') +
    '<div class="form-grid">' + field('Grade (0–100)', '<input type="number" name="grade" min="0" max="100" step="0.5" required value="' + (x.reflection.grade != null ? x.reflection.grade : '') + '">') + '</div>' + field('Feedback', '<textarea name="feedback" rows="3" maxlength="3000">' + esc(x.reflection.feedback || '') + '</textarea>'), 'Save grade', 'wide');
};
FORMS.smGradeRefl = (f, btn) => busy(btn, async () => { await call('smGradeReflection', { id: SM.run.id, uid: f.elements.uid.value, grade: f.elements.grade.value, feedback: f.elements.feedback.value }); closeModal(); toast('Saved.'); refresh(); });
ACT.smPushGrades = (d, btn) => busy(btn, async () => { const x = await call('smPushGrades', { id: SM.run.id }); toast(x.graded + ' grades sent to the gradebook.'); refresh(); });

async function smRunSettings(r) {
  const log = await call('smAudit', { id: r.id }).catch(() => []);
  return '<div class="grid-2"><section class="card"><div class="card-head"><h2>Observers</h2></div><div class="card-body"><p class="small muted">Read-only access to results and analytics — external evaluators, accreditation teams, colleagues.</p>' +
    '<ul class="sm-members">' + r.console.observers.map((o) => '<li>' + avatar(o.name, 'sm') + '<span>' + esc(o.name) + '</span><button class="btn-icon sm" data-act="smObsDel" data-uid="' + esc(o.uid) + '" aria-label="Remove">' + icon('x') + '</button></li>').join('') + '</ul>' +
    '<input type="search" data-input="smObsSearch" data-delay="250" placeholder="Find a person to add" aria-label="Find a person"><div id="smObsRes" class="sm-people"></div></div></section>' +
    '<section class="card"><div class="card-head"><h2>Run details</h2></div><div class="card-body small"><p>Simulation: <b>' + esc(r.simTitle) + '</b> v' + esc(r.version) + ' (frozen for this run)</p><p>Mode: ' + esc(r.mode) + ' · ' + r.teams.length + ' teams</p><p>Deadline per round: ' + (r.roundHours ? r.roundHours + ' h' : 'none') + (r.autoRun ? ' · runs automatically' : '') + '</p>' +
    '<button class="btn btn-sm btn-ghost danger" data-act="smRunDel">' + icon('trash', 'i-sm') + 'Delete this run</button></div></section></div>' +
    '<section class="card"><div class="card-head"><h2>Audit trail</h2></div><div class="table-wrap"><table class="table"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Detail</th></tr></thead><tbody>' + log.slice(0, 100).map((l) => '<tr><td class="small nowrap">' + esc(fmt(l.at)) + '</td><td class="small">' + esc(l.name || '') + '</td><td class="small">' + esc(SM_ACTIONS[l.action] || l.action) + '</td><td class="small">' + esc(l.extra || '') + '</td></tr>').join('') + '</tbody></table></div></section>';
}
INPUTS.smObsSearch = async (el) => { const list = await call('stPeople', { q: el.value }).catch(() => []); $('#smObsRes').innerHTML = list.filter((u) => u.role !== 'student').map((u) => '<button type="button" class="st-person" data-act="smObsAdd" data-uid="' + esc(u.id) + '">' + avatar(u.name, 'sm') + esc(u.name) + '</button>').join(''); };
ACT.smObsAdd = (d) => busy(null, async () => { await call('smControl', { id: SM.run.id, action: 'observers', observers: SM.run.console.observers.map((o) => o.uid).concat([d.uid]) }); refresh(); });
ACT.smObsDel = (d) => busy(null, async () => { await call('smControl', { id: SM.run.id, action: 'observers', observers: SM.run.console.observers.map((o) => o.uid).filter((u) => u !== d.uid) }); refresh(); });
ACT.smRunDel = async () => { if (!await confirmBox('Delete this run?', '<p>All results, journals and reflections of this run are removed. Grades already sent to the gradebook stay there.</p>', 'Delete run', true)) return; busy(null, async () => { await call('smRunDelete', { id: SM.run.id, confirm: true }); toast('Deleted.'); go('/sim'); }); };

/* ---------- printable report (Save as PDF) ---------- */
async function viewSmReport(id) {
  const r = await call('smRunGet', { id });
  const a = await call('smAnalytics', { id });
  const cur = r.basics.currency;
  return {
    title: 'Report: ' + r.title,
    html: '<div class="sm-report"><div class="st-noprint row" style="gap:.5rem;margin-bottom:1rem"><a class="btn" href="#/sim/run/' + esc(id) + '">' + icon('arrowLeft') + 'Back</a><span class="spacer"></span><button class="btn btn-primary" data-act="stPrintNow">' + icon('printer') + 'Print / Save as PDF</button></div>' +
      '<h1>' + esc(r.title) + '</h1><p class="muted">' + esc(r.simTitle) + ' v' + esc(r.version) + ' · ' + esc(r.course) + ' · ' + a.roundsRun + ' of ' + a.rounds + ' rounds · generated ' + esc(fmt(Date.now())) + '</p>' +
      '<h2>Final rankings</h2><table class="table"><thead><tr><th>#</th><th>Team</th><th>Members</th><th class="tnum">Score</th>' + r.categories.map((c) => '<th class="tnum">' + esc(c.label) + '</th>').join('') + '</tr></thead><tbody>' + a.teams.map((t) => '<tr><td>' + t.rank + '</td><td>' + esc(t.name) + '</td><td class="small">' + esc(t.members.join(', ')) + '</td><td class="tnum"><b>' + t.final + '</b></td>' + r.categories.map((c) => '<td class="tnum">' + (t.categories[c.key] == null ? '—' : Math.round(t.categories[c.key])) + '</td>').join('') + '</tr>').join('') + '</tbody></table>' +
      '<h2>Scores by round</h2>' + chartSlot('lines', { labels: a.classAverage.map((x) => 'R' + x.n), series: a.teams.map((t) => ({ name: t.name, color: t.color, values: t.scores })), label: 'Scores by round', yFmt: (v) => Math.round(v) }) +
      '<h2>Learning outcomes</h2><table class="table"><tbody>' + a.outcomes.map((o) => '<tr><td>' + esc(o.label) + '</td><td class="tnum">' + (o.average == null ? '—' : o.average) + '</td><td class="tnum">' + (o.achieved == null ? '—' : o.achieved + '% of teams ≥ 60') + '</td></tr>').join('') + '</tbody></table>' +
      '<h2>Events</h2><ul>' + a.events.map((e) => '<li><b>' + esc(e.name) + '</b> (round ' + e.start + ') — ' + esc(e.message || '') + '</li>').join('') + '</ul>' +
      '<h2>Common strategic mistakes</h2><ul>' + (a.mistakes.length ? a.mistakes.map((m) => '<li>' + m.count + '× ' + esc(m.text) + ' — ' + esc(m.teams.join(', ')) + '</li>').join('') : '<li>None detected.</li>') + '</ul>' +
      '<h2>Students</h2><table class="table"><thead><tr><th>Student</th><th>Team</th><th class="tnum">Simulation</th><th class="tnum">Team</th><th class="tnum">Decisions</th><th class="tnum">Participation</th><th class="tnum">Reflection</th><th class="tnum">Total %</th></tr></thead><tbody>' +
      a.individuals.map((i) => '<tr><td>' + esc(i.name) + '</td><td>' + esc(i.team) + '</td>' + (i.grade ? '<td class="tnum">' + i.grade.simulation + '</td><td class="tnum">' + i.grade.team + '</td><td class="tnum">' + i.grade.decision + '</td><td class="tnum">' + i.grade.participation + '</td><td class="tnum">' + (i.grade.reflectionGraded ? i.grade.reflection : '—') + '</td><td class="tnum"><b>' + i.grade.total + '</b></td>' : '<td colspan="6">—</td>') + '</tr>').join('') + '</tbody></table>' +
      '<p class="xs muted">Revenue and profit figures in ' + esc(cur) + '. Results are reproducible from the run\'s seed and stored decisions.</p></div>',
    after: () => mountCharts()
  };
}

/* ---------- settings (administrators) ---------- */
async function viewSmSettings() {
  const st = await call('smSettings');
  const sel = (name, chosen, people) => '<select name="' + name + '" multiple size="8">' + people.map((u) => '<option value="' + esc(u.id) + '"' + (chosen.some((c) => c.id === u.id) ? ' selected' : '') + '>' + esc(u.name) + (u.role ? ' (' + esc(u.role) + ')' : '') + '</option>').join('') + '</select>';
  return {
    title: 'Simulation settings',
    html: pageHead('Business simulation settings', { crumbs: [['Business simulations', '/sim'], ['Settings']] }) + smNav('/sim/settings') +
      '<form class="card card-pad" data-form="smSettings"><div class="form-grid">' + field('Institution administrators', sel('inst', st.grants.institutionAdmins, st.staff), 'See and manage every simulation and run, the institution library and usage.') +
      field('Observers', sel('obs', st.grants.observers, st.all), 'Read-only access to every run\'s results and analytics (evaluators, accreditation). Observers can also be added per run.') + '</div>' +
      '<div class="form-actions"><button class="btn btn-primary">Save</button></div></form>'
  };
}
FORMS.smSettings = (f, btn) => busy(btn, async () => { const v = (s) => Array.from(s.selectedOptions).map((o) => o.value); await call('smSaveSettings', { grants: { institutionAdmins: v(f.elements.inst), observers: v(f.elements.obs) } }); toast('Saved.'); });
