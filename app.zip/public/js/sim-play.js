'use strict';
/* =====================================================================
   BUSINESS SIMULATION — the game (students; faculty in preview)
   Overview · Market · Decisions (+ what-if) · Results · Performance ·
   Team & journal · Debrief. Everything is computed on the server; the
   page polls for new rounds so a team sees results as soon as they run.
   ===================================================================== */
const SP = { run: null, saveTimer: null, poll: null, whatIf: {} };
const SP_TABS = [['overview', 'Overview', 'dashboard'], ['market', 'Market', 'globe'], ['decide', 'Decisions', 'sliders'], ['results', 'Results', 'chart'], ['performance', 'Performance', 'trending'], ['team', 'Team & journal', 'users'], ['debrief', 'Debrief', 'award']];
const SP_CAT = { pricing: 'Pricing', marketing: 'Marketing', operations: 'Operations', hr: 'People', finance: 'Finance', rnd: 'R&D', strategy: 'Strategy', sustainability: 'Sustainability' };

async function viewSmPlay(id, params) {
  const r = await call('smRunGet', { id });
  if (!r.canPlay && (r.manage || r.observe) && !r.preview) { go('/sim/run/' + id); return null; }
  SP.run = r;
  const tab = params.get('tab') || (r.status === 'completed' ? 'debrief' : r.roundOpen && r.myTeam ? 'decide' : 'overview');
  S.onLeave = () => { clearInterval(SP.poll); SP.poll = null; clearTimeout(SP.saveTimer); };
  clearInterval(SP.poll);
  if (r.status === 'running' || r.status === 'paused') SP.poll = setInterval(spPoll, 15000);
  let body;
  if (!r.myTeam) body = spNoTeam(r);
  else if (tab === 'overview') body = spOverview(r);
  else if (tab === 'market') body = spMarket(r);
  else if (tab === 'decide') body = spDecide(r);
  else if (tab === 'results') body = spResults(r, params);
  else if (tab === 'performance') body = spPerformance(r);
  else if (tab === 'team') body = spTeam(r);
  else if (tab === 'debrief') body = await spDebrief(r);
  const myScore = r.myRounds && r.myRounds.length ? r.myRounds[r.myRounds.length - 1].score : null;
  const rank = r.leaderboard.rows.find((x) => x.mine);
  return {
    title: r.title,
    html: '<header class="sp-head"><div class="sp-head-main"><div class="sm-eyebrow">' + esc(r.preview ? 'Preview — you are playing as a student' : (r.course || 'Business simulation')) + '</div><h1>' + esc(r.title) + '</h1>' +
      '<div class="sp-head-meta">' + smStatus(r.status) + (r.myTeam ? ' <span class="sp-team"><span class="sm-dot" style="background:' + esc(r.myTeam.color) + '"></span>' + esc(r.myTeam.name) + (r.myTeam.role ? ' · ' + esc(r.myTeam.role) : '') + '</span>' : '') +
      (r.round ? ' <span class="small">Round ' + r.round + ' of ' + r.rounds + (r.roundInfo ? ' · <b>' + esc(r.roundInfo.title) + '</b>' : '') + '</span>' : '') + ' ' + (r.roundOpen ? smDeadline(r.deadline) : '') + '</div></div>' +
      (myScore ? '<div class="sp-head-score">' + smScoreRing(myScore.overall, 64) + '<div><div class="xs muted">Score (last round)</div>' + (rank ? '<b>Rank ' + rank.rank + (r.leaderboard.teams ? ' of ' + r.leaderboard.teams : '') + '</b>' : '') + '</div></div>' : '') +
      (r.preview ? '<div class="sp-preview-acts"><button class="btn btn-sm btn-primary" data-act="spPreviewRun"' + (r.roundOpen ? '' : ' disabled') + '>' + icon('zap', 'i-sm') + 'Run this round</button><a class="btn btn-sm" href="#/sim/build/' + esc(r.simId) + '?step=health">' + icon('arrowLeft', 'i-sm') + 'Back to the builder</a></div>' : '') + '</header>' +
      (r.myTeam ? '<nav class="tabs sp-tabs" aria-label="Simulation">' + SP_TABS.filter((t) => t[0] !== 'debrief' || r.status === 'completed' || r.preview).map((t) => '<a class="tab' + (t[0] === tab ? ' active' : '') + '" href="#/sim/play/' + esc(r.id) + '?tab=' + t[0] + '">' + icon(t[2]) + t[1] + (t[0] === 'decide' && r.roundOpen && r.draft && r.draft.status !== 'submitted' ? '<span class="count">!</span>' : '') + '</a>').join('') + '</nav>' : '') + body,
    after: () => { mountCharts(); if (tab === 'decide') spSyncAll(); }
  };
}
async function spPoll() {
  const r = SP.run; if (!r) return;
  try {
    const x = await call('smRunGet', { id: r.id });
    if (x.round !== r.round || x.status !== r.status || x.roundOpen !== r.roundOpen) { toast(x.status === 'completed' ? 'The simulation is complete — see your debrief.' : 'Round ' + (x.roundOpen ? x.round - 1 : x.round) + ' results are in.'); refresh(); }
  } catch (e) { /* offline: try again */ }
}
function spNoTeam(r) {
  if (r.settings.selfTeams && r.status !== 'completed') return '<section class="card"><div class="card-head"><h2>Join a team</h2></div><div class="card-body"><div class="sm-teamgrid">' + r.teams.map((t) => '<div class="card card-pad sm-teamcard"><b><span class="sm-dot" style="background:' + esc(t.color) + '"></span>' + esc(t.name) + '</b><p class="xs muted">' + t.size + ' / ' + r.basics.teamSize + ' members' + (t.members.length ? ': ' + t.members.map((m) => esc(m.name)).join(', ') : '') + '</p><button class="btn btn-sm btn-primary" data-act="spJoin" data-team="' + esc(t.id) + '"' + (t.size >= r.basics.teamSize ? ' disabled' : '') + '>Join</button></div>').join('') + '</div></div></section>';
  return '<div class="card card-pad">' + emptyState('users', 'You are not in a team yet', 'Your teacher assigns the teams for this simulation. Ask them to add you.', '', false) + '</div>';
}
ACT.spJoin = (d, btn) => busy(btn, async () => { await call('smJoinTeam', { id: SP.run.id, teamId: d.team }); toast('You joined the team.'); refresh(); });
ACT.spPreviewRun = (d, btn) => busy(btn, async () => { if (SP.run.draft && SP.run.draft.status !== 'submitted') await call('smSubmit', { id: SP.run.id }); await call('smControl', { id: SP.run.id, action: 'run' }); toast('Round complete.'); go('/sim/play/' + SP.run.id + '?tab=results'); });

/* ---------- overview ---------- */
function spOverview(r) {
  const st = r.state, b = r.basics, cur = b.currency, last = r.myRounds[r.myRounds.length - 1], m = last ? last.metrics : null, prev = r.myRounds[r.myRounds.length - 2];
  const delta = (k, fmtF) => (prev && m ? deltaHtml(m[k], prev.metrics[k]) : '');
  const tile = (label, value, sub) => '<div class="sp-tile"><span class="xs muted">' + esc(label) + '</span><b class="tnum">' + value + '</b>' + (sub || '') + '</div>';
  const news = r.events.filter((e) => e.active || e.start === r.round);
  return (r.announcements.length ? notice('<b>From your teacher:</b> ' + esc(r.announcements[0].text), '', 'megaphone') : '') +
    (r.status === 'paused' ? notice('The simulation is paused by your teacher.', 'warn') : '') +
    '<div class="sm-cols"><section class="sm-col">' +
    (r.roundInfo && r.status !== 'completed' ? '<section class="card sp-brief"><div class="card-body"><div class="sm-eyebrow">Round ' + r.round + (r.roundInfo.focus ? ' · ' + esc(r.roundInfo.focus) : '') + '</div><h2>' + esc(r.roundInfo.title) + '</h2><p>' + esc(r.roundInfo.brief) + '</p>' +
      (r.roundOpen ? '<a class="btn btn-primary" href="#/sim/play/' + esc(r.id) + '?tab=decide">' + icon('sliders') + (r.draft.status === 'submitted' ? 'Review your decisions' : 'Make this round\'s decisions') + '</a>' + (r.draft.status === 'submitted' ? ' ' + badge('Submitted', 'success', 'check') : '') : '') + '</div></section>' : '') +
    '<section class="card"><div class="card-head"><h2>' + esc(r.myTeam.company.name) + '</h2><span class="xs muted">' + (m ? 'after round ' + last.n : 'starting position') + '</span></div><div class="card-body"><div class="sp-tiles">' +
    tile('Cash', smMoney(st.cash, cur)) + tile('Revenue', m ? smMoney(m.revenue, cur) : '—', delta('revenue')) + tile('Net profit', m ? smMoney(m.netProfit, cur) : '—', delta('netProfit')) + tile('Market share', m ? smFmt(m.marketShare, 'pct') : '—', delta('marketShare')) +
    tile('Customers / units sold', m ? smNum(m.units, 0) : '—') + tile('Brand', smNum(st.brand, 0) + '/100') + tile('Quality', smNum(st.quality, 0) + '/100') + tile('Technology', smNum(st.tech, 0) + '/100') +
    tile('Employees', smNum(st.employees, 0)) + tile('Capacity', smNum(st.capacity, 0) + (st.pendingCapacity ? ' <span class="xs muted">+' + smNum(st.pendingCapacity, 0) + ' coming</span>' : '')) + tile('Inventory', smNum(st.inventory, 0) + ' ' + esc(b.unitName)) + tile('Debt', smMoney(st.debt, cur)) +
    tile('Customer satisfaction', smNum(st.satisfaction, 0) + '/100') + tile('Employee satisfaction', smNum(st.morale, 0) + '/100') + tile('Sustainability', smNum(st.sustainability, 0) + '/100') + tile('Distribution reach', smNum(st.distribution, 0) + '/100') +
    '</div>' + (last && last.notes.length ? '<ul class="sp-notes">' + last.notes.map((n) => '<li>' + icon('info', 'i-sm') + esc(n) + '</li>').join('') + '</ul>' : '') + '</div></section></section>' +
    '<aside class="sm-col side">' + (last ? '<section class="card"><div class="card-head"><h2>Last round</h2></div><div class="card-body sp-lastscore">' + smScoreRing(last.score.overall, 84) + '<div>' + r.categories.map((c) => '<div class="sp-catrow"><span class="xs">' + esc(c.label) + '</span><div class="progress"><i style="width:' + (last.score.categories[c.key] || 0) + '%"></i></div><b class="xs tnum">' + (last.score.categories[c.key] == null ? '—' : Math.round(last.score.categories[c.key])) + '</b></div>').join('') + '</div></div></section>' : '') +
    '<section class="card"><div class="card-head"><h2>News</h2></div><div class="card-body">' + (news.length ? news.map((e) => '<div class="sm-news ' + esc(e.severity || '') + '"><b>' + esc(e.name) + '</b>' + (e.teamOnly ? ' ' + badge('Your company', 'warning') : '') + '<p class="small">' + esc(e.message) + '</p></div>').join('') : '<p class="small muted">No major news this round.</p>') + '</div></section>' +
    smLbCard(r) + '<section class="card"><div class="card-head"><h2>Rounds</h2></div><div class="card-body">' + smRunStepper(r) + '</div></section></aside></div>';
}
function smLbCard(r) {
  const lb = r.leaderboard;
  if (lb.visibility === 'none' || !lb.rows.length) return '';
  return '<section class="card"><div class="card-head"><h2>' + (lb.visibility === 'own' ? 'Your ranking' : 'Leaderboard') + '</h2></div><div class="card-body"><ol class="sm-lb">' + lb.rows.map((x) => '<li class="' + (x.mine ? 'mine' : '') + '"><span class="rk">' + x.rank + '</span>' + (x.color ? '<span class="sm-dot" style="background:' + esc(x.color) + '"></span>' : '') + '<span class="nm">' + esc(x.name) + (x.mine ? ' (you)' : '') + '</span><b class="tnum">' + (lb.metric === 'score' ? x.value : smFmt(x.value, lb.metric === 'marketShare' || lb.metric === 'roi' ? 'pct' : lb.metric === 'satisfaction' || lb.metric === 'sustainability' ? 'index' : 'money', r.basics.currency)) + '</b></li>').join('') + '</ol>' + (lb.visibility === 'own' && lb.teams ? '<p class="xs muted">of ' + lb.teams + ' teams</p>' : '') + '</div></section>';
}

/* ---------- market ---------- */
function spMarket(r) {
  const mk = r.market, cur = r.basics.currency;
  const care = (lvl) => '<span class="sp-care l' + ({ None: 0, Low: 1, Medium: 2, High: 3, 'Very high': 4 }[lvl] || 0) + '">' + esc(lvl) + '</span>';
  return '<div class="grid-3 sm-kpis">' + statCard('globe', 'indigo', esc(mk.name), 'Market') + statCard('trending', 'green', mk.totalDemand == null ? '—' : smNum(mk.totalDemand, 0), 'Units bought last ' + esc(r.basics.period.toLowerCase())) + statCard('percent', 'amber', mk.avgPrice == null ? '—' : smMoney(mk.avgPrice, cur), 'Average price paid') + '</div>' +
    '<section class="card"><div class="card-head"><h2>Customer segments</h2><span class="xs muted">What each group cares about</span></div><div class="table-wrap"><table class="table"><thead><tr><th>Segment</th><th class="tnum">Potential (' + esc(r.basics.unitName) + ')</th><th class="tnum">Typical price</th><th class="tnum">Most they pay</th><th>Price</th><th>Quality</th><th>Brand</th><th>Sustainability</th><th>Reach</th><th>Loyalty</th></tr></thead><tbody>' +
    mk.segments.map((sg) => '<tr><td><b>' + esc(sg.name) + '</b>' + (sg.locked ? '<div class="xs">' + (r.state.entered.indexOf(sg.id) >= 0 ? badge('Entered', 'success') : badge('Locked · entry ' + smMoney(sg.entryCost, cur), 'warning', 'lock')) + '</div>' : '') + '<div class="xs muted">grows ' + smFmt(sg.growth, 'pct') + ' a round</div></td><td class="tnum">' + smNum(sg.potential, 0) + '</td><td class="tnum">' + smMoney(sg.refPrice, cur) + '</td><td class="tnum">' + smMoney(sg.maxPrice, cur) + '</td>' +
      ['price', 'quality', 'brand', 'sustainability', 'distribution'].map((k) => '<td>' + care(sg.cares[k]) + '</td>').join('') + '<td>' + care(sg.loyalty) + '</td></tr>').join('') + '</tbody></table></div></section>' +
    '<div class="grid-2"><section class="card"><div class="card-head"><h2>Competitors</h2><span class="xs muted">as of last round</span></div><div class="table-wrap"><table class="table"><thead><tr><th>Company</th><th class="tnum">Price</th><th class="tnum">Brand</th><th class="tnum">Quality</th><th class="tnum">Share</th></tr></thead><tbody>' +
    mk.competitors.map((c) => '<tr><td><b>' + esc(c.name) + '</b>' + (c.note && c.note.length ? '<div class="xs muted">' + esc(c.note.join('; ')) + '</div>' : '') + '</td><td class="tnum">' + smMoney(c.price, cur) + '</td><td class="tnum">' + c.brand + '</td><td class="tnum">' + c.quality + '</td><td class="tnum">' + (c.marketShare == null ? '—' : smFmt(c.marketShare, 'pct')) + '</td></tr>').join('') + '</tbody></table></div></section>' +
    '<section class="card"><div class="card-head"><h2>Economy</h2></div><div class="card-body"><div class="sp-tiles three">' + '<div class="sp-tile"><span class="xs muted">Inflation</span><b>' + smFmt(mk.economy.inflation, 'pct') + '</b></div><div class="sp-tile"><span class="xs muted">Interest rate</span><b>' + smFmt(mk.economy.interestRate, 'pct') + '</b></div><div class="sp-tile"><span class="xs muted">GDP growth</span><b>' + smFmt(mk.economy.gdpGrowth, 'pct') + '</b></div></div>' +
    (mk.history.length > 1 ? chartSlot('lines', { labels: mk.history.map((x) => 'R' + x.n), series: [{ name: 'Units bought', color: 'var(--accent)', values: mk.history.map((x) => x.demand), strong: true }], label: 'Market demand by round', yFmt: (v) => compact(v) }) : '') + '</div></section></div>';
}

/* ---------- decisions ---------- */
function spDecide(r) {
  if (!r.roundOpen) return '<div class="card card-pad">' + emptyState('clock', r.status === 'completed' ? 'The simulation is complete' : 'No round is open', r.status === 'completed' ? 'See your results and the debrief.' : 'Your teacher opens the next round. Results of the last round are under Results.', '', false) + '</div>';
  const dr = r.draft, sub = dr.status === 'submitted', b = r.basics, me = r.myTeam.role;
  const groups = {};
  r.decisions.forEach((d) => { (groups[d.category] = groups[d.category] || []).push(d); });
  const val = (d) => (dr.values[d.key] != null ? dr.values[d.key] : (r.lastValues[d.key] != null ? r.lastValues[d.key] : d.default));
  const roleMode = r.settings.roleMode;
  const roles = [...new Set(r.decisions.map((d) => d.role).filter(Boolean))];
  const ctl = (d) => {
    const v = val(d), dis = sub || !d.editable ? ' disabled' : '';
    if (d.type === 'toggle') return '<label class="sp-switch"><input type="checkbox" data-change="spSet" data-k="' + esc(d.key) + '"' + (Number(v) ? ' checked' : '') + dis + '><span>' + (Number(v) ? 'Yes' : 'No') + '</span></label>';
    if (d.type === 'select' && d.options.length) return '<select data-change="spSet" data-k="' + esc(d.key) + '"' + dis + '>' + d.options.map((o) => '<option value="' + o.value + '"' + (Number(v) === o.value ? ' selected' : '') + '>' + esc(o.label) + '</option>').join('') + '</select>';
    return '<div class="sp-range"><input type="range" min="' + d.min + '" max="' + d.max + '" step="' + (d.step || 'any') + '" value="' + v + '" data-k="' + esc(d.key) + '" data-input="spSet" data-delay="0" aria-label="' + esc(d.label) + '"' + dis + '><input type="number" class="sp-num" min="' + d.min + '" max="' + d.max + '" step="' + (d.step || 'any') + '" value="' + v + '" data-k="' + esc(d.key) + '" data-input="spSet" data-delay="400" aria-label="' + esc(d.label) + ' value"' + dis + '></div>';
  };
  const rowHtml = (d) => '<div class="sp-dec' + (d.editable ? '' : ' locked') + '"><div class="sp-dec-head"><label class="sp-dec-label">' + esc(d.label) + '</label>' + (d.role ? badge(d.role, d.role === me ? 'primary' : '') : '') + '<span class="spacer"></span><b class="tnum sp-val" data-show="' + esc(d.key) + '">' + esc(smUnitFmt(val(d), d.unit, b)) + '</b></div>' + ctl(d) +
    '<div class="sp-dec-foot">' + (d.help ? '<span class="xs muted">' + esc(d.help) + '</span>' : '') + (r.lastValues[d.key] != null ? '<span class="xs muted">Last round: ' + esc(smUnitFmt(r.lastValues[d.key], d.unit, b)) + '</span>' : '') + (!d.editable ? '<span class="xs">' + icon('lock', 'i-sm') + ' ' + esc(d.role) + ' decides</span>' : '') + '</div></div>';
  return '<div class="sp-decide"><section class="sp-decide-main">' +
    (sub ? notice('Submitted' + (dr.submittedBy ? ' by ' + esc(dr.submittedBy) : '') + ' ' + esc(rel(dr.submittedAt)) + '. The round runs when your teacher says so' + (r.deadline ? ' or at the deadline' : '') + '.', 'ok') : '') +
    (r.roundInfo ? '<p class="small muted">' + esc(r.roundInfo.brief) + '</p>' : '') +
    Object.keys(groups).map((g) => '<section class="card sp-group"><div class="card-head"><h2>' + esc(SP_CAT[g] || g) + '</h2></div><div class="card-body">' + groups[g].map(rowHtml).join('') + '</div></section>').join('') +
    '<section class="card"><div class="card-head"><h2>Why these decisions?</h2></div><div class="card-body"><textarea id="spWhy" rows="3" maxlength="2000" placeholder="Your reasoning goes into the decision journal — useful for the debrief and reflection."' + (sub ? ' disabled' : '') + ' data-input="spWhy" data-delay="800">' + esc(dr.rationale || '') + '</textarea></div></section></section>' +
    '<aside class="sp-decide-side"><section class="card sp-sticky"><div class="card-head"><h2>Submit</h2><span class="xs muted" id="spSaved">' + (sub ? 'Locked' : 'Saved') + '</span></div><div class="card-body">' +
    (roleMode && roles.length ? '<div class="sp-approvals">' + roles.filter((x) => x !== 'CEO').map((x) => '<div class="sp-appr">' + (dr.approvals[x] ? icon('checkCircle', 'i-sm') : icon('circle', 'i-sm')) + '<span class="small">' + esc(x) + (dr.approvals[x] ? ' — ' + esc(dr.approvals[x]) : '') + '</span>' + (!sub && !dr.approvals[x] && (me === x || me === 'CEO') ? '<button class="btn btn-sm btn-ghost" data-act="spApprove" data-role="' + esc(x) + '">Approve</button>' : '') + '</div>').join('') + '</div>' : '') +
    (sub ? (!roleMode || me === 'CEO' || r.manage ? '<button class="btn" data-act="spReopen">' + icon('edit') + 'Re-open decisions</button>' : '') : (!roleMode || me === 'CEO' || r.preview ? '<button class="btn btn-primary btn-block" data-act="spSubmit">' + icon('send') + 'Submit decisions</button>' : '<p class="small muted">Your CEO submits the team\'s decisions.</p>')) +
    '<p class="xs muted">Not submitted by the deadline? ' + (r.preview ? '' : 'Your saved draft (or last round\'s decisions) is used.') + '</p></div></section>' +
    (r.settings.whatIf ? spWhatIfCard(r) : '') + '</aside></div>';
}
function spSyncAll() { SP.whatIf = {}; }
ACT.spSet = (d, el) => spSetValue(el.dataset.k, el.type === 'checkbox' ? (el.checked ? 1 : 0) : Number(el.value), el);
INPUTS.spSet = (el) => spSetValue(el.dataset.k, Number(el.value), el);
function spSetValue(k, v, el) {
  const r = SP.run; if (!r || !isFinite(v)) return;
  const d = r.decisions.find((x) => x.key === k); if (!d) return;
  r.draft.values[k] = v;
  $$('[data-k="' + CSS.escape(k) + '"]').forEach((x) => { if (x !== el && x.type !== 'checkbox') x.value = v; if (x.type === 'checkbox' && x.nextElementSibling) x.nextElementSibling.textContent = v ? 'Yes' : 'No'; });
  const show = $('[data-show="' + CSS.escape(k) + '"]'); if (show) show.textContent = smUnitFmt(v, d.unit, r.basics);
  const s = $('#spSaved'); if (s) s.textContent = 'Saving…';
  clearTimeout(SP.saveTimer);
  SP.saveTimer = setTimeout(spSave, 700);
}
INPUTS.spWhy = () => { clearTimeout(SP.saveTimer); SP.saveTimer = setTimeout(spSave, 300); };
async function spSave() {
  const r = SP.run; if (!r || !r.draft || r.draft.status === 'submitted') return;
  try {
    const why = $('#spWhy');
    const x = await call('smDecide', { id: r.id, values: r.draft.values, rationale: why ? why.value : undefined });
    r.draft.values = x.values;
    const s = $('#spSaved'); if (s) s.textContent = 'Saved';
    if (x.notes && x.notes.length) toast(x.notes[0]);
  } catch (e) { const s = $('#spSaved'); if (s) s.textContent = 'Not saved'; toast(e.message, 'err'); }
}
ACT.spSubmit = (d, btn) => busy(btn, async () => { clearTimeout(SP.saveTimer); await spSave(); const why = $('#spWhy'); await call('smSubmit', { id: SP.run.id, rationale: why ? why.value : '' }); toast('Decisions submitted.'); refresh(); });
ACT.spReopen = (d, btn) => busy(btn, async () => { await call('smSubmit', { id: SP.run.id, reopen: true }); refresh(); });
ACT.spApprove = (d, btn) => busy(btn, async () => { await spSave(); await call('smApprove', { id: SP.run.id, role: d.role }); refresh(); });
function spWhatIfCard(r) {
  const nums = r.decisions.filter((d) => d.type !== 'toggle' && d.type !== 'select').slice(0, 8);
  return '<section class="card"><div class="card-head"><h2>What if…?</h2></div><form class="card-body" data-form="spWhatIf"><p class="xs muted">Test a change without saving it. Rivals are assumed to repeat last round.</p>' +
    nums.map((d) => '<label class="sm-field"><span class="sm-lbl">' + esc(d.label) + '</span><input type="number" step="any" name="' + esc(d.key) + '" placeholder="' + esc(String(r.draft.values[d.key] != null ? r.draft.values[d.key] : (r.lastValues[d.key] != null ? r.lastValues[d.key] : d.default))) + '"></label>').join('') +
    '<button class="btn btn-sm">' + icon('zap', 'i-sm') + 'Estimate</button><div id="spWhatIfOut"></div></form></section>';
}
FORMS.spWhatIf = (f, btn) => busy(btn, async () => {
  const values = {};
  Array.from(f.elements).forEach((el) => { if (el.name && el.value !== '') values[el.name] = Number(el.value); });
  if (!Object.keys(values).length) throw new Error('Enter at least one value to test.');
  const x = await call('smWhatIf', { id: SP.run.id, values });
  const cur = SP.run.basics.currency;
  const rows = [['Demand', 'demand', 'num'], ['Units sold', 'units', 'num'], ['Revenue', 'revenue', 'money'], ['Net profit', 'netProfit', 'money'], ['Market share', 'marketShare', 'pct'], ['Cash', 'cash', 'money'], ['Customer satisfaction', 'satisfaction', 'index'], ['Score (estimate)', 'score', 'index']];
  $('#spWhatIfOut').innerHTML = '<table class="table sp-whatif"><thead><tr><th></th><th class="tnum">Plan</th><th class="tnum">What if</th></tr></thead><tbody>' + rows.map((rw) => { const a = x.baseline[rw[1]], b = x.scenario[rw[1]]; return '<tr><td class="small">' + rw[0] + '</td><td class="tnum small">' + smFmt(a, rw[2], cur) + '</td><td class="tnum small ' + (b > a ? 'up' : b < a ? 'down' : '') + '">' + smFmt(b, rw[2], cur) + '</td></tr>'; }).join('') + '</tbody></table>' +
    (x.scenario.notes.length ? '<p class="xs muted">' + esc(x.scenario.notes.join(' ')) + '</p>' : '') + '<p class="xs muted">' + esc(x.caveat) + '</p>';
});

/* ---------- results ---------- */
function spResults(r, params) {
  if (!r.myRounds.length) return '<div class="card card-pad">' + emptyState('chart', 'No results yet', 'Results appear here after the first round has been run.', '', false) + '</div>';
  const n = Number(params.get('round')) || r.myRounds[r.myRounds.length - 1].n;
  const x = r.myRounds.find((y) => y.n === n) || r.myRounds[r.myRounds.length - 1];
  const cur = r.basics.currency, M = x.metrics, sc = x.score, st = x.statements;
  const kd = r.kpiDefs;
  const line = (label, v, cls) => '<tr class="' + (cls || '') + '"><td>' + label + '</td><td class="tnum">' + smMoney(v, cur) + '</td></tr>';
  return '<div class="pills sp-roundpills">' + r.myRounds.map((y) => '<a class="pill' + (y.n === x.n ? ' active' : '') + '" href="#/sim/play/' + esc(r.id) + '?tab=results&round=' + y.n + '">R' + y.n + ' ' + esc(y.title) + '</a>').join('') + '</div>' +
    '<div class="sm-cols"><section class="sm-col">' +
    '<section class="card"><div class="card-head"><h2>Score: why you got ' + Math.round(sc.overall) + '</h2></div><div class="card-body sp-scorebox">' + smScoreRing(sc.overall, 96) + '<div class="sp-expl">' + sc.explanation.categories.map((c) => '<div class="sp-expl-row"><div class="row"><b class="small">' + esc(c.category) + '</b><span class="xs muted">' + c.weight + '% of the score</span><span class="spacer"></span><b class="tnum">' + Math.round(c.score) + '</b></div><div class="progress"><i style="width:' + c.score + '%"></i></div><div class="xs muted">' + esc(c.text) + '</div></div>').join('') +
    (sc.explanation.strengths.length ? '<p class="small"><b>Strengths:</b> ' + esc(sc.explanation.strengths.join(', ')) + '</p>' : '') + (sc.explanation.weaknesses.length ? '<p class="small"><b>To improve:</b> ' + esc(sc.explanation.weaknesses.join('; ')) + '</p>' : '') + '</div></div></section>' +
    (x.mistakes.length || x.notes.length ? '<section class="card"><div class="card-head"><h2>What happened</h2></div><div class="card-body"><ul class="sp-notes">' + x.notes.map((t) => '<li>' + icon('info', 'i-sm') + esc(t) + '</li>').join('') + x.mistakes.map((t) => '<li class="warn">' + icon('alert', 'i-sm') + esc(t.text) + '</li>').join('') + '</ul></div></section>' : '') +
    '<section class="card"><div class="card-head"><h2>KPIs</h2></div><div class="table-wrap"><table class="table"><thead><tr><th>KPI</th><th class="tnum">Result</th><th class="tnum">Target</th><th class="tnum">Score</th></tr></thead><tbody>' + kd.map((k) => { const ks = sc.kpis[k.key]; return '<tr><td>' + esc(k.label) + '<div class="xs muted">' + esc((r.categories.find((c) => c.key === k.category) || {}).label || '') + '</div></td><td class="tnum">' + smFmt(x.kpis[k.key], k.format, cur) + '</td><td class="tnum">' + (k.dir === 'down' ? '≤ ' : '') + smFmt(k.target, k.format, cur) + '</td><td class="tnum"><span class="sp-kscore ' + (ks.score >= 70 ? 'hi' : ks.score >= 40 ? 'mid' : 'lo') + '">' + Math.round(ks.score) + '</span></td></tr>'; }).join('') + '</tbody></table></div></section>' +
    (x.trace ? spTrace(x, r) : '') + '</section>' +
    '<aside class="sm-col side"><section class="card"><div class="card-head"><h2>Income statement</h2></div><table class="table sp-fin"><tbody>' + line('Revenue', st.income.revenue, 'b') + line('Cost of goods sold', -st.income.cogs) + line('Gross profit', st.income.grossProfit, 'b') +
    [['Marketing', 'marketing'], ['R&D', 'rd'], ['Quality', 'quality'], ['Distribution', 'distribution'], ['Sustainability', 'sustainability'], ['People', 'people'], ['Fixed costs', 'fixed'], ['Inventory holding', 'holding'], ['Market entry', 'entry'], ['Other', 'other']].filter((k) => st.income[k[1]]).map((k) => line(k[0], -st.income[k[1]])).join('') +
    line('EBITDA', st.income.ebitda, 'b') + line('Depreciation', -st.income.depreciation) + line('EBIT', st.income.ebit, 'b') + line('Interest', -st.income.interest) + line('Tax', -st.income.tax) + line('Net profit', st.income.netProfit, 'b total') + '</tbody></table></section>' +
    '<section class="card"><div class="card-head"><h2>Cash flow</h2></div><table class="table sp-fin"><tbody>' + line('Opening cash', st.cashflow.opening, 'b') + line('Operating cash flow', st.cashflow.operatingCF) + line('Investment (capacity)', st.cashflow.investingCF) + line('Financing', st.cashflow.financingCF) + (st.cashflow.emergency ? line('Emergency loan', st.cashflow.emergency, 'warn') : '') + (st.cashflow.otherIncome ? line('One-off items', st.cashflow.otherIncome) : '') + line('Closing cash', st.cashflow.closing, 'b total') + '</tbody></table></section>' +
    '<section class="card"><div class="card-head"><h2>Balance sheet</h2></div><table class="table sp-fin"><tbody>' + line('Cash', st.balance.cash) + line('Receivables', st.balance.receivables) + line('Inventory', st.balance.inventory) + line('Plant & equipment', st.balance.ppe) + line('Total assets', st.balance.assets, 'b') +
    line('Payables', st.balance.payables) + line('Debt', st.balance.debt) + line('Share capital', st.balance.paidIn) + line('Retained earnings', st.balance.retained) + line('Liabilities + equity', st.balance.liabilities + st.balance.equity, 'b total') + '</tbody></table></section>' +
    '<section class="card"><div class="card-head"><h2>Decisions used</h2><span class="xs muted">' + esc(x.source) + '</span></div><table class="table sp-fin"><tbody>' + Object.keys(x.values).map((k) => { const d = (r.decisionDefs.find((y) => y.key === k)) || { label: k, unit: 'number' }; return '<tr><td>' + esc(d.label) + '</td><td class="tnum">' + esc(smUnitFmt(x.values[k], d.unit, r.basics)) + '</td></tr>'; }).join('') + '</tbody></table></section></aside></div>';
}
function spTrace(x, r) {
  const t = x.trace, cur = r.basics.currency;
  return '<section class="card"><div class="card-head"><h2>Calculation trace</h2>' + badge('Preview / teachers only', 'info') + '</div><div class="card-body small"><p>Unit cost ' + smMoney(t.unitCost, cur) + ' · produced ' + smNum(t.produced, 0) + ' (max ' + smNum(t.prodMax, 0) + ') · available to sell ' + smNum(t.supply, 0) + ' · interest rate ' + smFmt(t.rate, 'pct') + ' · cost index ' + smNum(t.econCost, 3) + (t.active.length ? ' · active events: ' + esc(t.active.join(', ')) : '') + '</p>' +
    '<div class="table-wrap"><table class="table"><thead><tr><th>Segment</th><th class="tnum">Potential</th><th class="tnum">Buying</th><th class="tnum">Your share</th><th class="tnum">Demand</th><th>Attractiveness (price · quality · brand · sustainability · reach · promotion · custom)</th></tr></thead><tbody>' +
    t.segments.map((s) => '<tr><td>' + esc(s.seg) + '</td><td class="tnum">' + smNum(s.potential, 0) + '</td><td class="tnum">' + smFmt(s.participation, 'pct') + '</td><td class="tnum">' + smFmt(s.share, 'pct') + '</td><td class="tnum">' + smNum(s.demand, 0) + '</td><td class="xs tnum">' + ['price', 'quality', 'brand', 'sustainability', 'distribution', 'promotion', 'custom'].map((k) => (s.utility[k] >= 0 ? '+' : '') + (Math.round(s.utility[k] * 100) / 100)).join(' · ') + (s.utility.power ? ' · power ' + Math.round(s.utility.power * 100) / 100 : '') + '</td></tr>').join('') + '</tbody></table></div></div></section>';
}

/* ---------- performance ---------- */
function spPerformance(r) {
  if (!r.myRounds.length) return '<div class="card card-pad">' + emptyState('trending', 'No results yet', 'Trends appear after the first round.', '', false) + '</div>';
  const labels = r.myRounds.map((x) => 'R' + x.n), cur = r.basics.currency, col = r.myTeam.color;
  const ser = (name, f) => [{ name, color: col, values: r.myRounds.map(f), strong: true }];
  const ch = (title, f, yf) => '<section class="card"><div class="card-head"><h2>' + title + '</h2></div><div class="card-body">' + chartSlot('lines', { labels, series: ser(title, f), label: title, yFmt: yf, valFmt: yf, height: 190 }) + '</div></section>';
  return '<div class="grid-2">' + ch('Score', (x) => x.score.overall, (v) => Math.round(v)) + ch('Revenue', (x) => x.metrics.revenue, (v) => smMoney(v, cur)) + ch('Net profit', (x) => x.metrics.netProfit, (v) => smMoney(v, cur)) + ch('Market share', (x) => x.metrics.marketShare, (v) => smFmt(v, 'pct')) + ch('Cash', (x) => x.metrics.cash, (v) => smMoney(v, cur)) + ch('Customer satisfaction', (x) => x.metrics.satisfaction, (v) => Math.round(v)) + '</div>' +
    '<section class="card"><div class="card-head"><h2>KPIs by round</h2></div><div class="table-wrap"><table class="table"><thead><tr><th>KPI</th>' + labels.map((l) => '<th class="tnum">' + l + '</th>').join('') + '<th class="tnum">Target</th></tr></thead><tbody>' +
    r.kpiDefs.map((k) => '<tr><td>' + esc(k.label) + '</td>' + r.myRounds.map((x) => '<td class="tnum">' + smFmt(x.kpis[k.key], k.format, cur) + '</td>').join('') + '<td class="tnum muted">' + smFmt(k.target, k.format, cur) + '</td></tr>').join('') +
    r.formulas.filter((f) => !r.kpiDefs.some((k) => k.key === f.key)).map((f) => '<tr><td>' + esc(f.label) + ' <span class="xs muted">formula</span></td>' + r.myRounds.map((x) => '<td class="tnum">' + smFmt(x.metrics[f.key], f.format, cur) + '</td>').join('') + '<td></td></tr>').join('') + '</tbody></table></div></section>' + smLbCard(r);
}

/* ---------- team and journal ---------- */
function spTeam(r) {
  const t = r.myTeam, ceo = t.role === 'CEO', roles = r.settings.teamRoles, cur = r.basics.currency;
  const typeLbl = { decision: ['Decision', 'send'], outcome: ['Outcome', 'chart'], note: ['Note', 'edit'], reflection: ['Reflection', 'award'] };
  return '<div class="sm-cols"><section class="sm-col"><section class="card"><div class="card-head"><h2>Decision journal</h2></div><div class="card-body">' +
    '<form data-form="spNote" class="sp-noteform"><textarea name="text" rows="2" maxlength="3000" placeholder="Add a note: an idea, a concern, why you changed course…"></textarea><button class="btn btn-sm btn-primary">' + icon('plus', 'i-sm') + 'Add note</button></form>' +
    (r.journal.length ? '<ol class="sp-journal">' + r.journal.map((j) => '<li class="' + j.type + '"><span class="sp-jicon">' + icon((typeLbl[j.type] || ['', 'info'])[1], 'i-sm') + '</span><div><div class="xs muted">' + (typeLbl[j.type] || [j.type])[0] + ' · round ' + j.round + ' · ' + esc(rel(j.at)) + (j.by ? ' · ' + esc(j.by) : '') + '</div>' +
      (j.type === 'outcome' ? '<div class="small">Revenue ' + smMoney(j.data.revenue, cur) + (j.data.dRevenue != null ? ' (' + (j.data.dRevenue >= 0 ? '+' : '') + smMoney(j.data.dRevenue, cur) + ')' : '') + ' · profit ' + smMoney(j.data.netProfit, cur) + ' · share ' + smFmt(j.data.marketShare, 'pct') + ' · score <b>' + Math.round(j.data.score) + '</b>' + (j.data.dScore != null ? ' (' + (j.data.dScore >= 0 ? '+' : '') + Math.round(j.data.dScore) + ')' : '') + (j.data.source && j.data.source !== 'submitted' ? ' · <i>' + esc(j.data.source) + '</i>' : '') + '</div>'
        : j.type === 'decision' ? '<div class="small">' + (j.text ? '“' + esc(j.text) + '”' : '<i>no reasoning given</i>') + '</div><details class="xs"><summary>Decisions</summary>' + Object.keys(j.data.values || {}).map((k) => { const d = r.decisionDefs.find((y) => y.key === k) || { label: k, unit: 'number' }; return esc(d.label) + ': ' + esc(smUnitFmt(j.data.values[k], d.unit, r.basics)); }).join(' · ') + '</details>'
          : '<div class="small sp-pre">' + esc(j.text) + '</div>') + '</div></li>').join('') + '</ol>' : '<p class="small muted">Decisions, outcomes and notes appear here.</p>') + '</div></section></section>' +
    '<aside class="sm-col side"><section class="card"><div class="card-head"><h2>' + esc(t.name) + '</h2></div><div class="card-body"><ul class="sm-members">' + t.members.map((m) => '<li>' + avatar(m.name, 'sm') + '<span>' + esc(m.name) + (m.me ? ' (you)' : '') + '</span>' + (ceo ? '<select data-change="spRole" data-uid="' + esc(m.uid) + '" aria-label="Role"><option value="">—</option>' + roles.map((x) => '<option' + (x === m.role ? ' selected' : '') + '>' + esc(x) + '</option>').join('') + '</select>' : '<span class="xs muted">' + esc(m.role || '') + '</span>') + '</li>').join('') + '</ul>' +
    (r.settings.roleMode ? '<p class="xs muted">Role-based decisions are on: each role sets its own decisions' + (r.settings.requireApprovals ? ' and approves them' : '') + '; the CEO submits.</p>' : '<p class="xs muted">Every member can change any decision; anyone can submit.</p>') + '</div></section>' +
    '<section class="card"><div class="card-head"><h2>Company</h2></div><div class="card-body small"><p><span class="sm-dot" style="background:' + esc(t.company.color) + '"></span><b>' + esc(t.company.name) + '</b> · founded ' + esc(t.company.foundingYear) + '</p><p class="muted">' + esc(r.basics.description) + '</p>' + (r.basics.objectives.length ? '<b class="xs">You will learn to</b><ul class="xs">' + r.basics.objectives.map((o) => '<li>' + esc(o) + '</li>').join('') + '</ul>' : '') + '</div></section></aside></div>';
}
FORMS.spNote = (f, btn) => busy(btn, async () => { await call('smJournal', { id: SP.run.id, text: f.elements.text.value }); refresh(); });
ACT.spRole = (d, el) => busy(null, async () => { const members = SP.run.myTeam.members.map((m) => ({ uid: m.uid, role: m.uid === d.uid ? el.value : m.role })); await call('smSetRoles', { id: SP.run.id, members }); toast('Roles updated.'); refresh(); });

/* ---------- debrief (also used by faculty analytics) ---------- */
async function spDebrief(r) {
  let db;
  try { db = await call('smDebrief', { id: r.id }); } catch (e) { return '<div class="card card-pad">' + emptyState('award', 'The debrief opens at the end', esc(e.message), '', false) + '</div>'; }
  return smDebriefHtml(db, r, false);
}
function smDebriefHtml(db, r, faculty) {
  const cur = r.basics.currency;
  const fmtR = (x) => (x > 0 ? '+' : '') + x.toFixed(2);
  return '<div class="sp-debrief"><section class="card sp-final"><div class="card-body">' + smScoreRing(db.final, 110) + '<div><div class="sm-eyebrow">' + esc(db.team) + ' — final score</div><h2>' + (db.final >= 70 ? 'An outstanding result' : db.final >= 55 ? 'A solid result' : db.final >= 40 ? 'Mixed results' : 'A tough simulation') + '</h2>' +
    db.explanation.categories.map((c) => '<div class="sp-catrow"><span class="xs">' + esc(c.category) + ' (' + c.weight + '%)</span><div class="progress"><i style="width:' + c.score + '%"></i></div><b class="xs tnum">' + Math.round(c.score) + '</b></div>').join('') + '</div></div></section>' +
    '<div class="sm-cols"><section class="sm-col">' +
    '<section class="card"><div class="card-head"><h2>What happened?</h2></div><div class="card-body"><ol class="sp-timeline">' + db.timeline.map((t) => '<li><b>Round ' + t.n + ': ' + esc(t.title) + '</b>' + (t.events.length ? ' ' + t.events.map((e) => badge(e, 'warning', 'zap')).join(' ') : '') + '<div class="small">Revenue ' + smMoney(t.revenue, cur) + ' · profit ' + smMoney(t.netProfit, cur) + ' · share ' + smFmt(t.marketShare, 'pct') + ' · score <b>' + Math.round(t.score) + '</b> · your price ' + smMoney(t.price, cur) + ' vs market ' + smMoney(t.marketPrice, cur) + '</div>' + (t.notes.length ? '<div class="xs muted">' + esc(t.notes.join(' ')) + '</div>' : '') + '</li>').join('') + '</ol></div></section>' +
    '<section class="card"><div class="card-head"><h2>Why did it happen?</h2></div><div class="card-body">' + (db.why.length ? '<ul class="small">' + db.why.map((w) => '<li><b>R' + w.n + ':</b> ' + esc(w.text) + '</li>').join('') + '</ul>' : '') +
    (db.drivers.length ? '<p class="small"><b>In the final round, against the average rival:</b></p><ul class="small">' + db.drivers.map((d) => '<li>' + (d.diff > 0 ? '✓ ' : '✗ ') + esc(d.text) + '</li>').join('') + '</ul>' : '') + '</div></section>' +
    '<section class="card"><div class="card-head"><h2>Which decisions mattered?</h2><span class="xs muted">link between each decision and round scores, across all teams</span></div><div class="card-body">' + (db.mattered.length ? db.mattered.map((m) => '<div class="sp-corr"><span class="small">' + esc(m.label) + '</span><div class="sp-corrbar"><i class="' + (m.r >= 0 ? 'pos' : 'neg') + '" style="width:' + Math.round(Math.abs(m.r) * 50) + '%;' + (m.r >= 0 ? 'left:50%' : 'right:50%') + '"></i></div><b class="xs tnum">' + fmtR(m.r) + '</b></div>').join('') + '<p class="xs muted">A link is not proof of cause: compare with what happened in the market.</p>' : '<p class="small muted">Not enough data.</p>') + '</div></section>' +
    '<section class="card"><div class="card-head"><h2>Which strategies performed differently?</h2></div><div class="table-wrap"><table class="table"><thead><tr><th>Team</th><th>Strategy</th><th class="tnum">Price vs market</th><th class="tnum">Final score</th></tr></thead><tbody>' + db.strategies.map((s) => '<tr class="' + (s.mine ? 'mine' : '') + '"><td>' + esc(s.team) + (s.mine ? ' (you)' : '') + '</td><td>' + esc(s.strategy) + '</td><td class="tnum">' + (s.relPrice ? Math.round(s.relPrice * 100) + '%' : '—') + '</td><td class="tnum"><b>' + s.final + '</b></td></tr>').join('') + '</tbody></table></div></section>' +
    '<section class="card"><div class="card-head"><h2>What could have been done differently?</h2></div><div class="card-body">' + (db.differently.length ? '<ul class="small">' + db.differently.map((d) => '<li>' + esc(d.text) + (d.rounds.length ? ' <span class="xs muted">(round ' + d.rounds.join(', ') + ')</span>' : '') + '</li>').join('') + '</ul>' : '<p class="small">No major mistakes detected — well done.</p>') + '</div></section></section>' +
    '<aside class="sm-col side"><section class="card"><div class="card-head"><h2>Key learning points</h2></div><div class="card-body"><ul class="small">' + db.learningPoints.map((p) => '<li>' + esc(p) + '</li>').join('') + '</ul>' + (db.facultyNotes && faculty ? '<p class="xs muted"><b>Teacher notes:</b> ' + esc(db.facultyNotes) + '</p>' : '') + '</div></section>' +
    (faculty ? '' : spReflectCard(db, r)) +
    '<section class="card"><div class="card-head"><h2>Decision vs outcome</h2></div><div class="card-body"><ol class="sp-journal compact">' + db.journal.filter((j) => j.type === 'decision' || j.type === 'outcome').map((j) => '<li class="' + j.type + '"><div class="xs muted">R' + j.round + ' · ' + j.type + '</div><div class="xs">' + (j.type === 'outcome' ? 'Score ' + Math.round(j.data.score) + (j.data.dScore != null ? ' (' + (j.data.dScore >= 0 ? '+' : '') + Math.round(j.data.dScore) + ')' : '') + ' · profit ' + smMoney(j.data.netProfit, cur) : (j.text ? '“' + esc(j.text.slice(0, 160)) + '”' : 'Decisions submitted')) + '</div></li>').join('') + '</ol></div></section></aside></div></div>';
}
function spReflectCard(db, r) {
  const ref = db.reflection;
  return '<section class="card"><div class="card-head"><h2>Reflection</h2>' + (ref ? badge(ref.grade != null ? 'Graded ' + ref.grade + '/100' : 'Submitted', ref.grade != null ? 'success' : 'info') : '') + '</div><form class="card-body" data-form="spReflect">' +
    db.questions.map((q, i) => '<label class="sm-field full"><span class="sm-lbl">' + esc(q) + '</span><textarea name="a' + i + '" rows="3" maxlength="5000">' + esc(ref ? (ref.answers[i] || '') : '') + '</textarea></label>').join('') +
    (ref && ref.feedback ? '<div class="notice ok"><div><b>Feedback:</b> ' + esc(ref.feedback) + '</div></div>' : '') + '<button class="btn btn-primary">' + icon('send', 'i-sm') + (ref ? 'Update reflection' : 'Submit reflection') + '</button></form></section>';
}
FORMS.spReflect = (f, btn) => busy(btn, async () => { const answers = Array.from(f.querySelectorAll('textarea')).map((t) => t.value); await call('smReflect', { id: SP.run.id, answers }); toast('Reflection saved.'); refresh(); });
