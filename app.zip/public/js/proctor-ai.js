'use strict';
/* =====================================================================
   PROCTORING AI — runs entirely in the student's browser.
   • MediaPipe Face Landmarker: face count, 478 landmarks, head pose (yaw/pitch)
     from the facial transformation matrix, gaze + mouth + blink from blendshapes.
   • MediaPipe Object Detector (EfficientDet-Lite0, COCO): phones, books,
     laptops/screens, extra people.
   • face-api.js (FaceNet-style 128-d embeddings): identity signatures that the
     server compares with the student's enrolled face.
   • Web Audio: voice-activity detection (speech-band energy over an adaptive
     noise floor).
   Models are fetched once from public CDNs and cached by the browser. Video and
   audio never leave the device; only events, small snapshots and signatures do.
   ===================================================================== */
const PAI = (() => {
  const MP = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@1.0.1';
  const FACE_MODEL = 'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task';
  const OBJ_MODEL = 'https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/int8/1/efficientdet_lite0.tflite';
  const FACEAPI = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.15';
  const OBJECTS = ['person', 'cell phone', 'book', 'laptop', 'tv', 'remote'];
  const st = { v: null, fileset: null, face: null, objects: null, fa: null, p: {}, gpu: '', lastTs: { face: 0, obj: 0 } };

  function withDelegate(opts, d) { const o = Object.assign({}, opts); o.baseOptions = Object.assign({}, opts.baseOptions, { delegate: d }); return o; }
  async function create(Task, opts, cpuOnly) {
    if (cpuOnly) return Task.createFromOptions(st.fileset, withDelegate(opts, 'CPU'));
    try { const t = await Task.createFromOptions(st.fileset, withDelegate(opts, 'GPU')); st.gpu = st.gpu || 'GPU'; return t; } catch (e) {
      st.gpu = 'CPU';
      return Task.createFromOptions(st.fileset, withDelegate(opts, 'CPU'));
    }
  }
  function once(key, fn) {
    if (!st.p[key]) st.p[key] = fn().catch((e) => { st.p[key] = null; throw e; });
    return st.p[key];
  }
  async function fileset() {
    if (!st.v) st.v = await import(MP + '/vision_bundle.mjs');
    if (!st.fileset) st.fileset = await st.v.FilesetResolver.forVisionTasks(MP + '/wasm');
    return st.v;
  }
  const loadFace = () => once('face', async () => {
    const v = await fileset();
    st.face = await create(v.FaceLandmarker, {
      baseOptions: { modelAssetPath: FACE_MODEL }, runningMode: 'VIDEO', numFaces: 4,
      outputFaceBlendshapes: true, outputFacialTransformationMatrixes: true,
      minFaceDetectionConfidence: 0.5, minFacePresenceConfidence: 0.5, minTrackingConfidence: 0.5
    });
    return true;
  });
  const loadObjects = () => once('obj', async () => {
    const v = await fileset();
    // The int8 model returns nothing on the WebGL delegate, so it always runs on the CPU (it's small and runs every 1.5 s).
    st.objects = await create(v.ObjectDetector, {
      baseOptions: { modelAssetPath: OBJ_MODEL }, runningMode: 'VIDEO', scoreThreshold: 0.35, maxResults: 10, categoryAllowlist: OBJECTS
    }, true);
    return true;
  });
  const loadIdentity = () => once('id', async () => {
    const m = await import(FACEAPI + '/dist/face-api.esm.js');
    const fa = m.nets ? m : m.default;
    if (fa.tf) { try { await fa.tf.setBackend('webgl'); } catch (e) { /* CPU fallback */ } await fa.tf.ready(); }
    await Promise.all([
      fa.nets.tinyFaceDetector.loadFromUri(FACEAPI + '/model'),
      fa.nets.faceLandmark68TinyNet.loadFromUri(FACEAPI + '/model'),
      fa.nets.faceRecognitionNet.loadFromUri(FACEAPI + '/model')
    ]);
    st.fa = fa;
    return true;
  });

  /** Monotonic timestamps per task (MediaPipe VIDEO mode requires them). */
  function ts(key) { let t = performance.now(); if (t <= st.lastTs[key]) t = st.lastTs[key] + 1; st.lastTs[key] = t; return t; }
  const DEG = 180 / Math.PI;
  const wrap = (a) => { a = ((a + 180) % 360 + 360) % 360 - 180; return a; };

  /** One pass of the face model. Angles are raw; subtract a baseline for deviation. */
  function face(video) {
    if (!st.face || !video.videoWidth) return null;
    const r = st.face.detectForVideo(video, ts('face'));
    const n = r.faceLandmarks ? r.faceLandmarks.length : 0;
    const out = { faces: n, yaw: null, pitch: null, gazeH: 0, gazeV: 0, jaw: 0, blink: 0, box: null };
    if (!n) return out;
    // Largest face = the student.
    let best = 0, bestArea = -1;
    r.faceLandmarks.forEach((lm, i) => {
      let x0 = 1, y0 = 1, x1 = 0, y1 = 0;
      lm.forEach((p) => { if (p.x < x0) x0 = p.x; if (p.x > x1) x1 = p.x; if (p.y < y0) y0 = p.y; if (p.y > y1) y1 = p.y; });
      const area = (x1 - x0) * (y1 - y0);
      if (area > bestArea) { bestArea = area; best = i; out.box = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 }; }
    });
    const m = r.facialTransformationMatrixes && r.facialTransformationMatrixes[best];
    if (m && m.data) {
      const d = m.data; // 4×4 column-major rotation+translation
      out.pitch = Math.atan2(d[6], d[10]) * DEG;
      out.yaw = Math.asin(Math.max(-1, Math.min(1, -d[2]))) * DEG;
    } else {
      // Fallback: nose tip against the outer eye corners.
      const lm = r.faceLandmarks[best], L = lm[33], R = lm[263], N = lm[1];
      out.yaw = ((N.x - L.x) / Math.max(1e-6, R.x - L.x) - 0.5) * 120;
      out.pitch = 0;
    }
    const bs = r.faceBlendshapes && r.faceBlendshapes[best];
    if (bs && bs.categories) {
      const c = {};
      bs.categories.forEach((k) => { c[k.categoryName] = k.score; });
      out.gazeH = ((c.eyeLookInLeft || 0) + (c.eyeLookOutRight || 0) - (c.eyeLookOutLeft || 0) - (c.eyeLookInRight || 0)) / 2;
      out.gazeV = ((c.eyeLookUpLeft || 0) + (c.eyeLookUpRight || 0) - (c.eyeLookDownLeft || 0) - (c.eyeLookDownRight || 0)) / 2;
      out.jaw = c.jawOpen || 0;
      out.blink = ((c.eyeBlinkLeft || 0) + (c.eyeBlinkRight || 0)) / 2;
    }
    return out;
  }

  function objects(video) {
    if (!st.objects || !video.videoWidth) return [];
    const r = st.objects.detectForVideo(video, ts('obj'));
    return (r.detections || []).map((d) => ({ label: d.categories[0].categoryName, score: d.categories[0].score, box: d.boundingBox }));
  }

  async function descriptor(input, big) {
    const fa = st.fa;
    if (!fa) return null;
    const r = await fa.detectSingleFace(input, new fa.TinyFaceDetectorOptions({ inputSize: big ? 512 : 416, scoreThreshold: big ? 0.35 : 0.42 }))
      .withFaceLandmarks(true).withFaceDescriptor();
    return r ? { d: Array.from(r.descriptor, (x) => Math.round(x * 10000) / 10000), score: r.detection.score } : null;
  }

  /* ---------- light / covered camera ---------- */
  const tiny = document.createElement('canvas');
  tiny.width = 32; tiny.height = 24;
  /** Mean/SD luminance of the frame, or of a normalised box (e.g. the face) when given. */
  function light(video, box) {
    if (!video.videoWidth) return null;
    const g = tiny.getContext('2d', { willReadFrequently: true });
    if (box) {
      const W = video.videoWidth, H = video.videoHeight;
      g.drawImage(video, Math.max(0, box.x * W), Math.max(0, box.y * H), Math.max(1, box.w * W), Math.max(1, box.h * H), 0, 0, 32, 24);
    } else g.drawImage(video, 0, 0, 32, 24);
    const px = g.getImageData(0, 0, 32, 24).data;
    let s = 0, s2 = 0;
    const n = px.length / 4;
    for (let i = 0; i < px.length; i += 4) { const y = 0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2]; s += y; s2 += y * y; }
    const mean = s / n;
    return { mean, sd: Math.sqrt(Math.max(0, s2 / n - mean * mean)) };
  }

  /** JPEG snapshot (base64, no prefix) of a video element or canvas. */
  function grab(src, width, quality, mirror) {
    const w0 = src.videoWidth || src.width, h0 = src.videoHeight || src.height;
    if (!w0 || !h0) return '';
    const w = Math.min(width, w0), h = Math.round(h0 * w / w0);
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const g = c.getContext('2d');
    if (mirror) { g.translate(w, 0); g.scale(-1, 1); }
    g.drawImage(src, 0, 0, w, h);
    return c.toDataURL('image/jpeg', quality || 0.7).split(',')[1] || '';
  }

  /* ---------- voice activity ---------- */
  function audio(stream) {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx || !stream || !stream.getAudioTracks().length) return null;
    const ctx = new Ctx();
    const an = ctx.createAnalyser();
    an.fftSize = 2048; an.smoothingTimeConstant = 0.3;
    ctx.createMediaStreamSource(stream).connect(an);
    const buf = new Float32Array(an.fftSize), spec = new Float32Array(an.frequencyBinCount);
    const hz = ctx.sampleRate / an.fftSize;
    let floor = -70;
    return {
      ctx,
      read() {
        if (ctx.state === 'suspended') ctx.resume().catch(() => {});
        an.getFloatTimeDomainData(buf);
        let rms = 0;
        for (let i = 0; i < buf.length; i++) rms += buf[i] * buf[i];
        const db = 10 * Math.log10(rms / buf.length + 1e-12);
        an.getFloatFrequencyData(spec);
        let band = 0, all = 0;
        for (let i = 1; i < spec.length; i++) {
          const f = i * hz;
          if (f < 80 || f > 8000) continue;
          const e = Math.pow(10, spec[i] / 10);
          all += e;
          if (f >= 300 && f <= 3400) band += e;
        }
        const ratio = all ? band / all : 0;
        // Noise floor follows quiet moments quickly and loud ones slowly.
        floor = db < floor ? floor * 0.7 + db * 0.3 : floor + 0.03;
        const voiced = db > -58 && db > floor + 12 && ratio > 0.55;
        return { db, level: Math.max(0, Math.min(1, (db + 70) / 55)), voiced, ratio };
      },
      close() { ctx.close().catch(() => {}); }
    };
  }

  const VIRTUAL = /virtual|obs|manycam|snap camera|xsplit|camtwist|splitcam|e2esoft|youcam|webcamoid|nvidia broadcast/i;
  const PHONECAM = /droidcam|iriun|epoccam|ivcam|camo\b|continuity/i;

  return {
    loadFace, loadObjects, loadIdentity, face, objects, descriptor, light, grab, audio, wrap,
    VIRTUAL, PHONECAM,
    ready: () => ({ face: !!st.face, objects: !!st.objects, identity: !!st.fa, delegate: st.gpu || '' })
  };
})();
