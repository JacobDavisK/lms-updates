'use strict';
/* =====================================================================
   PHONE APP (Android / iOS)
   The store apps open this site inside a native shell (Capacitor). In the app:
   downloads go to the share sheet (save to Files / Drive, send to WhatsApp…),
   other websites open in the system browser, the Android back button moves
   back through the LMS, and the status bar follows light / dark mode.
   In a normal browser none of this runs.
   ===================================================================== */
const NATIVE = !!(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform());
const NPlug = (name) => (NATIVE && window.Capacitor.Plugins && window.Capacitor.Plugins[name]) || null;

if (NATIVE) {
  document.documentElement.classList.add('is-app', 'is-app-' + window.Capacitor.getPlatform());

  /* ---------- downloads: blob/data links can't be saved by a WebView, so hand the file to the share sheet ---------- */
  const blobToB64 = (blob) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1] || ''); r.onerror = rej; r.readAsDataURL(blob); });
  async function nativeSave(href, name) {
    const fsys = NPlug('Filesystem'), share = NPlug('Share');
    if (!fsys || !share) { toast('Downloads are not available in this version of the app.', 'err'); return; }
    try {
      const blob = await (await fetch(href)).blob();
      const safe = String(name || 'download').replace(/[\\/:*?"<>|\x00-\x1f]+/g, '_').slice(0, 120) || 'download';
      const w = await fsys.writeFile({ path: safe, data: await blobToB64(blob), directory: 'CACHE' });
      await share.share({ title: safe, url: w.uri, dialogTitle: 'Save or share ' + safe });
    } catch (e) {
      if (!/cancel/i.test(String(e && e.message))) toast('Could not save the file: ' + (e && e.message ? e.message : e), 'err');
    }
  }
  const nativeClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (this.hasAttribute('download') && /^(blob:|data:)/.test(this.href)) { nativeSave(this.href, this.getAttribute('download')); return; }
    return nativeClick.call(this);
  };

  /* ---------- other websites open in the system browser (the app only shows this LMS) ---------- */
  const external = (url) => { try { const u = new URL(url, location.href); return /^https?:$/.test(u.protocol) && u.origin !== location.origin; } catch (e) { return false; } };
  const openOutside = (url) => { const b = NPlug('Browser'); if (b) b.open({ url: String(url) }); else location.href = url; };
  document.addEventListener('click', (e) => {
    const a = e.target.closest && e.target.closest('a[href]');
    if (!a) return;
    if (a.hasAttribute('download') && /^(blob:|data:)/.test(a.href)) { e.preventDefault(); nativeSave(a.href, a.getAttribute('download')); return; }
    if (external(a.href) || (/^(mailto|tel|sms|whatsapp):/i.test(a.getAttribute('href')))) { e.preventDefault(); if (/^https?:/i.test(a.href)) openOutside(a.href); else location.href = a.href; }
  }, true);
  const nativeOpen = window.open;
  window.open = function (url) {
    if (url && external(url)) { openOutside(url); return null; }
    return nativeOpen.apply(window, arguments);
  };

  /* ---------- printing is not available inside an app WebView ---------- */
  window.print = function () { toast('Printing is not available in the app. Use Export or Download, or open the LMS in a browser to print.', 'err'); };

  /* ---------- Android back button: close a dialog, then go back, then leave the app ---------- */
  const appPlug = NPlug('App');
  if (appPlug) {
    appPlug.addListener('backButton', () => {
      const pres = document.querySelector('.st-present');
      if (pres) { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); return; }
      if (document.querySelector('.modal-bg')) { if (typeof closeModal === 'function') closeModal(); return; }
      if (document.body.classList.contains('nav-open')) { document.body.classList.remove('nav-open'); return; }
      const home = typeof homePath === 'function' && S && S.me ? '#' + homePath() : '#/';
      if (location.hash && location.hash !== home && history.length > 1) history.back();
      else appPlug.minimizeApp ? appPlug.minimizeApp() : appPlug.exitApp();
    });
    // back from the background: refresh what is on screen (new messages, notifications)
    appPlug.addListener('resume', () => { if (S && S.me && typeof refresh === 'function' && !document.querySelector('.modal-bg, .st-editor, .exam, input:focus, textarea:focus')) refresh(); });
  }

  /* ---------- status bar follows the theme ---------- */
  const bar = NPlug('StatusBar');
  const paintBar = () => {
    if (!bar) return;
    const dark = document.documentElement.getAttribute('data-theme') === 'dark';
    try { bar.setStyle({ style: dark ? 'DARK' : 'LIGHT' }); if (window.Capacitor.getPlatform() === 'android') bar.setBackgroundColor({ color: dark ? '#0d0d0f' : '#f4f4f2' }); } catch (e) { /* older shell */ }
  };
  paintBar();
  new MutationObserver(paintBar).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
}
