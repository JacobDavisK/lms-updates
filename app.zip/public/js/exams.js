'use strict';
/* =====================================================================
   EXAMINATIONS — question papers (faculty only)
   /exams              papers hub: create, import from Word, review queue
   /exams/templates    institution & personal paper patterns
   /exams/p/:id        the editor: Word-style ribbon, A4 page, preview,
                       LaTeX export
   The paper is edited on an A4 "sheet" that mirrors the typeset output;
   every body is a contenteditable area whose DOM is converted into the
   same safe rich-text model the server turns into LaTeX (lib/qptex.js).
   ===================================================================== */
const EX = {
  paper: null, version: 0, canEdit: false, dirty: false, saving: false, timer: null, again: false,
  rt: null, range: null, idx: {}, files: {}, blobs: {}, checks: [], zoom: 1, katexP: null, home: null, info: null
};
const QP_STATUS = { draft: ['Draft', ''], review: ['Awaiting review', 'warning'], returned: ['Returned', 'danger'], approved: ['Approved', 'success'] };
const QP_CHOICE = { all: 'Answer all', either: 'Either (a) or (b)', any: 'Answer any' };
const QP_BL = {
  K: ['K1 Remember', 'K2 Understand', 'K3 Apply', 'K4 Analyse', 'K5 Evaluate', 'K6 Create'],
  L: ['L1 Remember', 'L2 Understand', 'L3 Apply', 'L4 Analyse', 'L5 Evaluate', 'L6 Create'],
  BT: ['BT1 Remember', 'BT2 Understand', 'BT3 Apply', 'BT4 Analyse', 'BT5 Evaluate', 'BT6 Create']
};
const QP_FONTS = { times: 'Times', lmodern: 'Latin Modern (Computer Modern)', palatino: 'Palatino', helvetica: 'Helvetica (sans serif)' };
const QP_PAPER = { a4: [210, 297], letter: [215.9, 279.4], legal: [215.9, 355.6] };
const ROMAN = ['i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii', 'viii', 'ix', 'x', 'xi', 'xii'];
const NUMWORD = ['ZERO', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE', 'TEN', 'ELEVEN', 'TWELVE', 'THIRTEEN', 'FOURTEEN', 'FIFTEEN', 'SIXTEEN', 'SEVENTEEN', 'EIGHTEEN', 'NINETEEN', 'TWENTY'];

/* ---------- small helpers ---------- */
function numS(n) { n = Number(n) || 0; return Number.isInteger(n) ? String(n) : String(Math.round(n * 100) / 100); }
function qpStatus(st) { const s = QP_STATUS[st] || QP_STATUS.draft; return badge(s[0], s[1]); }
function unitMarks(u) { return u && u.parts && u.parts.length ? u.parts.reduce((n, p) => n + (Number(p.marks) || 0), 0) : Number(u && u.marks) || 0; }
function secInfo(sec) {
  const qs = sec.questions || [];
  const each = Number(sec.marks) || 0;
  let counted = qs.map(unitMarks);
  const n = sec.choice === 'any' ? Math.max(0, Math.min(qs.length, Number(sec.attempt) || qs.length)) : qs.length;
  if (sec.choice === 'any') counted = counted.slice().sort((a, b) => b - a).slice(0, n);
  const total = counted.reduce((a, b) => a + b, 0);
  const uniform = each > 0 && qs.length && qs.every((q) => unitMarks(q) === each);
  return { total: uniform ? n * each : total, line: uniform && n ? n + ' × ' + numS(each) + ' = ' + numS(n * each) + ' Marks' : numS(total) + ' Marks', n, each };
}
function qpTotal(p) { return (p.sections || []).reduce((n, s) => n + secInfo(s).total, 0); }
function defaultNote(sec) {
  if (sec.choice === 'either') return 'Answer ALL questions, choosing either (a) or (b) from each';
  if (sec.choice === 'any') { const n = Number(sec.attempt) || 0; return 'Answer any ' + (NUMWORD[n] || n) + ' questions'; }
  return 'Answer ALL questions';
}
function uid(p) { return (p || 'Q') + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4); }
function blankUnit(marks) { return { id: uid('Q'), body: [], marks: marks || 0, co: 0, bl: 0, parts: [] }; }
function blankQ(sec) { return Object.assign(blankUnit(sec.marks), { alt: sec.choice === 'either' ? blankUnit(sec.marks) : null, pb: false }); }
function plainOf(blocks) {
  const inl = (c) => (c || []).map((r) => (r.x != null ? r.x : r.e != null ? r.e : r.bl ? '____' : ' ')).join('');
  return (blocks || []).map((b) => (b.t === 'p' || b.t === 'h' ? inl(b.c) : b.items ? b.items.map(plainOf).join(' ') : b.rows ? b.rows.map((r) => r.map((c) => plainOf(c.c)).join(' ')).join(' ') : b.x || '')).join(' ').trim();
}
function isEmptyBody(blocks) { return !(blocks || []).some((b) => b.t === 'img' || b.t === 'table' || b.t === 'eq' || plainOf([b]).trim()); }
function qpDownload(r) { downloadBase64(r.name, r.data, r.mime); }

/* ---------- KaTeX (served from /vendor/katex) ---------- */
function loadKatex() {
  if (window.katex) return Promise.resolve(window.katex);
  if (EX.katexP) return EX.katexP;
  EX.katexP = new Promise((res) => {
    const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = '/vendor/katex/katex.min.css'; document.head.appendChild(l);
    const s = document.createElement('script'); s.src = '/vendor/katex/katex.min.js';
    s.onload = () => res(window.katex); s.onerror = () => res(null);
    document.head.appendChild(s);
  });
  return EX.katexP;
}
function texHtml(tex, display) {
  if (!window.katex) return '<code class="rt-tex">' + esc(tex) + '</code>';
  try { return katex.renderToString(String(tex), { displayMode: !!display, throwOnError: false, strict: 'ignore', trust: false, output: 'html' }); } catch (e) { return '<code class="rt-tex">' + esc(tex) + '</code>'; }
}

/* =====================================================================
   MODEL → HTML   (edit: contenteditable islands for maths, images, blanks)
   ===================================================================== */
function inlineHtml(c) {
  return (c || []).map((r) => {
    if (r.br) return '<br>';
    if (r.bl) return '<span class="rt-blank" contenteditable="false" data-bl="' + r.bl + '" style="width:' + (r.bl * 0.9) + 'cm"></span>';
    if (r.e != null) return '<span class="rt-eq" contenteditable="false" data-tex="' + esc(r.e) + '">' + texHtml(r.e, false) + '</span>';
    let t = esc(r.x);
    if (r.k) t = '<code>' + t + '</code>';
    if (r.sup) t = '<sup>' + t + '</sup>';
    if (r.sub) t = '<sub>' + t + '</sub>';
    if (r.s) t = '<s>' + t + '</s>';
    if (r.u) t = '<u>' + t + '</u>';
    if (r.i) t = '<i>' + t + '</i>';
    if (r.b) t = '<b>' + t + '</b>';
    return t;
  }).join('');
}
function cellHtml(blocks) { return blocks.length === 1 && blocks[0].t === 'p' && !blocks[0].a ? inlineHtml(blocks[0].c) || '<br>' : blocksHtml(blocks) || '<br>'; }
function blocksHtml(blocks) {
  return (blocks || []).map((b) => {
    switch (b.t) {
      case 'p': return '<p' + (b.a && b.a !== 'j' ? ' style="text-align:' + { l: 'left', c: 'center', r: 'right' }[b.a] + '"' : '') + '>' + (inlineHtml(b.c) || '<br>') + '</p>';
      case 'h': return '<h4>' + (inlineHtml(b.c) || '<br>') + '</h4>';
      case 'ul': return '<ul>' + b.items.map((it) => '<li>' + cellHtml(it) + '</li>').join('') + '</ul>';
      case 'ol': return '<ol data-s="' + esc(b.s || '1') + '">' + b.items.map((it) => '<li>' + cellHtml(it) + '</li>').join('') + '</ol>';
      case 'table': return '<table class="rt-table"' + (b.head ? ' data-head="1"' : '') + '><tbody>' + b.rows.map((r, ri) => '<tr>' + r.map((c) => {
        const tag = b.head && ri === 0 ? 'th' : 'td';
        return '<' + tag + (c.cs > 1 ? ' colspan="' + c.cs + '"' : '') + '>' + cellHtml(c.c) + '</' + tag + '>';
      }).join('') + '</tr>').join('') + '</tbody></table>';
      case 'img': return '<figure class="rt-img" contenteditable="false" data-f="' + esc(b.f) + '" data-w="' + b.w + '" data-a="' + esc(b.a || 'c') + '" style="width:' + b.w + '%"><img data-f="' + esc(b.f) + '" alt="Figure"></figure>';
      case 'eq': return '<div class="rt-eqb" contenteditable="false" data-tex="' + esc(b.x) + '">' + texHtml(b.x, true) + '</div>';
      case 'code': return '<pre class="rt-code">' + esc(b.x) + '</pre>';
      default: return '';
    }
  }).join('');
}

/* =====================================================================
   HTML → MODEL   (editor DOM or pasted HTML from Word / Docs / web)
   ===================================================================== */
const QP_BLOCK = new Set(['P', 'DIV', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'LI', 'BLOCKQUOTE', 'SECTION', 'ARTICLE', 'HEADER', 'FOOTER', 'FIGURE', 'FIGCAPTION', 'ADDRESS', 'DD', 'DT', 'DL', 'CENTER', 'MAIN', 'ASIDE', 'NAV']);
const QP_SKIP = new Set(['STYLE', 'SCRIPT', 'META', 'TITLE', 'HEAD', 'LINK', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'SVG', 'NOSCRIPT', 'TEMPLATE', 'IFRAME', 'OBJECT']);
function alignOf(n) {
  const a = (n.style && n.style.textAlign) || n.getAttribute('align') || '';
  return /center/.test(a) ? 'c' : /right|end/.test(a) ? 'r' : /left|start/.test(a) ? 'l' : /justify/.test(a) ? 'j' : '';
}
function fmtOf(n, f) {
  const o = Object.assign({}, f);
  const t = n.tagName;
  if (t === 'B' || t === 'STRONG') o.b = 1;
  if (t === 'I' || t === 'EM' || t === 'CITE' || t === 'VAR') o.i = 1;
  if (t === 'U' || t === 'INS') o.u = 1;
  if (t === 'S' || t === 'STRIKE' || t === 'DEL') o.s = 1;
  if (t === 'SUP') { o.sup = 1; delete o.sub; }
  if (t === 'SUB') { o.sub = 1; delete o.sup; }
  if (t === 'CODE' || t === 'KBD' || t === 'TT' || t === 'SAMP') o.k = 1;
  const st = n.style;
  if (st) {
    if (/^(bold|bolder|[6-9]00)$/.test(st.fontWeight)) o.b = 1; else if (/^(normal|lighter|[1-5]00)$/.test(st.fontWeight)) delete o.b;
    if (st.fontStyle === 'italic') o.i = 1; else if (st.fontStyle === 'normal') delete o.i;
    const deco = st.textDecorationLine || st.textDecoration || '';
    if (/underline/.test(deco)) o.u = 1;
    if (/line-through/.test(deco)) o.s = 1;
    if (st.verticalAlign === 'super') o.sup = 1; else if (st.verticalAlign === 'sub') o.sub = 1;
    if (/mono|courier|consolas/i.test(st.fontFamily || '')) o.k = 1;
  }
  return o;
}
function pushText(c, t, f) {
  if (!t) return;
  const run = Object.assign({ x: t }, f);
  const prev = c[c.length - 1];
  const same = prev && prev.x != null && ['b', 'i', 'u', 's', 'sup', 'sub', 'k'].every((k) => !!prev[k] === !!run[k]);
  if (same) prev.x += t; else c.push(run);
}
function trimRuns(c) {
  c = c.filter((r) => r.x == null || r.x !== '');
  c.forEach((r) => { if (r.x != null) r.x = r.x.replace(/ {2,}/g, ' '); });
  while (c.length && c[0].br) c.shift();
  while (c.length && c[c.length - 1].br) c.pop();
  if (c[0] && c[0].x != null) c[0].x = c[0].x.replace(/^\s+/, '');
  const last = c[c.length - 1];
  if (last && last.x != null) last.x = last.x.replace(/\s+$/, '');
  return c.filter((r) => r.x == null || r.x !== '');
}
function listStyleOf(ol) {
  const d = ol.dataset && ol.dataset.s; if (d) return d;
  const t = ol.getAttribute('type'); if (t && /^[1aAiI]$/.test(t)) return t;
  const ls = (ol.style && ol.style.listStyleType) || '';
  return /lower-(alpha|latin)/.test(ls) ? 'a' : /upper-(alpha|latin)/.test(ls) ? 'A' : /lower-roman/.test(ls) ? 'i' : /upper-roman/.test(ls) ? 'I' : '1';
}
function tableBlock(tb) {
  const rows = [...tb.rows].map((tr) => [...tr.cells].map((td) => ({ c: domBlocks(td), cs: Math.max(1, Math.min(12, td.colSpan || 1)) }))).filter((r) => r.length);
  if (!rows.length) return null;
  const head = tb.dataset.head === '1' || [...tb.rows[0].cells].every((c) => c.tagName === 'TH');
  return { t: 'table', head, rows };
}
function domBlocks(root) {
  const out = []; let para = null;
  const cur = (ctx) => { if (!para) { para = { t: ctx.t || 'p', c: [] }; if (ctx.a && ctx.a !== 'j' && para.t === 'p') para.a = ctx.a; } return para; };
  const flush = () => { if (para) { para.c = trimRuns(para.c); if (para.c.length) out.push(para); para = null; } };
  const walk = (node, ctx) => {
    node.childNodes.forEach((n) => {
      if (n.nodeType === 3) {
        const t = n.nodeValue.replace(/[\r\n\t]+/g, ' ').replace(/\u00a0/g, ' ');
        if (!t || (!para && !t.trim())) return;
        pushText(cur(ctx).c, t, ctx.f); return;
      }
      if (n.nodeType !== 1) return;
      const tag = n.tagName, cl = n.classList;
      if (QP_SKIP.has(tag) || /^O:/.test(tag) || (n.style && /mso-list:\s*ignore/i.test(n.getAttribute('style') || ''))) return;
      if (cl.contains('rt-eq')) { cur(ctx).c.push({ e: n.dataset.tex || '' }); return; }
      if (cl.contains('rt-blank')) { cur(ctx).c.push({ bl: Number(n.dataset.bl) || 3 }); return; }
      if (tag === 'BR') { if (para) para.c.push({ br: 1 }); return; }
      if (cl.contains('rt-img')) { flush(); if (n.dataset.f) out.push({ t: 'img', f: n.dataset.f, w: Number(n.dataset.w) || 60, a: n.dataset.a || 'c' }); return; }
      if (cl.contains('rt-eqb')) { flush(); if (n.dataset.tex) out.push({ t: 'eq', x: n.dataset.tex }); return; }
      if (tag === 'PRE') { flush(); const x = n.innerText.replace(/\n$/, ''); if (x.trim()) out.push({ t: 'code', x }); return; }
      if (tag === 'UL' || tag === 'OL') {
        flush();
        const items = [...n.children].filter((li) => li.tagName === 'LI').map((li) => domBlocks(li));
        if (items.length) out.push(tag === 'UL' ? { t: 'ul', items } : { t: 'ol', s: listStyleOf(n), items });
        return;
      }
      if (tag === 'TABLE') { flush(); const t = tableBlock(n); if (t) out.push(t); return; }
      if (tag === 'IMG' || tag === 'HR' || tag === 'VIDEO' || tag === 'AUDIO' || tag === 'CANVAS') { if (tag === 'HR') flush(); return; }
      if (QP_BLOCK.has(tag)) {
        flush();
        walk(n, { f: fmtOf(n, ctx.f), t: /^H[1-6]$/.test(tag) ? 'h' : ctx.t, a: alignOf(n) || ctx.a });
        flush();
        return;
      }
      walk(n, { f: fmtOf(n, ctx.f), t: ctx.t, a: ctx.a });
    });
  };
  walk(root, { f: {}, t: 'p', a: '' });
  flush();
  return out;
}

/* =====================================================================
   HUB  /exams
   ===================================================================== */
route(/^\/exams$/, async (params) => {
  const d = await call('examHome');
  EX.home = d;
  const tab = params.get('tab') || 'all';
  const list = d.papers.filter((p) => tab === 'all' || (tab === 'review' ? p.status === 'review' : p.examType === tab));
  const card = (p) => '<a class="card qp-card" href="#/exams/p/' + esc(p.id) + '">' +
    '<div class="qp-card-sheet" aria-hidden="true"><i></i><i></i><i></i><i></i><b>' + esc(p.courseCode || 'QP') + '</b></div>' +
    '<div class="qp-card-body"><div class="row-wrap" style="gap:6px">' + qpStatus(p.status) + badge(p.examType === 'external' ? 'External' : 'Internal', p.examType === 'external' ? 'info' : 'outline') + '</div>' +
    '<h3>' + esc(p.title) + '</h3><div class="small muted">' + esc([p.courseCode, p.courseName].filter(Boolean).join(' · ') || p.examTitle || 'No course set') + '</div>' +
    '<div class="qp-card-meta">' + progressBar(p.progress) + '<span class="small muted">' + p.progress + '% written · ' + numS(p.total) + (p.maxMarks ? ' / ' + esc(p.maxMarks) : '') + ' marks · ' + plural(p.questions, 'question') + '</span></div>' +
    '<div class="xs muted">' + (p.ownerId === S.me.id ? 'You' : esc(p.ownerName)) + (p.collaborators ? ' + ' + plural(p.collaborators, 'co-setter') : '') + ' · edited ' + rel(p.updatedAt) + '</div></div></a>';
  const tabs = [['all', 'All papers'], ['internal', 'Internal'], ['external', 'External']].concat(d.isAdmin ? [['review', 'Awaiting review' + (d.stats.review ? ' (' + d.stats.review + ')' : '')]] : []);
  return {
    title: 'Question papers',
    html: pageHead('Question papers', {
      sub: 'Set internal and external examination papers in one uniform format, typeset in LaTeX.',
      actions: '<a class="btn" href="#/exams/templates">' + icon('template') + 'Templates</a>' +
        '<button class="btn" data-act="qpImportOpen">' + icon('upload') + 'Import Word paper</button>' +
        '<button class="btn btn-primary" data-act="qpNewOpen">' + icon('plus') + 'New question paper</button>'
    }) +
      '<div class="grid-4 kpis" style="margin-bottom:var(--sp-6)">' + kpi('In progress', d.stats.draft, 'drafts and returned papers', 'edit') + kpi('Awaiting review', d.stats.review, d.isAdmin ? 'need your decision' : 'with the reviewer', 'clock') +
      kpi('Approved', d.stats.approved, 'locked and ready to print', 'checkCircle') + kpi('Templates', d.templates.length, 'paper patterns available', 'template') + '</div>' +
      '<div class="row-wrap" style="justify-content:space-between;margin-bottom:var(--sp-5)"><div class="pills">' +
      tabs.map(([k, l]) => '<a class="pill' + (tab === k ? ' active' : '') + '" href="#/exams' + (k === 'all' ? '' : '?tab=' + k) + '">' + esc(l) + '</a>').join('') + '</div>' +
      '<span class="small muted">' + icon('lock', 'i-sm') + ' Visible only to you, your co-setters and administrators</span></div>' +
      (list.length ? '<div class="qp-grid">' + list.map(card).join('') + '</div>'
        : emptyState('exam', tab === 'review' ? 'Nothing awaiting review' : 'No question papers yet', tab === 'review' ? 'Submitted papers will appear here.' : 'Start from one of your institution’s templates, or import an existing Word paper.',
          tab === 'review' ? '' : '<div class="row-wrap" style="justify-content:center"><button class="btn" data-act="qpImportOpen">' + icon('upload') + 'Import Word paper</button><button class="btn btn-primary" data-act="qpNewOpen">' + icon('plus') + 'New question paper</button></div>'))
  };
});

function templateOptions(sel, allowNone) {
  const t = (EX.home && EX.home.templates) || [];
  return (allowNone ? '<option value="">No template (basic layout)</option>' : '') + t.map((x) => '<option value="' + esc(x.id) + '"' + (x.id === sel ? ' selected' : '') + '>' + esc(x.name) + (x.official ? '' : ' (mine)') + '</option>').join('');
}
function courseOptions(sel) {
  return '<option value="">Not linked to a course</option>' + ((EX.home && EX.home.courses) || []).map((c) => '<option value="' + esc(c.id) + '"' + (c.id === sel ? ' selected' : '') + '>' + esc(c.shortname + ' — ' + c.fullname) + '</option>').join('');
}
async function ensureHome() { if (!EX.home) EX.home = await call('examHome'); return EX.home; }
function patternLine(t) {
  return t.pattern.map((x) => esc(x.title || 'Part') + ': ' + x.count + ' × ' + numS(x.marks) + (x.choice === 'either' ? ' (either/or)' : x.choice === 'any' ? ' (any ' + x.attempt + ')' : '')).join(' · ');
}

ACT.qpNewOpen = (d) => busy(null, async () => {
  const h = await ensureHome();
  if (!h.templates.length) { toast('Create a template first.', 'err'); go('/exams/templates'); return; }
  const pre = d.tpl || h.templates[0].id;
  formModal('New question paper', 'Questions are laid out to match the template’s pattern, ready to fill in.', 'qpNew',
    field('Template', '<select name="templateId" data-change="qpTplPick">' + templateOptions(pre) + '</select>', '') +
    '<div class="qp-tpl-sum" id="qpTplSum"></div>' +
    '<div class="form-grid">' + field('Examination', '<select name="examType"><option value="internal">Internal (CIA / model)</option><option value="external">External (end semester)</option></select>') +
    field('Course', '<select name="courseId">' + courseOptions('') + '</select>', 'Fills in the course code and name') + '</div>' +
    field('Paper title', '<input type="text" name="title" maxlength="160" placeholder="e.g. BLAW201 · CIA I · Oct 2026">', 'For your list of papers; not printed'),
    'Create paper', 'wide');
  ACT.qpTplPick({}, $('select[name=templateId]'));
});
ACT.qpTplPick = (d, sel) => {
  const t = (EX.home.templates || []).find((x) => x.id === sel.value);
  const box = $('#qpTplSum');
  if (!t || !box) return;
  box.innerHTML = '<div class="small"><b>' + numS(t.total) + ' marks</b> · ' + esc(t.duration || '—') + ' · ' + esc(QP_FONTS[t.font] || t.font) + (t.customTex ? ' · custom LaTeX layout' : '') + '</div><div class="xs muted">' + patternLine(t) + '</div>';
  const et = $('select[name=examType]'); if (et && t.examType !== 'any') et.value = t.examType;
};
FORMS.qpNew = (f, btn) => busy(btn, async () => {
  const r = await call('examCreate', { templateId: f.templateId.value, examType: f.examType.value, courseId: f.courseId.value, title: f.title.value.trim() });
  closeModal(); EX.home = null; go('/exams/p/' + r.id);
});

ACT.qpImportOpen = () => busy(null, async () => {
  await ensureHome();
  formModal('Import a Word question paper', 'Upload a .docx paper. Parts, numbered questions, (a)/(b) choices, sub-questions, marks, CO and K-levels, tables, pictures and Word equations are recognised.', 'qpImport',
    field('Word file (.docx)', '<input type="file" name="file" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required>') +
    '<div class="form-grid">' + field('Apply the layout of', '<select name="templateId">' + templateOptions('', true) + '</select>', 'Fonts, header and columns come from this template') +
    field('Examination', '<select name="examType"><option value="internal">Internal</option><option value="external">External</option></select>') + '</div>' +
    notice('Tip: papers laid out as a table (<b>Q.No | Question | Marks | CO | BL</b>) or as numbered paragraphs with marks in brackets, e.g. <b>(13)</b>, import best. You can fix anything in the editor afterwards.', '', 'info'),
    'Import', 'wide');
});
FORMS.qpImport = (f, btn) => busy(btn, async () => {
  const file = f.file.files[0];
  if (!file) { toast('Choose a Word file.', 'err'); return; }
  if (file.size > 11 * 1024 * 1024) { toast('Word files must be 11 MB or smaller — compress large pictures in Word first.', 'err'); return; }
  const r = await call('examImportDocx', { name: file.name, data: await readFileB64(file), templateId: f.templateId.value, examType: f.examType.value });
  EX.home = null;
  openModal(modalHead('Paper imported', esc(file.name)) + '<div class="modal-body"><div class="grid-3" style="margin-bottom:1rem">' +
    kpi('Parts', r.report.sections) + kpi('Questions', r.report.questions) + kpi('Pictures', r.report.images) + '</div>' +
    (r.report.meta.length ? '<p class="small">Also read from the paper: ' + r.report.meta.map((k) => esc({ institution: 'institution', subtitle: 'subtitle', examTitle: 'exam title', programme: 'programme', semester: 'semester', courseCode: 'course code', courseName: 'course name', duration: 'duration', maxMarks: 'maximum marks', qpCode: 'QP code', date: 'date' }[k] || k)).join(', ') + '.</p>' : '') +
    r.report.warnings.map((w) => notice(esc(w), 'warn')).join('') +
    '<p class="small muted">Check every question in the editor — Review → Check paper lists anything that needs attention.</p>' +
    '<div class="form-actions"><a class="btn btn-primary" href="#/exams/p/' + esc(r.id) + '" data-act="close">Open the paper</a></div></div>', 'wide');
});

/* =====================================================================
   TEMPLATES  /exams/templates
   ===================================================================== */
route(/^\/exams\/templates$/, async () => {
  const d = await call('examHome');
  EX.home = d;
  const card = (t) => '<div class="card qp-tpl">' +
    '<div class="qp-tpl-head"><span class="i-tile tone-' + (t.examType === 'external' ? 'blue' : 'violet') + '">' + icon('template') + '</span><div style="min-width:0"><h3>' + esc(t.name) + '</h3>' +
    '<div class="row-wrap" style="gap:6px">' + (t.official ? badge('Institution', 'primary', 'building') : badge('Personal', 'outline', 'user')) + badge(t.examType === 'external' ? 'External' : t.examType === 'internal' ? 'Internal' : 'Any exam', 'outline') + (t.customTex ? badge('Custom LaTeX', 'info', 'code') : '') + '</div></div></div>' +
    (t.description ? '<p class="small muted">' + esc(t.description) + '</p>' : '') +
    '<div class="qp-pattern">' + t.pattern.map((x) => '<div><b>' + esc(x.title || 'Part') + '</b><span>' + x.count + ' × ' + numS(x.marks) + (x.choice === 'either' ? ' · either/or' : x.choice === 'any' ? ' · any ' + x.attempt : '') + '</span></div>').join('') + '</div>' +
    '<div class="small muted">' + numS(t.total) + ' marks · ' + esc(t.duration || '—') + ' · ' + esc(QP_FONTS[t.font] || t.font) + '</div>' +
    '<div class="qp-tpl-foot"><button class="btn btn-sm btn-primary" data-act="qpNewOpen" data-tpl="' + esc(t.id) + '">' + icon('plus') + 'Use</button>' +
    (t.canEdit ? '<button class="btn btn-sm" data-act="qpTplEdit" data-id="' + esc(t.id) + '">' + icon('edit') + 'Edit</button>' : '<button class="btn btn-sm" data-act="qpTplEdit" data-id="' + esc(t.id) + '" data-copy="1">' + icon('copy') + 'Copy</button>') +
    (t.canEdit ? '<button class="btn btn-sm btn-ghost btn-danger" data-act="qpTplDel" data-id="' + esc(t.id) + '" data-name="' + esc(t.name) + '">' + icon('trash') + '</button>' : '') + '</div></div>';
  return {
    title: 'Question paper templates',
    html: pageHead('Question paper templates', {
      crumbs: [['Question papers', '/exams'], ['Templates']],
      sub: 'A template fixes the header, instructions, parts and marks pattern, fonts and columns, so every paper made from it looks the same.',
      actions: '<button class="btn" data-act="qpTplDocx">' + icon('upload') + 'Upload Word template</button>' +
        '<button class="btn" data-act="qpSampleTex">' + icon('code') + 'Sample LaTeX layout</button>' +
        '<button class="btn btn-primary" data-act="qpTplEdit">' + icon('plus') + 'New template</button>'
    }) +
      '<input type="file" id="qpTplDocxFile" accept=".docx" hidden>' +
      (d.templates.length ? '<div class="qp-tpl-grid">' + d.templates.map(card).join('') + '</div>' : emptyState('template', 'No templates yet', 'Create one, or upload a Word question paper to use as the pattern.', '')) +
      '<div class="card card-pad" style="margin-top:var(--sp-6)"><h2 style="margin-top:0;font-size:var(--fs-body-lg)">Three ways to set up a template</h2><div class="grid-3">' +
      '<div><b>' + icon('edit', 'i-sm') + ' Design it here</b><p class="small muted">Header, instructions, parts (answer all · either/or · any n), marks, CO and K-level columns, fonts and margins.</p></div>' +
      '<div><b>' + icon('upload', 'i-sm') + ' From a Word paper</b><p class="small muted">Upload last year’s paper (.docx): the header, logo, instructions and parts pattern are read in for you to confirm.</p></div>' +
      '<div><b>' + icon('code', 'i-sm') + ' Custom LaTeX layout</b><p class="small muted">Administrators can upload the institution’s own .tex design with placeholders. Download the sample to start.</p></div>' +
      '</div></div>',
    after() {
      const inp = $('#qpTplDocxFile');
      if (inp) inp.onchange = () => { const f = inp.files[0]; inp.value = ''; if (f) qpTemplateFromDocx(f); };
    }
  };
});
ACT.qpTplDocx = () => { const i = $('#qpTplDocxFile'); if (i) i.click(); };
async function qpTemplateFromDocx(file) {
  await busy(null, async () => {
    if (!/\.docx$/i.test(file.name)) { toast('Choose a Word document (.docx).', 'err'); return; }
    const r = await call('examTemplateFromDocx', { name: file.name, data: await readFileB64(file) });
    toast('Read ' + plural(r.report.sections, 'part') + ' and ' + plural(r.report.questions, 'question') + ' — check the pattern and save.');
    qpTemplateEditor(Object.assign({ id: '', scope: 'institution', examType: 'any', description: 'Imported from ' + file.name }, r.draft));
  });
}
ACT.qpSampleTex = () => busy(null, async () => { const r = await call('examSampleTex', {}); downloadText(r.name, r.text, 'application/x-tex'); });
ACT.qpTplDel = async (d) => {
  if (!(await confirmBox('Delete this template?', 'Papers already made from “' + esc(d.name) + '” keep their layout.', 'Delete', true))) return;
  await busy(null, async () => { await call('examDeleteTemplate', { id: d.id }); toast('Template deleted.'); refresh(); });
};
ACT.qpTplEdit = (d) => busy(null, async () => {
  if (!d.id) {
    qpTemplateEditor({ id: '', name: '', description: '', examType: 'any', scope: 'institution', meta: { institution: SITE, duration: '3 Hours', maxMarks: '100' }, layout: {}, instructions: [], sections: [{ title: 'PART – A', choice: 'all', marks: 2, count: 10, attempt: 0, note: '' }] });
    return;
  }
  const r = await call('examTemplate', { id: d.id });
  const t = r.template;
  if (d.copy) { t.id = ''; t.name = 'Copy of ' + t.name; t.scope = 'personal'; }
  qpTemplateEditor(t);
});

/* ---------- template designer ---------- */
function qpTemplateEditor(t) {
  const L = Object.assign({ font: 'times', fontSize: 11, margin: 2, paper: 'a4', showCO: true, showBL: true, blScheme: 'K', coCount: 6, regBoxes: 10, logo: '', footer: '', endText: '* * * * *', numbering: 'continuous', texFile: '' }, t.layout || {});
  const M = t.meta || {};
  EX.tpl = { id: t.id, logo: L.logo, texFile: L.texFile, texName: L.texFile ? 'custom layout (.tex)' : '', sections: (t.sections || []).map((x) => Object.assign({}, x)) };
  const isAdmin = S.me.role === 'admin';
  const instr = (t.instructions || []).map((b) => (b.items ? b.items.map((it) => plainOf(it)).join('\n') : plainOf([b]))).join('\n');
  const inp = (name, val, ph, extra) => '<input type="text" name="' + name + '" value="' + esc(val || '') + '" placeholder="' + esc(ph || '') + '"' + (extra || '') + '>';
  formModal(t.id ? 'Edit template' : 'New template', 'Everything here is applied to each new paper made from the template.', 'qpTpl',
    '<div class="qp-tpl-form">' +
    '<h3 class="qp-form-h">Template</h3><div class="form-grid">' +
    field('Name', inp('name', t.name, 'e.g. CIA — 50 marks', ' required maxlength="120"')) +
    field('Used for', '<select name="examType">' + [['any', 'Any examination'], ['internal', 'Internal (CIA / model)'], ['external', 'External (end semester)']].map(([v, l]) => '<option value="' + v + '"' + (t.examType === v ? ' selected' : '') + '>' + l + '</option>').join('') + '</select>') + '</div>' +
    field('Description', inp('description', t.description, 'Shown on the template card')) +
    (isAdmin ? field('Available to', '<select name="scope"><option value="institution"' + (t.scope !== 'personal' ? ' selected' : '') + '>All faculty (institution template)</option><option value="personal"' + (t.scope === 'personal' ? ' selected' : '') + '>Only me</option></select>') : '') +
    '<h3 class="qp-form-h">Header</h3>' +
    '<div class="qp-logo-row"><div class="qp-logo-box" id="qpLogoBox">' + (L.logo ? '<img data-f="' + esc(L.logo) + '" alt="Logo">' : icon('image')) + '</div><div><button type="button" class="btn btn-sm" data-act="qpLogoPick">' + icon('upload') + (L.logo ? 'Change logo' : 'Add logo') + '</button> ' +
    '<button type="button" class="btn btn-sm btn-ghost' + (L.logo ? '' : ' hidden') + '" id="qpLogoDel" data-act="qpLogoDel">Remove</button><div class="hint">PNG or JPEG, printed at the top left</div><input type="file" id="qpLogoFile" accept="image/png,image/jpeg" hidden></div></div>' +
    '<div class="form-grid">' + field('Institution', inp('institution', M.institution, 'Institution name')) + field('Second line', inp('subtitle', M.subtitle, '(Autonomous) · Affiliated to …')) +
    field('Examination title', inp('examTitle', M.examTitle, 'End Semester Examinations — Nov 2026')) + field('Programme', inp('programme', M.programme, 'B.Com (Computer Applications)')) +
    field('Duration', inp('duration', M.duration, '3 Hours')) + field('Maximum marks', inp('maxMarks', M.maxMarks, '100')) + '</div>' +
    field('Register-number boxes', '<input type="number" name="regBoxes" min="0" max="16" value="' + (L.regBoxes || 0) + '">', '0 hides them') +
    '<h3 class="qp-form-h">Parts and marks pattern</h3><div id="qpPatternBox"></div>' +
    '<button type="button" class="btn btn-sm" data-act="qpPatAdd">' + icon('plus') + 'Add part</button><div class="small" id="qpPatTotal" style="margin-top:8px"></div>' +
    '<h3 class="qp-form-h">Instructions to candidates</h3>' +
    field('One instruction per line', '<textarea name="instructions" rows="4" placeholder="Answer ALL questions.">' + esc(instr) + '</textarea>') +
    '<h3 class="qp-form-h">Typesetting</h3><div class="form-grid-3">' +
    field('Font', '<select name="font">' + Object.keys(QP_FONTS).map((k) => '<option value="' + k + '"' + (L.font === k ? ' selected' : '') + '>' + QP_FONTS[k] + '</option>').join('') + '</select>') +
    field('Size', '<select name="fontSize">' + [10, 11, 12].map((n) => '<option' + (Number(L.fontSize) === n ? ' selected' : '') + '>' + n + '</option>').join('') + '</select>') +
    field('Paper', '<select name="paper">' + [['a4', 'A4'], ['letter', 'Letter'], ['legal', 'Legal']].map(([v, l]) => '<option value="' + v + '"' + (L.paper === v ? ' selected' : '') + '>' + l + '</option>').join('') + '</select>') +
    field('Margins (cm)', '<input type="number" name="margin" min="1.2" max="3" step="0.1" value="' + (L.margin || 2) + '">') +
    field('Question numbers', '<select name="numbering"><option value="continuous"' + (L.numbering !== 'section' ? ' selected' : '') + '>Continuous (1–16)</option><option value="section"' + (L.numbering === 'section' ? ' selected' : '') + '>Restart in each part</option></select>') +
    field('Course outcomes', '<input type="number" name="coCount" min="1" max="12" value="' + (L.coCount || 6) + '">', 'CO1 … COn') + '</div>' +
    '<div class="row-wrap" style="gap:var(--sp-5);margin-bottom:var(--sp-4)">' + check('showCO', 'CO column', L.showCO) + check('showBL', 'Cognitive-level column', L.showBL) +
    '<select name="blScheme" style="width:auto">' + [['K', 'K1–K6'], ['L', 'L1–L6'], ['BT', 'BT1–BT6'], ['none', 'None']].map(([v, l]) => '<option value="' + v + '"' + (L.blScheme === v ? ' selected' : '') + '>' + l + '</option>').join('') + '</select></div>' +
    '<div class="form-grid">' + field('Footer (centre)', inp('footer', L.footer, 'e.g. Confidential')) + field('End of paper', inp('endText', L.endText, '* * * * *')) + '</div>' +
    (isAdmin ? '<h3 class="qp-form-h">Custom LaTeX layout <span class="badge outline">optional</span></h3><p class="small muted">Replace the built-in design with your institution’s own .tex file. It must contain <code>&lt;&lt;QUESTIONS&gt;&gt;</code>; see “Sample LaTeX layout” for every placeholder.</p>' +
      '<div class="row-wrap"><span class="small" id="qpTexName">' + (L.texFile ? icon('code', 'i-sm') + ' A custom layout is attached' : 'Using the built-in layout') + '</span><button type="button" class="btn btn-sm" data-act="qpTexPick">' + icon('upload') + 'Upload .tex</button>' +
      '<button type="button" class="btn btn-sm btn-ghost' + (L.texFile ? '' : ' hidden') + '" id="qpTexDel" data-act="qpTexDel">Use built-in</button><input type="file" id="qpTexFile" accept=".tex" hidden></div>' : '') +
    '</div>', t.id ? 'Save template' : 'Create template', 'xwide');
  qpPatternRender();
  qpHydrate($('#modal-root'));
  $('#qpLogoFile').onchange = async (e) => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    if (!/^image\/(png|jpeg)$/.test(f.type)) { toast('Use a PNG or JPEG logo.', 'err'); return; }
    await busy(null, async () => { const r = await uploadFile(f); EX.tpl.logo = r.id; $('#qpLogoBox').innerHTML = '<img data-f="' + esc(r.id) + '" alt="Logo">'; $('#qpLogoDel').classList.remove('hidden'); qpHydrate($('#qpLogoBox')); });
  };
  const tf = $('#qpTexFile');
  if (tf) tf.onchange = async (e) => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    await busy(null, async () => {
      const r = await call('examUploadTex', { name: f.name, data: await readFileB64(f) });
      EX.tpl.texFile = r.fileId;
      $('#qpTexName').innerHTML = icon('code', 'i-sm') + ' ' + esc(r.name) + ' · ' + r.placeholders.length + ' placeholders' + (r.injectsPackages ? ' · required packages will be added' : '');
      $('#qpTexDel').classList.remove('hidden');
    });
  };
}
ACT.qpLogoPick = () => $('#qpLogoFile').click();
ACT.qpLogoDel = () => { EX.tpl.logo = ''; $('#qpLogoBox').innerHTML = icon('image'); $('#qpLogoDel').classList.add('hidden'); };
ACT.qpTexPick = () => $('#qpTexFile').click();
ACT.qpTexDel = () => { EX.tpl.texFile = ''; $('#qpTexName').textContent = 'Using the built-in layout'; $('#qpTexDel').classList.add('hidden'); };
function qpPatternRender() {
  const box = $('#qpPatternBox'); if (!box) return;
  const rows = EX.tpl.sections;
  box.innerHTML = '<div class="table-wrap"><table class="qp-pat"><thead><tr><th>Part</th><th>Choice</th><th>Questions</th><th>Marks each</th><th>Answer</th><th>Total</th><th>Instruction (optional)</th><th></th></tr></thead><tbody>' +
    rows.map((x, i) => {
      const total = (x.choice === 'any' ? (x.attempt || x.count) : x.count) * (Number(x.marks) || 0);
      return '<tr data-i="' + i + '"><td><input type="text" data-pat="title" value="' + esc(x.title) + '" placeholder="PART – A"></td>' +
        '<td><select data-pat="choice">' + Object.keys(QP_CHOICE).map((k) => '<option value="' + k + '"' + (x.choice === k ? ' selected' : '') + '>' + QP_CHOICE[k] + '</option>').join('') + '</select></td>' +
        '<td><input type="number" min="1" max="100" data-pat="count" value="' + (x.count || 1) + '"></td>' +
        '<td><input type="number" min="0" max="100" step="0.5" data-pat="marks" value="' + (x.marks || 0) + '"></td>' +
        '<td>' + (x.choice === 'any' ? '<input type="number" min="1" max="100" data-pat="attempt" value="' + (x.attempt || '') + '" placeholder="n">' : '<span class="muted small">' + (x.choice === 'either' ? '(a) or (b)' : 'all') + '</span>') + '</td>' +
        '<td class="tnum"><b>' + numS(total) + '</b></td>' +
        '<td><input type="text" data-pat="note" value="' + esc(x.note || '') + '" placeholder="' + esc(defaultNote(x)) + '"></td>' +
        '<td><button type="button" class="btn-icon sm" data-act="qpPatDel" data-i="' + i + '" aria-label="Remove part">' + icon('x') + '</button></td></tr>';
    }).join('') + '</tbody></table></div>';
  box.querySelectorAll('[data-pat]').forEach((el) => {
    el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'input', () => {
      const i = Number(el.closest('tr').dataset.i); const k = el.dataset.pat;
      EX.tpl.sections[i][k] = el.type === 'number' ? Number(el.value) : el.value;
      if (k === 'choice' || k === 'count' || k === 'marks' || k === 'attempt') { if (k === 'choice') qpPatternRender(); else qpPatternTotal(); }
    });
  });
  qpPatternTotal();
}
function qpPatternTotal() {
  const total = EX.tpl.sections.reduce((n, x) => n + (x.choice === 'any' ? (x.attempt || x.count) : x.count) * (Number(x.marks) || 0), 0);
  const max = Number(($('input[name=maxMarks]') || {}).value || 0);
  const el = $('#qpPatTotal');
  if (el) el.innerHTML = 'Pattern total: <b>' + numS(total) + ' marks</b>' + (max ? (max === total ? ' <span class="badge success">matches maximum marks</span>' : ' <span class="badge warning">maximum marks is ' + max + '</span>') : '');
  $$('#qpPatternBox tr[data-i]').forEach((tr) => { const x = EX.tpl.sections[Number(tr.dataset.i)]; tr.querySelector('td.tnum b').textContent = numS((x.choice === 'any' ? (x.attempt || x.count) : x.count) * (Number(x.marks) || 0)); });
}
ACT.qpPatAdd = () => { const n = EX.tpl.sections.length; EX.tpl.sections.push({ title: 'PART – ' + String.fromCharCode(65 + n), choice: 'all', marks: 5, count: 5, attempt: 0, note: '' }); qpPatternRender(); };
ACT.qpPatDel = (d) => { EX.tpl.sections.splice(Number(d.i), 1); qpPatternRender(); };
FORMS.qpTpl = (f, btn) => busy(btn, async () => {
  const lines = f.instructions.value.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const payload = {
    id: EX.tpl.id || '', name: f.name.value, description: f.description.value, examType: f.examType.value, scope: f.scope ? f.scope.value : 'personal',
    meta: { institution: f.institution.value, subtitle: f.subtitle.value, examTitle: f.examTitle.value, programme: f.programme.value, duration: f.duration.value, maxMarks: f.maxMarks.value },
    layout: { font: f.font.value, fontSize: Number(f.fontSize.value), paper: f.paper.value, margin: Number(f.margin.value), numbering: f.numbering.value, coCount: Number(f.coCount.value), showCO: f.showCO.checked, showBL: f.showBL.checked, blScheme: f.blScheme.value, regBoxes: Number(f.regBoxes.value), footer: f.footer.value, endText: f.endText.value, logo: EX.tpl.logo || '', texFile: EX.tpl.texFile || '' },
    instructions: lines.length ? [{ t: 'ol', s: '1', items: lines.map((l) => [{ t: 'p', c: [{ x: l.replace(/^\d+[.)]\s*/, '') }] }]) }] : [],
    sections: EX.tpl.sections
  };
  await call('examSaveTemplate', payload);
  closeModal(); toast('Template saved.'); EX.home = null;
  if (/^\/exams\/templates/.test(currentPath())) refresh(); else go('/exams/templates');
});

/* =====================================================================
   EDITOR  /exams/p/:id
   ===================================================================== */
route(/^\/exams\/p\/([A-Za-z0-9]+)$/, async (id) => {
  const [r] = await Promise.all([call('examGet', { id }), loadKatex()]);
  EX.info = r; EX.paper = r.paper; EX.version = r.paper.version; EX.canEdit = r.canEdit; EX.checks = r.checks; EX.files = r.files || {};
  EX.dirty = false; EX.saving = false; EX.rt = null; EX.range = null;
  if (!EX.home) ensureHome().catch(() => {});
  return { title: r.paper.title, html: editorHtml(), after: editorMount };
});

function editorHtml() {
  const r = EX.info, P = EX.paper;
  const actions = [];
  if (P.status === 'draft' || P.status === 'returned') actions.push('<button class="btn btn-sm btn-primary" data-act="qpSubmit">' + icon('send') + 'Submit for review</button>');
  if (P.status === 'review' && !r.isAdmin) actions.push('<button class="btn btn-sm" data-act="qpWithdraw">' + icon('undo') + 'Withdraw</button>');
  if (P.status === 'review' && r.isAdmin) actions.push('<button class="btn btn-sm" data-act="qpDecide" data-d="return">' + icon('reply') + 'Return</button><button class="btn btn-sm btn-success" data-act="qpDecide" data-d="approve">' + icon('checkCircle') + 'Approve</button>');
  if (P.status === 'approved' && r.isAdmin) actions.push('<button class="btn btn-sm" data-act="qpDecide" data-d="reopen">' + icon('lock') + 'Reopen</button>');
  const banner = P.status === 'approved' ? notice('Approved ' + (P.approvedAt ? fmt(P.approvedAt) : '') + '. The paper is locked; exports carry no watermark.', 'ok', 'lock')
    : P.status === 'review' ? notice('Awaiting review' + (r.isAdmin ? ' — approve it or return it with comments.' : '. Withdraw it if you need to make changes.'), 'warn', 'clock')
      : P.status === 'returned' && P.reviewNote ? notice('<b>Returned by the reviewer:</b> ' + esc(P.reviewNote), 'err', 'reply') : '';
  return '<div class="qpx' + (EX.canEdit ? '' : ' readonly') + '" id="qpx">' +
    '<div class="qpx-top">' +
    '<a class="btn-icon" href="#/exams" aria-label="All question papers">' + icon('arrowLeft') + '</a>' +
    '<span class="qpx-doc">' + icon('exam') + '</span>' +
    '<div class="qpx-titlebox"><input type="text" class="qpx-title" id="qpTitle" value="' + esc(P.title) + '" aria-label="Paper title"' + (EX.canEdit ? '' : ' readonly') + ' maxlength="160">' +
    '<div class="qpx-sub">' + qpStatus(P.status) + ' <span>' + (P.examType === 'external' ? 'External' : 'Internal') + '</span>' + (r.template ? '<span>· ' + esc(r.template.name) + '</span>' : '') +
    '<span>· ' + esc(r.ownerName) + (r.collaborators.length ? ' + ' + r.collaborators.map((c) => esc(c.name)).join(', ') : '') + '</span></div></div>' +
    '<span class="qpx-save" id="qpSave" aria-live="polite">' + (EX.canEdit ? icon('checkCircle', 'i-sm') + 'Saved' : icon('lock', 'i-sm') + 'Read only') + '</span>' +
    '<div class="spacer"></div>' +
    '<button class="btn btn-sm" data-act="qpShare">' + icon('users') + '<span class="hide-sm">Share</span></button>' +
    '<button class="btn btn-sm" data-act="qpPreview">' + icon('eye') + '<span class="hide-sm">Preview</span></button>' +
    '<div class="menu-wrap"><button class="btn btn-sm" data-act="menu">' + icon('download') + '<span class="hide-sm">Export</span></button><div class="menu menu-right">' +
    '<button class="menu-item" data-act="qpExport" data-format="zip">' + icon('code') + 'LaTeX project (.zip)</button>' +
    '<button class="menu-item" data-act="qpExport" data-format="tex">' + icon('file') + 'LaTeX source (.tex)</button>' +
    '<button class="menu-item" data-act="qpPdf">' + icon('page') + 'PDF' + (r.engine.pdf ? '' : ' <span class="xs muted">(needs TeX on server)</span>') + '</button>' +
    '<button class="menu-item" data-act="qpPreview" data-print="1">' + icon('printer') + 'Print / save as PDF (browser)</button>' +
    '<div class="menu-sep"></div><button class="menu-item" data-act="qpDup">' + icon('copy') + 'Duplicate paper</button>' +
    (r.isOwner || r.isAdmin ? '<button class="menu-item danger" data-act="qpDel">' + icon('trash') + 'Delete paper</button>' : '') +
    '</div></div>' + actions.join('') + '</div>' +
    ribbonHtml() +
    (banner ? '<div class="qpx-banner">' + banner + '</div>' : '') +
    '<div class="qpx-body"><aside class="qpx-outline" id="qpOutline"></aside>' +
    '<div class="qpx-canvas" id="qpCanvas"><div class="qp-sheet-wrap" id="qpWrap"></div></div></div>' +
    '<footer class="qpx-status" id="qpStatus"></footer>' +
    '<input type="file" id="qpImgFile" accept="image/png,image/jpeg" hidden></div>';
}

/* ---------- ribbon ---------- */
function ribbonHtml() {
  const b = (act, ico, label, extra) => '<button type="button" class="rb-btn" data-act="' + act + '" title="' + esc(label) + '" aria-label="' + esc(label) + '" ' + (extra || '') + '>' + icon(ico) + '</button>';
  const w = (act, ico, label, extra) => '<button type="button" class="rb-btn wide" data-act="' + act + '" ' + (extra || '') + '>' + icon(ico) + '<span>' + esc(label) + '</span></button>';
  const g = (name, inner, cls) => '<div class="rb-group ' + (cls || '') + '"><div class="rb-items">' + inner + '</div><div class="rb-name">' + name + '</div></div>';
  const c = (ico, label, command, state) => b('qpCmd', ico, label, 'data-c="' + command + '"' + (state ? ' data-state="' + command + '"' : ''));
  const home = g('History', c('undo', 'Undo (Ctrl+Z)', 'undo') + c('redo', 'Redo (Ctrl+Y)', 'redo')) +
    g('Style', '<select class="rb-select" id="rbStyle" data-change="qpBlockStyle" aria-label="Paragraph style"><option value="p">Normal text</option><option value="h4">Heading</option><option value="pre">Code block</option></select>') +
    g('Font', c('bold', 'Bold (Ctrl+B)', 'bold', 1) + c('italic', 'Italic (Ctrl+I)', 'italic', 1) + c('underline', 'Underline (Ctrl+U)', 'underline', 1) + c('strike', 'Strikethrough', 'strikeThrough', 1) +
      c('sup', 'Superscript', 'superscript', 1) + c('sub', 'Subscript', 'subscript', 1) + c('eraser', 'Clear formatting', 'removeFormat')) +
    g('Paragraph', c('listUl', 'Bulleted list', 'insertUnorderedList', 1) + c('listOl', 'Numbered list', 'insertOrderedList', 1) +
      '<select class="rb-select sm" data-change="qpListStyle" id="rbList" aria-label="Numbering style"><option value="1">1. 2. 3.</option><option value="a">(a) (b)</option><option value="i">(i) (ii)</option><option value="A">A. B.</option><option value="I">I. II.</option></select>' +
      c('outdent', 'Decrease indent', 'outdent') + c('indent', 'Increase indent', 'indent')) +
    g('Align', c('alignLeft', 'Align left', 'justifyLeft', 1) + c('alignCenter', 'Centre', 'justifyCenter', 1) + c('alignRight', 'Align right', 'justifyRight', 1) + c('alignJustify', 'Justify', 'justifyFull', 1));
  const insert = g('Questions', w('qpInsQ', 'plus', 'Question') + w('qpInsPart', 'subq', 'Sub-part') + w('qpInsAlt', 'split', 'OR choice') + w('qpSecAdd', 'rows', 'Part')) +
    g('Insert', w('qpTableMenu', 'table', 'Table') + w('qpImage', 'image', 'Picture') + w('qpEq', 'sigma', 'Equation') + w('qpSymbols', 'omega', 'Symbol') + w('qpBlank', 'blank', 'Blank') + w('qpCmd', 'code', 'Code', 'data-c="formatBlock" data-v="pre"')) +
    g('Page', w('qpPageBreak', 'pagebreak', 'Page break')) +
    g('Table', b('qpTbl', 'rows', 'Insert row above', 'data-op="rowAbove"') + b('qpTbl', 'plus', 'Insert row below', 'data-op="rowBelow"') + b('qpTbl', 'columns', 'Insert column right', 'data-op="colRight"') +
      b('qpTbl', 'split', 'Merge with the cell on the right', 'data-op="merge"') + b('qpTbl', 'heading', 'Header row on/off', 'data-op="head"') + b('qpTbl', 'minus', 'Delete row', 'data-op="delRow"') + b('qpTbl', 'x', 'Delete column', 'data-op="delCol"') + b('qpTbl', 'trash', 'Delete table', 'data-op="delTable"'), 'rb-table');
  const paper = g('Details', w('qpMeta', 'edit', 'Exam details') + w('qpSections', 'layers', 'Parts & pattern')) +
    g('Design', w('qpLayout', 'settings', 'Fonts & layout') + w('qpApplyTpl', 'template', 'Apply template')) +
    g('Zoom', b('qpZoom', 'minus', 'Zoom out', 'data-z="-1"') + '<span class="rb-zoom" id="rbZoom">100%</span>' + b('qpZoom', 'plus', 'Zoom in', 'data-z="1"') + w('qpZoom', 'monitor', 'Fit', 'data-z="0"'));
  const review = g('Proofing', w('qpChecks', 'checkCircle', 'Check paper') + w('qpBlueprint', 'pie', 'Blueprint') + w('qpCount', 'text', 'Word count') + (EX.canEdit ? w('qpFind', 'replace', 'Find & replace') : '')) +
    g('History', w('qpRevs', 'history', 'Versions') + w('qpActivity', 'activity', 'Activity')) +
    g('People', w('qpShare', 'users', 'Co-setters'));
  const tabs = EX.canEdit ? [['home', 'Home'], ['insert', 'Insert'], ['paper', 'Paper'], ['review', 'Review']] : [['review', 'Review']];
  const first = tabs[0][0];
  return '<div class="qpx-ribbon" id="qpRibbon"><div class="rb-tabs" role="tablist">' + tabs.map(([k, l]) => '<button type="button" role="tab" class="rb-tab' + (k === first ? ' active' : '') + '" data-act="qpRibbonTab" data-tab="' + k + '" aria-selected="' + (k === first) + '">' + l + '</button>').join('') + '</div>' +
    (EX.canEdit ? '<div class="rb-panel' + (first === 'home' ? '' : ' hidden') + '" data-panel="home">' + home + '</div><div class="rb-panel hidden" data-panel="insert">' + insert + '</div><div class="rb-panel hidden" data-panel="paper">' + paper + '</div>' : '') +
    '<div class="rb-panel' + (first === 'review' ? '' : ' hidden') + '" data-panel="review">' + review + '</div></div>';
}
ACT.qpRibbonTab = (d) => {
  $$('#qpRibbon .rb-tab').forEach((t) => { const on = t.dataset.tab === d.tab; t.classList.toggle('active', on); t.setAttribute('aria-selected', on); });
  $$('#qpRibbon .rb-panel').forEach((p) => p.classList.toggle('hidden', p.dataset.panel !== d.tab));
  try { sessionStorage.setItem('qp.tab', d.tab); } catch (e) { /* ignore */ }
};

/* ---------- the A4 sheet ---------- */
function coOptions(v) { const n = (EX.paper.layout.coCount || 6); let o = '<option value="0">–</option>'; for (let i = 1; i <= n; i++) o += '<option value="' + i + '"' + (Number(v) === i ? ' selected' : '') + '>CO' + i + '</option>'; return o; }
function blOptions(v) { const L = EX.paper.layout; const names = QP_BL[L.blScheme] || QP_BL.K; return '<option value="0">–</option>' + names.map((n, i) => '<option value="' + (i + 1) + '"' + (Number(v) === i + 1 ? ' selected' : '') + ' title="' + esc(n) + '">' + esc(n.split(' ')[0]) + '</option>').join(''); }

function sheetHtml(P, o) {
  o = o || {};
  const E = !!o.edit, L = P.layout || {}, M = P.meta || {};
  const blPrefix = { K: 'K', L: 'L', BT: 'BT' }[L.blScheme] || 'K';
  const showBL = L.showBL && L.blScheme !== 'none';
  const f = (k, ph, cls) => E ? '<span class="qp-f ' + (cls || '') + '" contenteditable="true" spellcheck="true" data-meta="' + k + '" data-ph="' + esc(ph) + '">' + esc(M[k] || '') + '</span>'
    : (M[k] ? '<span class="' + (cls || '') + '">' + esc(M[k]) + '</span>' : '');
  const regN = Number(L.regBoxes) || 0;
  const reg = regN ? '<span class="qp-reg"><span>Reg. No.:</span>' + '<i></i>'.repeat(regN) + '</span>' : '';
  const qpc = E ? '<span class="qp-code">Question Paper Code: ' + f('qpCode', 'optional', 'b') + '</span>' : (M.qpCode ? '<span class="qp-code">Question Paper Code: <b>' + esc(M.qpCode) + '</b></span>' : '<span></span>');
  const progSem = E ? '<div class="qp-line">' + f('programme', 'Programme') + ' <span class="qp-dash">–</span> ' + f('semester', 'Semester') + '</div>'
    : ([M.programme, M.semester ? (/sem/i.test(M.semester) ? M.semester : 'Semester ' + M.semester) : ''].filter(Boolean).length ? '<div class="qp-line">' + [M.programme, M.semester ? (/sem/i.test(M.semester) ? M.semester : 'Semester ' + M.semester) : ''].filter(Boolean).map(esc).join(' – ') + '</div>' : '');
  const course = E ? '<div class="qp-line b">' + f('courseCode', 'Course code') + ' <span class="qp-dash">–</span> ' + f('courseName', 'Course name') + '</div>'
    : ([M.courseCode, M.courseName].filter(Boolean).length ? '<div class="qp-line b">' + [M.courseCode, M.courseName].filter(Boolean).map(esc).join(' – ') + '</div>' : '');
  const date = E ? '<div class="qp-line sm">Date: ' + f('date', '—') + ' &nbsp; Session: ' + f('session', '—') + '</div>'
    : ([M.date ? 'Date: ' + M.date : '', M.session ? 'Session: ' + M.session : ''].filter(Boolean).length ? '<div class="qp-line sm">' + [M.date ? 'Date: ' + M.date : '', M.session ? 'Session: ' + M.session : ''].filter(Boolean).map(esc).join(' &nbsp; ') + '</div>' : '');
  let head = '<div class="qp-head">' +
    ((E || M.qpCode || regN) ? '<div class="qp-topline">' + qpc + reg + '</div>' : '') +
    '<div class="qp-inst' + (L.logo ? ' with-logo' : '') + '">' + (L.logo ? '<img class="qp-logo" data-f="' + esc(L.logo) + '" alt="">' : '') +
    '<div class="qp-inst-text">' + (E ? '<div>' + f('institution', 'Institution name', 'qp-institution') + '</div><div>' + f('subtitle', 'Second line (e.g. Autonomous · Affiliated to …)', 'qp-subtitle') + '</div>'
      : (M.institution ? '<div class="qp-institution">' + esc(M.institution) + '</div>' : '') + (M.subtitle ? '<div class="qp-subtitle">' + esc(M.subtitle) + '</div>' : '')) + '</div></div>' +
    '<div class="qp-exam">' + (E ? '<div class="qp-line b">' + f('examTitle', 'Examination title') + '</div>' : (M.examTitle ? '<div class="qp-line b">' + esc(M.examTitle) + '</div>' : '')) + progSem + course + date + '</div>' +
    '<div class="qp-time"><span><b>Time:</b> ' + (E ? f('duration', '3 Hours') : esc(M.duration || '')) + '</span><span><b>Maximum Marks:</b> ' + (E ? f('maxMarks', String(qpTotal(P))) : esc(M.maxMarks || numS(qpTotal(P)))) + '</span></div><hr class="qp-rule">';
  if (E || !isEmptyBody(P.instructions)) {
    head += '<div class="qp-instr"><div class="qp-instr-h">Instructions to candidates</div>' +
      (E ? '<div class="rt qp-rt-instr" contenteditable="true" data-rt="instructions" data-ph="Add instructions (optional)…">' + blocksHtml(P.instructions) + '</div>' : '<div class="rt-view">' + blocksHtml(P.instructions) + '</div>') + '</div>';
  }
  head += '</div>';

  // Question table
  const N = 4 + (L.showCO ? 1 : 0) + (showBL ? 1 : 0);
  const cols = '<colgroup><col style="width:1.1cm"><col style="width:1.3cm"><col><col style="width:1.25cm">' + (L.showCO ? '<col style="width:1.2cm">' : '') + (showBL ? '<col style="width:1.15cm">' : '') + '</colgroup>';
  const thead = cols + '<thead><tr><th class="c-no">Q.&thinsp;No.</th><th class="c-q" colspan="2">Question</th><th class="c-m">Marks</th>' + (L.showCO ? '<th class="c-co">CO</th>' : '') + (showBL ? '<th class="c-bl" title="Cognitive (Bloom’s) level">BL</th>' : '') + '</tr></thead>';
  const rows = [];
  let qn = 0;
  const cells = (u, leaf) => {
    let h = '<td class="c-m">' + (leaf ? (E ? '<input class="qp-mk" type="number" min="0" max="500" step="0.5" data-mk="' + esc(u.id) + '" value="' + (u.marks ? numS(u.marks) : '') + '" aria-label="Marks">' : (u.marks ? numS(u.marks) : '')) : '') + '</td>';
    if (L.showCO) h += '<td class="c-co">' + (leaf ? (E ? '<select class="qp-sel" data-co="' + esc(u.id) + '" aria-label="Course outcome">' + coOptions(u.co) + '</select>' : (u.co ? 'CO' + u.co : '')) : '') + '</td>';
    if (showBL) h += '<td class="c-bl">' + (leaf ? (E ? '<select class="qp-sel" data-bl="' + esc(u.id) + '" aria-label="Cognitive level">' + blOptions(u.bl) + '</select>' : (u.bl ? blPrefix + u.bl : '')) : '') + '</td>';
    return h;
  };
  const body = (u, ph) => E ? '<div class="rt" contenteditable="true" data-rt="' + esc(u.id) + '" data-ph="' + esc(ph) + '">' + blocksHtml(u.body) + '</div>' : '<div class="rt-view">' + blocksHtml(u.body) + '</div>';
  const tools = (q, sec, kind, part, host) => {
    if (!E) return '';
    let items;
    if (kind === 'part') {
      items = '<button class="menu-item" data-act="qpOp" data-op="partUp" data-id="' + esc(part.id) + '">' + icon('up') + 'Move up</button>' +
        '<button class="menu-item" data-act="qpOp" data-op="partDown" data-id="' + esc(part.id) + '">' + icon('down') + 'Move down</button>' +
        '<button class="menu-item" data-act="qpOp" data-op="partAdd" data-id="' + esc(host.id) + '">' + icon('subq') + 'Add another sub-part</button>' +
        '<div class="menu-sep"></div><button class="menu-item danger" data-act="qpOp" data-op="partDel" data-id="' + esc(part.id) + '">' + icon('trash') + 'Delete sub-part</button>';
    } else {
      items = '<button class="menu-item" data-act="qpOp" data-op="partAdd" data-id="' + esc(host.id) + '">' + icon('subq') + 'Add sub-part (i), (ii)…</button>' +
        (kind === 'q' ? '<button class="menu-item" data-act="qpOp" data-op="alt" data-id="' + esc(q.id) + '">' + icon('split') + (q.alt ? 'Remove OR choice (b)' : 'Add OR choice (b)') + '</button>' +
          '<button class="menu-item" data-act="qpOp" data-op="up" data-id="' + esc(q.id) + '">' + icon('up') + 'Move up</button>' +
          '<button class="menu-item" data-act="qpOp" data-op="down" data-id="' + esc(q.id) + '">' + icon('down') + 'Move down</button>' +
          '<button class="menu-item" data-act="qpOp" data-op="dup" data-id="' + esc(q.id) + '">' + icon('copy') + 'Duplicate</button>' +
          '<button class="menu-item" data-act="qpOp" data-op="pb" data-id="' + esc(q.id) + '">' + icon('pagebreak') + (q.pb ? 'Remove page break' : 'Start on a new page') + '</button>' +
          '<div class="menu-sep"></div><button class="menu-item danger" data-act="qpOp" data-op="del" data-id="' + esc(q.id) + '">' + icon('trash') + 'Delete question</button>' : '');
    }
    return '<div class="menu-wrap qp-tools"><button type="button" class="qp-tool" data-act="menu" aria-label="Question options">' + icon('more') + '</button><div class="menu">' + items + '</div></div>';
  };
  const unitRows = (u, q, sec, no, label, kind, grp) => {
    const parts = u.parts || [];
    const out = [];
    const ph = kind === 'alt' ? 'Type the alternative question (b)…' : 'Type the question…';
    if (!parts.length) {
      out.push('<tr class="qp-q" data-u="' + esc(u.id) + '" data-grp="' + grp + '"><td class="c-no">' + no + tools(q, sec, kind, null, u) + '</td><td class="c-sub">' + label + '</td><td class="c-q">' + body(u, ph) + '</td>' + cells(u, true) + '</tr>');
      return out;
    }
    let first = true;
    if (E || !isEmptyBody(u.body)) {
      out.push('<tr class="qp-q stem" data-u="' + esc(u.id) + '" data-grp="' + grp + '"><td class="c-no">' + no + tools(q, sec, kind, null, u) + '</td><td class="c-sub">' + label + '</td><td class="c-q">' + body(u, 'Common instruction for the sub-parts (optional)…') + '</td>' + cells(u, false) + '</tr>');
      first = false;
    }
    parts.forEach((p, i) => {
      const sub = (first ? label : '') + '(' + ROMAN[i] + ')';
      out.push('<tr class="qp-q part" data-u="' + esc(p.id) + '" data-grp="' + grp + '"><td class="c-no">' + (first ? no : '') + '</td><td class="c-sub">' + sub + tools(q, sec, 'part', p, u) + '</td><td class="c-q">' + body(p, 'Sub-part (' + ROMAN[i] + ')…') + '</td>' + cells(p, true) + '</tr>');
      first = false;
    });
    return out;
  };
  (P.sections || []).forEach((sec, si) => {
    if (L.numbering === 'section') qn = 0;
    const info = secInfo(sec);
    const note = sec.note || defaultNote(sec);
    rows.push('<tr class="qp-sec" data-sec="' + esc(sec.id) + '"><td colspan="' + N + '"><div class="qp-sec-title">' +
      (E ? '<span class="qp-f b" contenteditable="true" data-sec-title="' + esc(sec.id) + '" data-ph="Part title">' + esc(sec.title) + '</span>' : '<b>' + esc(sec.title) + '</b>') +
      ' <span class="qp-sec-marks" data-secm="' + esc(sec.id) + '">(' + esc(info.line) + ')</span>' +
      (E ? '<span class="qp-sec-tools"><button type="button" class="qp-tool" data-act="qpSecEdit" data-id="' + esc(sec.id) + '" title="Part settings">' + icon('settings') + '</button>' +
        '<button type="button" class="qp-tool" data-act="qpSecMove" data-id="' + esc(sec.id) + '" data-d="-1" title="Move part up"' + (si === 0 ? ' disabled' : '') + '>' + icon('up') + '</button>' +
        '<button type="button" class="qp-tool" data-act="qpSecMove" data-id="' + esc(sec.id) + '" data-d="1" title="Move part down"' + (si === P.sections.length - 1 ? ' disabled' : '') + '>' + icon('down') + '</button>' +
        '<button type="button" class="qp-tool danger" data-act="qpSecDel" data-id="' + esc(sec.id) + '" title="Delete part">' + icon('trash') + '</button></span>' : '') + '</div>' +
      (E ? '<div class="qp-sec-note"><span class="qp-f it" contenteditable="true" data-sec-note="' + esc(sec.id) + '" data-ph="' + esc(defaultNote(sec)) + '">' + esc(sec.note || '') + '</span></div>'
        : (note && note !== '-' ? '<div class="qp-sec-note it">' + esc(note) + '</div>' : '')) + '</td></tr>');
    sec.questions.forEach((q) => {
      qn++;
      const grp = esc(q.id);
      if (q.pb) rows.push('<tr class="qp-pb" data-grp="' + grp + '" data-pb="1"><td colspan="' + N + '"><span>Page break</span></td></tr>');
      if (q.alt) {
        rows.push(...unitRows(q, q, sec, qn + '.', '(a)', 'q', grp));
        rows.push('<tr class="qp-or" data-grp="' + grp + '"><td></td><td colspan="' + (N - 1) + '"><b>(OR)</b></td></tr>');
        rows.push(...unitRows(q.alt, q, sec, '', '(b)', 'alt', grp));
      } else rows.push(...unitRows(q, q, sec, qn + '.', '', 'q', grp));
    });
    if (E) rows.push('<tr class="qp-add"><td colspan="' + N + '"><button type="button" class="qp-addq" data-act="qpAddQ" data-sec="' + esc(sec.id) + '">' + icon('plus') + 'Add a question to ' + esc(sec.title || 'this part') + '</button></td></tr>');
  });
  const table = '<table class="qp-table cols-' + N + '">' + thead + '<tbody>' + rows.join('') + '</tbody></table>';
  const foot = (E ? '<div class="qp-addsec"><button type="button" class="btn btn-sm" data-act="qpSecAdd">' + icon('plus') + 'Add a part</button></div>' : '') +
    '<div class="qp-endtext">' + esc(L.endText != null ? L.endText : '* * * * *') + '</div>';
  if (o.parts) return { head, thead, rows, foot, N };
  return '<div class="qp-sheet font-' + esc(L.font || 'times') + ' fs-' + (L.fontSize || 11) + (E ? ' editing' : '') + '" style="--qp-w:' + (QP_PAPER[L.paper] || QP_PAPER.a4)[0] + 'mm;--qp-m:' + (Number(L.margin) || 2) + 'cm">' + head + table + foot + '</div>';
}

/* ---------- mount, sync, save ---------- */
function indexUnits() {
  EX.idx = {};
  EX.paper.sections.forEach((sec) => sec.questions.forEach((q) => {
    const reg = (u, kind, host) => { EX.idx[u.id] = { u, q, sec, kind, host }; (u.parts || []).forEach((p) => { EX.idx[p.id] = { u: p, q, sec, kind: 'part', host: u }; }); };
    reg(q, 'q'); if (q.alt) reg(q.alt, 'alt');
  }));
}
function renderSheet(keepScroll) {
  const wrap = $('#qpWrap'); if (!wrap) return;
  const canvas = $('#qpCanvas');
  const y = canvas ? canvas.scrollTop : 0;
  indexUnits();
  wrap.innerHTML = sheetHtml(EX.paper, { edit: EX.canEdit });
  qpHydrate(wrap);
  applyZoom();
  renderOutline(); renderStatus();
  if (keepScroll && canvas) canvas.scrollTop = y;
}
function editorMount(main) {
  main.classList.add('content-flush');
  document.body.classList.add('qp-editing');
  try { const t = sessionStorage.getItem('qp.tab'); if (t && EX.canEdit && $('#qpRibbon [data-tab="' + t + '"]')) ACT.qpRibbonTab({ tab: t }); } catch (e) { /* ignore */ }
  const fit = window.innerWidth < 900;
  EX.zoom = fit ? 0 : (prefs.get('qpZoom', 1) || 1);
  renderSheet();
  updateRibbonState(null, null);
  const canvas = $('#qpCanvas');
  const title = $('#qpTitle');
  if (EX.canEdit) {
    title.addEventListener('input', () => { EX.paper.title = title.value; markDirty(); });
    canvas.addEventListener('input', onCanvasInput);
    canvas.addEventListener('change', onCanvasChange);
    canvas.addEventListener('keydown', onCanvasKey);
    canvas.addEventListener('paste', onCanvasPaste);
    canvas.addEventListener('dblclick', onCanvasDbl);
    canvas.addEventListener('click', onCanvasClick);
    canvas.addEventListener('focusin', (e) => { const rt = e.target.closest('.rt'); if (rt) EX.rt = rt; });
    $('#qpImgFile').onchange = (e) => { const f = e.target.files[0]; e.target.value = ''; if (f) insertImageFile(f); };
  }
  const onSel = () => { if (!EX.canEdit) return; if (EX.selRaf) return; EX.selRaf = requestAnimationFrame(() => { EX.selRaf = 0; trackSelection(); }); };
  const onKey = (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); if (EX.canEdit) saveNow(); }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'h' && EX.canEdit) { e.preventDefault(); ACT.qpFind(); }
  };
  const onDown = (e) => {
    const b = e.target.closest('#qpRibbon .rb-btn, .qp-pop button, .qp-pop .qp-grid-cell');
    if (b) { saveSelection(); e.preventDefault(); }
    if (e.target.closest('#qpRibbon select')) saveSelection();
    if (!e.target.closest('.qp-pop') && !e.target.closest('[data-act="qpTableMenu"],[data-act="qpSymbols"]')) closePop();
  };
  const onUnload = (e) => { if (EX.dirty || EX.saving) { e.preventDefault(); e.returnValue = ''; } };
  const onResize = () => { if (EX.zoom === 0) applyZoom(); };
  document.addEventListener('selectionchange', onSel);
  document.addEventListener('keydown', onKey);
  document.addEventListener('mousedown', onDown, true);
  window.addEventListener('beforeunload', onUnload);
  window.addEventListener('resize', onResize);
  S.onLeave = () => {
    document.removeEventListener('selectionchange', onSel);
    document.removeEventListener('keydown', onKey);
    document.removeEventListener('mousedown', onDown, true);
    window.removeEventListener('beforeunload', onUnload);
    window.removeEventListener('resize', onResize);
    document.body.classList.remove('qp-editing');
    main.classList.remove('content-flush');
    closePop(); closePreview();
    if (EX.dirty) saveNow();
  };
}

function syncFromDom() {
  if (!EX.canEdit) return;
  const wrap = $('#qpWrap'); if (!wrap) return;
  indexUnits();
  wrap.querySelectorAll('.rt[data-rt]').forEach((el) => {
    const k = el.dataset.rt;
    const blocks = domBlocks(el);
    if (k === 'instructions') EX.paper.instructions = blocks;
    else if (EX.idx[k]) EX.idx[k].u.body = blocks;
  });
  wrap.querySelectorAll('[data-meta]').forEach((el) => { EX.paper.meta[el.dataset.meta] = el.textContent.replace(/\s+/g, ' ').trim(); });
  wrap.querySelectorAll('[data-sec-title]').forEach((el) => { const s = EX.paper.sections.find((x) => x.id === el.dataset.secTitle); if (s) s.title = el.textContent.replace(/\s+/g, ' ').trim(); });
  wrap.querySelectorAll('[data-sec-note]').forEach((el) => { const s = EX.paper.sections.find((x) => x.id === el.dataset.secNote); if (s) s.note = el.textContent.replace(/\s+/g, ' ').trim(); });
}
function setSave(state, text) {
  const el = $('#qpSave'); if (!el) return;
  const ico = { saved: 'checkCircle', saving: 'refresh', dirty: 'edit', error: 'alert' }[state] || 'checkCircle';
  el.className = 'qpx-save ' + state;
  el.innerHTML = icon(ico, 'i-sm') + esc(text);
}
function markDirty() {
  if (!EX.canEdit) return;
  EX.dirty = true;
  setSave('dirty', 'Editing…');
  clearTimeout(EX.timer);
  EX.timer = setTimeout(saveNow, 1400);
  renderStatusSoon();
}
function payload() {
  const P = EX.paper;
  return { title: P.title, examType: P.examType, courseId: P.courseId, meta: P.meta, layout: P.layout, instructions: P.instructions, sections: P.sections };
}
async function saveNow(force) {
  clearTimeout(EX.timer);
  if (!EX.canEdit || !EX.paper) return;
  if (EX.saving) { EX.again = true; return; }
  syncFromDom();
  EX.saving = true; EX.dirty = false;
  setSave('saving', 'Saving…');
  const id = EX.paper.id;
  try {
    const r = await call('examSave', { id, version: EX.version, paper: payload(), force: !!force });
    if (!EX.paper || EX.paper.id !== id) return;
    EX.version = r.version; EX.paper.version = r.version; EX.checks = r.checks;
    setSave('saved', 'Saved ' + fmtTime(Date.now()));
    renderOutline(); renderStatus();
  } catch (e) {
    EX.dirty = true;
    if (/^CONFLICT/.test(e.message)) {
      setSave('error', 'Not saved — conflict');
      openModal(modalHead('Someone else changed this paper', 'A co-setter saved a newer version while you were editing.') + '<div class="modal-body"><p class="small">Reload to see their version (your latest typing will be lost), or keep yours and overwrite theirs. Their version stays in Review → Versions either way.</p>' +
        '<div class="form-actions"><button class="btn" data-act="qpReload">Reload their version</button><button class="btn btn-primary" data-act="qpForce">Keep mine</button></div></div>', 'narrow');
    } else { setSave('error', 'Not saved — retrying'); if (!isExpired(e)) { clearTimeout(EX.timer); EX.timer = setTimeout(saveNow, 5000); } }
  } finally {
    EX.saving = false;
    if (EX.again) { EX.again = false; if (EX.dirty) saveNow(); }
  }
}
ACT.qpReload = () => { closeModal(); EX.dirty = false; refresh(); };
ACT.qpForce = () => { closeModal(); saveNow(true); };

/* ---------- outline & status bar ---------- */
function renderOutline() {
  const el = $('#qpOutline'); if (!el) return;
  const bad = new Set(EX.checks.filter((c) => c.level === 'error').map((c) => c.ref));
  let qn = 0;
  const total = qpTotal(EX.paper);
  const max = Number(String(EX.paper.meta.maxMarks || '').replace(/[^\d.]/g, ''));
  el.innerHTML = '<div class="qpo-total"><span>Marks</span><b class="' + (max && total !== max ? 'bad' : 'ok') + '">' + numS(total) + (max ? ' / ' + numS(max) : '') + '</b></div>' +
    EX.paper.sections.map((sec) => {
      if (EX.paper.layout.numbering === 'section') qn = 0;
      const info = secInfo(sec);
      return '<div class="qpo-sec"><div class="qpo-sec-h"><span>' + esc(sec.title || 'Part') + '</span><span class="muted">' + numS(info.total) + '</span></div><div class="qpo-qs">' +
        sec.questions.map((q) => {
          qn++;
          const units = [q].concat(q.alt ? [q.alt] : []);
          const filled = units.every((u) => (u.parts && u.parts.length ? u.parts.every((p) => !isEmptyBody(p.body)) : !isEmptyBody(u.body)));
          const err = units.some((u) => bad.has(u.id) || (u.parts || []).some((p) => bad.has(p.id))) || bad.has(q.id);
          return '<button type="button" class="qpo-q' + (filled ? ' done' : '') + (err ? ' err' : '') + '" data-act="qpJump" data-id="' + esc(q.id) + '" title="Question ' + qn + (filled ? '' : ' — not written yet') + '">' + qn + '</button>';
        }).join('') + '</div></div>';
    }).join('') +
    '<button type="button" class="qpo-checks" data-act="qpChecks">' + checkSummary() + '</button>';
}
function checkSummary() {
  const e = EX.checks.filter((c) => c.level === 'error').length, w = EX.checks.filter((c) => c.level === 'warn').length;
  return !e && !w ? icon('checkCircle', 'i-sm') + '<span>No problems found</span>' : icon('alert', 'i-sm') + '<span>' + (e ? plural(e, 'error') : '') + (e && w ? ', ' : '') + (w ? plural(w, 'warning') : '') + '</span>';
}
let statusRaf = 0;
function renderStatusSoon() { if (!statusRaf) statusRaf = requestAnimationFrame(() => { statusRaf = 0; updateTotals(); }); }
function updateTotals() {
  EX.paper.sections.forEach((sec) => { const el = $('[data-secm="' + sec.id + '"]'); if (el) el.textContent = '(' + secInfo(sec).line + ')'; });
  renderStatus();
  const t = $('#qpOutline .qpo-total b');
  if (t) { const total = qpTotal(EX.paper); const max = Number(String(EX.paper.meta.maxMarks || '').replace(/[^\d.]/g, '')); t.textContent = numS(total) + (max ? ' / ' + numS(max) : ''); t.className = max && total !== max ? 'bad' : 'ok'; }
}
function renderStatus() {
  const el = $('#qpStatus'); if (!el) return;
  const P = EX.paper;
  const nq = P.sections.reduce((n, s) => n + s.questions.length, 0);
  const words = ($('#qpWrap') ? ($('#qpWrap').innerText.match(/[\p{L}\p{N}]+/gu) || []).length : 0);
  el.innerHTML = '<span>' + plural(P.sections.length, 'part') + '</span><span>' + plural(nq, 'question') + '</span><span>' + numS(qpTotal(P)) + ' marks</span><span>' + words.toLocaleString() + ' words</span>' +
    '<button type="button" class="qpx-stat-btn" data-act="qpChecks">' + checkSummary() + '</button><span class="spacer"></span>' +
    '<span class="hide-sm">' + esc(QP_FONTS[P.layout.font] || P.layout.font) + ' ' + P.layout.fontSize + ' pt · ' + esc(String(P.layout.paper || 'a4').toUpperCase()) + '</span>' +
    '<button type="button" class="qpx-stat-btn" data-act="qpZoom" data-z="-1" aria-label="Zoom out">' + icon('minus', 'i-sm') + '</button><span id="qpZoomPct">' + Math.round(currentZoom() * 100) + '%</span><button type="button" class="qpx-stat-btn" data-act="qpZoom" data-z="1" aria-label="Zoom in">' + icon('plus', 'i-sm') + '</button>';
}
ACT.qpJump = (d) => {
  const row = $('#qpWrap tr[data-grp="' + d.id + '"]') || $('#qpWrap [data-u="' + d.id + '"]');
  if (!row) return;
  row.scrollIntoView({ behavior: 'smooth', block: 'center' });
  row.classList.add('flash'); setTimeout(() => row.classList.remove('flash'), 1400);
  const rt = row.querySelector('.rt'); if (rt && EX.canEdit) setTimeout(() => rt.focus(), 300);
};

/* ---------- zoom ---------- */
function currentZoom() {
  if (EX.zoom) return EX.zoom;
  const c = $('#qpCanvas'); const sheet = $('#qpWrap .qp-sheet');
  if (!c || !sheet) return 1;
  return Math.max(0.35, Math.min(1.2, (c.clientWidth - 32) / (sheet.offsetWidth || 794)));
}
function applyZoom() {
  const wrap = $('#qpWrap'); if (!wrap) return;
  wrap.style.zoom = '';
  const z = currentZoom();
  wrap.style.zoom = z;
  const a = $('#rbZoom'); if (a) a.textContent = Math.round(z * 100) + '%';
  const b = $('#qpZoomPct'); if (b) b.textContent = Math.round(z * 100) + '%';
}
ACT.qpZoom = (d) => {
  const steps = [0.5, 0.67, 0.75, 0.9, 1, 1.1, 1.25, 1.5];
  const z = currentZoom();
  if (d.z === '0') EX.zoom = 0;
  else if (d.z === '1') EX.zoom = steps.find((s) => s > z + 0.01) || 1.5;
  else EX.zoom = steps.slice().reverse().find((s) => s < z - 0.01) || 0.5;
  prefs.set('qpZoom', EX.zoom);
  applyZoom();
};

/* ---------- images ---------- */
function qpHydrate(root) {
  $$('img[data-f]', root).forEach((img) => {
    if (img.getAttribute('src')) return;
    const id = img.dataset.f;
    if (EX.blobs[id]) { img.src = EX.blobs[id]; return; }
    fetchFileBlob({ id }).then((b) => { EX.blobs[id] = URL.createObjectURL(b); img.src = EX.blobs[id]; }).catch(() => { img.alt = 'Picture unavailable'; img.classList.add('missing'); });
  });
}

/* ---------- canvas events ---------- */
function onCanvasInput(e) {
  const t = e.target;
  if (t.matches('.qp-mk')) {
    const x = EX.idx[t.dataset.mk];
    if (x) x.u.marks = Number(t.value) || 0;
    markDirty(); return;
  }
  if (t.closest('[data-meta]')) {
    const m = t.closest('[data-meta]'); EX.paper.meta[m.dataset.meta] = m.textContent.replace(/\s+/g, ' ').trim();
    if (m.dataset.meta === 'maxMarks') updateTotals();
  }
  markDirty();
}
function onCanvasChange(e) {
  const t = e.target;
  if (t.dataset.co && EX.idx[t.dataset.co]) { EX.idx[t.dataset.co].u.co = Number(t.value); markDirty(); }
  if (t.dataset.bl && EX.idx[t.dataset.bl]) { EX.idx[t.dataset.bl].u.bl = Number(t.value); markDirty(); }
}
function onCanvasKey(e) {
  const t = e.target;
  if (t.matches('[data-meta],[data-sec-title],[data-sec-note]') && e.key === 'Enter') { e.preventDefault(); t.blur(); return; }
  if (!t.closest('.rt')) return;
  if (e.key === 'Tab') {
    const cell = selCell();
    if (cell) {
      e.preventDefault();
      const cellsAll = [...cell.closest('table').querySelectorAll('td,th')];
      let i = cellsAll.indexOf(cell) + (e.shiftKey ? -1 : 1);
      if (i >= cellsAll.length) { tableOp('rowBelow'); return; }
      i = Math.max(0, i);
      placeCaret(cellsAll[i]);
    }
  }
}
function onCanvasPaste(e) {
  const rt = e.target.closest('.rt');
  const plainField = e.target.closest('[data-meta],[data-sec-title],[data-sec-note]');
  if (plainField) { e.preventDefault(); document.execCommand('insertText', false, (e.clipboardData.getData('text/plain') || '').replace(/\s+/g, ' ')); return; }
  if (!rt) return;
  const cd = e.clipboardData;
  const imgs = [...(cd.files || [])].filter((f) => /^image\/(png|jpeg)$/.test(f.type));
  if (imgs.length) { e.preventDefault(); saveSelection(); imgs.forEach(insertImageFile); return; }
  const html = cd.getData('text/html');
  const text = cd.getData('text/plain');
  e.preventDefault();
  let blocks;
  if (html) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    blocks = domBlocks(doc.body);
  } else {
    blocks = String(text || '').split(/\r?\n/).map((l) => ({ t: 'p', c: l ? [{ x: l }] : [] }));
  }
  if (!blocks.length) return;
  const h = blocks.length === 1 && blocks[0].t === 'p' ? inlineHtml(blocks[0].c) : blocksHtml(blocks);
  document.execCommand('insertHTML', false, h);
  hydrateNew();
  markDirty();
}
function hydrateNew() { const w = $('#qpWrap'); if (w) qpHydrate(w); }
function onCanvasDbl(e) {
  const eq = e.target.closest('.rt-eq,.rt-eqb');
  if (eq && eq.closest('.rt')) { e.preventDefault(); openEquation(eq); }
}
function onCanvasClick(e) {
  const fig = e.target.closest('.rt-img');
  $$('#qpWrap .rt-img.sel').forEach((x) => { if (x !== fig) x.classList.remove('sel'); });
  if (fig && fig.closest('.rt')) { fig.classList.add('sel'); imageBar(fig); return; }
  const eq = e.target.closest('.rt-eq,.rt-eqb');
  if (eq && eq.closest('.rt')) { const r = document.createRange(); r.selectNode(eq); const s = getSelection(); s.removeAllRanges(); s.addRange(r); EX.range = r.cloneRange(); EX.rt = eq.closest('.rt'); }
}

/* ---------- selection & commands ---------- */
function trackSelection() {
  const s = getSelection();
  if (!s.rangeCount) return;
  const n = s.anchorNode;
  const el = n && (n.nodeType === 1 ? n : n.parentElement);
  const rt = el && el.closest && el.closest('#qpWrap .rt');
  if (rt) { EX.rt = rt; EX.range = s.getRangeAt(0).cloneRange(); }
  updateRibbonState(rt, el);
}
function saveSelection() {
  const s = getSelection();
  if (!s.rangeCount) return;
  const n = s.anchorNode; const el = n && (n.nodeType === 1 ? n : n.parentElement);
  if (el && el.closest && el.closest('#qpWrap .rt')) { EX.range = s.getRangeAt(0).cloneRange(); EX.rt = el.closest('#qpWrap .rt'); }
}
function restoreSelection() {
  if (!EX.rt || !document.body.contains(EX.rt)) { EX.rt = null; return false; }
  EX.rt.focus({ preventScroll: true });
  if (EX.range) { const s = getSelection(); s.removeAllRanges(); s.addRange(EX.range); }
  return true;
}
function needRt() {
  if (restoreSelection()) return true;
  toast('Click inside a question first.', 'err');
  return false;
}
function updateRibbonState(rt, el) {
  const rb = $('#qpRibbon'); if (!rb) return;
  $$('[data-state]', rb).forEach((b) => { let on = false; try { on = !!rt && document.queryCommandState(b.dataset.state); } catch (e) { /* unsupported */ } b.classList.toggle('on', on); });
  const inTable = !!(rt && el && el.closest('td,th'));
  $$('.rb-table .rb-btn', rb).forEach((b) => { b.disabled = !inTable; });
  const style = $('#rbStyle');
  if (style && el && rt) { const blk = el.closest('h1,h2,h3,h4,h5,h6,pre,p,li,td,th'); style.value = blk && /^H/.test(blk.tagName) ? 'h4' : blk && blk.tagName === 'PRE' ? 'pre' : 'p'; }
  const ls = $('#rbList');
  if (ls && el) { const ol = el.closest('ol'); if (ol) ls.value = ol.dataset.s || '1'; }
}
ACT.qpCmd = (d) => {
  if (!needRt()) return;
  try { document.execCommand('styleWithCSS', false, false); } catch (e) { /* ignore */ }
  document.execCommand(d.c, false, d.v || null);
  if (d.c === 'insertOrderedList') { const ol = selEl() && selEl().closest('ol'); if (ol && !ol.dataset.s) ol.dataset.s = ($('#rbList') || {}).value || '1'; }
  markDirty(); trackSelection();
};
ACT.qpBlockStyle = (d, sel) => { if (!needRt()) return; document.execCommand('formatBlock', false, sel.value === 'p' ? 'P' : sel.value.toUpperCase()); markDirty(); };
ACT.qpListStyle = (d, sel) => {
  if (!needRt()) return;
  let ol = selEl() && selEl().closest('ol');
  if (!ol) { document.execCommand('insertOrderedList'); ol = selEl() && selEl().closest('ol'); }
  if (ol) ol.dataset.s = sel.value;
  markDirty();
};
function selEl() { const s = getSelection(); if (!s.rangeCount) return null; const n = s.anchorNode; return n && (n.nodeType === 1 ? n : n.parentElement); }
function selCell() { const el = selEl(); return el && el.closest('.rt td, .rt th'); }
function placeCaret(el) { const r = document.createRange(); r.selectNodeContents(el); r.collapse(!el.textContent.trim()); const s = getSelection(); s.removeAllRanges(); s.addRange(r); EX.range = r.cloneRange(); }
function insertHtmlAtCaret(html) { if (!needRt()) return false; document.execCommand('insertHTML', false, html); hydrateNew(); markDirty(); return true; }

/* ---------- popovers (table grid, symbols, image size) ---------- */
function closePop() { const p = $('.qp-pop'); if (p) p.remove(); }
function openPop(anchor, html, cls) {
  closePop();
  const p = document.createElement('div');
  p.className = 'qp-pop ' + (cls || '');
  p.innerHTML = html;
  document.body.appendChild(p);
  const r = anchor.getBoundingClientRect();
  const w = p.offsetWidth;
  p.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, r.left)) + 'px';
  p.style.top = Math.min(window.innerHeight - p.offsetHeight - 8, r.bottom + 6) + 'px';
  return p;
}
ACT.qpTableMenu = (d, btn) => {
  if (!EX.rt) { toast('Click inside a question first.', 'err'); return; }
  const R = 8, C = 8;
  let cells = '';
  for (let r = 1; r <= R; r++) for (let c = 1; c <= C; c++) cells += '<button type="button" class="qp-grid-cell" data-r="' + r + '" data-c="' + c + '" aria-label="' + r + ' by ' + c + '"></button>';
  const p = openPop(btn, '<div class="qp-grid-label" id="qpGridLabel">Insert table</div><div class="qp-grid" style="grid-template-columns:repeat(' + C + ',18px)">' + cells + '</div><label class="check small"><input type="checkbox" id="qpGridHead" checked><span>First row is a header</span></label>');
  p.addEventListener('mouseover', (e) => {
    const cell = e.target.closest('.qp-grid-cell'); if (!cell) return;
    const r = Number(cell.dataset.r), c = Number(cell.dataset.c);
    $$('.qp-grid-cell', p).forEach((x) => x.classList.toggle('on', Number(x.dataset.r) <= r && Number(x.dataset.c) <= c));
    $('#qpGridLabel').textContent = r + ' × ' + c + ' table';
  });
  p.addEventListener('click', (e) => {
    const cell = e.target.closest('.qp-grid-cell'); if (!cell) return;
    const r = Number(cell.dataset.r), c = Number(cell.dataset.c), head = $('#qpGridHead').checked;
    const mark = 't' + Date.now();
    let h = '<table class="rt-table" data-new="' + mark + '"' + (head ? ' data-head="1"' : '') + '><tbody>';
    for (let i = 0; i < r; i++) { h += '<tr>'; for (let j = 0; j < c; j++) h += (head && i === 0 ? '<th><br></th>' : '<td><br></td>'); h += '</tr>'; }
    h += '</tbody></table><p><br></p>';
    closePop();
    if (!insertHtmlAtCaret(h)) return;
    const t = $('#qpWrap table[data-new="' + mark + '"]');
    if (t) { t.removeAttribute('data-new'); const r0 = document.createRange(); r0.selectNodeContents(t.rows[0].cells[0]); r0.collapse(true); const s = getSelection(); s.removeAllRanges(); s.addRange(r0); EX.range = r0.cloneRange(); trackSelection(); }
  });
};
function tableOp(op) {
  if (!needRt()) return;
  const cell = selCell();
  if (!cell) { toast('Put the cursor in a table cell first.', 'err'); return; }
  const tr = cell.parentElement, table = cell.closest('table');
  const idx = [...tr.cells].indexOf(cell);
  const width = Math.max(...[...table.rows].map((r) => [...r.cells].reduce((n, c) => n + (c.colSpan || 1), 0)));
  const newRow = () => { const r = document.createElement('tr'); for (let i = 0; i < width; i++) { const td = document.createElement('td'); td.innerHTML = '<br>'; r.appendChild(td); } return r; };
  switch (op) {
    case 'rowAbove': tr.parentElement.insertBefore(newRow(), tr); break;
    case 'rowBelow': { const r = newRow(); tr.parentElement.insertBefore(r, tr.nextSibling); placeCaret(r.cells[0]); break; }
    case 'colRight': [...table.rows].forEach((r) => { const c = document.createElement(r.cells[0] && r.cells[0].tagName === 'TH' ? 'th' : 'td'); c.innerHTML = '<br>'; const ref = r.cells[Math.min(idx, r.cells.length - 1)]; r.insertBefore(c, ref ? ref.nextSibling : null); }); break;
    case 'delRow': if (table.rows.length <= 1) table.remove(); else tr.remove(); break;
    case 'delCol': [...table.rows].forEach((r) => { const c = r.cells[Math.min(idx, r.cells.length - 1)]; if (c) { if ((c.colSpan || 1) > 1) c.colSpan -= 1; else c.remove(); } }); if (![...table.rows].some((r) => r.cells.length)) table.remove(); break;
    case 'merge': { const next = cell.nextElementSibling; if (!next) { toast('There is no cell to the right.', 'err'); return; } cell.colSpan = (cell.colSpan || 1) + (next.colSpan || 1); if (next.textContent.trim()) cell.insertAdjacentHTML('beforeend', ' ' + next.innerHTML); next.remove(); break; }
    case 'head': {
      const on = table.dataset.head !== '1';
      if (on) table.dataset.head = '1'; else delete table.dataset.head;
      const first = table.rows[0];
      [...first.cells].forEach((c) => { const n = document.createElement(on ? 'th' : 'td'); n.innerHTML = c.innerHTML; if (c.colSpan > 1) n.colSpan = c.colSpan; c.replaceWith(n); });
      break;
    }
    case 'delTable': table.remove(); break;
    default: return;
  }
  markDirty(); trackSelection();
}
ACT.qpTbl = (d) => tableOp(d.op);

const QP_SYMBOLS = [
  ['Greek', 'α β γ δ ε θ λ μ π ρ σ τ φ ω Γ Δ Θ Λ Π Σ Φ Ψ Ω'],
  ['Maths', '± × ÷ − ≤ ≥ ≠ ≈ ≡ ∝ ∞ √ ∑ ∏ ∫ ∂ ∇ ° ′ ″ ∠ ⊥ ∥ ∴ ∵'],
  ['Sets & logic', '∈ ∉ ⊂ ⊃ ⊆ ⊇ ∪ ∩ ∅ ∀ ∃ ¬ ∧ ∨ ⊕ ℝ ℕ ℤ ℚ ℂ'],
  ['Arrows', '→ ← ↑ ↓ ↔ ⇒ ⇐ ⇔ ↦'],
  ['Other', '₹ € £ $ % § ¶ © ™ • … – — ½ ¼ ¾ ² ³ ¹ ⁿ ₁ ₂']
];
ACT.qpSymbols = (d, btn) => {
  if (!EX.rt) { toast('Click inside a question first.', 'err'); return; }
  const p = openPop(btn, QP_SYMBOLS.map(([g, list]) => '<div class="qp-sym-g">' + esc(g) + '</div><div class="qp-syms">' + list.split(' ').map((ch) => '<button type="button" data-ch="' + esc(ch) + '" title="' + esc(ch) + '">' + esc(ch) + '</button>').join('') + '</div>').join(''), 'qp-sym-pop');
  p.addEventListener('click', (e) => {
    const b = e.target.closest('[data-ch]'); if (!b) return;
    if (restoreSelection()) { document.execCommand('insertText', false, b.dataset.ch); saveSelection(); markDirty(); }
  });
};
ACT.qpBlank = () => insertHtmlAtCaret('<span class="rt-blank" contenteditable="false" data-bl="3" style="width:2.7cm"></span>&nbsp;');
ACT.qpImage = () => { if (!EX.rt) { toast('Click inside a question first.', 'err'); return; } saveSelection(); $('#qpImgFile').click(); };
async function insertImageFile(file) {
  if (!/^image\/(png|jpeg)$/.test(file.type)) { toast('Use PNG or JPEG pictures (LaTeX cannot print other formats).', 'err'); return; }
  await busy(null, async () => {
    const r = await uploadFile(file);
    EX.files[r.id] = { name: r.name, mime: r.mime };
    insertHtmlAtCaret('<figure class="rt-img" contenteditable="false" data-f="' + esc(r.id) + '" data-w="60" data-a="c" style="width:60%"><img data-f="' + esc(r.id) + '" alt="Figure"></figure><p><br></p>');
  });
}
function imageBar(fig) {
  const w = Number(fig.dataset.w) || 60;
  const p = openPop(fig, '<div class="qp-imgbar">' + [25, 40, 60, 80, 100].map((n) => '<button type="button" data-w="' + n + '" class="' + (n === w ? 'on' : '') + '">' + n + '%</button>').join('') +
    '<span class="sep"></span>' + [['l', 'alignLeft'], ['c', 'alignCenter'], ['r', 'alignRight']].map(([a, ic]) => '<button type="button" data-a="' + a + '" class="' + ((fig.dataset.a || 'c') === a ? 'on' : '') + '" aria-label="Align">' + icon(ic, 'i-sm') + '</button>').join('') +
    '<span class="sep"></span><button type="button" data-del="1" aria-label="Delete picture">' + icon('trash', 'i-sm') + '</button></div>');
  p.addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.w) { fig.dataset.w = b.dataset.w; fig.style.width = b.dataset.w + '%'; }
    if (b.dataset.a) fig.dataset.a = b.dataset.a;
    if (b.dataset.del) { fig.remove(); closePop(); markDirty(); return; }
    markDirty(); imageBar(fig);
  });
}
ACT.qpPageBreak = () => {
  const x = EX.rt && EX.idx[EX.rt.dataset.rt];
  if (!x) { toast('Click inside the question that should start on a new page.', 'err'); return; }
  questionOp('pb', x.q.id);
};

/* ---------- equations ---------- */
const QP_EQ = [
  ['Structures', [['\\frac{a}{b}', 'Fraction'], ['x^{2}', 'Power'], ['x_{i}', 'Subscript'], ['\\sqrt{x}', 'Square root'], ['\\sqrt[n]{x}', 'n-th root'], ['\\sum_{i=1}^{n} x_i', 'Sum'], ['\\int_{a}^{b} f(x)\\,dx', 'Integral'],
    ['\\lim_{x \\to 0}', 'Limit'], ['\\frac{d}{dx}', 'Derivative'], ['\\frac{\\partial f}{\\partial x}', 'Partial'], ['\\binom{n}{r}', 'Binomial'], ['\\log_{b} x', 'Logarithm'], ['\\vec{v}', 'Vector'], ['\\overline{x}', 'Bar'], ['\\hat{\\theta}', 'Hat']]],
  ['Layouts', [['\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}', 'Matrix'], ['\\begin{vmatrix} a & b \\\\ c & d \\end{vmatrix}', 'Determinant'], ['f(x) = \\begin{cases} x & x \\ge 0 \\\\ -x & x < 0 \\end{cases}', 'Cases'], ['\\begin{aligned} a &= b + c \\\\ &= d \\end{aligned}', 'Aligned']]],
  ['Symbols', [['\\alpha'], ['\\beta'], ['\\gamma'], ['\\delta'], ['\\theta'], ['\\lambda'], ['\\mu'], ['\\pi'], ['\\sigma'], ['\\phi'], ['\\omega'], ['\\Delta'], ['\\Sigma'], ['\\Omega'],
    ['\\le'], ['\\ge'], ['\\ne'], ['\\approx'], ['\\equiv'], ['\\pm'], ['\\times'], ['\\div'], ['\\cdot'], ['\\infty'], ['\\in'], ['\\subset'], ['\\cup'], ['\\cap'], ['\\rightarrow'], ['\\Rightarrow'], ['\\leftrightarrow'], ['^{\\circ}'], ['\\angle'], ['\\therefore']]]
];
function openEquation(existing) {
  if (!existing && !EX.rt) { toast('Click inside a question first.', 'err'); return; }
  if (!existing) saveSelection();
  EX.eqEdit = existing || null;
  const tex = existing ? existing.dataset.tex : '';
  const display = existing ? existing.classList.contains('rt-eqb') : false;
  openModal(modalHead(existing ? 'Edit equation' : 'Insert equation', 'Type LaTeX maths or pick a structure; the preview is exactly what will be typeset.') + '<div class="modal-body">' +
    QP_EQ.map(([g, list]) => '<div class="qp-eq-g">' + esc(g) + '</div><div class="qp-eq-pal">' + list.map(([t, label]) => '<button type="button" class="qp-eq-btn" data-act="qpEqIns" data-t="' + esc(t) + '" title="' + esc(label || t) + '">' + texHtml(t.replace(/\\begin\{aligned\}[\s\S]*/, 'a = b'), false) + '</button>').join('') + '</div>').join('') +
    '<label class="label" for="qpEqSrc" style="margin-top:var(--sp-4)">LaTeX</label><textarea id="qpEqSrc" class="mono" rows="3" spellcheck="false" data-input="qpEqPrev" data-delay="80" placeholder="e.g. \\frac{-b \\pm \\sqrt{b^2-4ac}}{2a}">' + esc(tex) + '</textarea>' +
    '<div class="qp-eq-prev" id="qpEqPrev"></div><div class="small" id="qpEqErr" role="alert"></div>' +
    '<label class="check"><input type="checkbox" id="qpEqDisp"' + (display ? ' checked' : '') + '><span>Display on its own line (centred)</span></label>' +
    '<div class="form-actions">' + (existing ? '<button class="btn btn-danger" data-act="qpEqDel">Delete</button><span class="spacer"></span>' : '') + '<button class="btn" data-act="close">Cancel</button><button class="btn btn-primary" data-act="qpEqOk">' + (existing ? 'Update' : 'Insert') + '</button></div></div>', 'wide');
  INPUTS.qpEqPrev();
  const ta = $('#qpEqSrc'); ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length);
}
INPUTS.qpEqPrev = () => {
  const src = ($('#qpEqSrc') || {}).value || '';
  const box = $('#qpEqPrev'), err = $('#qpEqErr');
  if (!box) return;
  if (!src.trim()) { box.innerHTML = '<span class="muted small">Preview appears here</span>'; err.textContent = ''; return; }
  try { box.innerHTML = katex.renderToString(src, { displayMode: true, throwOnError: true, strict: 'ignore' }); err.textContent = ''; } catch (e) { err.innerHTML = '<span style="color:var(--error)">' + esc(String(e.message || e).replace(/^KaTeX parse error: /, '')) + '</span>'; }
};
ACT.qpEqIns = (d) => {
  const ta = $('#qpEqSrc'); if (!ta) return;
  const a = ta.selectionStart, b = ta.selectionEnd;
  ta.value = ta.value.slice(0, a) + d.t + ta.value.slice(b);
  ta.focus(); ta.setSelectionRange(a + d.t.length, a + d.t.length);
  INPUTS.qpEqPrev();
};
ACT.qpEq = () => openEquation(null);
ACT.qpEqOk = () => {
  const src = $('#qpEqSrc').value.trim();
  if (!src) { toast('Type an equation first.', 'err'); return; }
  try { katex.renderToString(src, { throwOnError: true, strict: 'ignore' }); } catch (e) { toast('Fix the equation first: ' + String(e.message || e).replace(/^KaTeX parse error: /, ''), 'err'); return; }
  const disp = $('#qpEqDisp').checked;
  const html = disp ? '<div class="rt-eqb" contenteditable="false" data-tex="' + esc(src) + '">' + texHtml(src, true) + '</div>' : '<span class="rt-eq" contenteditable="false" data-tex="' + esc(src) + '">' + texHtml(src, false) + '</span>';
  closeModal();
  if (EX.eqEdit && document.body.contains(EX.eqEdit)) { EX.eqEdit.outerHTML = html; markDirty(); }
  else insertHtmlAtCaret(html + (disp ? '<p><br></p>' : '&nbsp;'));
  EX.eqEdit = null;
};
ACT.qpEqDel = () => { if (EX.eqEdit) { EX.eqEdit.remove(); EX.eqEdit = null; markDirty(); } closeModal(); };

/* ---------- questions, sub-parts, OR choices, parts ---------- */
function currentUnit() { return EX.rt && EX.idx[EX.rt.dataset.rt]; }
function questionOp(op, id) {
  syncFromDom();
  const P = EX.paper;
  const x = EX.idx[id];
  let focusId = null;
  const sec = x && x.sec;
  const qi = sec ? sec.questions.indexOf(x.q) : -1;
  switch (op) {
    case 'up': if (qi > 0) { sec.questions.splice(qi - 1, 0, sec.questions.splice(qi, 1)[0]); } break;
    case 'down': if (qi >= 0 && qi < sec.questions.length - 1) { sec.questions.splice(qi + 1, 0, sec.questions.splice(qi, 1)[0]); } break;
    case 'dup': { const c = JSON.parse(JSON.stringify(x.q)); const re = (u) => { u.id = uid('Q'); (u.parts || []).forEach(re); }; re(c); if (c.alt) re(c.alt); sec.questions.splice(qi + 1, 0, c); focusId = c.id; break; }
    case 'del': sec.questions.splice(qi, 1); break;
    case 'pb': x.q.pb = !x.q.pb; break;
    case 'alt': x.q.alt = x.q.alt ? null : blankUnit(unitMarks(x.q) || sec.marks); if (x.q.alt) focusId = x.q.alt.id; break;
    case 'partAdd': {
      const host = x.kind === 'part' ? x.host : x.u;
      if (!host.parts) host.parts = [];
      if (host.parts.length >= 10) { toast('A question can have at most 10 sub-parts.', 'err'); break; }
      const p = blankUnit(0);
      if (!host.parts.length) { p.body = host.body; p.co = host.co; p.bl = host.bl; p.marks = host.marks; host.body = []; host.marks = 0; }
      host.parts.push(p);
      if (host.parts.length === 1) { const p2 = blankUnit(0); host.parts.push(p2); focusId = p2.id; } else focusId = p.id;
      break;
    }
    case 'partDel': case 'partUp': case 'partDown': {
      const host = x.host; const i = host.parts.indexOf(x.u);
      if (op === 'partDel') {
        host.parts.splice(i, 1);
        if (host.parts.length === 1) { const only = host.parts[0]; host.body = host.body.concat(only.body); host.marks = only.marks; host.co = only.co; host.bl = only.bl; host.parts = []; }
      } else {
        const j = i + (op === 'partUp' ? -1 : 1);
        if (j >= 0 && j < host.parts.length) host.parts.splice(j, 0, host.parts.splice(i, 1)[0]);
      }
      break;
    }
    default: return;
  }
  renderSheet(true); markDirty();
  if (focusId) setTimeout(() => ACT.qpJump({ id: focusId }), 50);
  void P;
}
ACT.qpOp = (d) => {
  if (d.op === 'del') {
    const x = EX.idx[d.id];
    const empty = x && isEmptyBody(x.q.body) && !(x.q.parts || []).length && !x.q.alt;
    if (!empty) { confirmBox('Delete this question?', 'Its text, sub-parts and OR choice are removed. You can restore an earlier version from Review → Versions.', 'Delete', true).then((ok) => { if (ok) questionOp('del', d.id); }); return; }
  }
  questionOp(d.op, d.id);
};
ACT.qpAddQ = (d) => {
  syncFromDom();
  const sec = EX.paper.sections.find((s) => s.id === d.sec); if (!sec) return;
  const q = blankQ(sec); sec.questions.push(q);
  renderSheet(true); markDirty();
  setTimeout(() => ACT.qpJump({ id: q.id }), 50);
};
ACT.qpInsQ = () => {
  syncFromDom();
  const x = currentUnit();
  const sec = x ? x.sec : EX.paper.sections[EX.paper.sections.length - 1];
  if (!sec) { ACT.qpSecAdd(); return; }
  const q = blankQ(sec);
  const i = x ? sec.questions.indexOf(x.q) + 1 : sec.questions.length;
  sec.questions.splice(i, 0, q);
  renderSheet(true); markDirty();
  setTimeout(() => ACT.qpJump({ id: q.id }), 50);
};
ACT.qpInsPart = () => { const x = currentUnit(); if (!x) { toast('Click inside the question that needs sub-parts.', 'err'); return; } questionOp('partAdd', x.u.id); };
ACT.qpInsAlt = () => { const x = currentUnit(); if (!x) { toast('Click inside the question that needs an OR choice.', 'err'); return; } questionOp('alt', x.q.id); };

function sectionForm(sec) {
  return field('Part title', '<input type="text" name="title" value="' + esc(sec.title || '') + '" placeholder="PART – A" maxlength="120">') +
    '<div class="form-grid">' + field('Choice', '<select name="choice">' + Object.keys(QP_CHOICE).map((k) => '<option value="' + k + '"' + (sec.choice === k ? ' selected' : '') + '>' + QP_CHOICE[k] + '</option>').join('') + '</select>') +
    field('Students answer (for “Answer any”)', '<input type="number" name="attempt" min="0" max="100" value="' + (sec.attempt || '') + '" placeholder="e.g. 5">') +
    field('Marks for each question', '<input type="number" name="marks" min="0" max="500" step="0.5" value="' + (sec.marks || '') + '">', 'Leave 0 if questions carry different marks') +
    field('Number of questions', '<input type="number" name="count" min="1" max="100" value="' + ((sec.questions || []).length || sec.count || 1) + '">', 'Adds empty questions, or removes empty ones from the end') + '</div>' +
    field('Instruction line', '<input type="text" name="note" value="' + esc(sec.note || '') + '" placeholder="' + esc(defaultNote(sec)) + '" maxlength="300">', 'Leave blank for the standard wording; type “-” for none');
}
ACT.qpSecEdit = (d) => { const sec = EX.paper.sections.find((s) => s.id === d.id); if (!sec) return; EX.secEdit = sec.id; formModal('Part settings', esc(sec.title || ''), 'qpSec', sectionForm(sec), 'Apply', 'wide'); };
ACT.qpSecAdd = () => { EX.secEdit = ''; const n = EX.paper.sections.length; formModal('Add a part', '', 'qpSec', sectionForm({ title: 'PART – ' + String.fromCharCode(65 + n), choice: 'all', marks: 0, count: 1, questions: [] }), 'Add part', 'wide'); };
FORMS.qpSec = (f) => {
  syncFromDom();
  let sec = EX.paper.sections.find((s) => s.id === EX.secEdit);
  const isNew = !sec;
  if (isNew) { sec = { id: uid('S'), title: '', note: '', choice: 'all', attempt: 0, marks: 0, questions: [] }; EX.paper.sections.push(sec); }
  const oldMarks = sec.marks;
  Object.assign(sec, { title: f.title.value.trim(), choice: f.choice.value, attempt: Number(f.attempt.value) || 0, marks: Number(f.marks.value) || 0, note: f.note.value.trim() });
  const want = Math.max(1, Math.min(100, Number(f.count.value) || 1));
  while (sec.questions.length < want) sec.questions.push(blankQ(sec));
  let removed = 0;
  while (sec.questions.length > want) { const last = sec.questions[sec.questions.length - 1]; if (!isEmptyBody(last.body) || (last.parts || []).length || (last.alt && !isEmptyBody(last.alt.body))) break; sec.questions.pop(); removed++; }
  if (sec.questions.length > want) toast('Kept ' + (sec.questions.length - want) + ' question(s) that already have text — delete them yourself if needed.', 'err');
  sec.questions.forEach((q) => {
    if (sec.choice === 'either' && !q.alt) q.alt = blankUnit(sec.marks);
    if (sec.marks && sec.marks !== oldMarks) { [q, q.alt].filter(Boolean).forEach((u) => { if (!(u.parts || []).length && (!u.marks || u.marks === oldMarks)) u.marks = sec.marks; }); }
  });
  closeModal(); renderSheet(true); markDirty();
  void removed; void isNew;
};
ACT.qpSecMove = (d) => {
  syncFromDom();
  const a = EX.paper.sections; const i = a.findIndex((s) => s.id === d.id); const j = i + Number(d.d);
  if (i < 0 || j < 0 || j >= a.length) return;
  a.splice(j, 0, a.splice(i, 1)[0]); renderSheet(true); markDirty();
};
ACT.qpSecDel = async (d) => {
  const sec = EX.paper.sections.find((s) => s.id === d.id); if (!sec) return;
  if (!(await confirmBox('Delete ' + (sec.title || 'this part') + '?', 'Its ' + plural(sec.questions.length, 'question') + ' are removed too.', 'Delete part', true))) return;
  syncFromDom();
  EX.paper.sections = EX.paper.sections.filter((s) => s.id !== d.id);
  renderSheet(true); markDirty();
};

/* ---------- Paper tab: details, layout, template ---------- */
ACT.qpMeta = () => {
  syncFromDom();
  const P = EX.paper, M = P.meta;
  const inp = (k, label, ph, hint) => field(label, '<input type="text" name="' + k + '" value="' + esc(M[k] || '') + '" placeholder="' + esc(ph || '') + '">', hint);
  formModal('Examination details', 'Printed in the header of the paper.', 'qpMetaF',
    '<div class="form-grid">' + field('Paper title (your list only)', '<input type="text" name="title" value="' + esc(P.title) + '" maxlength="160">') +
    field('Examination', '<select name="examType"><option value="internal"' + (P.examType === 'internal' ? ' selected' : '') + '>Internal</option><option value="external"' + (P.examType === 'external' ? ' selected' : '') + '>External</option></select>') +
    field('Linked course', '<select name="courseId" data-change="qpCoursePick">' + courseOptions(P.courseId) + '</select>') + inp('qpCode', 'Question paper code', 'optional') +
    inp('institution', 'Institution') + inp('subtitle', 'Second line', '(Autonomous) · Affiliated to …') + inp('examTitle', 'Examination title', 'End Semester Examinations — Nov 2026') + inp('programme', 'Programme', 'B.Com (CA)') +
    inp('semester', 'Semester', 'III') + inp('courseCode', 'Course code') + inp('courseName', 'Course name') + inp('date', 'Date', 'dd-mm-yyyy') + inp('session', 'Session', 'FN / AN') +
    inp('duration', 'Duration', '3 Hours') + inp('maxMarks', 'Maximum marks', String(qpTotal(P)), 'The parts currently total ' + numS(qpTotal(P))) + '</div>', 'Apply', 'xwide');
};
ACT.qpCoursePick = (d, sel) => {
  const c = ((EX.home && EX.home.courses) || []).find((x) => x.id === sel.value);
  if (!c) return;
  const f = sel.form; if (f.courseCode && !f.courseCode.value) f.courseCode.value = c.shortname; if (f.courseName && !f.courseName.value) f.courseName.value = c.fullname;
};
FORMS.qpMetaF = (f) => {
  const P = EX.paper;
  ['qpCode', 'institution', 'subtitle', 'examTitle', 'programme', 'semester', 'courseCode', 'courseName', 'date', 'session', 'duration', 'maxMarks'].forEach((k) => { P.meta[k] = f[k].value.trim(); });
  P.title = f.title.value.trim() || P.title; P.examType = f.examType.value; P.courseId = f.courseId.value;
  const t = $('#qpTitle'); if (t) t.value = P.title;
  closeModal(); renderSheet(true); markDirty();
};
ACT.qpLayout = () => {
  syncFromDom();
  const L = EX.paper.layout;
  formModal('Fonts & layout', 'These follow the template; change them only if this paper needs to differ.', 'qpLayoutF',
    '<div class="form-grid-3">' + field('Font', '<select name="font">' + Object.keys(QP_FONTS).map((k) => '<option value="' + k + '"' + (L.font === k ? ' selected' : '') + '>' + QP_FONTS[k] + '</option>').join('') + '</select>') +
    field('Size (pt)', '<select name="fontSize">' + [10, 11, 12].map((n) => '<option' + (Number(L.fontSize) === n ? ' selected' : '') + '>' + n + '</option>').join('') + '</select>') +
    field('Paper', '<select name="paper">' + [['a4', 'A4'], ['letter', 'Letter'], ['legal', 'Legal']].map(([v, l]) => '<option value="' + v + '"' + (L.paper === v ? ' selected' : '') + '>' + l + '</option>').join('') + '</select>') +
    field('Margins (cm)', '<input type="number" name="margin" min="1.2" max="3" step="0.1" value="' + (L.margin || 2) + '">') +
    field('Register-number boxes', '<input type="number" name="regBoxes" min="0" max="16" value="' + (L.regBoxes || 0) + '">') +
    field('Question numbers', '<select name="numbering"><option value="continuous"' + (L.numbering !== 'section' ? ' selected' : '') + '>Continuous</option><option value="section"' + (L.numbering === 'section' ? ' selected' : '') + '>Restart in each part</option></select>') + '</div>' +
    '<div class="row-wrap" style="gap:var(--sp-5);margin-bottom:var(--sp-4)">' + check('showCO', 'CO column', L.showCO) + field('Course outcomes', '<input type="number" name="coCount" min="1" max="12" value="' + (L.coCount || 6) + '" style="width:90px">') +
    check('showBL', 'Cognitive-level column', L.showBL) + '<select name="blScheme" style="width:auto">' + [['K', 'K1–K6'], ['L', 'L1–L6'], ['BT', 'BT1–BT6'], ['none', 'None']].map(([v, l]) => '<option value="' + v + '"' + (L.blScheme === v ? ' selected' : '') + '>' + l + '</option>').join('') + '</select></div>' +
    '<div class="form-grid">' + field('Footer (centre)', '<input type="text" name="footer" value="' + esc(L.footer || '') + '">') + field('End of paper', '<input type="text" name="endText" value="' + esc(L.endText != null ? L.endText : '* * * * *') + '">') + '</div>', 'Apply', 'wide');
};
FORMS.qpLayoutF = (f) => {
  const L = EX.paper.layout;
  Object.assign(L, { font: f.font.value, fontSize: Number(f.fontSize.value), paper: f.paper.value, margin: Number(f.margin.value) || 2, regBoxes: Number(f.regBoxes.value) || 0, numbering: f.numbering.value,
    showCO: f.showCO.checked, coCount: Number(f.coCount.value) || 6, showBL: f.showBL.checked, blScheme: f.blScheme.value, footer: f.footer.value, endText: f.endText.value });
  closeModal(); renderSheet(true); markDirty();
};
ACT.qpApplyTpl = () => busy(null, async () => {
  await ensureHome();
  formModal('Apply a template', 'Replaces the fonts, columns, header and instructions with the template’s. Your questions are kept.', 'qpApplyTplF',
    field('Template', '<select name="templateId">' + templateOptions(EX.paper.templateId) + '</select>') +
    check('header', 'Also replace the header (institution, exam title, duration, maximum marks)', true) + check('instructions', 'Also replace the instructions', false), 'Apply template');
});
FORMS.qpApplyTplF = (f, btn) => busy(btn, async () => {
  const r = await call('examTemplate', { id: f.templateId.value });
  syncFromDom();
  const t = r.template, P = EX.paper;
  P.layout = Object.assign({}, t.layout); P.templateId = t.id;
  if (f.header.checked) ['institution', 'subtitle', 'examTitle', 'programme', 'duration', 'maxMarks'].forEach((k) => { if (t.meta[k]) P.meta[k] = t.meta[k]; });
  if (f.instructions.checked) P.instructions = JSON.parse(JSON.stringify(t.instructions));
  closeModal(); renderSheet(true); markDirty(); toast('Template applied.');
});

/* ---------- Review tab ---------- */
ACT.qpChecks = () => busy(null, async () => {
  if (EX.canEdit && (EX.dirty || EX.saving)) await saveNow();
  const list = EX.checks;
  const ico = { error: ['alert', 'danger'], warn: ['alert', 'warning'], info: ['info', 'info'] };
  openModal(modalHead('Check paper', list.length ? plural(list.filter((c) => c.level === 'error').length, 'error') + ' · ' + plural(list.filter((c) => c.level === 'warn').length, 'warning') : 'Everything looks right') +
    '<div class="modal-body">' + (list.length ? '<ul class="qp-checks">' + list.map((c) => '<li class="' + c.level + '">' + '<span class="badge ' + ico[c.level][1] + '">' + icon(ico[c.level][0]) + (c.level === 'warn' ? 'warning' : c.level) + '</span><span>' + esc(c.text) + '</span>' +
      (c.ref ? '<button class="btn btn-sm btn-ghost" data-act="qpCheckGo" data-id="' + esc(c.ref) + '">Show</button>' : '') + '</li>').join('') + '</ul>'
      : emptyState('checkCircle', 'No problems found', 'Every question has text, marks' + (EX.paper.layout.showCO ? ', a CO' : '') + (EX.paper.layout.showBL ? ' and a level' : '') + ', and the parts add up to the maximum marks.', '', false)) +
    '<p class="xs muted">Errors must be fixed before the paper can be submitted for review.</p></div>', 'wide');
});
ACT.qpCheckGo = (d) => {
  closeModal();
  const row = $('#qpWrap [data-u="' + d.id + '"]') || $('#qpWrap [data-grp="' + d.id + '"]') || $('#qpWrap [data-sec="' + d.id + '"]');
  if (!row) return;
  row.scrollIntoView({ behavior: 'smooth', block: 'center' });
  row.classList.add('flash'); setTimeout(() => row.classList.remove('flash'), 1400);
};
function blueprint(P) {
  const grid = {}, byCo = {}, byBl = {}; let total = 0;
  const add = (u) => { const m = Number(u.marks) || 0; if (!m) return; const co = Number(u.co) || 0, bl = Number(u.bl) || 0; grid[co] = grid[co] || {}; grid[co][bl] = (grid[co][bl] || 0) + m; byCo[co] = (byCo[co] || 0) + m; byBl[bl] = (byBl[bl] || 0) + m; total += m; };
  const unit = (u) => { if (u.parts && u.parts.length) u.parts.forEach(add); else add(u); };
  P.sections.forEach((s) => s.questions.forEach((q) => { unit(q); if (q.alt) unit(q.alt); }));
  return { grid, byCo, byBl, total };
}
ACT.qpBlueprint = () => {
  syncFromDom();
  const P = EX.paper, bp = blueprint(P);
  const L = P.layout, names = QP_BL[L.blScheme] || QP_BL.K;
  const cos = Object.keys(bp.byCo).map(Number).sort((a, b) => (a || 99) - (b || 99));
  const pctS = (v) => (bp.total ? Math.round(v / bp.total * 100) + '%' : '—');
  const bar = (label, v, tone) => '<div class="qp-bar"><span>' + esc(label) + '</span><div><i style="width:' + (bp.total ? v / bp.total * 100 : 0) + '%;background:var(--' + tone + ')"></i></div><b>' + numS(v) + '</b><em>' + pctS(v) + '</em></div>';
  openModal(modalHead('Blueprint', 'Marks by course outcome and cognitive level — every question offered, including OR choices (' + numS(bp.total) + ' marks).') + '<div class="modal-body">' +
    '<div class="grid-2"><div><h3 class="qp-form-h">By cognitive level</h3>' + names.map((n, i) => bar(n, bp.byBl[i + 1] || 0, i < 2 ? 'info' : i < 4 ? 'accent' : 'success')).join('') + (bp.byBl[0] ? bar('Not set', bp.byBl[0], 'faint') : '') +
    '<p class="xs muted">Lower order (levels 1–2): <b>' + pctS((bp.byBl[1] || 0) + (bp.byBl[2] || 0)) + '</b> · Higher order (levels 4–6): <b>' + pctS((bp.byBl[4] || 0) + (bp.byBl[5] || 0) + (bp.byBl[6] || 0)) + '</b></p></div>' +
    '<div><h3 class="qp-form-h">By course outcome</h3>' + cos.map((c) => bar(c ? 'CO' + c : 'Not set', bp.byCo[c], c ? 'accent' : 'faint')).join('') + '</div></div>' +
    '<h3 class="qp-form-h">CO × level (marks)</h3><div class="table-wrap"><table class="table qp-bp"><thead><tr><th></th>' + names.map((n) => '<th class="num">' + esc(n.split(' ')[0]) + '</th>').join('') + '<th class="num">Total</th></tr></thead><tbody>' +
    cos.map((c) => '<tr><th>' + (c ? 'CO' + c : 'Not set') + '</th>' + [1, 2, 3, 4, 5, 6].map((l) => '<td class="num">' + (((bp.grid[c] || {})[l]) ? numS(bp.grid[c][l]) : '<span class="faint">·</span>') + '</td>').join('') + '<td class="num"><b>' + numS(bp.byCo[c]) + '</b></td></tr>').join('') +
    '</tbody></table></div><p class="xs muted">Tick “Blueprint page” in the preview to add this table to the exported LaTeX for the scrutiny committee.</p></div>', 'xwide');
};
ACT.qpCount = () => {
  syncFromDom();
  const P = EX.paper;
  const all = [P.instructions];
  let eqs = 0, imgs = 0, tables = 0, parts = 0;
  const walk = (blocks) => (blocks || []).forEach((b) => { if (b.t === 'eq') eqs++; if (b.t === 'img') imgs++; if (b.t === 'table') { tables++; b.rows.forEach((r) => r.forEach((c) => walk(c.c))); } if (b.items) b.items.forEach(walk); if (b.c) eqs += b.c.filter((r) => r.e != null).length; });
  P.sections.forEach((s) => s.questions.forEach((q) => [q, q.alt].filter(Boolean).forEach((u) => { all.push(u.body); (u.parts || []).forEach((p) => { all.push(p.body); parts++; }); })));
  all.forEach(walk);
  const text = all.map(plainOf).join(' ');
  const words = (text.match(/[\p{L}\p{N}]+/gu) || []).length;
  const rows = [['Words', words], ['Characters (no spaces)', text.replace(/\s/g, '').length], ['Parts', P.sections.length], ['Questions', P.sections.reduce((n, s) => n + s.questions.length, 0)], ['Sub-parts', parts], ['Equations', eqs], ['Pictures', imgs], ['Tables', tables], ['Marks', numS(qpTotal(P))]];
  openModal(modalHead('Word count') + '<div class="modal-body"><table class="kv">' + rows.map(([k, v]) => '<tr><th>' + k + '</th><td class="tnum">' + (typeof v === 'number' ? v.toLocaleString() : v) + '</td></tr>').join('') + '</table><div class="form-actions"><button class="btn btn-primary" data-act="close">Close</button></div></div>', 'narrow');
};
ACT.qpFind = () => {
  const sel = String(getSelection() || '').trim();
  openModal(modalHead('Find & replace', 'Searches question text and instructions.') + '<div class="modal-body">' +
    field('Find', '<input type="text" id="qpFindQ" value="' + esc(sel.length < 80 ? sel : '') + '" data-input="qpFindCount" data-delay="120">') + field('Replace with', '<input type="text" id="qpFindR">') +
    check('qpFindCase', 'Match case', false) + '<div class="small muted" id="qpFindN"></div>' +
    '<div class="form-actions"><button class="btn" data-act="qpFindNext">Find next</button><button class="btn btn-primary" data-act="qpReplaceAll">Replace all</button></div></div>', 'narrow');
  INPUTS.qpFindCount();
};
function findRe() {
  const q = ($('#qpFindQ') || {}).value || '';
  if (!q) return null;
  const cs = $('input[name=qpFindCase]') && $('input[name=qpFindCase]').checked;
  return new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), cs ? 'g' : 'gi');
}
function textNodes() {
  const out = [];
  $$('#qpWrap .rt').forEach((rt) => { const w = document.createTreeWalker(rt, NodeFilter.SHOW_TEXT, { acceptNode: (n) => (n.parentElement.closest('.rt-eq,.rt-eqb,.katex') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT) }); let n; while ((n = w.nextNode())) out.push(n); });
  return out;
}
INPUTS.qpFindCount = () => {
  EX.findIdx = null;
  const re = findRe(); const el = $('#qpFindN'); if (!el) return;
  if (!re) { el.textContent = ''; return; }
  const n = textNodes().reduce((k, t) => k + (t.nodeValue.match(re) || []).length, 0);
  el.textContent = n ? plural(n, 'match', 'matches') : 'No matches';
};
ACT.qpFindNext = () => {
  const re = findRe(); if (!re) return;
  const hits = [];
  textNodes().forEach((t) => { let m; re.lastIndex = 0; while ((m = re.exec(t.nodeValue))) { hits.push([t, m.index, m[0].length]); if (!m[0].length) break; } });
  if (!hits.length) { toast('No matches.'); return; }
  EX.findIdx = ((EX.findIdx == null ? -1 : EX.findIdx) + 1) % hits.length;
  const [t, i, len] = hits[EX.findIdx];
  const r = document.createRange(); r.setStart(t, i); r.setEnd(t, i + len);
  const s = getSelection(); s.removeAllRanges(); s.addRange(r);
  t.parentElement.scrollIntoView({ block: 'center', behavior: 'smooth' });
  $('#qpFindN').textContent = (EX.findIdx + 1) + ' of ' + hits.length;
};
ACT.qpReplaceAll = () => {
  const re = findRe(); if (!re) return;
  const rep = $('#qpFindR').value;
  let n = 0;
  textNodes().forEach((t) => { const v = t.nodeValue.replace(re, () => { n++; return rep; }); if (v !== t.nodeValue) t.nodeValue = v; });
  closeModal();
  if (n) { markDirty(); toast('Replaced ' + plural(n, 'match', 'matches') + '.'); } else toast('No matches.');
};
ACT.qpRevs = () => busy(null, async () => {
  if (EX.canEdit && EX.dirty) await saveNow();
  const r = await call('examRevisions', { id: EX.paper.id });
  openModal(modalHead('Versions', 'A version is kept every 10 minutes of editing, and at each submission, approval and restore.') + '<div class="modal-body">' +
    (r.revisions.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Saved</th><th>By</th><th>Why</th><th class="num">Questions</th><th class="num">Marks</th><th></th></tr></thead><tbody>' +
      r.revisions.map((v) => '<tr><td>' + fmt(v.at) + '</td><td>' + esc(v.by || '—') + '</td><td>' + esc(v.why) + '</td><td class="num">' + v.questions + '</td><td class="num">' + numS(v.total) + '</td><td class="actions">' +
        (EX.canEdit ? '<button class="btn btn-sm" data-act="qpRestore" data-i="' + v.index + '" data-at="' + esc(fmt(v.at)) + '">Restore</button>' : '') + '</td></tr>').join('') + '</tbody></table></div>'
      : emptyState('history', 'No earlier versions yet', 'They appear as you keep editing.', '', false)) + '</div>', 'wide');
});
ACT.qpRestore = async (d) => {
  if (!(await confirmBox('Restore the version from ' + esc(d.at) + '?', 'The current paper is kept as a version too, so you can undo this.', 'Restore'))) return;
  await busy(null, async () => { const r = await call('examRestore', { id: EX.paper.id, index: Number(d.i) }); EX.dirty = false; toast('Version restored.'); void r; refresh(); });
};
ACT.qpActivity = () => {
  const log = EX.info.log || [];
  const verb = { created: 'created the paper', shared: 'changed co-setters', submitted: 'submitted it for review', withdrew: 'withdrew it from review', approved: 'approved it', returned: 'returned it', reopened: 'reopened it', restored: 'restored', exported: 'exported' };
  openModal(modalHead('Activity') + '<div class="modal-body">' + (log.length ? '<ul class="qp-log">' + log.map((l) => '<li><span>' + avatar(l.name, 'sm') + '</span><div><b>' + esc(l.name) + '</b> ' + esc(verb[l.what] || l.what) + (l.note ? ' <span class="muted">— ' + esc(l.note) + '</span>' : '') + '<div class="xs muted">' + fmt(l.at) + '</div></div></li>').join('') + '</ul>' : '<p class="muted">Nothing yet.</p>') + '</div>', 'wide');
};
ACT.qpShare = () => busy(null, async () => {
  if (!EX.info.isOwner && !EX.info.isAdmin) { toast('Only the paper’s owner can choose co-setters.', 'err'); return; }
  const r = await call('examStaff');
  const cur = new Set((EX.info.collaborators || []).map((c) => c.id));
  formModal('Co-setters', 'Co-setters can open and edit this paper. Nobody else sees it except administrators.', 'qpShareF',
    (r.people.length ? '<div class="qp-people">' + r.people.map((p) => '<label class="check"><input type="checkbox" name="u" value="' + esc(p.id) + '"' + (cur.has(p.id) ? ' checked' : '') + '><span>' + esc(p.name) + ' <span class="hint">@' + esc(p.username) + ' · ' + esc(p.role) + '</span></span></label>').join('') + '</div>' : '<p class="muted">There are no other faculty accounts yet.</p>'), 'Save', 'wide');
});
FORMS.qpShareF = (f, btn) => busy(btn, async () => {
  const uids = $$('input[name=u]:checked', f).map((i) => i.value);
  await call('examShare', { id: EX.paper.id, uids });
  closeModal(); toast('Co-setters updated.'); refresh();
});

/* ---------- workflow ---------- */
ACT.qpSubmit = () => busy(null, async () => {
  await saveNow();
  const errors = EX.checks.filter((c) => c.level === 'error');
  if (errors.length) { toast('Fix ' + plural(errors.length, 'error') + ' first — opening Check paper.', 'err'); ACT.qpChecks(); return; }
  formModal('Submit for review', 'The paper is locked while an administrator reviews it. You are notified of the decision.', 'qpSubmitF',
    field('Note to the reviewer (optional)', '<textarea name="note" rows="3" maxlength="500"></textarea>') +
    (EX.checks.length ? notice(plural(EX.checks.length, 'warning') + ' remain — see Review → Check paper.', 'warn') : notice('All checks passed.', 'ok')), 'Submit');
});
FORMS.qpSubmitF = (f, btn) => busy(btn, async () => { await call('examSubmit', { id: EX.paper.id, note: f.note.value }); closeModal(); toast('Submitted for review.'); refresh(); });
ACT.qpWithdraw = async () => {
  if (!(await confirmBox('Withdraw from review?', 'The paper becomes an editable draft again.', 'Withdraw'))) return;
  await busy(null, async () => { await call('examWithdraw', { id: EX.paper.id }); refresh(); });
};
ACT.qpDecide = (d) => {
  const title = { approve: 'Approve this paper', return: 'Return with comments', reopen: 'Reopen for changes' }[d.d];
  EX.decision = d.d;
  formModal(title, d.d === 'approve' ? 'The paper is locked and its exports no longer carry a watermark.' : d.d === 'return' ? 'The setter can edit it again and sees your comments.' : 'The paper becomes a draft that its setters can change.', 'qpDecideF',
    field(d.d === 'return' ? 'What needs to change?' : 'Note (optional)', '<textarea name="note" rows="4" maxlength="1000"' + (d.d === 'return' ? ' required' : '') + '></textarea>'), title.split(' ')[0], '', d.d === 'reopen');
};
FORMS.qpDecideF = (f, btn) => busy(btn, async () => { await call('examReview', { id: EX.paper.id, decision: EX.decision, note: f.note.value }); closeModal(); toast('Done.'); refresh(); });
ACT.qpDup = () => busy(null, async () => { if (EX.dirty) await saveNow(); const r = await call('examDuplicate', { id: EX.paper.id }); toast('Copy created.'); go('/exams/p/' + r.id); });
ACT.qpDel = async () => {
  if (!(await confirmBox('Delete this question paper?', '“' + esc(EX.paper.title) + '” will be removed for you and your co-setters.', 'Delete', true))) return;
  await busy(null, async () => { EX.dirty = false; await call('examDelete', { id: EX.paper.id }); EX.home = null; toast('Paper deleted.'); go('/exams'); });
};

/* ---------- export ---------- */
ACT.qpExport = (d) => busy(null, async () => {
  if (EX.canEdit && (EX.dirty || EX.saving)) await saveNow();
  const pv = $('#qpPreview');
  const r = await call('examExport', { id: EX.paper.id, format: d.format, blueprint: pv ? $('#qpvBp').checked : false, watermark: pv ? $('#qpvWm').checked : true });
  qpDownload(r);
  toast(d.format === 'zip' ? 'LaTeX project downloaded — compile main.tex with ' + r.engine + ' (twice), or upload the .zip to Overleaf.' : 'LaTeX source downloaded.');
});
ACT.qpPdf = (d, btn) => busy(btn, async () => {
  if (!EX.info.engine.pdf) {
    openModal(modalHead('PDF from LaTeX', 'No TeX engine is installed on this server.') + '<div class="modal-body"><p class="small">You can still get a perfectly typeset PDF:</p><ol class="small"><li><b>Download the LaTeX project (.zip)</b> and compile <code>main.tex</code> with MiKTeX / TeX Live, or upload the .zip to Overleaf (New Project → Upload Project).</li><li>Or use <b>Print / save as PDF</b> for a quick browser copy.</li></ol><p class="xs muted">Administrators: install TeX Live (Linux: <code>apt install texlive-latex-extra texlive-fonts-recommended</code>) or MiKTeX (Windows) and restart the site to enable one-click PDFs.</p>' +
      '<div class="form-actions"><button class="btn" data-act="qpPreview" data-print="1">' + icon('printer') + 'Print from browser</button><button class="btn btn-primary" data-act="qpExport" data-format="zip">' + icon('download') + 'LaTeX project (.zip)</button></div></div>', 'wide');
    return;
  }
  if (EX.canEdit && (EX.dirty || EX.saving)) await saveNow();
  toast('Typesetting with LaTeX…');
  const pv = $('#qpPreview');
  const r = await call('examPdf', { id: EX.paper.id, blueprint: pv ? $('#qpvBp').checked : false, watermark: pv ? $('#qpvWm').checked : true });
  qpDownload(r);
});

/* =====================================================================
   PREVIEW — paginated print layout, LaTeX source, print
   ===================================================================== */
function closePreview() {
  const p = $('#qpPreview'); if (p) p.remove();
  document.body.classList.remove('qp-noscroll', 'qp-print-mode');
  const st = $('#qpPageStyle'); if (st) st.remove();
}
ACT.qpPreview = (d) => {
  if (EX.canEdit) syncFromDom();
  closePop(); closeModal();
  const P = EX.paper;
  const wm = P.status !== 'approved';
  const ov = document.createElement('div');
  ov.className = 'qp-preview'; ov.id = 'qpPreview';
  ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-label', 'Print preview');
  ov.innerHTML = '<div class="qpv-bar"><button class="btn btn-sm" data-act="qpvClose">' + icon('arrowLeft') + 'Back to editing</button>' +
    '<div class="pills"><button class="pill active" data-act="qpvMode" data-m="pages">Print layout</button><button class="pill" data-act="qpvMode" data-m="tex">LaTeX source</button></div>' +
    '<span class="small muted" id="qpvInfo"></span><span class="spacer"></span>' +
    '<label class="check small"><input type="checkbox" id="qpvBp" data-change="qpvRefresh"><span>Blueprint page</span></label>' +
    '<label class="check small"><input type="checkbox" id="qpvWm" data-change="qpvRefresh"' + (wm ? ' checked' : '') + '><span>' + (P.status === 'review' ? '“FOR REVIEW”' : '“DRAFT”') + ' watermark</span></label>' +
    '<button class="btn btn-sm" data-act="qpvPrint">' + icon('printer') + 'Print / PDF</button>' +
    '<button class="btn btn-sm btn-primary" data-act="qpExport" data-format="zip">' + icon('download') + 'LaTeX (.zip)</button>' +
    (EX.info.engine.pdf ? '<button class="btn btn-sm" data-act="qpPdf">' + icon('page') + 'PDF</button>' : '') + '</div>' +
    '<div class="qpv-scroll" id="qpvScroll"><div class="qpv-pages" id="qpvPages"></div><div class="qpv-tex hidden" id="qpvTex"></div></div>';
  document.body.appendChild(ov);
  document.body.classList.add('qp-noscroll');
  $('#qpvWm').checked = wm && P.status !== 'approved';
  if (P.status === 'approved') $('#qpvWm').closest('label').classList.add('hidden');
  renderPages().then(() => { if (d && d.print) setTimeout(ACT.qpvPrint, 300); });
};
ACT.qpvClose = () => closePreview();
ACT.qpvRefresh = () => { if ($('#qpvTex') && !$('#qpvTex').classList.contains('hidden')) loadTexSource(); else renderPages(); };
ACT.qpvMode = (d) => {
  $$('#qpPreview .pills .pill').forEach((p) => p.classList.toggle('active', p.dataset.m === d.m));
  $('#qpvPages').classList.toggle('hidden', d.m !== 'pages');
  $('#qpvTex').classList.toggle('hidden', d.m !== 'tex');
  if (d.m === 'tex') loadTexSource();
};
async function loadTexSource() {
  const box = $('#qpvTex'); if (!box) return;
  box.innerHTML = '<div class="qpv-tex-card"><div class="sk sk-line"></div><div class="sk sk-line" style="width:70%"></div></div>';
  if (EX.canEdit && (EX.dirty || EX.saving)) await saveNow();
  try {
    const r = await call('examLatexSource', { id: EX.paper.id, blueprint: $('#qpvBp').checked, watermark: $('#qpvWm').checked });
    EX.texSrc = r.tex;
    const lines = r.tex.split('\n');
    const hl = (l) => esc(l).replace(/(%.*)$/, '<span class="tx-c">$1</span>').replace(/(\\[A-Za-z@]+\*?)/g, '<span class="tx-k">$1</span>').replace(/(&lt;&lt;[A-Z_]+&gt;&gt;)/g, '<span class="tx-p">$1</span>');
    box.innerHTML = '<div class="qpv-tex-card"><div class="qpv-tex-head"><div><b>main.tex</b> <span class="small muted">· ' + lines.length + ' lines · compile with ' + esc(r.engine) + (r.images.length ? ' · ' + plural(r.images.length, 'picture') + ' in images/' : '') + '</span></div>' +
      '<div class="row"><button class="btn btn-sm" data-act="qpvCopy">' + icon('copy') + 'Copy</button><button class="btn btn-sm" data-act="qpExport" data-format="tex">' + icon('download') + '.tex</button></div></div>' +
      '<pre class="qpv-code">' + lines.map((l, i) => '<span class="ln">' + (i + 1) + '</span>' + hl(l)).join('\n') + '</pre></div>';
  } catch (e) { box.innerHTML = errorState(e.message); }
}
ACT.qpvCopy = () => { navigator.clipboard.writeText(EX.texSrc || '').then(() => toast('LaTeX copied.'), () => toast('Copy failed — select the text instead.', 'err')); };
ACT.qpvPrint = () => {
  const P = EX.paper;
  const size = (QP_PAPER[P.layout.paper] || QP_PAPER.a4);
  let st = $('#qpPageStyle');
  if (!st) { st = document.createElement('style'); st.id = 'qpPageStyle'; document.head.appendChild(st); }
  st.textContent = '@page { size: ' + size[0] + 'mm ' + size[1] + 'mm; margin: 0 }';
  document.body.classList.add('qp-print-mode');
  const done = () => { document.body.classList.remove('qp-print-mode'); window.removeEventListener('afterprint', done); };
  window.addEventListener('afterprint', done);
  window.print();
};
async function renderPages() {
  const host = $('#qpvPages'); if (!host) return;
  const P = EX.paper, L = P.layout, M = P.meta;
  const size = QP_PAPER[L.paper] || QP_PAPER.a4;
  const m = Number(L.margin) || 2;
  const parts = sheetHtml(P, { edit: false, parts: true });
  const cls = 'qp-sheet qp-pg font-' + esc(L.font || 'times') + ' fs-' + (L.fontSize || 11);
  const style = '--qp-m:' + m + 'cm;width:' + size[0] + 'mm;height:' + size[1] + 'mm;padding:' + m + 'cm ' + m + 'cm ' + (m + 0.4) + 'cm';
  // 1. Measure everything on one tall page.
  const meas = document.createElement('div');
  meas.className = 'qpv-measure';
  meas.innerHTML = '<div class="' + cls + '" style="' + style + ';height:auto">' + parts.head + '<table class="qp-table cols-' + parts.N + '">' + parts.thead + '<tbody>' + parts.rows.join('') + '</tbody></table>' + parts.foot + '</div>';
  host.innerHTML = ''; host.appendChild(meas);
  qpHydrate(meas);
  await Promise.all($$('img', meas).map((img) => (img.complete && img.getAttribute('src') ? Promise.resolve() : new Promise((r) => { img.onload = img.onerror = r; setTimeout(r, 1500); }))));
  const page = meas.firstElementChild;
  const mmPx = page.offsetWidth / size[0];
  const usable = (size[1] - m * 10 - (m + 0.4) * 10) * mmPx - 34; // leave room for the footer
  const headH = page.querySelector('.qp-head').offsetHeight;
  const theadH = page.querySelector('thead').offsetHeight;
  const footH = page.querySelector('.qp-endtext').offsetHeight + 8;
  const trs = [...page.querySelector('table.qp-table > tbody').children]; // not the rows of tables inside questions
  // Keep a section heading with the question after it; keep a question's rows together.
  const groups = [];
  trs.forEach((tr) => {
    const g = tr.dataset.grp || (tr.classList.contains('qp-sec') ? 'sec' + groups.length : 'x' + groups.length);
    const last = groups[groups.length - 1];
    if (last && (last.key === g || last.sticky)) { last.rows.push(tr); last.h += tr.offsetHeight; last.key = g; last.sticky = tr.classList.contains('qp-sec'); if (tr.dataset.pb) last.pb = true; }
    else groups.push({ key: g, rows: [tr], h: tr.offsetHeight, sticky: tr.classList.contains('qp-sec'), pb: !!tr.dataset.pb });
  });
  const pages = [[]]; let used = headH + theadH;
  groups.forEach((g) => {
    const cur = pages[pages.length - 1];
    if (cur.length && (g.pb || used + g.h > usable)) { pages.push([]); used = theadH + 24; }
    pages[pages.length - 1].push(g); used += g.h;
  });
  const needEndPage = used + footH > usable + 10;
  const total = pages.length + (needEndPage ? 1 : 0) + ($('#qpvBp').checked ? 1 : 0);
  const wm = $('#qpvWm').checked && P.status !== 'approved' ? '<div class="qpv-wm">' + (P.status === 'review' ? 'FOR REVIEW' : 'DRAFT') + '</div>' : '';
  const footer = (i) => '<div class="qpv-foot"><span>' + esc(M.courseCode || '') + '</span><span>' + esc(L.footer || '') + '</span><span>Page ' + i + ' of ' + total + '</span></div>';
  let html = '';
  pages.forEach((pg, i) => {
    html += '<div class="' + cls + '" style="' + style + '">' + wm + (i === 0 ? parts.head : '<div class="qpv-cont">(continued)</div>') +
      '<table class="qp-table cols-' + parts.N + '">' + parts.thead + '<tbody>' + pg.map((g) => g.rows.map((r) => r.outerHTML).join('')).join('') + '</tbody></table>' +
      (i === pages.length - 1 && !needEndPage ? parts.foot : '<div class="qpv-next">Continued on next page</div>') + footer(i + 1) + '</div>';
  });
  if (needEndPage) html += '<div class="' + cls + '" style="' + style + '">' + wm + parts.foot + footer(pages.length + 1) + '</div>';
  if ($('#qpvBp').checked) html += '<div class="' + cls + '" style="' + style + '">' + wm + bpPageHtml(P) + footer(total) + '</div>';
  host.innerHTML = html;
  qpHydrate(host);
  const info = $('#qpvInfo'); if (info) info.textContent = plural(total, 'page') + ' · ' + String(L.paper || 'a4').toUpperCase() + ' · ' + (QP_FONTS[L.font] || L.font) + ' ' + L.fontSize + ' pt';
}
function bpPageHtml(P) {
  const bp = blueprint(P);
  const names = QP_BL[P.layout.blScheme] || QP_BL.K;
  const cos = Object.keys(bp.byCo).map(Number).sort((a, b) => (a || 99) - (b || 99));
  const pctS = (v) => (bp.total ? Math.round(v / bp.total * 1000) / 10 + '%' : '—');
  return '<div class="qpv-bp"><h2>Blueprint: marks by course outcome and cognitive level</h2><p>For scrutiny only. Counts every question offered, including choices.</p><table><thead><tr><th></th>' + names.map((n) => '<th>' + esc(n.split(' ')[0]) + '</th>').join('') + '<th>Total</th><th>%</th></tr></thead><tbody>' +
    cos.map((c) => '<tr><td>' + (c ? 'CO' + c : 'Not tagged') + '</td>' + [1, 2, 3, 4, 5, 6].map((l) => '<td>' + numS((bp.grid[c] || {})[l] || 0) + '</td>').join('') + '<td>' + numS(bp.byCo[c]) + '</td><td>' + pctS(bp.byCo[c]) + '</td></tr>').join('') +
    '</tbody><tfoot><tr><td><b>Total</b></td>' + [1, 2, 3, 4, 5, 6].map((l) => '<td>' + numS(bp.byBl[l] || 0) + '</td>').join('') + '<td><b>' + numS(bp.total) + '</b></td><td></td></tr><tr><td>%</td>' + [1, 2, 3, 4, 5, 6].map((l) => '<td>' + pctS(bp.byBl[l] || 0) + '</td>').join('') + '<td></td><td></td></tr></tfoot></table></div>';
}
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && $('#qpPreview') && !$('.modal-bg')) closePreview(); });
