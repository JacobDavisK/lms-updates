'use strict';
/* =====================================================================
   ACTIVITY / RESOURCE PAGE
   ===================================================================== */
async function viewModule(id) {
  const r = await call('getModule', { id });
  S.module = r;
  S.ctx = { courseId: r.course.id };
  const m = r.module;
  let body;
  if (m.type === 'quiz') {
    body = r.editor ? quizTeacherBody(r) : quizStudentBody(r, await call('quizInfo', { quizId: m.quizId }));
  } else if (m.type === 'assignment') {
    body = r.editor ? assignTeacherBody(r, await call('listSubmissions', { moduleId: m.id })) : assignStudentBody(r);
  } else if (m.type === 'forum') body = forumBody(r);
  else if (m.type === 'page') body = pageBody(r);
  else if (m.type === 'url') body = urlBody(r);
  else if (m.type === 'file') body = fileBody(r);
  else if (m.type === 'studio') body = await stModuleBody(r);
  else body = '<div class="card card-pad"><div class="prose lg">' + md(m.description) + '</div></div>';
  return {
    title: m.title,
    html: modHeader(r) + body + lessonNav(r),
    after: (root) => { if (m.type === 'assignment' && !r.editor) renderSubFiles(); if (m.type === 'studio') { stFitViewer(); stHydrate(root); } }
  };
}

function modHeader(r) {
  const m = r.module, c = r.course, meta = MOD[m.type];
  const actions = [];
  if (r.completion && r.completion.tracked) {
    actions.push(completionControl({ id: m.id, type: m.type, tracked: true, manual: r.completion.manual, done: r.completion.done }));
  }
  if (r.editor) {
    actions.push('<div class="menu-wrap"><button class="btn" data-act="menu">' + icon('settings') + 'Manage ' + icon('down', 'i-sm') + '</button><div class="menu">' +
      '<button class="menu-item" data-act="editMod" data-id="' + esc(m.id) + '">' + icon('edit') + 'Edit settings</button>' +
      '<button class="menu-item" data-act="toggleVis" data-id="' + esc(m.id) + '" data-visible="' + (m.visible ? '1' : '') + '">' + icon(m.visible ? 'eyeOff' : 'eye') + (m.visible ? 'Hide from students' : 'Show to students') + '</button>' +
      '<div class="menu-sep"></div><button class="menu-item danger" data-act="delMod" data-id="' + esc(m.id) + '" data-title="' + esc(m.title) + '">' + icon('trash') + 'Delete</button></div></div>');
  }
  const bits = [];
  if (r.nav && r.nav.total > 1) bits.push('<span class="lesson-pos">Step ' + r.nav.index + ' of ' + r.nav.total + progressBar(Math.round(r.nav.index / r.nav.total * 100)) + '</span>');
  if (r.editor && !m.visible) bits.push(badge('Hidden from students', 'warning', 'eyeOff'));
  bits.push('<span>Updated ' + esc(rel(m.updatedAt)) + '</span>');
  return '<div class="mod-head tone-' + meta.tone + '">' + modTile(m.type, 'lg') + '<div class="mh-text">' +
    crumbs([['My courses', '/courses'], [c.shortname, '/course/' + c.id]].concat(r.section ? [[r.section.title, '/course/' + c.id]] : []).concat([[m.title]])) +
    '<span class="act-type">' + meta.label + '</span><h1>' + esc(m.title) + '</h1><div class="mod-meta">' + bits.join('') + '</div></div>' +
    (actions.length ? '<div class="page-actions">' + actions.join('') + '</div>' : '') + '</div>';
}
/** Previous / next activity, so a course can be worked through without going back to the index. */
function lessonNav(r) {
  const n = r.nav;
  if (!n || (!n.prev && !n.next)) return '';
  const link = (x, cls, label) => '<a class="' + cls + '" href="#/mod/' + esc(x.id) + '" rel="' + (cls === 'next' ? 'next' : 'prev') + '"><small>' +
    (cls === 'next' ? label + ' ' + icon('right', 'i-sm') : icon('left', 'i-sm') + ' ' + label) + '</small><b>' + esc(x.title) + '</b></a>';
  return '<nav class="lesson-nav" aria-label="Lesson navigation">' + (n.prev ? link(n.prev, 'prev', 'Previous') : '') + (n.next ? link(n.next, 'next', 'Next') : '') + '</nav>';
}
function descCard(m, title) {
  return m.description ? '<div class="card">' + (title ? '<div class="card-head"><h3>' + esc(title) + '</h3></div>' : '') + '<div class="card-body"><div class="prose">' + md(m.description) + '</div></div></div>' : '';
}

/* ---------- resources ---------- */
function pageBody(r) {
  const m = r.module;
  // Reading view: no box, a comfortable measure, the text is the interface.
  return '<article class="reading">' +
    (m.description ? '<p class="muted" style="font-size:var(--fs-body-lg);margin-bottom:var(--sp-6)">' + esc(m.description.replace(/[#*_`>]/g, '')) + '</p>' : '') +
    '<div class="prose lg">' + md(m.content) + '</div></article>';
}
/** YouTube / Vimeo links play in place (privacy-enhanced embeds); anything else opens externally. */
function videoEmbed(url) {
  let u;
  try { u = new URL(url); } catch (e) { return ''; }
  const host = u.hostname.replace(/^www\.|^m\./, '');
  let id = '';
  if (host === 'youtu.be') id = u.pathname.slice(1);
  else if (host === 'youtube.com' || host === 'youtube-nocookie.com') id = u.searchParams.get('v') || (/^\/(?:shorts|embed|live)\/([^/?]+)/.exec(u.pathname) || [])[1] || '';
  if (/^[A-Za-z0-9_-]{6,20}$/.test(id)) return 'https://www.youtube-nocookie.com/embed/' + id + '?rel=0&modestbranding=1';
  if (host === 'vimeo.com') { const v = /^\/(\d{5,12})/.exec(u.pathname); if (v) return 'https://player.vimeo.com/video/' + v[1] + '?dnt=1'; }
  return '';
}
function urlBody(r) {
  const m = r.module;
  const embed = videoEmbed(m.url);
  if (embed) {
    return '<div class="media-stage"><iframe src="' + esc(embed) + '" title="' + esc(m.title) + '" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" ' +
      'allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen" allowfullscreen></iframe></div>' +
      '<div class="reading" style="margin-top:var(--sp-6)">' + (m.description ? '<div class="prose">' + md(m.description) + '</div>' : '') +
      '<p class="small" style="margin-top:var(--sp-4)"><a href="' + esc(m.url) + '" target="_blank" rel="noopener noreferrer">Open on ' + esc(new URL(m.url).hostname.replace(/^www\./, '')) + ' ' + icon('external', 'i-sm') + '</a></p></div>';
  }
  return '<div class="stack" style="max-width:var(--read-max)">' + descCard(m) +
    '<div class="card link-card"><span class="i-tile lg tone-cyan">' + icon('external') + '</span><div style="flex:1;min-width:0"><b>External resource</b><div class="url">' + esc(m.url) + '</div></div>' +
    '<a class="btn btn-primary" href="' + esc(m.url) + '" target="_blank" rel="noopener noreferrer">Open link ' + icon('external', 'i-sm') + '</a></div></div>';
}
function fileBody(r) {
  const m = r.module, f = r.file;
  return '<div class="stack" style="max-width:900px">' + descCard(m) +
    (f ? '<div class="card big-file"><span class="i-tile lg tone-slate">' + icon(fileIcon(f)) + '</span><div style="flex:1;min-width:0"><b style="word-break:break-word">' + esc(f.name) + '</b><div class="small muted">' + fileSize(f.size) + (f.mime ? ' · ' + esc(f.mime) : '') + '</div></div>' +
      (PREVIEWABLE.indexOf(f.mime) >= 0 ? '<button class="btn" data-act="previewFile" data-id="' + esc(f.id) + '" data-name="' + esc(f.name) + '" data-mime="' + esc(f.mime) + '">' + icon('eye') + 'Preview</button>' : '') +
      '<button class="btn btn-primary" data-act="downloadFile" data-id="' + esc(f.id) + '" data-name="' + esc(f.name) + '">' + icon('download') + 'Download</button></div>'
      : notice('The file for this resource is missing.', 'warn')) + '</div>';
}

/* =====================================================================
   ASSIGNMENT — STUDENT
   ===================================================================== */
function assignStudentBody(r) {
  const m = r.module, sub = r.submission;
  const now = Date.now();
  const submitted = !!(sub && sub.status === 'submitted');
  const graded = !!(sub && sub.grade !== null);
  S.subFiles = sub ? sub.files.slice() : [];
  let remaining;
  if (submitted) remaining = sub.late ? '<td class="warn">Submitted ' + durationText(sub.submittedAt - m.dueAt) + ' late</td>' : '<td class="ok">Submitted ' + (m.dueAt ? durationText(m.dueAt - sub.submittedAt) + ' early' : 'on time') + '</td>';
  else if (!m.dueAt) remaining = '<td>No due date</td>';
  else if (now < m.dueAt) remaining = '<td>' + durationText(m.dueAt - now) + ' remaining</td>';
  else remaining = '<td class="bad">Overdue by ' + durationText(now - m.dueAt) + '</td>';
  const status = '<div class="card"><div class="card-head"><span class="i-tile sm tone-pink">' + icon('assignment') + '</span><h2>Submission status</h2></div><table class="kv">' +
    '<tr><th>Submission status</th>' + (submitted ? '<td class="ok">Submitted for grading</td>' : '<td>No submission yet</td>') + '</tr>' +
    '<tr><th>Grading status</th>' + (graded ? '<td class="ok">Graded</td>' : '<td>Not graded</td>') + '</tr>' +
    '<tr><th>Due date</th><td>' + (m.dueAt ? esc(fmt(m.dueAt)) : 'No due date') + '</td></tr>' +
    (m.cutoffAt ? '<tr><th>Cut-off date</th><td>' + esc(fmt(m.cutoffAt)) + '</td></tr>' : '') +
    '<tr><th>Time remaining</th>' + remaining + '</tr>' +
    '<tr><th>Last modified</th><td>' + (sub && sub.submittedAt ? esc(fmt(sub.submittedAt)) : '—') + '</td></tr>' +
    (sub && sub.text ? '<tr><th>Online text</th><td><div class="prose">' + md(sub.text) + '</div></td></tr>' : '') +
    (sub && sub.files.length ? '<tr><th>Files</th><td><div class="file-list">' + sub.files.map((f) => fileChip(f)).join('') + '</div></td></tr>' : '') +
    '</table></div>';
  const feedback = graded ? '<div class="card"><div class="card-head"><span class="i-tile sm tone-green">' + icon('award') + '</span><h2>Feedback</h2></div>' +
    '<div class="card-body"><div class="score-hero" style="padding:0 0 1rem"><div class="big">' + sub.grade + '<span> / ' + m.maxGrade + '</span></div>' +
    '<span class="grade-pill ' + gradeClass(pct(sub.grade, m.maxGrade)) + '" style="font-size:1rem">' + pct(sub.grade, m.maxGrade) + '%</span></div>' +
    (sub.feedback ? '<div class="prose">' + md(sub.feedback) + '</div>' : '<p class="muted small">No written feedback.</p>') +
    '<div class="xs muted" style="margin-top:.75rem">Graded' + (sub.grader ? ' by ' + esc(sub.grader) : '') + ' on ' + esc(fmt(sub.gradedAt)) + '</div></div></div>' : '';
  let form = '';
  if (r.canSubmit) {
    form = '<div class="card" id="subCard"><div class="card-head"><span class="i-tile sm tone-indigo">' + icon('upload') + '</span><h2>' + (submitted ? 'Edit your submission' : 'Add your submission') + '</h2>' +
      (submitted ? '<div class="spacer"></div><button class="btn btn-sm" data-act="toggleSubForm">' + icon('edit') + 'Edit</button>' : '') + '</div>' +
      '<div class="card-body' + (submitted ? ' hidden' : '') + '" id="subFormBody"><form data-form="submitAssign" novalidate>' +
      (m.subText ? field('Online text', '<textarea name="text" maxlength="50000" style="min-height:200px" placeholder="Type or paste your answer…">' + esc(sub ? sub.text : '') + '</textarea>' + mdHelp()) : '') +
      (m.subFile ? '<div class="field"><span class="label">File submissions <span class="hint">Up to 5 files, 10 MB each.</span></span><div id="subFiles" class="file-list" style="margin-bottom:.6rem"></div>' +
        '<label class="dropzone">' + icon('upload') + '<b>Choose files to upload</b><span class="small">or drop them here</span><input type="file" multiple data-change="subFile"></label></div>' : '') +
      '<div class="row"><span class="small muted">' + (m.dueAt && now > m.dueAt ? icon('alert', 'i-sm') + ' This will be marked as late.' : 'You can edit your submission until it is graded.') + '</span><div class="spacer"></div>' +
      '<button class="btn btn-primary" type="submit">' + icon('send') + (submitted ? 'Update submission' : 'Submit assignment') + '</button></div></form></div></div>';
  } else if (!graded) {
    form = notice('Submissions for this assignment are closed.', 'warn', 'lock');
  }
  return '<div class="split"><div class="stack">' + descCard(m, 'Instructions') + form + status + feedback + '</div>' +
    '<div class="stack"><div class="facts">' +
    '<div class="fact"><small>Due</small><b>' + (m.dueAt ? esc(fmt(m.dueAt)) : 'No due date') + '</b></div>' +
    '<div class="fact"><small>Maximum grade</small><b>' + m.maxGrade + '</b></div>' +
    '<div class="fact"><small>Submission types</small><b>' + [m.subText ? 'Online text' : '', m.subFile ? 'Files' : ''].filter(Boolean).join(', ') + '</b></div></div></div></div>';
}
function renderSubFiles() {
  const box = $('#subFiles');
  if (box) box.innerHTML = S.subFiles.map((f) => fileChip(f, { remove: 'removeSubFile' })).join('');
}
ACT.toggleSubForm = () => { const b = $('#subFormBody'); if (b) b.classList.toggle('hidden'); };
ACT.subFile = async (d, input) => {
  const files = Array.from(input.files || []);
  input.value = '';
  for (const file of files) {
    if (S.subFiles.length >= 5) { toast('You can attach at most 5 files.', 'err'); break; }
    const box = $('#subFiles');
    const tmp = document.createElement('span'); tmp.className = 'small muted'; tmp.textContent = 'Uploading ' + file.name + '…';
    if (box) box.appendChild(tmp);
    try { S.subFiles.push(await uploadFile(file)); } catch (e) { if (!isExpired(e)) toast(e.message, 'err'); }
    renderSubFiles();
  }
};
ACT.removeSubFile = (d) => { S.subFiles = S.subFiles.filter((f) => f.id !== d.id); renderSubFiles(); };
FORMS.submitAssign = (f, btn) => busy(btn, async () => {
  await call('submitAssignment', { moduleId: S.module.module.id, text: f.elements.text ? f.elements.text.value : '', fileIds: S.subFiles.map((x) => x.id) });
  toast('Your work was submitted.');
  await refresh();
});

/* =====================================================================
   ASSIGNMENT — TEACHER
   ===================================================================== */
function assignTeacherBody(r, list) {
  const m = r.module, st = r.stats;
  S.subs = list;
  const rows = list.rows.map((x) => {
    const s = x.submission;
    const submitted = s && s.status === 'submitted';
    const graded = s && s.grade !== null;
    const state = graded ? 'graded' : submitted ? 'needs' : 'none';
    return '<tr data-state="' + state + '" data-text="' + esc((x.name + ' ' + x.username + ' ' + x.batch).toLowerCase()) + '">' +
      '<td><div class="cell-user">' + avatar(x.name) + '<div><b>' + esc(x.name) + '</b><span>' + esc(x.batch || '@' + x.username) + '</span></div></div></td>' +
      '<td>' + (submitted ? badge('Submitted', 'success', 'check') + (s.late ? ' ' + badge('Late', 'warning') : '') : badge('No submission')) + '</td>' +
      '<td class="small muted">' + (submitted ? esc(fmt(s.submittedAt)) : '—') + '</td>' +
      '<td class="num">' + (graded ? '<span class="grade-pill ' + gradeClass(pct(s.grade, list.maxGrade)) + '">' + s.grade + ' / ' + list.maxGrade + '</span>' : '<span class="muted">—</span>') + '</td>' +
      '<td class="actions"><button class="btn btn-sm ' + (state === 'needs' ? 'btn-primary' : '') + '" data-act="gradeSub" data-id="' + esc(x.userId) + '">' + icon(graded ? 'edit' : 'award', 'i-sm') + (graded ? 'Edit grade' : 'Grade') + '</button></td></tr>';
  }).join('');
  return '<div class="stats">' + statCard('users', 'blue', st.participants, 'Participants') + statCard('inbox', 'green', st.submitted, 'Submitted') +
    statCard('assignment', 'amber', st.needsGrading, 'Needs grading') + statCard('clock', 'pink', m.dueAt ? esc(fmtDay(m.dueAt)) : '—', m.dueAt ? 'Due ' + fmtTime(m.dueAt) : 'No due date') + '</div>' +
    descCard(m, 'Instructions') +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-pink">' + icon('list') + '</span><h2>Submissions</h2><div class="spacer"></div>' +
    '<div class="pills" id="subFilter"><button class="pill active" data-act="filterSubs" data-f="">All</button><button class="pill" data-act="filterSubs" data-f="needs">Needs grading</button>' +
    '<button class="pill" data-act="filterSubs" data-f="none">Not submitted</button><button class="pill" data-act="filterSubs" data-f="graded">Graded</button></div></div>' +
    (list.rows.length ? '<div class="table-wrap"><table class="table" id="subTable"><thead><tr><th>Student</th><th>Status</th><th>Last modified</th><th class="num">Grade</th><th></th></tr></thead><tbody>' + rows + '</tbody></table></div>'
      : '<div class="card-body">' + emptyState('users', 'No students enrolled', 'Enrol students in this course to collect submissions.', '<a class="btn btn-primary" href="#/course/' + esc(r.course.id) + '/participants">Enrol users</a>', false) + '</div>') + '</div>';
}
ACT.filterSubs = (d, btn) => {
  $$('#subFilter .pill').forEach((b) => b.classList.toggle('active', b === btn));
  $$('#subTable tbody tr').forEach((tr) => tr.classList.toggle('hidden', !!d.f && tr.dataset.state !== d.f));
};
ACT.gradeSub = (d) => {
  const x = S.subs.rows.find((y) => y.userId === d.id);
  if (!x) return;
  const s = x.submission;
  const max = S.subs.maxGrade;
  const work = s && s.status === 'submitted'
    ? '<div class="card" style="margin-bottom:1rem"><div class="card-head"><h3>Submission</h3><div class="spacer"></div>' + (s.late ? badge('Late', 'warning') : '') + '<span class="xs muted">' + esc(fmt(s.submittedAt)) + '</span></div><div class="card-body">' +
      (s.text ? '<div class="prose" style="max-height:320px;overflow:auto">' + md(s.text) + '</div>' : '') +
      (s.files.length ? '<div class="file-list" style="margin-top:' + (s.text ? '1rem' : '0') + '">' + s.files.map((f) => fileChip(f)).join('') + '</div>' : '') +
      (!s.text && !s.files.length ? '<span class="muted small">Empty submission.</span>' : '') + '</div></div>'
    : notice('This student has not submitted anything. You can still record a grade.', 'warn');
  formModal('Grade ' + x.name, esc(S.module.module.title), 'grade',
    work + '<input type="hidden" name="userId" value="' + esc(x.userId) + '">' +
    '<div class="form-grid">' + field('Grade out of ' + max, '<input type="number" name="grade" min="0" max="' + max + '" step="any" value="' + (s && s.grade !== null ? s.grade : '') + '" autofocus>', 'Leave empty to remove the grade.') + '<div></div></div>' +
    field('Feedback', '<textarea name="feedback" maxlength="10000" style="min-height:120px" placeholder="What went well, what to improve…">' + esc(s ? s.feedback : '') + '</textarea>' + mdHelp()),
    'Save grade', 'wide');
};
FORMS.grade = (f, btn) => busy(btn, async () => {
  const g = f.elements.grade.value.trim();
  await call('gradeSubmission', { moduleId: S.module.module.id, userId: f.elements.userId.value, grade: g === '' ? '' : Number(g), feedback: f.elements.feedback.value });
  closeModal(); toast('Grade saved. The student has been notified.'); await refresh();
});

/* =====================================================================
   FORUM
   ===================================================================== */
function forumBody(r) {
  const list = r.discussions;
  return '<div class="stack" style="max-width:980px">' + descCard(r.module) +
    '<div class="card"><div class="card-head"><span class="i-tile sm tone-green">' + icon('forum') + '</span><h2>Discussions</h2><span class="badge">' + list.length + '</span><div class="spacer"></div>' +
    '<button class="btn btn-primary btn-sm" data-act="newDiscussion">' + icon('plus') + 'Add discussion topic</button></div>' +
    (list.length ? list.map((d) => '<a class="disc-row" href="#/discussion/' + esc(d.id) + '">' + avatar(d.author) +
      '<div class="dr-main"><div class="dr-title">' + (d.pinned ? icon('pin', 'i-sm') : '') + esc(d.subject) + '</div><div class="dr-meta">Started by ' + esc(d.author) + ' · ' + esc(rel(d.createdAt)) + '</div></div>' +
      '<div class="dr-count"><b>' + d.replies + '</b>' + (d.replies === 1 ? 'reply' : 'replies') + '</div>' +
      '<div class="dr-count" style="min-width:110px"><b style="font-size:.85rem">' + esc(rel(d.lastPostAt)) + '</b>last post</div></a>').join('')
      : '<div class="card-body">' + emptyState('message', 'No discussions yet', 'Start the conversation — ask a question or share an idea.', '', false) + '</div>') + '</div></div>';
}
ACT.newDiscussion = () => formModal('New discussion topic', esc(S.module.module.title), 'discussion',
  field('Subject', '<input type="text" name="subject" maxlength="200" autofocus>') +
  field('Message', '<textarea name="message" maxlength="20000" style="min-height:180px"></textarea>' + mdHelp()), 'Post to forum', 'wide');
FORMS.discussion = (f, btn) => busy(btn, async () => {
  const r = await call('postDiscussion', { moduleId: S.module.module.id, subject: f.elements.subject.value, message: f.elements.message.value });
  closeModal(); toast('Discussion posted.'); go('/discussion/' + r.id);
});

async function viewDiscussion(id) {
  const r = await call('getDiscussion', { id });
  S.discussion = r;
  S.ctx = { courseId: r.course.id };
  const d = r.discussion;
  const posts = r.posts.map((p, i) => '<div class="post' + (i ? ' reply' : '') + '" id="post-' + esc(p.id) + '">' + avatar(p.author, i ? '' : 'lg') + '<div class="post-main">' +
    '<div class="post-head"><b>' + esc(p.author) + '</b>' + (p.authorRole === 'teacher' ? badge('Teacher', 'primary') : p.authorRole === 'admin' ? badge('Admin', 'info') : '') +
    '<time title="' + esc(fmt(p.createdAt)) + '">' + esc(rel(p.createdAt)) + '</time></div>' +
    (p.replyTo && i ? '<div class="reply-to">' + icon('reply', 'i-sm') + ' In reply to ' + esc(p.replyTo) + '</div>' : '') +
    '<div class="prose">' + md(p.message) + '</div>' +
    '<div class="post-actions"><button class="btn btn-sm btn-ghost" data-act="replyTo" data-id="' + esc(p.id) + '" data-name="' + esc(p.author) + '">' + icon('reply', 'i-sm') + 'Reply</button>' +
    (p.canDelete ? '<button class="btn btn-sm btn-ghost btn-danger" data-act="delPost" data-id="' + esc(p.id) + '" data-first="' + (i ? '' : '1') + '">' + icon('trash', 'i-sm') + 'Delete</button>' : '') + '</div></div></div>').join('');
  return {
    title: d.subject,
    html: pageHead(d.subject, {
      crumbs: [['My courses', '/courses'], [r.course.shortname, '/course/' + r.course.id], [r.module.title, '/mod/' + r.module.id], ['Discussion']],
      sub: (d.pinned ? badge('Pinned', 'primary', 'pin') + ' ' : '') + plural(Math.max(0, r.posts.length - 1), 'reply', 'replies'),
      actions: (r.editor ? '<button class="btn" data-act="pinDisc" data-id="' + esc(d.id) + '">' + icon('pin') + (d.pinned ? 'Unpin' : 'Pin to top') + '</button>' : '') +
        '<a class="btn" href="#/mod/' + esc(r.module.id) + '">' + icon('arrowLeft') + 'All discussions</a>'
    }) +
      '<div class="card" style="max-width:980px">' + posts +
      '<div class="composer"><form data-form="reply" novalidate><input type="hidden" name="parentId" value="">' +
      '<div class="row" style="margin-bottom:.5rem"><b class="small">Your reply</b><span id="replyingTo" class="small muted"></span></div>' +
      '<textarea name="message" maxlength="20000" placeholder="Write a reply…"></textarea>' + mdHelp() +
      '<div class="row" style="margin-top:.75rem"><div class="spacer"></div><button class="btn btn-primary" type="submit">' + icon('send') + 'Post reply</button></div></form></div></div>'
  };
}
ACT.replyTo = (d) => {
  const f = $('form[data-form=reply]');
  f.elements.parentId.value = d.id;
  $('#replyingTo').innerHTML = '· replying to ' + esc(d.name) + ' <button class="link" data-act="cancelReplyTo">cancel</button>';
  f.elements.message.focus();
  f.scrollIntoView({ behavior: 'smooth', block: 'center' });
};
ACT.cancelReplyTo = () => { const f = $('form[data-form=reply]'); f.elements.parentId.value = ''; $('#replyingTo').innerHTML = ''; };
FORMS.reply = (f, btn) => busy(btn, async () => {
  await call('postReply', { discussionId: S.discussion.discussion.id, parentId: f.elements.parentId.value, message: f.elements.message.value });
  toast('Reply posted.'); await refresh();
  window.scrollTo(0, document.body.scrollHeight);
});
ACT.delPost = async (d) => {
  const first = !!d.first;
  if (!await confirmBox(first ? 'Delete this discussion?' : 'Delete this post?', first ? '<p>Deleting the opening post removes the whole discussion, including replies.</p>' : '<p>This cannot be undone.</p>', 'Delete', true)) return;
  busy(null, async () => {
    const r = await call('deletePost', { id: d.id });
    toast(r.discussionDeleted ? 'Discussion deleted.' : 'Post deleted.');
    if (r.discussionDeleted) go('/mod/' + r.moduleId); else refresh();
  });
};
ACT.pinDisc = (d, btn) => busy(btn, async () => { await call('pinDiscussion', { id: d.id }); await refresh(); });
