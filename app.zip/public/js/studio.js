'use strict';
/* =====================================================================
   ACADEMIC CONTENT STUDIO — "Create once. Teach everywhere."
   Dashboard, library, AI create / start from syllabus / import, viewer,
   publish, live activities, analytics, outcomes and settings.
   The editors are in studio-editor.js. Every list and item comes from the
   server already filtered to what the viewer may see.
   ===================================================================== */
const ST = { kinds: null, tpl: null, img: {}, courses: null, brand: null };
// single quotes only: these go inside style="…" attributes
const ST_FONTS = { sans: 'Segoe UI, system-ui, Arial, sans-serif', serif: "Georgia, Cambria, 'Times New Roman', serif", display: "'Segoe UI Semibold', 'Helvetica Neue', Arial, sans-serif", mono: "Consolas, 'Courier New', monospace" };
const ST_STATUS = { draft: ['Draft', ''], review: ['In review', 'warning'], approved: ['Approved', 'success'], published: ['Published', 'primary'], archived: ['Archived', ''] };
function stStatus(st) { const x = ST_STATUS[st] || [st, '']; return badge(x[0], x[1]); }
function stIsStaff() { return S.me && (S.me.role === 'teacher' || S.me.role === 'admin'); }
async function stTemplates() { if (!ST.tpl) ST.tpl = await call('stTemplates'); ST.kinds = ST.tpl.kinds; return ST.tpl; }
async function stCourses() { if (!ST.courses) ST.courses = (await call('stCourses')).courses; return ST.courses; }
function stKindLabel(k) { const x = (ST.kinds || []).find((y) => y.key === k); return x ? x.label : k; }
function stKindIcon(k) { const x = (ST.kinds || []).find((y) => y.key === k); return x ? x.icon : 'file'; }
function stNav(active) {
  const items = [['/studio', 'Home', 'sparkle'], ['/studio/library', 'Library', 'folder']];
  if (stIsStaff()) items.push(['/studio/live', 'Live activities', 'live'], ['/studio/analytics', 'Analytics', 'chart'], ['/studio/outcomes', 'Outcomes & syllabus', 'target']);
  if (S.me.role === 'admin') items.push(['/studio/settings', 'Settings', 'settings']);
  return '<nav class="tabs st-tabs" aria-label="Content Studio">' + items.map((i) => '<a class="tab' + (i[0] === active ? ' active' : '') + '" href="#' + i[0] + '"' + (i[0] === active ? ' aria-current="page"' : '') + '>' + icon(i[2]) + i[1] + '</a>').join('') + '</nav>';
}

/* =====================================================================
   RENDERING (shared by editor, viewer, thumbnails, print)
   ===================================================================== */
function stBorder(e) { return Number(e.bw) > 0 && e.bc ? 'border:' + Number(e.bw) + 'px solid ' + e.bc + ';' : ''; }
function stTextCss(e) {
  return 'font-family:' + (ST_FONTS[e.ff] || ST_FONTS.sans) + ';font-size:' + (Number(e.fs) || 18) + 'px;font-weight:' + (Number(e.fw) || 400) + ';' + (e.fi ? 'font-style:italic;' : '') + (e.u ? 'text-decoration:underline;' : '') +
    'color:' + (e.color || '#1b1b1f') + ';text-align:' + (e.align || 'left') + ';line-height:' + (Number(e.lh) || 1.3) + ';';
}
function stTextHtml(e) {
  const t = String(e.text || '');
  if (e.list) return '<ul class="st-ul">' + t.split('\n').map((l) => (l.trim() ? '<li>' + esc(l) + '</li>' : '<li class="st-blank">&nbsp;</li>')).join('') + '</ul>';
  return esc(t) || '&nbsp;';
}
function stChartSvg(e) {
  const c = e.chart || {}, w = Number(e.w) || 300, h = Number(e.h) || 200;
  const labels = c.labels || [], vals = (c.values || []).map((v) => Number(v) || 0), cols = ['#1f3a6e', '#c8952c', '#2e7d5b', '#b03a48', '#5b61d9', '#13918a'];
  const top = c.title ? 26 : 6, max = Math.max(...vals, 1);
  let g = c.title ? '<text x="' + w / 2 + '" y="17" text-anchor="middle" font-size="14" font-weight="700" fill="#1b1b1f">' + esc(c.title) + '</text>' : '';
  if (c.type === 'pie') {
    const total = vals.reduce((a, b) => a + Math.max(0, b), 0) || 1, r = Math.min((h - top - 8) / 2, w / 3), cx = r + 8, cy = top + r;
    let a0 = -Math.PI / 2;
    vals.forEach((v, i) => {
      const a1 = a0 + Math.max(0, v) / total * Math.PI * 2;
      const large = a1 - a0 > Math.PI ? 1 : 0;
      g += Math.max(0, v) / total >= 0.999 ? '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="' + cols[i % 6] + '"/>' :
        '<path d="M' + cx + ',' + cy + 'L' + (cx + r * Math.cos(a0)) + ',' + (cy + r * Math.sin(a0)) + 'A' + r + ',' + r + ' 0 ' + large + ' 1 ' + (cx + r * Math.cos(a1)) + ',' + (cy + r * Math.sin(a1)) + 'Z" fill="' + cols[i % 6] + '"><title>' + esc(labels[i] || '') + ': ' + v + '</title></path>';
      g += '<rect x="' + (2 * r + 24) + '" y="' + (top + i * 20) + '" width="11" height="11" rx="2" fill="' + cols[i % 6] + '"/><text x="' + (2 * r + 40) + '" y="' + (top + 10 + i * 20) + '" font-size="12" fill="#3c3c43">' + esc(labels[i] || '') + ' (' + v + ')</text>';
      a0 = a1;
    });
  } else {
    const L = 34, B = 22, pw = w - L - 8, ph = h - top - B, n = Math.max(vals.length, 1), slot = (c.type === 'bar' ? ph : pw) / n;
    g += '<line x1="' + L + '" y1="' + (top + ph) + '" x2="' + (w - 6) + '" y2="' + (top + ph) + '" stroke="#b7bcc8"/>';
    [0, 0.5, 1].forEach((f) => { g += '<text x="' + (L - 4) + '" y="' + (top + ph - f * ph + 4) + '" text-anchor="end" font-size="10" fill="#6e6e76">' + Math.round(max * f) + '</text>'; });
    if (c.type === 'line') {
      const pts = vals.map((v, i) => [L + slot * i + slot / 2, top + ph - v / max * ph]);
      g += '<polyline points="' + pts.map((p) => p.join(',')).join(' ') + '" fill="none" stroke="' + cols[0] + '" stroke-width="3"/>' + pts.map((p, i) => '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="4" fill="' + cols[0] + '"><title>' + esc(labels[i] || '') + ': ' + vals[i] + '</title></circle>').join('');
    } else if (c.type === 'bar') {
      vals.forEach((v, i) => { const bw = v / max * pw; g += '<rect x="' + L + '" y="' + (top + slot * i + slot * 0.18) + '" width="' + Math.max(1, bw) + '" height="' + slot * 0.64 + '" rx="3" fill="' + cols[(c.multi ? i : 0) % 6] + '"><title>' + esc(labels[i] || '') + ': ' + v + '</title></rect><text x="' + (L + bw + 4) + '" y="' + (top + slot * i + slot / 2 + 4) + '" font-size="11" fill="#3c3c43">' + esc(labels[i] || '') + '</text>'; });
    } else vals.forEach((v, i) => { const bh = v / max * ph; g += '<rect x="' + (L + slot * i + slot * 0.18) + '" y="' + (top + ph - bh) + '" width="' + slot * 0.64 + '" height="' + Math.max(1, bh) + '" rx="3" fill="' + cols[(c.multi ? i : 0) % 6] + '"><title>' + esc(labels[i] || '') + ': ' + v + '</title></rect>'; });
    if (c.type !== 'bar') labels.forEach((l, i) => { g += '<text x="' + (L + slot * i + slot / 2) + '" y="' + (h - 6) + '" text-anchor="middle" font-size="11" fill="#3c3c43">' + esc(String(l).slice(0, 14)) + '</text>'; });
  }
  return '<svg width="100%" height="100%" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="' + esc(c.title || 'Chart') + '">' + g + '</svg>';
}
function stElHtml(e) {
  let st = 'left:' + e.x + 'px;top:' + e.y + 'px;width:' + e.w + 'px;height:' + e.h + 'px;' + (Number(e.rot) ? 'transform:rotate(' + Number(e.rot) + 'deg);' : '') + (e.op != null && Number(e.op) < 1 ? 'opacity:' + Number(e.op) + ';' : '');
  let inner = '';
  if (e.t === 'text') { st += stTextCss(e) + (e.bg ? 'background:' + e.bg + ';' : '') + stBorder(e) + (e.radius ? 'border-radius:' + e.radius + 'px;' : ''); inner = '<div class="st-text">' + stTextHtml(e) + '</div>'; }
  else if (e.t === 'rect' || e.t === 'ellipse') {
    st += 'background:' + (e.bg || 'transparent') + ';' + stBorder(e) + 'border-radius:' + (e.t === 'ellipse' ? '50%' : (Number(e.radius) || 0) + 'px') + ';';
    if (e.text) { st += stTextCss(e); inner = '<div class="st-text st-mid">' + stTextHtml(e) + '</div>'; }
  } else if (e.t === 'line') {
    const id = 'ar' + e.id;
    inner = '<svg width="100%" height="100%" viewBox="0 0 ' + e.w + ' ' + e.h + '" preserveAspectRatio="none" style="overflow:visible">' + (e.arrow ? '<defs><marker id="' + esc(id) + '" markerWidth="10" markerHeight="8" refX="9" refY="4" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L10,4 L0,8 z" fill="' + (e.bc || '#8a93a6') + '"/></marker></defs>' : '') +
      '<line x1="0" y1="' + (e.flip ? e.h : 0) + '" x2="' + e.w + '" y2="' + (e.flip ? 0 : e.h) + '" stroke="' + (e.bc || '#8a93a6') + '" stroke-width="' + (Number(e.bw) || 2) + '"' + (e.dash ? ' stroke-dasharray="6 5"' : '') + (e.arrow ? ' marker-end="url(#' + esc(id) + ')"' : '') + '/></svg>';
  } else if (e.t === 'image') {
    inner = e.src ? '<img class="st-img" data-fid="' + esc(e.src) + '" alt="' + esc(e.alt || '') + '" style="object-fit:' + (e.fit === 'cover' ? 'cover' : e.fit === 'fill' ? 'fill' : 'contain') + '" src="' + (ST.img[e.src] || 'data:image/gif;base64,R0lGODlhAQABAAAAACw=') + '">' : '<div class="st-imgph">' + icon('image') + '<span>Image</span></div>';
  } else if (e.t === 'table') {
    const rows = e.rows && e.rows.length ? e.rows : [['']];
    inner = '<table class="st-table" style="font-family:' + (ST_FONTS[e.ff] || ST_FONTS.sans) + ';font-size:' + (Number(e.fs) || 14) + 'px;color:' + (e.color || '#1b1b1f') + '">' + rows.map((r, ri) => '<tr>' + r.map((c) => (ri === 0 && e.header !== false ? '<th style="background:' + (e.hc || '#1f3a6e') + '">' : '<td style="background:' + (e.bg || '#fff') + '">') + esc(c) + (ri === 0 && e.header !== false ? '</th>' : '</td>')).join('') + '</tr>').join('') + '</table>';
  } else if (e.t === 'chart') inner = stChartSvg(e);
  else if (e.t === 'icon') { st += 'color:' + (e.color || '#1f3a6e') + ';'; inner = icon(e.icon || 'sparkle', 'st-icon'); }
  return '<div class="st-el st-t-' + e.t + (e.link ? ' st-linked' : '') + '" data-id="' + esc(e.id) + '" style="' + st + '">' + inner + '</div>';
}
function stPageHtml(it, page, cls) {
  const w = (it.size && it.size.w) || 960, h = (it.size && it.size.h) || 540;
  return '<div class="st-page ' + (cls || '') + '" style="width:' + w + 'px;height:' + h + 'px;background:' + (page.bg || '#fff') + '">' + (page.elements || []).map(stElHtml).join('') + '</div>';
}
/** A page drawn at a fixed width (thumbnails, previews): the page is scaled with a CSS transform. */
function stThumb(it, page, width) {
  if (!page) return '<div class="st-thumb-empty">' + icon(stKindIcon(it.kind || '')) + '</div>';
  const w = (it.size && it.size.w) || 960, h = (it.size && it.size.h) || 540, s = width / w;
  return '<div class="st-thumb" style="width:' + width + 'px;height:' + Math.round(h * s) + 'px"><div style="transform:scale(' + s + ');transform-origin:0 0;width:' + w + 'px;height:' + h + 'px">' + stPageHtml(it, page) + '</div></div>';
}
/** Loads studio images (they need the session token, so they are fetched as blobs). */
function stHydrate(root) {
  $$('img.st-img[data-fid]', root || document).forEach((img) => {
    const fid = img.dataset.fid;
    if (ST.img[fid]) { img.src = ST.img[fid]; return; }
    if (ST.img[fid] === null) return;
    ST.img[fid] = null;
    fetchFileBlob({ id: fid }).then((b) => { ST.img[fid] = URL.createObjectURL(b); $$('img.st-img[data-fid="' + fid + '"]').forEach((x) => { x.src = ST.img[fid]; }); }).catch(() => { delete ST.img[fid]; });
  });
}

/* =====================================================================
   HOME
   ===================================================================== */
async function viewStHome() {
  const [h, t] = await Promise.all([call('stHome'), stTemplates()]);
  ST.brand = h.brand;
  const staff = stIsStaff();
  const groups = staff ? [['Teach', ['presentation', 'notes', 'infographic', 'case', 'activity', 'discussion', 'lessonplan', 'conceptmap']], ['Assess', ['quiz', 'poll', 'assignment', 'rubric', 'questionpaper', 'flashcards', 'revision', 'worksheet']], ['Design', ['poster', 'mindmap', 'timeline', 'flowchart', 'certificate', 'document', 'videoscript', 'handout']]]
    : [['Create', ['presentation', 'infographic', 'poster', 'conceptmap', 'mindmap', 'pitch', 'bmc', 'portfolio', 'document', 'case', 'journal', 'flashcards', 'videoscript', 'revision']]];
  const allowed = new Set(t.kinds.map((k) => k.key));
  const tile = (k) => allowed.has(k) ? '<a class="st-kind" href="#/studio/new?kind=' + k + '">' + '<span class="i-tile sm tone-' + (['quiz', 'poll', 'assignment', 'rubric', 'questionpaper'].indexOf(k) >= 0 ? 'violet' : ['presentation', 'infographic', 'poster', 'pitch'].indexOf(k) >= 0 ? 'indigo' : 'cyan') + '">' + icon(stKindIcon(k)) + '</span><span>' + esc(stKindLabel(k)) + '</span></a>' : '';
  const card = (r) => '<a class="st-card" href="#/studio/edit/' + esc(r.id) + '"><div class="st-card-art">' + (r.thumb ? stThumb({ size: r.thumb.size }, r.thumb.page, 236) : '<div class="st-thumb-empty">' + icon(stKindIcon(r.kind)) + '</div>') + '</div>' +
    '<div class="st-card-body"><b>' + esc(r.title) + '</b><span class="xs muted">' + esc(r.kindLabel) + ' · ' + esc(rel(r.updatedAt)) + '</span><span class="st-card-tags">' + stStatus(r.status) + (r.ai ? badge(r.aiReviewed ? 'AI · reviewed' : 'AI-generated', r.aiReviewed ? 'info' : 'warning', 'sparkle') : '') + '</span></div></a>';
  const aiOff = h.aiProvider === 'builtin';
  return {
    title: 'Academic Content Studio',
    html: '<div class="st-home">' +
      '<section class="st-hero"><div><div class="st-eyebrow">Academic Content Studio</div><h1>Create once. Teach everywhere.</h1><p class="muted">' + (staff ? 'Turn a topic, a syllabus unit or your own notes into lecture slides, notes, cases, quizzes, activities and more — linked to your course outcomes.' : 'Create presentations, infographics, posters, concept maps and portfolios for your courses.') + '</p></div>' +
      '<form class="st-ai" data-form="stAiQuick"><label class="st-ai-label" for="stAiQ">' + icon('sparkle') + ' Academic Copilot</label><textarea id="stAiQ" name="prompt" rows="2" maxlength="3000" placeholder="' + (staff ? 'e.g. Create a 15-slide interactive lecture on essentials of a valid contract for B.Com students' : 'e.g. Create an infographic on the 4 Ps of marketing') + '"></textarea>' +
      '<div class="st-ai-row"><span class="xs muted">' + (aiOff ? icon('info', 'i-sm') + ' No AI provider is connected: the Copilot builds a structured outline from your topic, or real content from text you provide.' : icon('checkCircle', 'i-sm') + ' AI provider: ' + esc(h.aiProvider)) + '</span><span class="spacer"></span>' +
      (staff ? '<button class="btn" type="button" data-act="stSyllabus">' + icon('book') + 'Start from syllabus</button>' : '') + '<button class="btn" type="button" data-act="stImport">' + icon('upload') + 'Import</button><button class="btn btn-primary" type="submit">' + icon('sparkle') + 'Create with AI</button></div></form></section>' +
      stNav('/studio') +
      (h.live.length ? notice(h.live.map((l) => icon('live', 'i-sm') + ' Live now in ' + esc(l.course) + ': <a href="#/studio/live/' + esc(l.id) + '"><b>' + esc(l.title) + '</b></a>').join('<br>'), 'ok', 'live') : '') +
      (h.counts.review ? notice('<b>' + plural(h.counts.review, 'item') + '</b> waiting for your review. <a href="#/studio/library?view=review">Open the review queue</a>', 'warn', 'checkCircle') : '') +
      (h.assignments.length ? '<section class="card st-sec"><div class="card-head"><h2>Assignments you can submit studio work to</h2></div><div class="card-body st-chips">' + h.assignments.map((a) => '<span class="badge">' + esc(a.course) + ' · ' + esc(a.title) + (a.dueAt ? ' · due ' + esc(fmtDate(a.dueAt)) : '') + '</span>').join(' ') + '<p class="xs muted">Open your work and choose <b>Submit to assignment</b>.</p></div></section>' : '') +
      groups.map((g) => '<section class="st-sec"><h2 class="st-h2">' + g[0] + '</h2><div class="st-kinds">' + g[1].map(tile).join('') + '</div></section>').join('') +
      '<section class="st-sec"><div class="row"><h2 class="st-h2">Recent</h2><span class="spacer"></span><a class="btn btn-sm btn-ghost" href="#/studio/library">All content ' + icon('right', 'i-sm') + '</a></div>' +
      (h.recent.length ? '<div class="st-grid">' + h.recent.map(card).join('') + '</div>' : '<div class="card card-pad">' + emptyState('sparkle', 'Nothing here yet', staff ? 'Describe what you want to teach above, start from a syllabus unit, or pick a format to begin.' : 'Pick a format above to start your first design.', '', false) + '</div>') + '</section></div>',
    after: (root) => stHydrate(root)
  };
}

/* ---------- AI create, start from syllabus, import ---------- */
function stGuessKind(text) {
  const t = String(text || '').toLowerCase();
  const map = [['quiz', /\b(quiz|mcqs?|multiple[- ]choice)\b/], ['flashcards', /flash ?cards?/], ['case', /\bcase stud(y|ies)\b|\bcase\b/], ['assignment', /\bassignment\b/], ['infographic', /\binfographic\b/], ['poster', /\bposter\b/],
    ['conceptmap', /concept map/], ['mindmap', /mind ?map/], ['notes', /\b(lecture )?notes\b/], ['discussion', /\bdiscussion\b/], ['activity', /\b(activity|role ?play|exercise)\b/], ['lessonplan', /lesson plan/], ['rubric', /\brubric\b/], ['revision', /\brevision\b/], ['videoscript', /video script/], ['glossary', /\bglossary\b/], ['timeline', /\btimeline\b/], ['flowchart', /flow ?chart|process map/]];
  const hit = map.find((m) => m[1].test(t));
  return hit ? hit[0] : 'presentation';
}
FORMS.stAiQuick = (f) => { const p = f.elements.prompt.value.trim(); stAiCreate({ prompt: p }); };
ACT.stAiCreate = () => stAiCreate({});
async function stAiCreate(pre) {
  const [t, courses, prompts] = await Promise.all([stTemplates(), stCourses(), call('stPrompts')]);
  ST.prompts = prompts;
  const kinds = t.kinds.filter((k) => k.key !== 'certificate');
  formModal('Create with Academic Copilot', 'Describe what you need. Add your own notes for richer, source-based content.', 'stAiCreate',
    field('What would you like to create?', '<textarea name="prompt" rows="3" maxlength="3000" autofocus required>' + esc(pre.prompt || '') + '</textarea>', 'Topic, audience and length work well, e.g. "a 15-slide interactive lecture on working capital management for B.Com students".') +
    (prompts.length ? field('Or start from the prompt library', '<select data-change="stPromptPick"><option value="">Choose a prompt…</option>' + [...new Set(prompts.map((p) => p.category))].map((c) => '<optgroup label="' + esc(c) + '">' + prompts.filter((p) => p.category === c).map((p) => '<option value="' + esc(p.id) + '">' + esc(p.title) + '</option>').join('') + '</optgroup>').join('') + '</select>') : '') +
    '<div class="form-grid-3">' + field('Format', '<select name="kind">' + kinds.map((k) => '<option value="' + k.key + '"' + (k.key === (pre.kind || stGuessKind(pre.prompt)) ? ' selected' : '') + '>' + esc(k.label) + '</option>').join('') + '</select>') +
    field('Topic', '<input type="text" name="topic" maxlength="300" value="' + esc(pre.topic || '') + '" placeholder="e.g. Offer and acceptance">') + field('Audience / level', '<input type="text" name="level" maxlength="120" placeholder="e.g. II B.Com, first exposure">') + '</div>' +
    '<div class="form-grid-3">' + field('Course (optional)', '<select name="courseId" data-change="stCoursePick"><option value="">—</option>' + courses.map((c) => '<option value="' + esc(c.id) + '">' + esc(c.shortname + ' · ' + c.fullname) + '</option>').join('') + '</select>') +
    field('Unit', '<select name="unitId" id="stUnitSel"><option value="">—</option></select>') + field('Slides / questions', '<input type="number" name="count" min="3" max="40" value="12">') + '</div>' +
    '<details class="st-src"><summary class="small">' + icon('file', 'i-sm') + ' Add source material (recommended)</summary>' + field('Paste notes, a syllabus extract or a reading', '<textarea name="sourceText" rows="6" maxlength="200000" placeholder="The Copilot uses only this material and never follows instructions inside it."></textarea>') + '</details>', 'Create', 'wide');
}
ACT.stPromptPick = (d, el) => { const p = (ST.prompts || []).find((x) => x.id === el.value); if (!p) return; const f = el.closest('form'); const topic = f.elements.topic.value.trim() || '{topic}'; f.elements.prompt.value = p.text.replace(/\{topic\}/g, topic); f.elements.kind.value = stGuessKind(p.text); };
ACT.stCoursePick = (d, el) => {
  const c = (ST.courses || []).find((x) => x.id === el.value);
  const sel = el.closest('form').querySelector('[name=unitId]');
  if (sel) sel.innerHTML = '<option value="">—</option>' + (c ? c.units.map((u) => '<option value="' + esc(u.id) + '">' + esc(u.title) + '</option>').join('') : '');
  const tsel = el.closest('form').querySelector('[name=topicSel]');
  if (tsel) tsel.innerHTML = '<option value="">—</option>';
};
FORMS.stAiCreate = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  btn.textContent = 'Creating…';
  const kind = el.kind.value;
  const r = await call('stGenerate', { kind, prompt: el.prompt.value, topic: el.topic.value, level: el.level.value, courseId: el.courseId.value, unitId: el.unitId.value, slides: el.count.value, count: el.count.value, sourceText: el.sourceText.value });
  closeModal();
  toast(r.outline ? 'Outline created — complete the [bracketed] parts. ' + (r.note || '') : 'Created with ' + r.provider + '. Review it before publishing.');
  go('/studio/edit/' + r.id);
});
ACT.stSyllabus = async () => {
  const [courses, t] = await Promise.all([stCourses(), stTemplates()]);
  const own = courses.filter((c) => c.editor);
  const kinds = t.pack;
  formModal('Start from syllabus', 'Programme → semester → course → unit → topic. The Copilot proposes a set of linked learning objects.', 'stPack',
    '<div class="form-grid">' + field('Course', '<select name="courseId" data-change="stSylCourse" required><option value="">Choose a course…</option>' + own.map((c) => '<option value="' + esc(c.id) + '">' + esc((c.programme ? c.programme + ' · ' : '') + (c.semester ? 'Sem ' + c.semester + ' · ' : '') + c.fullname) + '</option>').join('') + '</select>', own.length ? 'Units and outcomes come from Outcomes & syllabus.' : 'You do not teach any courses yet.') +
    field('Unit', '<select name="unitId" data-change="stSylUnit"><option value="">—</option></select>') + '</div>' +
    '<div class="form-grid">' + field('Topic', '<select name="topicSel" data-change="stSylTopic"><option value="">—</option></select>') + field('Or type a topic', '<input type="text" name="topic" maxlength="300" required>') + '</div>' +
    '<div id="stSylCos" class="small muted"></div>' +
    field('Request (optional)', '<input type="text" name="prompt" maxlength="2000" placeholder="e.g. Create a 15-slide interactive lecture on essentials of a valid contract.">') +
    '<fieldset class="fieldset"><legend>Learning objects to create</legend><div class="st-checkgrid">' + kinds.map((k) => '<label class="check"><input type="checkbox" name="k_' + k + '"' + (['presentation', 'notes', 'infographic', 'case', 'quiz', 'discussion', 'assignment'].indexOf(k) >= 0 ? ' checked' : '') + '><span>' + esc(stKindLabel(k)) + '</span></label>').join('') + '</div></fieldset>' +
    '<details class="st-src"><summary class="small">' + icon('file', 'i-sm') + ' Add source material (recommended)</summary><textarea name="sourceText" rows="6" maxlength="200000" placeholder="Paste your notes or the textbook extract for this topic."></textarea></details>', 'Create learning objects', 'wide');
};
ACT.stSylCourse = (d, el) => {
  const c = (ST.courses || []).find((x) => x.id === el.value);
  const f = el.closest('form');
  f.querySelector('[name=unitId]').innerHTML = '<option value="">—</option>' + (c ? c.units.map((u) => '<option value="' + esc(u.id) + '">' + esc(u.title) + '</option>').join('') : '');
  f.querySelector('[name=topicSel]').innerHTML = '<option value="">—</option>';
  $('#stSylCos').innerHTML = c && c.co.length ? '<b>Course outcomes:</b> ' + c.co.map((o) => esc(o.code)).join(', ') + ' — they will be suggested for each object.' : c ? 'This course has no outcomes yet — add them under Outcomes & syllabus.' : '';
};
ACT.stSylUnit = (d, el) => { const f = el.closest('form'); const c = (ST.courses || []).find((x) => x.id === f.elements.courseId.value); const u = c && c.units.find((x) => x.id === el.value); f.querySelector('[name=topicSel]').innerHTML = '<option value="">—</option>' + (u ? u.topics.map((t) => '<option>' + esc(t) + '</option>').join('') : ''); };
ACT.stSylTopic = (d, el) => { if (el.value) el.closest('form').elements.topic.value = el.value; };
FORMS.stPack = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  const kinds = Array.from(f.querySelectorAll('input[type=checkbox][name^=k_]')).filter((c) => c.checked).map((c) => c.name.slice(2));
  if (!kinds.length) throw new Error('Choose at least one learning object.');
  btn.textContent = 'Creating ' + kinds.length + ' objects…';
  const r = await call('stPack', { courseId: el.courseId.value, unitId: el.unitId.value, topic: el.topic.value, prompt: el.prompt.value, sourceText: el.sourceText.value, kinds });
  openModal(modalHead('Learning objects created', r.outline ? 'Outlines to complete — connect an AI provider or add source material for full content.' : 'Review each one before publishing.') + '<div class="modal-body"><div class="st-family">' +
    r.items.map((x) => '<a class="st-fam" href="#/studio/edit/' + esc(x.id) + '" data-act="close">' + icon(stKindIcon(x.kind)) + '<span><b>' + esc(stKindLabel(x.kind)) + '</b><span class="xs muted">' + esc(x.title) + '</span></span>' + (x.master ? badge('Master', 'primary') : '') + '</a>').join('') +
    '</div><p class="xs muted">All objects share one content family: when the master notes change, the others are flagged for review.</p><div class="form-actions"><button class="btn btn-primary" data-act="close">Done</button></div></div>', 'wide');
  ST.courses = null;
});
ACT.stImport = () => formModal('Import', 'PDF, Word, PowerPoint, Excel/CSV or text — or a public web page.', 'stImport',
  '<label class="dropzone" style="padding:1.25rem">' + icon('upload') + '<b>Choose a file</b><span class="small">PDF, DOCX, PPTX, XLSX, CSV, TXT, MD — up to 15 MB</span><input type="file" name="file" accept=".pdf,.docx,.pptx,.xlsx,.csv,.txt,.md"></label>' +
  '<p class="small muted" style="text-align:center;margin:.8rem 0">or</p>' + field('Web page address', '<input type="url" name="url" maxlength="2000" placeholder="https://…">', 'Public https pages only. Respect copyright and your institution’s policies.'), 'Import', 'wide');
FORMS.stImport = (f, btn) => busy(btn, async () => {
  const file = f.elements.file.files[0], url = f.elements.url.value.trim();
  if (!file && !url) throw new Error('Choose a file or enter a web address.');
  btn.textContent = 'Importing…';
  const r = file ? await call('stImport', { name: file.name, data: await readFileB64(file) }) : await call('stImport', { url });
  closeModal(); toast('Imported.'); go('/studio/edit/' + r.id);
});

/* ---------- new item (template picker) ---------- */
async function viewStNew(params) {
  const kind = params.get('kind') || 'presentation';
  const t = await stTemplates();
  const k = t.kinds.find((x) => x.key === kind);
  if (!k) return { title: 'Not available', html: '<div class="card card-pad">' + emptyState('lock', 'Not available', 'This type of content is not available to you.', '<a class="btn" href="#/studio">Back</a>', false) + '</div>' };
  const tpls = t.builtin.filter((x) => x.kind === kind || (kind === 'presentation' && ['presentation'].indexOf(x.kind) >= 0)).concat(t.institutional.filter((x) => x.kind === kind));
  const posters = kind === 'poster' ? t.builtin.filter((x) => x.kind === 'poster') : [];
  const list = posters.length ? posters : tpls;
  return {
    title: 'New ' + k.label,
    html: pageHead('New ' + k.label.toLowerCase(), { crumbs: [['Studio', '/studio'], ['New']], sub: 'Start from a template, a blank ' + (k.format === 'canvas' ? 'canvas' : 'document') + ', or let the Copilot draft it.' }) +
      '<div class="st-tpls">' +
      '<button class="st-tpl" data-act="stNewBlank" data-kind="' + esc(kind) + '"><div class="st-thumb-empty big">' + icon('plus') + '</div><b>Blank</b></button>' +
      '<button class="st-tpl" data-act="stNewAi" data-kind="' + esc(kind) + '"><div class="st-thumb-empty big ai">' + icon('sparkle') + '</div><b>Draft with Copilot</b></button>' +
      list.map((x) => '<button class="st-tpl" data-act="stNewTpl" data-kind="' + esc(x.kind) + '" data-tpl="' + esc(x.id) + '">' + (x.preview ? stThumb({ size: x.preview.size }, x.preview.page, 220) : '<div class="st-thumb-empty big">' + icon(stKindIcon(x.kind)) + '</div>') + '<b>' + esc(x.name) + '</b>' + (t.institutional.indexOf(x) >= 0 ? badge('Institution', 'primary') : '') + '</button>').join('') + '</div>',
    after: (root) => stHydrate(root)
  };
}
ACT.stNewBlank = (d, btn) => busy(btn, async () => { const r = await call('stCreate', { kind: d.kind, blank: true }); go('/studio/edit/' + r.id); });
ACT.stNewTpl = (d, btn) => busy(btn, async () => { const r = await call('stCreate', { kind: d.kind, templateId: d.tpl }); go('/studio/edit/' + r.id); });
ACT.stNewAi = (d) => stAiCreate({ kind: d.kind });

/* =====================================================================
   LIBRARY
   ===================================================================== */
const ST_VIEWS = [['recent', 'Recent', 'clock'], ['mine', 'My content', 'user'], ['shared', 'Shared with me', 'users'], ['department', 'My department', 'building'], ['library', 'University library', 'book'], ['published', 'Published', 'send'], ['drafts', 'Drafts', 'edit'], ['favorites', 'Favorites', 'award'], ['review', 'Review queue', 'checkCircle'], ['archived', 'Archived', 'folder'], ['trash', 'Trash', 'trash']];
async function viewStLibrary(params) {
  const p = Object.fromEntries(params.entries());
  const [r] = await Promise.all([call('stList', p), stTemplates()]);
  const views = ST_VIEWS.filter((v) => stIsStaff() || ['department', 'library', 'review'].indexOf(v[0]) < 0);
  const card = (x) => '<div class="st-card' + (r.view === 'trash' ? ' is-trash' : '') + '">' + '<a class="st-card-art" href="#/studio/' + (x.mine || x.canEdit ? 'edit' : 'edit') + '/' + esc(x.id) + '">' + (x.thumb ? stThumb({ size: x.thumb.size }, x.thumb.page, 236) : '<div class="st-thumb-empty">' + icon(stKindIcon(x.kind)) + '</div>') + '</a>' +
    '<div class="st-card-body"><a href="#/studio/edit/' + esc(x.id) + '"><b>' + esc(x.title) + '</b></a><span class="xs muted">' + esc(x.kindLabel) + (x.course ? ' · ' + esc(x.course) : '') + ' · ' + (x.mine ? '' : esc(x.owner) + ' · ') + esc(rel(x.updatedAt)) + '</span>' +
    '<span class="st-card-tags">' + stStatus(x.status) + (x.ai ? badge(x.aiReviewed ? 'AI · reviewed' : 'AI-generated', x.aiReviewed ? 'info' : 'warning', 'sparkle') : '') + (x.library === 'approved' ? badge('Library', 'success', 'book') : x.library === 'pending' ? badge('Library: pending', 'warning') : '') + x.co.map((c) => '<span class="badge outline">' + esc(c) + '</span>').join('') + '</span>' +
    '<span class="row st-card-acts">' + (r.view === 'trash' ? '<button class="btn btn-sm" data-act="stRestoreTrash" data-id="' + esc(x.id) + '">Restore</button>' : '<button class="btn-icon sm" title="' + (x.favorite ? 'Remove from favorites' : 'Add to favorites') + '" aria-pressed="' + x.favorite + '" data-act="stFav" data-id="' + esc(x.id) + '" data-on="' + (x.favorite ? '' : '1') + '">' + icon('award') + '</button><button class="btn-icon sm" title="Duplicate" data-act="stDup" data-id="' + esc(x.id) + '">' + icon('copy') + '</button>' +
      (r.view === 'library' && x.library === 'pending' && S.me.role !== 'student' ? '<button class="btn btn-sm btn-soft" data-act="stLib" data-id="' + esc(x.id) + '" data-approve="1">Approve for library</button><button class="btn btn-sm btn-ghost" data-act="stLib" data-id="' + esc(x.id) + '">Decline</button>' : '')) + '</span></div></div>';
  const kindsUsed = (ST.kinds || []);
  return {
    title: 'Content library',
    html: pageHead('Content library', { crumbs: [['Studio', '/studio'], ['Library']], actions: '<a class="btn btn-primary" href="#/studio">' + icon('plus') + 'Create</a>' }) + stNav('/studio/library') +
      '<div class="st-lib"><aside class="st-lib-side card">' + views.map((v) => '<a class="st-lib-link' + (r.view === v[0] ? ' active' : '') + '" href="#/studio/library?view=' + v[0] + '">' + icon(v[2]) + v[1] + (v[0] === 'review' && r.reviewCount ? '<span class="count">' + r.reviewCount + '</span>' : '') + '</a>').join('') +
      (r.folders.length ? '<div class="st-lib-label">Folders</div>' + r.folders.map((f) => '<a class="st-lib-link' + (p.folder === f ? ' active' : '') + '" href="#/studio/library?view=mine&folder=' + encodeURIComponent(f) + '">' + icon('folder') + esc(f) + '</a>').join('') : '') +
      (r.tags.length ? '<div class="st-lib-label">Tags</div><div class="st-chips">' + r.tags.slice(0, 30).map((t) => '<a class="badge outline" href="#/studio/library?view=mine&tag=' + encodeURIComponent(t) + '">#' + esc(t) + '</a>').join(' ') + '</div>' : '') + '</aside>' +
      '<div class="st-lib-main"><form class="card st-filters" data-form="stFilter"><input type="hidden" name="view" value="' + esc(r.view) + '"><div class="search-box">' + icon('search') + '<input type="search" name="q" value="' + esc(p.q || '') + '" placeholder="Search titles, topics, tags and text" aria-label="Search content"></div>' +
      '<select name="kind" aria-label="Type"><option value="">All types</option>' + kindsUsed.map((k) => '<option value="' + k.key + '"' + (p.kind === k.key ? ' selected' : '') + '>' + esc(k.label) + '</option>').join('') + '</select>' +
      '<select name="sort" aria-label="Sort"><option value="updated">Last edited</option><option value="created"' + (p.sort === 'created' ? ' selected' : '') + '>Newest</option><option value="title"' + (p.sort === 'title' ? ' selected' : '') + '>Title</option></select><button class="btn" type="submit">' + icon('filter', 'i-sm') + 'Apply</button></form>' +
      (r.rows.length ? '<div class="st-grid">' + r.rows.map(card).join('') + '</div>' + (r.pages > 1 ? '<div class="row" style="justify-content:center;gap:.5rem;margin-top:1rem">' + (r.page > 1 ? '<a class="btn btn-sm" href="#/studio/library?' + new URLSearchParams(Object.assign({}, p, { page: r.page - 1 })) + '">Previous</a>' : '') + '<span class="small muted">Page ' + r.page + ' of ' + r.pages + '</span>' + (r.page < r.pages ? '<a class="btn btn-sm" href="#/studio/library?' + new URLSearchParams(Object.assign({}, p, { page: r.page + 1 })) + '">Next</a>' : '') + '</div>' : '')
        : '<div class="card card-pad">' + emptyState(r.view === 'review' ? 'checkCircle' : 'folder', r.view === 'review' ? 'Nothing to review' : 'No content here', r.view === 'library' ? 'Approved resources shared across the institution appear here.' : r.view === 'shared' ? 'Content colleagues share with you appears here.' : 'Try another view or clear the search.', '', false) + '</div>') + '</div></div>',
    after: (root) => stHydrate(root)
  };
}
FORMS.stFilter = (f) => { const q = new URLSearchParams(); Array.from(f.elements).forEach((el) => { if (el.name && el.value) q.set(el.name, el.value); }); go('/studio/library?' + q.toString()); };
ACT.stFav = (d, btn) => busy(btn, async () => { await call('stFavorite', { id: d.id, on: !!d.on }); refresh(); });
ACT.stDup = (d, btn) => busy(btn, async () => { const r = await call('stDuplicate', { id: d.id }); toast('Copy created.'); go('/studio/edit/' + r.id); });
ACT.stRestoreTrash = (d, btn) => busy(btn, async () => { await call('stDelete', { id: d.id, restore: true }); toast('Restored.'); refresh(); });
ACT.stLib = (d, btn) => busy(btn, async () => { await call('stLibrary', { id: d.id, approve: !!d.approve }); toast(d.approve ? 'Added to the university library.' : 'Declined.'); refresh(); });

/* =====================================================================
   VIEWER (students and published content; also inside a course activity)
   ===================================================================== */
async function stViewerHtml(id, opts) {
  opts = opts || {};
  const it = await call('stView', { id, moduleId: opts.moduleId || '', version: opts.version || '' });
  ST.view = { it, page: 0, moduleId: opts.moduleId || '' };
  let body;
  if (it.format === 'canvas') {
    body = '<div class="st-viewer"><div class="st-vstage" id="stVStage">' + stVPage() + '</div>' +
      '<div class="st-vbar">' + (it.pages.length > 1 ? '<button class="btn-icon" data-act="stVNav" data-d="-1" aria-label="Previous page">' + icon('left') + '</button><span class="small" id="stVPos">1 / ' + it.pages.length + '</span><button class="btn-icon" data-act="stVNav" data-d="1" aria-label="Next page">' + icon('right') + '</button>' : '') +
      '<span class="spacer"></span><button class="btn btn-sm" data-act="stPresent">' + icon('monitor') + 'Present</button></div>' +
      (it.pages.length > 1 ? '<div class="st-vthumbs">' + it.pages.map((p, i) => '<button class="st-vthumb' + (i === 0 ? ' active' : '') + '" data-act="stVGo" data-i="' + i + '" aria-label="Page ' + (i + 1) + '">' + stThumb(it, p, 120) + '</button>').join('') + '</div>' : '') +
      (stIsStaff() && it.pages.some((p) => p.notes) ? '<details class="card st-notes"><summary class="card-head"><h3>Speaker notes</h3></summary><div class="card-body small" id="stVNotes">' + esc(it.pages[0].notes || '') + '</div></details>' : '') + '</div>';
  } else if (it.format === 'doc') body = '<div class="card"><div class="card-body"><article class="prose lg st-doc-view">' + md(it.doc) + '</article></div></div>';
  else if (it.format === 'cards') body = '<div class="st-deck">' + it.cards.map((c, i) => '<button class="st-flash" data-act="stFlip" aria-label="Flashcard ' + (i + 1) + ': ' + esc(c.front) + '. Press to see the answer."><span class="st-flash-front">' + esc(c.front) + '</span><span class="st-flash-back">' + esc(c.back) + '</span></button>').join('') + '</div><p class="xs muted">Select a card to flip it.</p>';
  else body = '<div class="st-selfcheck">' + it.questions.map((q, i) => '<div class="card st-q" data-qid="' + esc(q.id) + '"><div class="card-body"><div class="xs muted">Question ' + (i + 1) + ' · ' + esc(q.bloom || '') + '</div><p><b>' + esc(q.text) + '</b></p>' +
    (q.type === 'short' ? '<form data-form="stCheckShort" class="row"><input type="text" name="a" maxlength="200" aria-label="Your answer"><button class="btn btn-sm">Check</button></form>' : '<div class="st-opts">' + q.options.map((o, j) => '<button class="st-opt" data-act="stCheck" data-qid="' + esc(q.id) + '" data-i="' + j + '">' + esc(o) + '</button>').join('') + '</div>') + '<div class="st-qres" aria-live="polite"></div></div></div>').join('') + '</div>';
  const head = '<div class="st-vhead">' + (it.ai ? badge('AI-assisted content · reviewed by faculty', 'info', 'sparkle') : '') + '<span class="xs muted">' + esc(it.kindLabel) + ' · by ' + esc(it.owner) + ' · updated ' + esc(rel(it.updatedAt)) + '</span></div>';
  return head + body;
}
function stVPage() {
  const v = ST.view, it = v.it, pg = it.pages[v.page];
  return '<div class="st-vfit" id="stVFit" data-w="' + it.size.w + '" data-h="' + it.size.h + '">' + stPageHtml(it, pg) + '</div>';
}
function stFitViewer() {
  const fit = $('#stVFit'), stage = $('#stVStage');
  if (!fit || !stage) return;
  const s = stage.clientWidth / Number(fit.dataset.w); // fill the stage width, up or down
  fit.style.transform = 'scale(' + s + ')'; fit.style.height = '0'; stage.style.height = Math.round(Number(fit.dataset.h) * s) + 'px';
  fit.firstChild.style.transformOrigin = '0 0';
}
window.addEventListener('resize', () => { stFitViewer(); });
function stVShow(i) {
  const v = ST.view; if (!v) return;
  v.page = Math.max(0, Math.min(v.it.pages.length - 1, i));
  $('#stVStage').innerHTML = stVPage(); stFitViewer(); stHydrate($('#stVStage'));
  if ($('#stVPos')) $('#stVPos').textContent = (v.page + 1) + ' / ' + v.it.pages.length;
  $$('.st-vthumb').forEach((b, j) => b.classList.toggle('active', j === v.page));
  if ($('#stVNotes')) $('#stVNotes').textContent = v.it.pages[v.page].notes || '';
}
ACT.stVNav = (d) => stVShow(ST.view.page + Number(d.d));
ACT.stVGo = (d) => stVShow(Number(d.i));
ACT.stFlip = (d, el) => el.classList.toggle('flipped');
ACT.stCheck = (d, el) => busy(null, async () => {
  const r = await call('stCheck', { id: ST.view.it.id, moduleId: ST.view.moduleId, qid: d.qid, answer: Number(d.i) });
  const box = el.closest('.st-q');
  $$('.st-opt', box).forEach((b, j) => { b.classList.toggle('right', j === Number(r.answer)); b.classList.toggle('wrong', j === Number(d.i) && !r.correct); b.disabled = true; });
  $('.st-qres', box).innerHTML = (r.correct ? badge('Correct', 'success', 'checkCircle') : badge('Not quite', 'danger', 'x')) + (r.explanation ? ' <span class="small">' + esc(r.explanation) + '</span>' : '');
});
FORMS.stCheckShort = (f) => busy(null, async () => {
  const box = f.closest('.st-q');
  const r = await call('stCheck', { id: ST.view.it.id, moduleId: ST.view.moduleId, qid: box.dataset.qid, answer: f.elements.a.value });
  $('.st-qres', box).innerHTML = (r.correct ? badge('Correct', 'success', 'checkCircle') : badge('Model answer: ' + r.answer, 'info')) + (r.explanation ? ' <span class="small">' + esc(r.explanation) + '</span>' : '');
});
async function viewStView(id, params) {
  const html = await stViewerHtml(id, { version: params.get('v') || '' });
  const it = ST.view.it;
  return { title: it.title, html: pageHead(it.title, { crumbs: [['Studio', '/studio'], [it.title]], actions: it.canEdit ? '<a class="btn" href="#/studio/edit/' + esc(it.id) + '">' + icon('edit') + 'Edit</a>' : '' }) + html, after: (root) => { stFitViewer(); stHydrate(root); } };
}
/* Present mode: full screen, arrow keys / click to advance, Esc to leave. */
ACT.stPresent = (d) => {
  const it = (ST.ed && d.editor) ? ST.ed.it : ST.view.it;
  let i = (ST.ed && d.editor) ? ST.ed.page : ST.view.page;
  const ov = document.createElement('div');
  ov.className = 'st-present'; ov.tabIndex = 0;
  const draw = () => {
    const s = Math.min(window.innerWidth / it.size.w, window.innerHeight / it.size.h);
    ov.innerHTML = '<div class="st-present-page" style="transform:scale(' + s + ');left:' + (window.innerWidth - it.size.w * s) / 2 + 'px;top:' + (window.innerHeight - it.size.h * s) / 2 + 'px">' + stPageHtml(it, it.pages[i]) + '</div><div class="st-present-pos">' + (i + 1) + ' / ' + it.pages.length + ' · Esc to exit</div>';
    stHydrate(ov);
  };
  const close = () => { document.removeEventListener('keydown', key, true); ov.remove(); if (document.fullscreenElement) document.exitFullscreen().catch(() => {}); };
  const key = (e) => { if (['ArrowRight', 'PageDown', ' ', 'Enter'].indexOf(e.key) >= 0) { i = Math.min(it.pages.length - 1, i + 1); draw(); e.preventDefault(); e.stopPropagation(); } else if (['ArrowLeft', 'PageUp', 'Backspace'].indexOf(e.key) >= 0) { i = Math.max(0, i - 1); draw(); e.preventDefault(); e.stopPropagation(); } else if (e.key === 'Escape') { close(); e.stopPropagation(); } };
  ov.addEventListener('click', (e) => { i = e.clientX < window.innerWidth / 3 ? Math.max(0, i - 1) : Math.min(it.pages.length - 1, i + 1); draw(); });
  document.addEventListener('keydown', key, true);
  document.body.appendChild(ov); draw(); ov.focus();
  if (ov.requestFullscreen) ov.requestFullscreen().catch(() => {});
  window.addEventListener('resize', draw, { once: true });
};

/* =====================================================================
   PRINT (PDF) and IMAGE EXPORT
   ===================================================================== */
async function viewStPrint(id) {
  const it = await call('stView', { id });
  ST.view = { it, page: 0 };
  const body = it.format === 'canvas' ? it.pages.map((p) => '<div class="st-print-page" style="width:' + it.size.w + 'px;height:' + it.size.h + 'px">' + stPageHtml(it, p) + '</div>').join('')
    : it.format === 'doc' ? '<article class="prose lg st-print-doc"><h1>' + esc(it.title) + '</h1>' + md(it.doc) + '</article>'
      : it.format === 'cards' ? '<article class="prose st-print-doc"><h1>' + esc(it.title) + '</h1><table><tr><th>Front</th><th>Back</th></tr>' + it.cards.map((c) => '<tr><td>' + esc(c.front) + '</td><td>' + esc(c.back) + '</td></tr>').join('') + '</table></article>'
        : '<article class="prose st-print-doc"><h1>' + esc(it.title) + '</h1><ol>' + it.questions.map((q) => '<li><p>' + esc(q.text) + '</p>' + (q.options.length ? '<ol type="A">' + q.options.map((o) => '<li>' + esc(o) + '</li>').join('') + '</ol>' : '<p>________________</p>') + '</li>').join('') + '</ol></article>';
  const orient = it.format === 'canvas' && it.size.w > it.size.h ? 'landscape' : 'portrait';
  return {
    title: it.title,
    html: '<style>@page{size:' + (it.format === 'canvas' ? it.size.w + 'px ' + it.size.h + 'px' : 'A4 ' + orient) + ';margin:' + (it.format === 'canvas' ? '0' : '18mm') + '}</style><div class="st-print"><div class="st-noprint row" style="gap:.5rem;margin-bottom:1rem"><a class="btn" href="#/studio/edit/' + esc(it.id) + '">' + icon('arrowLeft') + 'Back</a><span class="spacer"></span><span class="small muted">Use “Save as PDF” as the printer. Turn on background graphics.</span><button class="btn btn-primary" data-act="stPrintNow">' + icon('printer') + 'Print / Save as PDF</button></div>' + body + '</div>',
    after: (root) => stHydrate(root)
  };
}
ACT.stPrintNow = () => window.print();
/** Draws one canvas page to a <canvas> (PNG/JPG export) — no HTML-to-image tricks, so nothing taints the canvas. */
async function stRaster(it, page, scale) {
  scale = scale || 2;
  const W = it.size.w, H = it.size.h;
  const cv = document.createElement('canvas'); cv.width = W * scale; cv.height = H * scale;
  const g = cv.getContext('2d'); g.scale(scale, scale);
  g.fillStyle = page.bg || '#fff'; g.fillRect(0, 0, W, H);
  const font = (e) => (e.fi ? 'italic ' : '') + (Number(e.fw) || 400) + ' ' + (Number(e.fs) || 18) + 'px ' + (ST_FONTS[e.ff] || ST_FONTS.sans);
  const rr = (x, y, w, h, r) => { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); };
  const wrap = (e, x, y, w, h, mid) => {
    g.font = font(e); g.fillStyle = e.color || '#1b1b1f'; g.textBaseline = 'top';
    const lh = (Number(e.fs) || 18) * (Number(e.lh) || 1.3), lines = [];
    String(e.text || '').split('\n').forEach((para) => {
      const pre = e.list && para.trim() ? '•  ' : '';
      let line = pre;
      para.split(/\s+/).forEach((wd) => { const test = line + (line && line !== pre ? ' ' : '') + wd; if (g.measureText(test).width > w - (e.list ? 4 : 0) && line && line !== pre) { lines.push(line); line = (e.list ? '   ' : '') + wd; } else line = test; });
      lines.push(line);
    });
    let ty = y + (mid ? Math.max(0, (h - lines.length * lh) / 2) : 0);
    lines.forEach((l) => { const lw = g.measureText(l).width; const tx = e.align === 'center' ? x + (w - lw) / 2 : e.align === 'right' ? x + w - lw : x; g.fillText(l, tx, ty + (lh - (Number(e.fs) || 18)) / 2); ty += lh; });
  };
  for (const e of page.elements || []) {
    g.save(); g.globalAlpha = e.op != null ? Number(e.op) : 1;
    if (Number(e.rot)) { g.translate(e.x + e.w / 2, e.y + e.h / 2); g.rotate(Number(e.rot) * Math.PI / 180); g.translate(-(e.x + e.w / 2), -(e.y + e.h / 2)); }
    if (e.t === 'rect' || e.t === 'ellipse' || (e.t === 'text' && e.bg)) {
      if (e.t === 'ellipse') { g.beginPath(); g.ellipse(e.x + e.w / 2, e.y + e.h / 2, e.w / 2, e.h / 2, 0, 0, Math.PI * 2); } else rr(e.x, e.y, e.w, e.h, Math.min(Number(e.radius) || 0, e.w / 2, e.h / 2));
      if (e.bg && e.bg !== 'transparent') { g.fillStyle = e.bg; g.fill(); }
      if (Number(e.bw) > 0 && e.bc) { g.strokeStyle = e.bc; g.lineWidth = Number(e.bw); g.stroke(); }
    }
    if ((e.t === 'text' || ((e.t === 'rect' || e.t === 'ellipse') && e.text))) wrap(e, e.x + (e.bg ? 6 : 0), e.y, e.w - (e.bg ? 12 : 0), e.h, e.t !== 'text');
    if (e.t === 'line') {
      const [x1, y1, x2, y2] = e.flip ? [e.x, e.y + e.h, e.x + e.w, e.y] : [e.x, e.y, e.x + e.w, e.y + e.h];
      g.strokeStyle = e.bc || '#8a93a6'; g.lineWidth = Number(e.bw) || 2; if (e.dash) g.setLineDash([6, 5]);
      g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke();
      if (e.arrow) { const a = Math.atan2(y2 - y1, x2 - x1); g.fillStyle = e.bc || '#8a93a6'; g.beginPath(); g.moveTo(x2, y2); g.lineTo(x2 - 11 * Math.cos(a - 0.4), y2 - 11 * Math.sin(a - 0.4)); g.lineTo(x2 - 11 * Math.cos(a + 0.4), y2 - 11 * Math.sin(a + 0.4)); g.fill(); }
    }
    if (e.t === 'image' && e.src) {
      try {
        const url = ST.img[e.src] || (ST.img[e.src] = URL.createObjectURL(await fetchFileBlob({ id: e.src })));
        const img = await new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = url; });
        let { x, y, w, h } = e;
        if (e.fit !== 'fill') { const s = (e.fit === 'cover' ? Math.max : Math.min)(w / img.width, h / img.height); const nw = img.width * s, nh = img.height * s; if (e.fit === 'cover') { g.beginPath(); g.rect(x, y, w, h); g.clip(); } x += (w - nw) / 2; y += (h - nh) / 2; w = nw; h = nh; }
        g.drawImage(img, x, y, w, h);
      } catch (err) { /* skip unavailable image */ }
    }
    if (e.t === 'table') {
      const rows = e.rows || [[]], cols = Math.max(...rows.map((r) => r.length), 1), cw = e.w / cols, rh = e.h / rows.length;
      rows.forEach((r, ri) => Array.from({ length: cols }, (_, ci) => { const head = ri === 0 && e.header !== false; g.fillStyle = head ? (e.hc || '#1f3a6e') : (e.bg || '#fff'); g.fillRect(e.x + ci * cw, e.y + ri * rh, cw, rh); g.strokeStyle = '#c9ced8'; g.lineWidth = 1; g.strokeRect(e.x + ci * cw, e.y + ri * rh, cw, rh); wrap({ text: r[ci] || '', fs: e.fs || 14, ff: e.ff, fw: head ? 700 : 400, color: head ? '#fff' : (e.color || '#1b1b1f'), lh: 1.2 }, e.x + ci * cw + 6, e.y + ri * rh + 4, cw - 12, rh - 8, false); }));
    }
    if (e.t === 'chart' || e.t === 'icon') {
      const svg = e.t === 'chart' ? stChartSvg(e).replace('width="100%" height="100%"', 'width="' + e.w + '" height="' + e.h + '" xmlns="http://www.w3.org/2000/svg"') : icon(e.icon || 'sparkle').replace('<svg class="i"', '<svg xmlns="http://www.w3.org/2000/svg" width="' + e.w + '" height="' + e.h + '"').replace(/currentColor/g, e.color || '#1f3a6e');
      try { const img = await new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg); }); g.drawImage(img, e.x, e.y, e.w, e.h); } catch (err) { /* skip */ }
    }
    g.restore();
  }
  return cv;
}
async function stExportImage(it, fmt, all) {
  const pages = all ? it.pages : [it.pages[(ST.ed && ST.ed.page) || 0]];
  for (let i = 0; i < pages.length; i++) {
    const cv = await stRaster(it, pages[i], 2);
    const blob = await new Promise((r) => cv.toBlob(r, fmt === 'jpg' ? 'image/jpeg' : 'image/png', 0.92));
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = it.title.replace(/[^\w .-]+/g, '').slice(0, 50) + (pages.length > 1 ? '-' + (i + 1) : '') + '.' + fmt; document.body.appendChild(a); a.click(); a.remove();
    await new Promise((r) => setTimeout(r, 250));
  }
}

/* =====================================================================
   LIVE ACTIVITIES (polls, MCQ checks, word clouds)
   ===================================================================== */
async function viewStLiveList() {
  const list = await call('stLiveList');
  return {
    title: 'Live activities',
    html: pageHead('Live activities', { crumbs: [['Studio', '/studio'], ['Live']], sub: 'Launch a quiz or poll during class from its editor (Launch live). Students join from a notification or this page.' }) + (stIsStaff() ? stNav('/studio/live') : '') +
      '<div class="card">' + (list.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Activity</th><th>Course</th><th>Started</th><th>Responses</th><th></th></tr></thead><tbody>' + list.map((x) => '<tr><td><b>' + esc(x.title) + '</b></td><td>' + esc(x.course) + '</td><td class="small">' + esc(rel(x.startedAt)) + '</td><td class="tnum">' + x.responses + '</td><td>' + (x.open ? '<a class="btn btn-sm btn-primary" href="#/studio/live/' + esc(x.id) + '">' + (x.teacher ? 'Open console' : 'Join') + '</a>' : badge('Ended')) + '</td></tr>').join('') + '</tbody></table></div>'
        : '<div class="card-body">' + emptyState('live', 'No live activities', stIsStaff() ? 'Open a quiz or poll in the Studio and choose Launch live.' : 'When your teacher starts one, it appears here and in your notifications.', '', false) + '</div>') + '</div>'
  };
}
async function viewStLive(id) {
  const r = await call('stLiveState', { id });
  S.onLeave = () => { clearInterval(ST.liveTimer); ST.liveTimer = null; };
  ST.liveTimer = setInterval(async () => { try { const x = await call('stLiveState', { id }); const box = $('#stLive'); if (box && JSON.stringify(x) !== ST.liveLast) { ST.liveLast = JSON.stringify(x); box.innerHTML = stLiveHtml(x); } } catch (e) { /* keep trying */ } }, 2000);
  ST.liveLast = JSON.stringify(r);
  return { title: 'Live: ' + r.title, html: pageHead(r.title, { crumbs: [['Studio', '/studio'], ['Live', '/studio/live'], [r.title]], sub: r.teacher ? 'Teacher console — results update every two seconds.' : 'Live class activity' }) + '<div id="stLive" aria-live="polite">' + stLiveHtml(r) + '</div>' };
}
function stLiveHtml(r) {
  if (!r.open && !r.teacher) return '<div class="card card-pad">' + emptyState('checkCircle', 'This activity has ended', 'Thank you for taking part.', '', false) + '</div>';
  const q = r.question;
  if (!q) return '';
  const res = r.results;
  let body = '<div class="card st-live"><div class="card-body"><div class="row"><span class="xs muted">Question ' + (r.index + 1) + ' of ' + r.total + '</span><span class="spacer"></span>' + (r.open ? badge('Live', 'danger', 'live') : badge('Ended')) + '</div><h2 class="st-live-q">' + esc(q.text) + '</h2>';
  if (q.type === 'short') {
    if (!r.teacher) body += r.mine ? notice('Answer received: <b>' + esc(r.mine.answer) + '</b>', 'ok') : '<form data-form="stLiveShort" class="row"><input type="text" name="a" maxlength="200" autofocus aria-label="Your answer"><button class="btn btn-primary">Send</button></form>';
    if (res && res.words) body += '<div class="st-cloud">' + res.words.map((w) => '<span style="font-size:' + Math.min(44, 13 + w.n * 5) + 'px">' + esc(w.w) + '</span>').join(' ') + '</div>';
  } else {
    body += '<div class="st-live-opts">' + q.options.map((o, i) => {
      const n = res ? res.counts[i] || 0 : 0, pctv = res && res.responses ? Math.round(n / res.responses * 100) : 0;
      const isRight = q.correct != null && (Array.isArray(q.correct) ? q.correct.indexOf(i) >= 0 : Number(q.correct) === i) && (r.reveal || r.teacher);
      const mine = r.mine && (Array.isArray(r.mine.answer) ? r.mine.answer.indexOf(i) >= 0 : Number(r.mine.answer) === i);
      return r.teacher || r.reveal ? '<div class="st-live-bar' + (isRight && r.reveal ? ' right' : '') + (mine ? ' mine' : '') + '"><span class="st-live-fill" style="width:' + pctv + '%"></span><span class="st-live-lbl">' + 'ABCDEF'.charAt(i) + '. ' + esc(o) + (isRight ? ' ' + icon('checkCircle', 'i-sm') : '') + '</span><b>' + (res ? n + ' · ' + pctv + '%' : '') + '</b></div>'
        : '<button class="st-opt big' + (mine ? ' chosen' : '') + '" data-act="stLiveAns" data-i="' + i + '" aria-pressed="' + !!mine + '">' + 'ABCDEF'.charAt(i) + '. ' + esc(o) + '</button>';
    }).join('') + '</div>';
    if (!r.teacher && r.mine && !r.reveal) body += '<p class="small muted">' + icon('check', 'i-sm') + ' Answer received — you can change it until the teacher reveals the answer.</p>';
    if (r.reveal && q.explanation) body += notice(esc(q.explanation), 'ok');
  }
  if (r.teacher) {
    body += '<div class="st-live-stats small muted">' + (res ? res.responses + ' of ' + res.enrolled + ' students answered · ' + (q.type !== 'short' && q.correct != null ? res.correct + ' correct · ' : '') + 'average ' + Math.round(res.avgMs / 1000) + 's · ' + r.participants + ' taking part' : '') + '</div>' +
      '<div class="form-actions st-live-ctl"><button class="btn" data-act="stLiveCtl" data-a="prev"' + (r.index === 0 ? ' disabled' : '') + '>' + icon('left') + 'Previous</button>' + (r.reveal ? '<button class="btn" data-act="stLiveCtl" data-a="hide">Hide answer</button>' : '<button class="btn" data-act="stLiveCtl" data-a="reveal">' + icon('eye') + 'Reveal answer</button>') +
      (r.index < r.total - 1 ? '<button class="btn btn-primary" data-act="stLiveCtl" data-a="next">Next question' + icon('right') + '</button>' : '') + (r.open ? '<button class="btn btn-danger" data-act="stLiveCtl" data-a="close">End activity</button>' : '') + '</div>';
  }
  return body + '</div></div>';
}
ACT.stLiveAns = (d) => busy(null, async () => { const id = currentPath().split('/').pop(); const x = await call('stLiveAnswer', { id, answer: Number(d.i) }); $('#stLive').innerHTML = stLiveHtml(x); ST.liveLast = JSON.stringify(x); });
FORMS.stLiveShort = (f, btn) => busy(btn, async () => { const id = currentPath().split('/').pop(); const x = await call('stLiveAnswer', { id, answer: f.elements.a.value }); $('#stLive').innerHTML = stLiveHtml(x); });
ACT.stLiveCtl = (d, btn) => busy(btn, async () => { if (d.a === 'close' && !await confirmBox('End this activity?', '<p>Students can no longer answer. Results are kept.</p>', 'End activity')) return; const id = currentPath().split('/').pop(); const x = await call('stLiveControl', { id, action: d.a }); $('#stLive').innerHTML = stLiveHtml(x); ST.liveLast = JSON.stringify(x); });

/* =====================================================================
   ANALYTICS
   ===================================================================== */
async function viewStAnalytics(params) {
  const scope = params.get('scope') || 'me';
  const [r, st] = await Promise.all([call('stAnalytics', { scope, days: params.get('days') || 90 }), call('stSettings')]);
  const k = r.kpis;
  const scopes = [['me', 'My content']].concat(st.grants.reviewer || st.grants.acad ? [['department', 'Department']] : []).concat(st.grants.acad ? [['institution', 'Institution']] : []);
  const tile = (ico, tone, v, l) => statCard(ico, tone, v, l);
  return {
    title: 'Content analytics',
    html: pageHead('Academic content analytics', { crumbs: [['Studio', '/studio'], ['Analytics']], sub: 'Creation, use and engagement over the last ' + (params.get('days') || 90) + ' days.', actions: '<div class="pills">' + scopes.map((s) => '<a class="pill' + (s[0] === scope ? ' active' : '') + '" href="#/studio/analytics?scope=' + s[0] + '">' + s[1] + '</a>').join('') + '</div>' }) + stNav('/studio/analytics') +
      '<div class="grid-4 st-kpis">' + tile('layers', 'indigo', k.items, 'Content items') + tile('send', 'green', k.published, 'Published to courses') + tile('eye', 'blue', k.views + ' / ' + k.viewers, 'Views / unique viewers') + tile('live', 'pink', k.liveResponses, 'Live responses' + (k.liveResponses ? ' (' + Math.round(k.liveCorrect / k.liveResponses * 100) + '% correct)' : '')) +
      tile('sparkle', 'violet', k.aiRequests, 'AI requests') + tile('activity', 'amber', k.aiTokens.toLocaleString(), 'AI tokens' + (k.aiCost ? ' · ~$' + k.aiCost : '')) + tile('users', 'cyan', k.creators, 'Active creators') + tile('checkCircle', 'green', k.approved, 'Approved') + '</div>' +
      '<div class="grid-2"><section class="card"><div class="card-head"><h2>Content by type</h2></div><div class="card-body">' + (r.byKind.length ? hbars(r.byKind) : '<p class="small muted">No content yet.</p>') + '</div></section>' +
      '<section class="card"><div class="card-head"><h2>Most used resources</h2></div>' + (r.top.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Resource</th><th>Views</th><th>Viewers</th></tr></thead><tbody>' + r.top.map((x) => '<tr><td><a href="#/studio/edit/' + esc(x.id) + '">' + esc(x.title) + '</a><div class="xs muted">' + esc(x.kind) + '</div></td><td class="tnum">' + x.views + '</td><td class="tnum">' + x.viewers + '</td></tr>').join('') + '</tbody></table></div>' : '<div class="card-body small muted">No views yet. Publish content to a course.</div>') + '</section></div>' +
      '<section class="card"><div class="card-head"><h2>Outcome coverage</h2></div>' + (r.coverage.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Course</th><th>Outcomes covered</th><th>Not yet covered</th></tr></thead><tbody>' + r.coverage.map((c) => '<tr><td><b>' + esc(c.course) + '</b></td><td style="min-width:200px"><div class="row" style="gap:.5rem;align-items:center">' + '<div style="flex:1;min-width:100px">' + progressBar(Math.round(c.covered / c.total * 100)) + '</div><b class="small">' + c.covered + '/' + c.total + '</b></div></td><td class="small">' + (c.missing.length ? c.missing.map(esc).join(', ') : '—') + '</td></tr>').join('') + '</tbody></table></div>' : '<div class="card-body small muted">Add course outcomes under Outcomes & syllabus, then map content to them.</div>') + '</section>' +
      (r.aiByProvider.length ? '<section class="card"><div class="card-head"><h2>AI usage by provider</h2></div><div class="card-body">' + hbars(r.aiByProvider) + '<p class="xs muted">"builtin" is the offline generator (no external AI).</p></div></section>' : '') +
      (r.creators ? '<section class="card"><div class="card-head"><h2>Faculty adoption</h2></div><div class="table-wrap"><table class="table"><thead><tr><th>Faculty</th><th>Items</th><th>Published</th></tr></thead><tbody>' + r.creators.map((c) => '<tr><td>' + esc(c.name) + '</td><td class="tnum">' + c.items + '</td><td class="tnum">' + c.published + '</td></tr>').join('') + '</tbody></table></div><div class="card-body xs muted">Listed alphabetically — activity, not a ranking.</div></section>' : '') +
      (r.storageMb != null ? '<p class="small muted">Studio image storage: ' + r.storageMb + ' MB.</p>' : '')
  };
}

/* =====================================================================
   OUTCOMES & SYLLABUS (per course)
   ===================================================================== */
async function viewStOutcomes(params) {
  const courses = (await call('stCourses')).courses.filter((c) => c.editor);
  ST.courses = null;
  const c = courses.find((x) => x.id === params.get('course')) || courses[0];
  if (!c) return { title: 'Outcomes & syllabus', html: pageHead('Outcomes & syllabus', { crumbs: [['Studio', '/studio'], ['Outcomes']] }) + stNav('/studio/outcomes') + '<div class="card card-pad">' + emptyState('book', 'No courses', 'You can map outcomes for courses you teach.', '', false) + '</div>' };
  const list = (name, arr, prefix) => '<div class="st-oclist" data-name="' + name + '">' + (arr.length ? arr : [{ code: prefix + '1', text: '' }]).map((o) => '<div class="st-ocrow"><input type="text" class="st-occode" value="' + esc(o.code) + '" maxlength="12" aria-label="Code"><input type="text" class="st-octext" value="' + esc(o.text) + '" maxlength="600" aria-label="Outcome statement" placeholder="Students will be able to…"><button type="button" class="btn-icon sm" data-act="stOcDel" aria-label="Remove">' + icon('x') + '</button></div>').join('') + '</div><button type="button" class="btn btn-sm btn-ghost" data-act="stOcAdd" data-name="' + name + '" data-prefix="' + prefix + '">' + icon('plus', 'i-sm') + 'Add ' + prefix + '</button>';
  return {
    title: 'Outcomes & syllabus',
    html: pageHead('Outcomes & syllabus', { crumbs: [['Studio', '/studio'], ['Outcomes']], sub: 'Course outcomes, programme outcomes and units power outcome mapping, suggestions and coverage reports.' }) + stNav('/studio/outcomes') +
      '<div class="card"><div class="card-head"><select data-change="stOcCourse" aria-label="Course" style="max-width:420px">' + courses.map((x) => '<option value="' + esc(x.id) + '"' + (x.id === c.id ? ' selected' : '') + '>' + esc(x.shortname + ' · ' + x.fullname) + '</option>').join('') + '</select></div>' +
      '<form class="card-body" data-form="stOutcomes" data-course="' + esc(c.id) + '"><div class="form-grid-3">' + field('Programme', '<input type="text" name="programme" maxlength="160" value="' + esc(c.programme) + '" placeholder="e.g. B.Com Corporate Secretaryship">') + field('Semester', '<input type="text" name="semester" maxlength="20" value="' + esc(c.semester) + '">') + field('Department', '<input type="text" name="department" maxlength="80" value="' + esc(c.department) + '">') + '</div>' +
      '<h3 class="st-h3">Course outcomes (CO)</h3>' + list('co', c.co, 'CO') + '<h3 class="st-h3">Programme outcomes (PO)</h3>' + list('po', c.po, 'PO') + '<h3 class="st-h3">Programme-specific outcomes (PSO)</h3>' + list('pso', c.pso, 'PSO') +
      '<h3 class="st-h3">Units and topics</h3><div id="stUnits">' + (c.units.length ? c.units : [{ id: '', title: 'Unit I', topics: [] }]).map(stUnitRow).join('') + '</div><button type="button" class="btn btn-sm btn-ghost" data-act="stUnitAdd">' + icon('plus', 'i-sm') + 'Add unit</button>' +
      '<div class="form-actions"><button class="btn btn-primary" type="submit">Save</button></div></form></div>'
  };
}
function stUnitRow(u) { return '<fieldset class="fieldset st-unit"><input type="hidden" class="st-uid" value="' + esc(u.id || '') + '"><div class="row" style="gap:.5rem"><input type="text" class="st-utitle" value="' + esc(u.title) + '" maxlength="200" aria-label="Unit title"><button type="button" class="btn-icon sm" data-act="stUnitDel" aria-label="Remove unit">' + icon('x') + '</button></div>' + field('Topics (one per line)', '<textarea class="st-utopics" rows="3">' + esc((u.topics || []).join('\n')) + '</textarea>') + '</fieldset>'; }
ACT.stOcCourse = (d, el) => go('/studio/outcomes?course=' + encodeURIComponent(el.value));
ACT.stOcAdd = (d, el) => { const box = el.previousElementSibling; const n = box.children.length + 1; box.insertAdjacentHTML('beforeend', '<div class="st-ocrow"><input type="text" class="st-occode" value="' + d.prefix + n + '" maxlength="12" aria-label="Code"><input type="text" class="st-octext" maxlength="600" aria-label="Outcome statement" placeholder="Students will be able to…"><button type="button" class="btn-icon sm" data-act="stOcDel" aria-label="Remove">' + icon('x') + '</button></div>'); };
ACT.stOcDel = (d, el) => el.closest('.st-ocrow').remove();
ACT.stUnitAdd = () => $('#stUnits').insertAdjacentHTML('beforeend', stUnitRow({ title: 'Unit ' + ($$('.st-unit').length + 1), topics: [] }));
ACT.stUnitDel = (d, el) => el.closest('.st-unit').remove();
FORMS.stOutcomes = (f, btn) => busy(btn, async () => {
  const get = (name) => $$('.st-oclist[data-name="' + name + '"] .st-ocrow', f).map((r) => ({ code: $('.st-occode', r).value, text: $('.st-octext', r).value })).filter((o) => o.text.trim());
  await call('stSaveOutcomes', { courseId: f.dataset.course, programme: f.elements.programme.value, semester: f.elements.semester.value, department: f.elements.department.value, co: get('co'), po: get('po'), pso: get('pso'),
    units: $$('.st-unit', f).map((u) => ({ id: $('.st-uid', u).value, title: $('.st-utitle', u).value, topics: $('.st-utopics', u).value.split('\n').map((x) => x.trim()).filter(Boolean) })) });
  ST.courses = null; toast('Outcomes and syllabus saved.');
});

/* =====================================================================
   SETTINGS (administrators): AI providers, policies, roles, brand kit, templates
   ===================================================================== */
async function viewStSettings() {
  const r = await call('stSettings');
  if (!r.grants.admin) return { title: 'Studio settings', html: '<div class="card card-pad">' + emptyState('lock', 'Administrators only', '', '', false) + '</div>' };
  const st = r.settings, b = st.brand, tpl = await call('stTemplates');
  const sel = (name, people) => '<select name="' + name + '" multiple size="6">' + r.staff.map((u) => '<option value="' + esc(u.id) + '"' + (people.some((p) => p.id === u.id) ? ' selected' : '') + '>' + esc(u.name) + '</option>').join('') + '</select>';
  const fonts = [['sans', 'Sans serif (Segoe UI)'], ['serif', 'Serif (Georgia)'], ['display', 'Display'], ['mono', 'Monospace']];
  ST.brandDraft = Object.assign({}, b);
  return {
    title: 'Studio settings',
    html: pageHead('Academic Content Studio settings', { crumbs: [['Studio', '/studio'], ['Settings']] }) + stNav('/studio/settings') +
      '<form class="card card-pad" data-form="stSettings"><h3 class="st-h3" style="margin-top:0">AI providers</h3>' +
      '<div class="table-wrap"><table class="table"><thead><tr><th>Provider</th><th>Status</th><th>Model</th></tr></thead><tbody>' + r.providers.map((p) => '<tr><td>' + esc({ anthropic: 'Anthropic Claude', openai: 'OpenAI', google: 'Google Gemini', local: 'Local model (Ollama)' }[p.name]) + '</td><td>' + (p.ready ? badge('Connected', 'success') : badge('Not configured')) + '</td><td class="small">' + esc(p.model || '—') + '</td></tr>').join('') + '</tbody></table></div>' +
      '<p class="xs muted">Keys are set on the server (environment variables, or Site administration → Settings for Claude) and never sent to browsers. See STUDIO.md for the variables.</p>' +
      field('Provider to use', '<select name="provider">' + [['auto', 'Automatic (first connected provider)'], ['builtin', 'Built-in only (no external AI)'], ['anthropic', 'Anthropic Claude'], ['openai', 'OpenAI'], ['google', 'Google Gemini'], ['local', 'Local model']].map((o) => '<option value="' + o[0] + '"' + (st.provider === o[0] ? ' selected' : '') + '>' + o[1] + '</option>').join('') + '</select>', 'Now using: ' + esc(r.active)) +
      check('piiRedaction', 'Remove email addresses, phone numbers and student IDs before sending text to an external AI provider', st.piiRedaction) +
      check('aiNotice', 'Show “AI-generated content should be reviewed by the faculty member before publication”', st.aiNotice) +
      '<div class="form-grid">' + field('AI requests per faculty member per day', '<input type="number" name="limFac" min="0" max="5000" value="' + st.limits.faculty + '">') + field('AI requests per student per day', '<input type="number" name="limStu" min="0" max="1000" value="' + st.limits.student + '">') + '</div>' +
      '<h3 class="st-h3">Policies</h3>' + check('studentCreate', 'Students can use the Studio to create presentations, infographics, posters, concept maps and portfolios', st.studentCreate) + check('studentAI', 'Students can use the Academic Copilot (AI assistance)', st.studentAI) +
      check('requireApproval', 'Content must be approved before it is published to a course', st.requireApproval) + check('peerReview', 'Include a peer-review stage in the workflow', st.peerReview) + check('hodReview', 'Include an HOD review stage in the workflow', st.hodReview) + check('allowUrlImport', 'Allow importing public web pages', st.allowUrlImport) +
      '<p class="xs muted">AI never assigns grades in this release: AI feedback is a suggestion for the faculty member.</p>' +
      '<div class="form-grid-3">' + field('Published quiz time limit (min)', '<input type="number" name="qDur" min="1" max="600" value="' + st.quizDefaults.durationMin + '">') + field('Attempts allowed', '<input type="number" name="qAtt" min="0" max="50" value="' + st.quizDefaults.maxAttempts + '">') + field('After submitting, students see', '<select name="qRev"><option value="immediate"' + (st.quizDefaults.reviewMode === 'immediate' ? ' selected' : '') + '>Answers and explanations</option><option value="score"' + (st.quizDefaults.reviewMode === 'score' ? ' selected' : '') + '>Score only</option><option value="none"' + (st.quizDefaults.reviewMode === 'none' ? ' selected' : '') + '>Nothing</option></select>') + '</div>' +
      '<h3 class="st-h3">Roles</h3><div class="form-grid">' + field('Academic administrators', sel('acad', r.people.academicAdmins), 'Institutional templates, library approvals, curriculum mapping, usage.') + field('Reviewers', sel('rev', r.people.reviewers), 'In addition to the HODs set in Mentoring → Departments.') + '</div>' +
      '<div class="form-actions"><button class="btn btn-primary" type="submit">Save settings</button></div></form>' +
      '<form class="card card-pad" data-form="stBrand"><h3 class="st-h3" style="margin-top:0">Brand kit</h3><div class="form-grid">' + field('Institution name', '<input type="text" name="name" maxlength="120" value="' + esc(b.name) + '">') + field('Footer text', '<input type="text" name="footer" maxlength="200" value="' + esc(b.footer) + '" placeholder="e.g. Department of Commerce">') + '</div>' +
      '<div class="st-swatches">' + ['primary', 'accent', 'dark', 'light', 'muted'].map((k) => '<label class="st-swatch"><input type="color" name="' + k + '" value="' + esc(b[k]) + '"><span>' + k + '</span></label>').join('') + '</div>' +
      '<div class="form-grid">' + field('Heading font', '<select name="fontHead">' + fonts.map((f) => '<option value="' + f[0] + '"' + (b.fontHead === f[0] ? ' selected' : '') + '>' + f[1] + '</option>').join('') + '</select>') + field('Body font', '<select name="fontBody">' + fonts.map((f) => '<option value="' + f[0] + '"' + (b.fontBody === f[0] ? ' selected' : '') + '>' + f[1] + '</option>').join('') + '</select>') + '</div>' +
      field('Logo', (b.logoFileId ? '<img class="st-img st-logo" data-fid="' + esc(b.logoFileId) + '" alt="Current logo"> ' : '') + '<input type="file" name="logo" accept=".png,.jpg,.jpeg,.webp,.gif">', 'PNG or JPEG. Used on new templates and title slides.') +
      '<div class="form-actions"><button class="btn btn-primary" type="submit">Save brand kit</button></div></form>' +
      '<section class="card"><div class="card-head"><h2>Institutional templates</h2></div>' + (tpl.institutional.length ? '<div class="table-wrap"><table class="table"><tbody>' + tpl.institutional.map((t) => '<tr><td><b>' + esc(t.name) + '</b><div class="xs muted">' + esc(t.kindLabel) + ' · ' + esc(t.audience) + '</div></td><td class="actions"><button class="btn btn-sm btn-ghost" data-act="stTplDel" data-id="' + esc(t.id) + '">Remove</button></td></tr>').join('') + '</tbody></table></div>' : '<div class="card-body small muted">Open any design and choose ⋯ → Save as institutional template.</div>') + '</section>' +
      (r.aiLog.length ? '<section class="card"><div class="card-head"><h2>Recent AI calls</h2></div><div class="table-wrap"><table class="table"><thead><tr><th>When</th><th>Provider</th><th>Purpose</th><th>Tokens</th><th>Cost</th><th>Result</th></tr></thead><tbody>' + r.aiLog.map((x) => '<tr><td class="small nowrap">' + esc(rel(x.at)) + '</td><td class="small">' + esc(x.provider + ' · ' + x.model) + '</td><td class="small">' + esc(x.purpose) + '</td><td class="tnum">' + (x.inTokens + x.outTokens) + '</td><td class="tnum">$' + x.costUsd + '</td><td>' + (x.ok ? badge('OK', 'success') : badge('Failed', 'danger')) + '</td></tr>').join('') + '</tbody></table></div></section>' : ''),
    after: (root) => stHydrate(root)
  };
}
FORMS.stSettings = (f, btn) => busy(btn, async () => {
  const el = f.elements, multi = (s) => Array.from(s.selectedOptions).map((o) => o.value);
  await call('stSaveSettings', { provider: el.provider.value, piiRedaction: el.piiRedaction.checked, aiNotice: el.aiNotice.checked, studentCreate: el.studentCreate.checked, studentAI: el.studentAI.checked, requireApproval: el.requireApproval.checked, peerReview: el.peerReview.checked, hodReview: el.hodReview.checked, allowUrlImport: el.allowUrlImport.checked,
    limits: { faculty: el.limFac.value, student: el.limStu.value }, quizDefaults: { durationMin: el.qDur.value, maxAttempts: el.qAtt.value, reviewMode: el.qRev.value }, grants: { academicAdmins: multi(el.acad), reviewers: multi(el.rev) } });
  ST.tpl = null; toast('Settings saved.');
});
FORMS.stBrand = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  const p = { name: el.name.value, footer: el.footer.value, fontHead: el.fontHead.value, fontBody: el.fontBody.value };
  ['primary', 'accent', 'dark', 'light', 'muted'].forEach((k) => { p[k] = el[k].value; });
  if (el.logo.files[0]) { const up = await uploadFile(el.logo.files[0]); const a = await call('stAsset', { fileId: up.id, brand: true }); p.logoFileId = a.id; }
  await call('stSaveBrand', p); ST.tpl = null; toast('Brand kit saved.'); refresh();
});
ACT.stTplDel = (d, btn) => busy(btn, async () => { await call('stSaveTemplate', { remove: d.id }); ST.tpl = null; refresh(); });

/* ---------- Studio content inside a course activity ---------- */
async function stModuleBody(r) {
  try { return '<div class="st-inmod">' + await stViewerHtml(r.module.studioId, { moduleId: r.module.id }) + '</div>' + (r.module.description ? descCard(r.module) : ''); }
  catch (e) { return notice(esc(e.message), 'err'); }
}
