'use strict';
/* =====================================================================
   ACADEMIC CONTENT STUDIO — EDITORS
   Canvas editor (presentations, infographics, posters, maps…), document
   editor, quiz editor and flashcard editor, sharing the same top bar and the
   Details (outcomes) / Review (accessibility, AI, workflow, comments) panels.
   Autosaves (debounced) with a revision check, so two people editing the same
   item never silently overwrite each other; remote changes load automatically.
   ===================================================================== */
const ED_GRID = 8, ED_SNAP = 6;
let ED = null; // state of the open editor (also exposed as ST.ed for present/export)

let edPending = null;
async function viewStEdit(id) {
  if (edPending) { try { await edPending; } catch (er) { /* reported by edSave */ } edPending = null; }
  const [it] = await Promise.all([call('stGet', { id }), stTemplates()]);
  if (S.me.role === 'student' && !it.perms.edit) return viewStView(id, new URLSearchParams()); // students open others' work in the viewer
  if (!ST.brand) ST.brand = await call('stBrand');
  ED = ST.ed = { it, page: 0, sel: new Set(), zoom: 1, hist: [], fut: [], dirty: false, rev: it.rev, timer: null, poll: null, panel: 'templates', rpanel: 'design', editing: null, clip: null };
  S.onLeave = edLeave;
  window.addEventListener('beforeunload', edUnload);
  document.addEventListener('keydown', edKey);
  ED.poll = setInterval(edPoll, 15000);
  const ro = !it.perms.edit;
  const body = it.format === 'canvas' ? edCanvasLayout(ro) : it.format === 'doc' ? edDocLayout(ro) : it.format === 'quiz' ? edQuizLayout(ro) : edCardsLayout(ro);
  return {
    title: it.title,
    html: '<div class="st-editor' + (ro ? ' is-ro' : '') + ' fmt-' + it.format + '" id="stEd">' + edTop(it, ro) + body + '</div>',
    after: () => { edAfterRender(); }
  };
}
function edLeave() { if (ED && ED.dirty) edPending = edSave(); else if (ED && ED.saving) edPending = ED.saving; clearInterval(ED && ED.poll); document.removeEventListener('keydown', edKey); window.removeEventListener('beforeunload', edUnload); ED = ST.ed = null; }
function edUnload(e) { if (ED && ED.dirty) { edSave(); e.preventDefault(); e.returnValue = ''; } }
function edAfterRender() {
  if (!ED) return;
  if (ED.it.format === 'canvas') { edFit(); edDraw(); edThumbs(); }
  edLeft(); edRight();
  stHydrate($('#stEd'));
}

/* ---------- top bar ---------- */
function edTop(it, ro) {
  const p = it.perms;
  const canvas = it.format === 'canvas';
  return '<header class="st-top"><a class="btn-icon" href="#/studio/library" aria-label="Back to the library">' + icon('arrowLeft') + '</a>' +
    '<input class="st-title" id="edTitle" value="' + esc(it.title) + '" maxlength="200" aria-label="Title"' + (ro ? ' readonly' : '') + ' data-input="edTitle" data-delay="500">' +
    '<span class="st-kindtag">' + esc(it.kindLabel) + '</span>' + stStatus(it.status) + (it.ai ? badge(it.ai.outline ? 'Outline' : (it.ai.reviewed ? 'AI · reviewed' : 'AI-generated'), it.ai.reviewed ? 'info' : 'warning', 'sparkle') : '') +
    '<span class="st-save" id="edSaveState" aria-live="polite">' + (ro ? 'View only' : 'Saved') + '</span><span class="spacer"></span>' +
    (ro ? '' : '<button class="btn-icon" data-act="edUndo" title="Undo (Ctrl+Z)" aria-label="Undo">' + icon('undo') + '</button><button class="btn-icon" data-act="edRedo" title="Redo (Ctrl+Y)" aria-label="Redo">' + icon('redo') + '</button>') +
    (canvas ? '<span class="st-zoom"><button class="btn-icon sm" data-act="edZoom" data-z="-1" aria-label="Zoom out">' + icon('minus') + '</button><button class="btn btn-sm btn-ghost" data-act="edZoom" data-z="0" id="edZoomLbl">Fit</button><button class="btn-icon sm" data-act="edZoom" data-z="1" aria-label="Zoom in">' + icon('plus') + '</button></span>' +
      '<button class="btn btn-sm" data-act="stPresent" data-editor="1">' + icon('monitor') + 'Present</button>' : '<a class="btn btn-sm" href="#/studio/view/' + esc(it.id) + '">' + icon('eye') + 'Preview</a>') +
    (it.format === 'quiz' && stIsStaff() ? '<button class="btn btn-sm" data-act="edLive">' + icon('live') + 'Launch live</button>' : '') +
    '<button class="btn btn-sm" data-act="edRight" data-p="review" title="Comments, review and accessibility">' + icon('message') + 'Review' + (it.comments.filter((c) => !c.resolved).length ? '<span class="count">' + it.comments.filter((c) => !c.resolved).length + '</span>' : '') + '</button>' +
    (p.share ? '<button class="btn btn-sm" data-act="edShare">' + icon('users') + 'Share</button>' : '') +
    '<div class="menu-wrap"><button class="btn btn-sm" data-act="menu">' + icon('download') + 'Export</button><div class="menu">' +
    (canvas ? '<button class="menu-item" data-act="edExport" data-f="pdf">' + icon('printer') + 'PDF (print)</button><button class="menu-item" data-act="edExport" data-f="png">' + icon('image') + 'PNG — this page</button><button class="menu-item" data-act="edExport" data-f="pngall">' + icon('image') + 'PNG — all pages</button><button class="menu-item" data-act="edExport" data-f="jpg">' + icon('image') + 'JPG — this page</button><button class="menu-item" data-act="edExport" data-f="pptx">' + icon('monitor') + 'PowerPoint (.pptx)</button>' : '<button class="menu-item" data-act="edExport" data-f="pdf">' + icon('printer') + 'PDF (print)</button>') +
    '<button class="menu-item" data-act="edExport" data-f="docx">' + icon('file') + 'Word (.docx)</button>' + (it.format === 'quiz' || it.format === 'cards' ? '<button class="menu-item" data-act="edExport" data-f="csv">' + icon('table') + 'CSV</button>' : '') + '</div></div>' +
    '<div class="menu-wrap"><button class="btn-icon" data-act="menu" aria-label="More actions">' + icon('more') + '</button><div class="menu">' +
    '<button class="menu-item" data-act="edVersions">' + icon('history') + 'Version history</button>' + (ro ? '' : '<button class="menu-item" data-act="edSaveVersion">' + icon('flag') + 'Save a named version</button>') +
    '<button class="menu-item" data-act="stDup" data-id="' + esc(it.id) + '">' + icon('copy') + 'Make a copy</button>' + (stIsStaff() ? '<div class="menu-sep"></div><button class="menu-item" data-act="edTransform">' + icon('sparkle') + 'Transform into…</button>' : S.me.role === 'student' ? '<button class="menu-item" data-act="edTransform">' + icon('sparkle') + 'Transform into…</button>' : '') +
    (p.template ? '<button class="menu-item" data-act="edAsTemplate">' + icon('template') + 'Save as institutional template</button>' : '') + (it.published.length && stIsStaff() ? '<button class="menu-item" data-act="edInsights">' + icon('trending') + 'Learning insights</button>' : '') +
    (p.owner ? '<div class="menu-sep"></div><button class="menu-item" data-act="edArchive">' + icon('folder') + (it.status === 'archived' ? 'Restore from archive' : 'Archive') + '</button><button class="menu-item danger" data-act="edDelete">' + icon('trash') + 'Move to trash</button>' : '') + '</div></div>' +
    (stIsStaff() && p.edit ? '<button class="btn btn-sm btn-primary" data-act="edPublish">' + icon('send') + 'Publish to course</button>' : S.me.role === 'student' && p.owner ? '<button class="btn btn-sm btn-primary" data-act="edSubmitWork">' + icon('send') + 'Submit to assignment</button>' : '') + '</header>' +
    (it.source && it.source.outdated ? notice('The source "' + esc(it.source.title) + '" changed after this was generated. <a href="#/studio/edit/' + esc(it.source.id) + '">Open the source</a> to compare.' + (p.edit ? ' <button class="link" data-act="edSourceOk">I have updated this — dismiss</button>' : ''), 'warn', 'refresh') : '') +
    (it.ai && !it.ai.reviewed && it.aiNotice ? '<div class="st-ainote">' + icon('sparkle', 'i-sm') + ' AI-generated content should be reviewed by the faculty member before publication. Check facts, references, citations, legal provisions, statistics, dates and terminology.' + (p.edit ? ' <label class="check inline"><input type="checkbox" data-change="edAiOk"><span>I have reviewed and verified this content</span></label>' : '') + '</div>' : '');
}

/* =====================================================================
   CANVAS EDITOR
   ===================================================================== */
const ED_TABS = [['templates', 'Templates', 'template'], ['elements', 'Elements', 'layers'], ['text', 'Text', 'text'], ['images', 'Images', 'image'], ['charts', 'Charts', 'chart'], ['tables', 'Tables', 'table'], ['icons', 'Icons', 'smile'], ['diagrams', 'Diagrams', 'split'], ['ai', 'AI', 'sparkle'], ['brand', 'Brand kit', 'award'], ['layers', 'Layers', 'list']];
function edCanvasLayout(ro) {
  return '<div class="st-body">' + (ro ? '' : '<aside class="st-left"><nav class="st-rail" aria-label="Insert">' + ED_TABS.map((t) => '<button class="st-railbtn' + (t[0] === ED.panel ? ' active' : '') + '" data-act="edPanel" data-p="' + t[0] + '" title="' + t[1] + '">' + icon(t[2]) + '<span>' + t[1] + '</span></button>').join('') + '</nav><div class="st-lpanel" id="edLeft"></div></aside>') +
    '<main class="st-center"><div class="st-stage" id="edStage" tabindex="-1"><div class="st-pagewrap" id="edWrap"><div id="edPage"></div><div class="st-overlay" id="edOverlay"></div></div></div>' +
    '<div class="st-strip" id="edStrip"></div></main><aside class="st-right"><div class="st-rtabs" role="tablist">' + [['design', 'Design'], ['details', 'Details'], ['review', 'Review']].map((t) => '<button role="tab" class="st-rtab' + (ED.rpanel === t[0] ? ' active' : '') + '" data-act="edRight" data-p="' + t[0] + '">' + t[1] + '</button>').join('') + '</div><div id="edRight" class="st-rpanel"></div></aside></div>';
}
const edPg = () => ED.it.pages[ED.page];
const edEls = () => edPg().elements;
const edGet = (id) => edEls().find((e) => e.id === id);
const edSelEls = () => edEls().filter((e) => ED.sel.has(e.id));
function edUid() { return 'e' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function edFit() {
  const st = $('#edStage'); if (!st) return;
  const it = ED.it;
  if (ED.fit !== false) ED.zoom = Math.max(0.1, Math.min(2, (st.clientWidth - 64) / it.size.w, (st.clientHeight - 48) / it.size.h));
  const w = $('#edWrap'); w.style.width = it.size.w * ED.zoom + 'px'; w.style.height = it.size.h * ED.zoom + 'px';
  $('#edPage').style.transform = 'scale(' + ED.zoom + ')'; $('#edOverlay').style.transform = 'scale(' + ED.zoom + ')';
  $('#edPage').style.width = $('#edOverlay').style.width = it.size.w + 'px'; $('#edPage').style.height = $('#edOverlay').style.height = it.size.h + 'px';
  if ($('#edZoomLbl')) $('#edZoomLbl').textContent = Math.round(ED.zoom * 100) + '%';
}
window.addEventListener('resize', () => { if (ED && ED.it.format === 'canvas' && $('#edStage')) { edFit(); edOverlay(); } });
function edDraw() {
  const pg = edPg(); if (!pg) return;
  $('#edPage').innerHTML = stPageHtml(ED.it, pg, 'st-edit-page');
  stHydrate($('#edPage'));
  edOverlay();
}
function edOverlay(guides) {
  const ov = $('#edOverlay'); if (!ov) return;
  const els = edSelEls();
  let h = '';
  if (els.length) {
    const b = edBox(els);
    const one = els.length === 1 && !els[0].locked;
    h += '<div class="st-selbox" style="left:' + b.x + 'px;top:' + b.y + 'px;width:' + b.w + 'px;height:' + b.h + 'px;border-width:' + (1.5 / ED.zoom) + 'px">' +
      (one ? ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'].map((d) => '<span class="st-h st-h-' + d + '" data-h="' + d + '" style="width:' + 10 / ED.zoom + 'px;height:' + 10 / ED.zoom + 'px;margin:' + (-5 / ED.zoom) + 'px"></span>').join('') : '') + '</div>';
  }
  (guides || []).forEach((g) => { h += g.v ? '<div class="st-guide v" style="left:' + g.p + 'px;width:' + 1 / ED.zoom + 'px"></div>' : '<div class="st-guide" style="top:' + g.p + 'px;height:' + 1 / ED.zoom + 'px"></div>'; });
  ov.innerHTML = h;
}
function edBox(els) {
  const x = Math.min(...els.map((e) => e.x)), y = Math.min(...els.map((e) => e.y));
  return { x, y, w: Math.max(...els.map((e) => e.x + e.w)) - x, h: Math.max(...els.map((e) => e.y + e.h)) - y };
}
let edThumbTimer = null;
function edThumbs(now) {
  clearTimeout(edThumbTimer);
  const run = () => {
    const strip = $('#edStrip'); if (!strip || !ED) return;
    const ro = !ED.it.perms.edit;
    strip.innerHTML = ED.it.pages.map((p, i) => '<div class="st-pthumb' + (i === ED.page ? ' active' : '') + '"><button class="st-pthumb-btn" data-act="edGoPage" data-i="' + i + '" aria-label="Page ' + (i + 1) + '">' + stThumb(ED.it, p, 132) + '</button><span class="st-pnum">' + (i + 1) + '</span>' +
      (ro ? '' : '<span class="st-pacts"><button class="btn-icon sm" data-act="edPageOp" data-op="up" data-i="' + i + '" title="Move earlier" aria-label="Move page earlier">' + icon('left') + '</button><button class="btn-icon sm" data-act="edPageOp" data-op="dup" data-i="' + i + '" title="Duplicate page" aria-label="Duplicate page">' + icon('copy') + '</button><button class="btn-icon sm" data-act="edPageOp" data-op="del" data-i="' + i + '" title="Delete page" aria-label="Delete page">' + icon('trash') + '</button><button class="btn-icon sm" data-act="edPageOp" data-op="down" data-i="' + i + '" title="Move later" aria-label="Move page later">' + icon('right') + '</button></span>') + '</div>').join('') +
      (ro ? '' : '<button class="st-addpage" data-act="edPageOp" data-op="add" aria-label="Add page">' + icon('plus') + '<span>Page</span></button>');
    stHydrate(strip);
  };
  if (now) run(); else edThumbTimer = setTimeout(run, 500);
}

/* ---------- history, autosave ---------- */
function edSnap() { return JSON.stringify(ED.it.format === 'canvas' ? ED.it.pages : ED.it.format === 'doc' ? ED.it.doc : ED.it.format === 'quiz' ? ED.it.questions : ED.it.cards); }
function edPush() { ED.hist.push(edSnap()); if (ED.hist.length > 120) ED.hist.shift(); ED.fut = []; }
function edApplySnap(s) { const v = JSON.parse(s); if (ED.it.format === 'canvas') { ED.it.pages = v; ED.page = Math.min(ED.page, v.length - 1); } else if (ED.it.format === 'doc') ED.it.doc = v; else if (ED.it.format === 'quiz') ED.it.questions = v; else ED.it.cards = v; }
function edChanged(opts) {
  opts = opts || {};
  ED.dirty = true;
  const s = $('#edSaveState'); if (s) s.textContent = 'Editing…';
  clearTimeout(ED.timer); ED.timer = setTimeout(edSave, 1500);
  if (ED.it.format === 'canvas') { if (opts.draw !== false) edDraw(); edThumbs(); if (opts.right !== false) edRight(); }
}
ACT.edUndo = () => { if (!ED || !ED.hist.length) return; ED.fut.push(edSnap()); edApplySnap(ED.hist.pop()); ED.sel.clear(); edRerender(); edChanged(); };
ACT.edRedo = () => { if (!ED || !ED.fut.length) return; ED.hist.push(edSnap()); edApplySnap(ED.fut.pop()); ED.sel.clear(); edRerender(); edChanged(); };
function edRerender() { if (ED.it.format === 'doc') { const t = $('#edDoc'); if (t) t.value = ED.it.doc; edDocPreview(); } else if (ED.it.format === 'quiz') $('#edQ').innerHTML = edQuizList(); else if (ED.it.format === 'cards') $('#edC').innerHTML = edCardsList(); }
async function edSave(note) {
  const ed = ED; // the editor may be closed or reopened while this save is in flight
  if (!ed) return;
  if (!ed.dirty && !note) return ed.saving;
  const it = ed.it;
  clearTimeout(ed.timer);
  ed.dirty = false;
  const live = () => ED === ed;
  if (live() && $('#edSaveState')) $('#edSaveState').textContent = 'Saving…';
  const p = { id: it.id, rev: ed.rev, title: it.title, versionNote: note || '' };
  if (it.format === 'canvas') { p.pages = it.pages; p.size = it.size; } else if (it.format === 'doc') p.doc = it.doc; else if (it.format === 'quiz') p.questions = it.questions; else p.cards = it.cards;
  ed.saving = (async () => {
    try {
      const r = await run('api', S.token, 'stSave', p);
      ed.rev = r.rev;
      if (live() && $('#edSaveState')) $('#edSaveState').textContent = ed.dirty ? 'Editing…' : 'Saved ' + fmtTime(r.updatedAt);
    } catch (er) {
      if (/^CONFLICT/.test(er.message)) { toast(er.message.replace('CONFLICT: ', ''), 'err'); if (live()) go('/studio/edit/' + it.id); return; }
      ed.dirty = true;
      if (live()) { if ($('#edSaveState')) $('#edSaveState').textContent = 'Not saved — retrying'; clearTimeout(ed.timer); ed.timer = setTimeout(edSave, 5000); }
      if (!isExpired(er)) toast(er.message, 'err');
    }
  })();
  return ed.saving;
}
async function edPoll() {
  if (!ED || ED.dirty || ED.editing || ED.drag) return;
  try {
    const it = await run('api', S.token, 'stGet', { id: ED.it.id });
    if (!ED || it.rev === ED.rev || ED.dirty) return;
    const keepPage = ED.page;
    Object.assign(ED.it, it); ED.rev = it.rev; ED.page = Math.min(keepPage, (it.pages || [1]).length - 1);
    if (ED.it.format === 'canvas') { ED.sel.clear(); edDraw(); edThumbs(true); edRight(); } else edRerender();
    toast('Updated with ' + it.editor + '’s latest changes.');
  } catch (e) { /* offline — try later */ }
}

/* ---------- pointer interactions (move, resize, snapping) ---------- */
document.addEventListener('pointerdown', (e) => {
  if (!ED || ED.it.format !== 'canvas' || !ED.it.perms.edit) return;
  const stage = e.target.closest('#edStage');
  if (!stage || e.button !== 0) return;
  if (ED.editing && e.target.closest('.st-editing')) return;
  if (ED.editing) edEndText();
  const handle = e.target.closest('.st-h');
  const elDom = e.target.closest('.st-el');
  const pt = edPoint(e);
  if (handle) { edStartResize(e, handle.dataset.h, pt); return; }
  if (elDom) {
    let id = elDom.dataset.id; const el = edGet(id);
    if (el && el.g && !e.altKey) edEls().filter((x) => x.g === el.g).forEach((x) => ED.sel.add(x.id));
    if (e.shiftKey) { if (ED.sel.has(id) && !el.g) ED.sel.delete(id); else ED.sel.add(id); } else if (!ED.sel.has(id)) { ED.sel.clear(); ED.sel.add(id); if (el && el.g) edEls().filter((x) => x.g === el.g).forEach((x) => ED.sel.add(x.id)); }
    edOverlay(); edRight();
    if (el && !el.locked) edStartMove(e, pt);
    e.preventDefault();
    return;
  }
  if (e.target.closest('.st-selbox')) { edStartMove(e, pt); e.preventDefault(); return; }
  ED.sel.clear(); edOverlay(); edRight();
});
function edPoint(e) { const r = $('#edPage').getBoundingClientRect(); return { x: (e.clientX - r.left) / ED.zoom, y: (e.clientY - r.top) / ED.zoom }; }
function edSnapMove(b, dx, dy) {
  const it = ED.it, others = edEls().filter((x) => !ED.sel.has(x.id));
  const xs = [0, it.size.w / 2, it.size.w].concat(...others.map((o) => [o.x, o.x + o.w / 2, o.x + o.w]));
  const ys = [0, it.size.h / 2, it.size.h].concat(...others.map((o) => [o.y, o.y + o.h / 2, o.y + o.h]));
  const guides = [];
  const best = (cands, edges, d) => { let m = null; edges.forEach((ed) => cands.forEach((c) => { const diff = c - (ed + d); if (Math.abs(diff) <= ED_SNAP / ED.zoom && (!m || Math.abs(diff) < Math.abs(m.diff))) m = { diff, at: c }; })); return m; };
  const mx = best(xs, [b.x, b.x + b.w / 2, b.x + b.w], dx), my = best(ys, [b.y, b.y + b.h / 2, b.y + b.h], dy);
  if (mx) { dx += mx.diff; guides.push({ v: true, p: mx.at }); }
  if (my) { dy += my.diff; guides.push({ v: false, p: my.at }); }
  return { dx, dy, guides };
}
function edStartMove(e, start) {
  const els = edSelEls().filter((x) => !x.locked);
  if (!els.length) return;
  const orig = els.map((x) => ({ x: x.x, y: x.y })), b0 = edBox(els);
  let moved = false;
  ED.drag = true;
  const move = (ev) => {
    const p = edPoint(ev);
    let dx = p.x - start.x, dy = p.y - start.y;
    if (!moved && Math.abs(dx) + Math.abs(dy) < 2 / ED.zoom) return;
    if (!moved) { edPush(); moved = true; }
    const sn = ev.altKey ? { dx, dy, guides: [] } : edSnapMove(b0, dx, dy);
    els.forEach((x, i) => { x.x = Math.round(orig[i].x + sn.dx); x.y = Math.round(orig[i].y + sn.dy); const d = $('#edPage .st-el[data-id="' + CSS.escape(x.id) + '"]'); if (d) { d.style.left = x.x + 'px'; d.style.top = x.y + 'px'; } });
    edOverlay(sn.guides);
  };
  const up = () => { document.removeEventListener('pointermove', move); document.removeEventListener('pointerup', up); ED.drag = false; edOverlay(); if (moved) edChanged({ draw: false }); };
  document.addEventListener('pointermove', move); document.addEventListener('pointerup', up);
}
function edStartResize(e, dir, start) {
  const el = edSelEls()[0]; if (!el) return;
  const o = { x: el.x, y: el.y, w: el.w, h: el.h }, ratio = o.w / o.h;
  edPush(); ED.drag = true;
  const move = (ev) => {
    const p = edPoint(ev), dx = p.x - start.x, dy = p.y - start.y;
    let { x, y, w, h } = o;
    if (dir.indexOf('e') >= 0) w = o.w + dx;
    if (dir.indexOf('w') >= 0) { w = o.w - dx; x = o.x + dx; }
    if (dir.indexOf('s') >= 0) h = o.h + dy;
    if (dir.indexOf('n') >= 0) { h = o.h - dy; y = o.y + dy; }
    if ((ev.shiftKey || el.t === 'image' || el.t === 'icon') && dir.length === 2) { h = w / ratio; if (dir.indexOf('n') >= 0) y = o.y + o.h - h; }
    el.w = Math.max(8, Math.round(w)); el.h = Math.max(4, Math.round(h)); el.x = Math.round(Math.min(x, o.x + o.w - 8)); el.y = Math.round(Math.min(y, o.y + o.h - 4));
    const d = $('#edPage .st-el[data-id="' + CSS.escape(el.id) + '"]');
    if (d) { d.outerHTML = stElHtml(el); stHydrate($('#edPage')); }
    edOverlay();
  };
  const up = () => { document.removeEventListener('pointermove', move); document.removeEventListener('pointerup', up); ED.drag = false; edChanged(); };
  document.addEventListener('pointermove', move); document.addEventListener('pointerup', up);
}
/* ---------- text editing in place ---------- */
document.addEventListener('dblclick', (e) => {
  if (!ED || ED.it.format !== 'canvas' || !ED.it.perms.edit) return;
  const d = e.target.closest('#edPage .st-el'); if (!d) return;
  const el = edGet(d.dataset.id);
  if (!el || el.locked) return;
  if (el.t === 'text' || el.t === 'rect' || el.t === 'ellipse') edStartText(el, d);
  else if (el.t === 'table' || el.t === 'chart') { ED.rpanel = 'design'; edRight(); const ta = $('#edRight textarea'); if (ta) ta.focus(); }
});
function edStartText(el, d) {
  edPush();
  ED.editing = el.id;
  d.classList.add('st-editing');
  let t = d.querySelector('.st-text');
  if (!t) { d.insertAdjacentHTML('beforeend', '<div class="st-text st-mid"></div>'); t = d.querySelector('.st-text'); d.style.cssText += stTextCss(Object.assign({ fs: 20, color: '#1b1b1f', align: 'center' }, el)); }
  t.textContent = el.text || '';
  t.contentEditable = 'plaintext-only';
  if (t.contentEditable !== 'plaintext-only') t.contentEditable = 'true';
  t.focus();
  const r = document.createRange(); r.selectNodeContents(t); const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(r);
  t.addEventListener('blur', edEndText, { once: true });
}
function edEndText() {
  if (!ED || !ED.editing) return;
  const id = ED.editing; ED.editing = null;
  const d = $('#edPage .st-el[data-id="' + CSS.escape(id) + '"]');
  const el = edGet(id);
  if (d && el) { const t = d.querySelector('.st-text'); el.text = t ? t.innerText.replace(/\n$/, '') : el.text; }
  edChanged();
}

/* ---------- keyboard ---------- */
function edKey(e) {
  if (!ED) return;
  const typing = /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName) || document.activeElement.isContentEditable;
  const mod = e.ctrlKey || e.metaKey;
  if (mod && e.key.toLowerCase() === 's') { e.preventDefault(); edSave('Saved by ' + S.me.name); toast('Version saved.'); return; }
  if (typing || $('.modal-bg') || $('.st-present')) return;
  if (ED.it.format !== 'canvas' || !ED.it.perms.edit) { if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); ACT[e.shiftKey ? 'edRedo' : 'edUndo'](); } return; }
  const k = e.key.toLowerCase();
  if (mod && k === 'z') { e.preventDefault(); ACT[e.shiftKey ? 'edRedo' : 'edUndo'](); return; }
  if (mod && k === 'y') { e.preventDefault(); ACT.edRedo(); return; }
  if (mod && k === 'a') { e.preventDefault(); edEls().forEach((x) => ED.sel.add(x.id)); edOverlay(); edRight(); return; }
  if (mod && (k === 'c' || k === 'x')) { if (!ED.sel.size) return; e.preventDefault(); ED.clip = JSON.stringify(edSelEls()); try { localStorage.setItem('oq.stclip', ED.clip); } catch (er) { /* fine */ } if (k === 'x') ACT.edDelete(); return; }
  if (mod && k === 'v') { e.preventDefault(); let c = ED.clip; try { c = c || localStorage.getItem('oq.stclip'); } catch (er) { /* fine */ } if (c) edPaste(JSON.parse(c)); return; }
  if (mod && k === 'd') { e.preventDefault(); if (ED.sel.size) edPaste(edSelEls()); return; }
  if (mod && k === 'g') { e.preventDefault(); ACT[e.shiftKey ? 'edUngroup' : 'edGroup'](); return; }
  if (k === 'delete' || k === 'backspace') { if (ED.sel.size) { e.preventDefault(); ACT.edDelete(); } return; }
  if (k === 'escape') { ED.sel.clear(); edOverlay(); edRight(); return; }
  if (k === 'pageup' || k === 'pagedown') { e.preventDefault(); ACT.edGoPage({ i: ED.page + (k === 'pagedown' ? 1 : -1) }); return; }
  if (['arrowleft', 'arrowright', 'arrowup', 'arrowdown'].indexOf(k) >= 0 && ED.sel.size) {
    e.preventDefault(); edPush();
    const step = e.shiftKey ? 10 : 1;
    edSelEls().forEach((x) => { if (x.locked) return; if (k === 'arrowleft') x.x -= step; if (k === 'arrowright') x.x += step; if (k === 'arrowup') x.y -= step; if (k === 'arrowdown') x.y += step; });
    edChanged();
  }
}
function edPaste(list) {
  edPush();
  const map = {};
  ED.sel.clear();
  list.forEach((x) => { const c = JSON.parse(JSON.stringify(x)); c.id = edUid(); c.x += 16; c.y += 16; if (c.g) c.g = map[c.g] || (map[c.g] = 'g' + edUid()); edEls().push(c); ED.sel.add(c.id); });
  edChanged();
}
ACT.edDelete = () => { if (!ED.sel.size) return; edPush(); edPg().elements = edEls().filter((x) => !ED.sel.has(x.id) || x.locked); ED.sel.clear(); edChanged(); };
ACT.edGroup = () => { if (ED.sel.size < 2) return; edPush(); const g = 'g' + edUid(); edSelEls().forEach((x) => { x.g = g; }); edChanged(); toast('Grouped — Ctrl+Shift+G to ungroup.'); };
ACT.edUngroup = () => { if (!ED.sel.size) return; edPush(); edSelEls().forEach((x) => { delete x.g; }); edChanged(); };
ACT.edZoom = (d) => { if (Number(d.z) === 0) ED.fit = true; else { ED.fit = false; ED.zoom = Math.max(0.1, Math.min(3, ED.zoom * (Number(d.z) > 0 ? 1.2 : 1 / 1.2))); } edFit(); edOverlay(); };
ACT.edGoPage = (d) => { if (ED.editing) edEndText(); ED.page = Math.max(0, Math.min(ED.it.pages.length - 1, Number(d.i))); ED.sel.clear(); edDraw(); edThumbs(true); edRight(); };
ACT.edPageOp = (d) => {
  const P = ED.it.pages, i = d.i != null ? Number(d.i) : ED.page;
  edPush();
  if (d.op === 'add') { P.splice(ED.page + 1, 0, { id: 'p' + edUid(), bg: P[ED.page] ? P[ED.page].bg : '#fff', notes: '', elements: [] }); ED.page++; }
  if (d.op === 'dup') { const c = JSON.parse(JSON.stringify(P[i])); c.id = 'p' + edUid(); c.elements.forEach((x) => { x.id = edUid(); }); P.splice(i + 1, 0, c); ED.page = i + 1; }
  if (d.op === 'del') { if (P.length === 1) { toast('A design needs at least one page.', 'err'); ED.hist.pop(); return; } P.splice(i, 1); ED.page = Math.min(ED.page, P.length - 1); }
  if (d.op === 'up' && i > 0) { [P[i - 1], P[i]] = [P[i], P[i - 1]]; ED.page = i - 1; }
  if (d.op === 'down' && i < P.length - 1) { [P[i + 1], P[i]] = [P[i], P[i + 1]]; ED.page = i + 1; }
  ED.sel.clear(); edChanged(); edThumbs(true);
};
function edAdd(el, opts) {
  edPush();
  const it = ED.it;
  el.id = edUid();
  if (el.x == null) { el.x = Math.round((it.size.w - el.w) / 2); el.y = Math.round((it.size.h - el.h) / 2); }
  edEls().push(el);
  ED.sel.clear(); ED.sel.add(el.id);
  edChanged();
  if (!opts || !opts.quiet) { ED.rpanel = 'design'; edRight(); }
  return el;
}

/* ---------- left panel ---------- */
ACT.edPanel = (d) => { ED.panel = d.p; $$('.st-railbtn').forEach((b) => b.classList.toggle('active', b.dataset.p === d.p)); edLeft(); };
function edLeft() {
  if (!ED) return;
  if (ED.it.format !== 'canvas') { edLeftText(); return; }
  const box = $('#edLeft'); if (!box) return;
  const B = ST.brand || {};
  const P = ED.panel;
  let h = '<h3 class="st-ph">' + (ED_TABS.find((t) => t[0] === P) || ['', 'Insert'])[1] + '</h3>';
  if (P === 'templates') {
    const list = (ST.tpl.builtin || []).concat(ST.tpl.institutional || []).filter((t) => t.preview && t.preview.size.w === ED.it.size.w && t.preview.size.h === ED.it.size.h);
    h += '<p class="xs muted">Adds the template’s pages after the current page.</p><div class="st-ltpls">' + (list.length ? list.map((t) => '<button class="st-ltpl" data-act="edUseTpl" data-id="' + esc(t.id) + '" title="' + esc(t.name) + '">' + stThumb({ size: t.preview.size }, t.preview.page, 108) + '<span class="xs">' + esc(t.name) + '</span></button>').join('') : '<p class="small muted">No templates for this page size.</p>') + '</div>';
  } else if (P === 'elements') {
    const sh = [['rect', 'Rectangle', { t: 'rect', w: 240, h: 140, bg: B.light || '#e9eef8' }], ['round', 'Rounded', { t: 'rect', w: 240, h: 140, bg: B.light || '#e9eef8', radius: 18 }], ['circle', 'Circle', { t: 'ellipse', w: 140, h: 140, bg: B.primary || '#1f3a6e' }],
      ['card', 'Card', { t: 'rect', w: 280, h: 160, bg: '#ffffff', bc: '#d9dde6', bw: 1, radius: 14 }], ['line', 'Line', { t: 'line', w: 300, h: 2, bc: '#8a93a6', bw: 2 }], ['arrow', 'Arrow', { t: 'line', w: 220, h: 2, bc: B.primary || '#1f3a6e', bw: 3, arrow: true }],
      ['dashed', 'Dashed line', { t: 'line', w: 300, h: 2, bc: '#8a93a6', bw: 2, dash: true }], ['label', 'Label box', { t: 'rect', w: 200, h: 56, bg: B.primary || '#1f3a6e', radius: 28, text: 'Label', color: '#ffffff', fs: 18, fw: 700, align: 'center' }]];
    ED.shapes = Object.fromEntries(sh.map((s) => [s[0], s[2]]));
    h += '<div class="st-lgrid">' + sh.map((s) => '<button class="st-lshape" data-act="edAddShape" data-k="' + s[0] + '" title="' + s[1] + '">' + stThumb({ size: { w: 320, h: 200 } }, { bg: 'transparent', elements: [Object.assign({ id: 'x', x: 30, y: s[2].t === 'line' ? 100 : 30, w: s[2].t === 'line' ? 260 : 260, h: s[2].t === 'line' ? 2 : 140 }, s[2], s[2].t === 'ellipse' ? { x: 90, w: 140, h: 140 } : {})] }, 84) + '<span class="xs">' + s[1] + '</span></button>').join('') + '</div>';
  } else if (P === 'text') {
    const T = [['Title', 48, 700, B.fontHead || 'serif'], ['Heading', 32, 700, B.fontHead || 'serif'], ['Subheading', 22, 600, B.fontBody || 'sans'], ['Body text', 18, 400, B.fontBody || 'sans'], ['Bullet list', 20, 400, B.fontBody || 'sans', true], ['Quote', 24, 400, 'serif', false, true], ['Caption', 13, 400, B.fontBody || 'sans']];
    h += T.map((t, i) => '<button class="st-ltext" data-act="edAddText" data-i="' + i + '" style="font-family:' + ST_FONTS[t[3]] + ';font-size:' + Math.min(26, t[1] * 0.55 + 6) + 'px;font-weight:' + t[2] + (t[5] ? ';font-style:italic' : '') + '">' + t[0] + '</button>').join('');
    ED.texts = T;
  } else if (P === 'images') {
    h += '<label class="dropzone st-drop">' + icon('upload') + '<b>Upload an image</b><span class="xs">PNG, JPEG, GIF or WebP · 10 MB</span><input type="file" accept=".png,.jpg,.jpeg,.gif,.webp" data-change="edUpload"></label><div class="st-lgrid" id="edUploads"><p class="small muted">Loading your uploads…</p></div>' +
      '<button class="btn btn-sm" data-act="edAddShape" data-k="ph" style="margin-top:.5rem">' + icon('image', 'i-sm') + 'Image placeholder</button>';
    ED.shapes = Object.assign(ED.shapes || {}, { ph: { t: 'image', w: 320, h: 220, src: '', alt: '' } });
    setTimeout(edLoadUploads, 0);
  } else if (P === 'charts') {
    h += [['column', 'Column chart'], ['bar', 'Bar chart'], ['line', 'Line chart'], ['pie', 'Pie chart']].map((c) => '<button class="st-lrow" data-act="edAddChart" data-t="' + c[0] + '">' + icon('chart') + c[1] + '</button>').join('') + '<p class="xs muted">Edit the data in the Design panel.</p>';
  } else if (P === 'tables') {
    h += [[2, 2], [3, 3], [4, 3], [3, 5], [5, 4]].map((d) => '<button class="st-lrow" data-act="edAddTable" data-r="' + d[0] + '" data-c="' + d[1] + '">' + icon('table') + d[1] + ' columns × ' + d[0] + ' rows</button>').join('');
  } else if (P === 'icons') {
    const names = ['cap', 'book', 'users', 'user', 'chart', 'trending', 'target', 'award', 'checkCircle', 'alert', 'info', 'clock', 'calendar', 'building', 'layers', 'sparkle', 'zap', 'flag', 'shield', 'key', 'lock', 'mail', 'message', 'forum', 'monitor', 'video', 'mic', 'camera', 'image', 'file', 'folder', 'link', 'search', 'settings', 'pie', 'activity', 'smile', 'gavel', 'exam', 'sigma', 'globe' in ICONS ? 'globe' : 'compass'];
    h += '<div class="st-icons">' + names.filter((n) => ICONS[n]).map((n) => '<button class="st-licon" data-act="edAddIcon" data-n="' + n + '" title="' + n + '" aria-label="Icon ' + n + '">' + icon(n) + '</button>').join('') + '</div>';
  } else if (P === 'diagrams') {
    h += [['flow', 'Process flow (4 steps)'], ['cycle', 'Cycle (4 stages)'], ['hub', 'Hub and spokes'], ['compare', 'Comparison (2 columns)'], ['matrix', '2 × 2 matrix'], ['timeline', 'Timeline (5 points)']].map((x) => '<button class="st-lrow" data-act="edAddDiagram" data-k="' + x[0] + '">' + icon('split') + x[1] + '</button>').join('') + '<p class="xs muted">Diagrams are grouped shapes — double-click a box to edit its text; Ctrl+Shift+G ungroups.</p>';
  } else if (P === 'ai') h += edAiPanel();
  else if (P === 'brand') {
    h += '<div class="st-palette">' + ['primary', 'accent', 'dark', 'light', 'muted'].map((k) => '<button class="st-pal" data-act="edBrandColor" data-c="' + esc(B[k] || '#000') + '" style="background:' + esc(B[k] || '#000') + '" title="' + k + ' ' + esc(B[k] || '') + '" aria-label="Brand colour ' + k + '"></button>').join('') + '</div><p class="xs muted">Select an element, then a colour: fills shapes, colours text.</p>' +
      '<button class="st-lrow" data-act="edBrandFonts">' + icon('text') + 'Apply brand fonts to this page</button>' + (B.logoFileId ? '<button class="st-lrow" data-act="edBrandLogo">' + icon('image') + 'Insert logo</button>' : '<p class="small muted">No logo yet — administrators add it under Studio settings.</p>') +
      '<button class="st-lrow" data-act="edBrandFooter">' + icon('minus') + 'Add footer (' + esc(B.name || '') + ')</button>';
  } else if (P === 'layers') {
    const els = edEls().slice().reverse();
    h += els.length ? '<div class="st-layers">' + els.map((x) => '<div class="st-layer' + (ED.sel.has(x.id) ? ' active' : '') + '"><button class="st-layer-name" data-act="edSelect" data-id="' + esc(x.id) + '">' + icon({ text: 'text', rect: 'layers', ellipse: 'circle', line: 'minus', image: 'image', table: 'table', chart: 'chart', icon: 'smile' }[x.t] || 'layers', 'i-sm') + esc((x.text || x.alt || (x.chart && x.chart.title) || x.t).toString().slice(0, 28)) + (x.g ? ' ' + badge('group') : '') + '</button>' +
      '<button class="btn-icon sm" data-act="edLock" data-id="' + esc(x.id) + '" title="' + (x.locked ? 'Unlock' : 'Lock') + '" aria-label="' + (x.locked ? 'Unlock' : 'Lock') + '">' + icon(x.locked ? 'lock' : 'key') + '</button></div>').join('') + '</div>' : '<p class="small muted">No elements on this page.</p>';
  }
  box.innerHTML = h;
  stHydrate(box);
}
ACT.edSelect = (d) => { ED.sel.clear(); ED.sel.add(d.id); edOverlay(); edRight(); edLeft(); };
ACT.edLock = (d) => { const el = edGet(d.id); if (!el) return; edPush(); el.locked = !el.locked; edChanged(); edLeft(); };
ACT.edAddShape = (d) => { const s = ED.shapes[d.k]; if (s) edAdd(JSON.parse(JSON.stringify(s))); };
ACT.edAddText = (d) => { const t = ED.texts[Number(d.i)]; edAdd({ t: 'text', w: t[4] ? 520 : t[1] > 30 ? 700 : 520, h: Math.round(t[1] * (t[4] ? 4.6 : 1.5)), text: t[4] ? 'First point\nSecond point\nThird point' : t[0], fs: t[1], fw: t[2], ff: t[3], color: t[5] ? (ST.brand.primary || '#1f3a6e') : (ST.brand.dark || '#1b1b1f'), list: !!t[4], fi: !!t[5], align: 'left', lh: 1.35 }); };
ACT.edAddChart = (d) => edAdd({ t: 'chart', w: 420, h: 280, chart: { type: d.t, title: 'Chart title', labels: ['A', 'B', 'C', 'D'], values: [40, 65, 30, 80] } });
ACT.edAddTable = (d) => { const r = Number(d.r), c = Number(d.c); edAdd({ t: 'table', w: Math.min(ED.it.size.w - 80, c * 150), h: r * 40, fs: 14, header: true, rows: Array.from({ length: r }, (_, i) => Array.from({ length: c }, (__, j) => (i === 0 ? 'Heading ' + (j + 1) : ''))) }); };
ACT.edAddIcon = (d) => edAdd({ t: 'icon', w: 72, h: 72, icon: d.n, color: ST.brand.primary || '#1f3a6e' });
ACT.edAddDiagram = (d) => {
  const B = ST.brand, g = 'g' + edUid(), it = ED.it, cx = it.size.w / 2, cy = it.size.h / 2, out = [];
  const box = (x, y, w, h, text, fill, col) => out.push({ t: 'rect', x, y, w, h, bg: fill || '#fff', bc: B.primary, bw: 2, radius: 12, text, fs: 16, fw: 600, align: 'center', color: col || B.dark, g });
  const arrow = (x1, y1, x2, y2) => out.push({ t: 'line', x: Math.min(x1, x2), y: Math.min(y1, y2), w: Math.max(2, Math.abs(x2 - x1)), h: Math.max(2, Math.abs(y2 - y1)), flip: (x2 < x1) !== (y2 < y1), bc: B.accent, bw: 3, arrow: true, g });
  if (d.k === 'flow') { const w = 160, gap = 50, x0 = cx - (4 * w + 3 * gap) / 2; for (let i = 0; i < 4; i++) { box(x0 + i * (w + gap), cy - 40, w, 80, 'Step ' + (i + 1)); if (i < 3) arrow(x0 + i * (w + gap) + w + 4, cy, x0 + (i + 1) * (w + gap) - 6, cy); } }
  if (d.k === 'cycle') { const r = 150; for (let i = 0; i < 4; i++) { const a = -Math.PI / 2 + i * Math.PI / 2, x = cx + r * Math.cos(a), y = cy + r * Math.sin(a); box(x - 80, y - 32, 160, 64, 'Stage ' + (i + 1)); const b = a + Math.PI / 2; arrow(cx + r * 0.62 * Math.cos(a + 0.5), cy + r * 0.62 * Math.sin(a + 0.5), cx + r * 0.62 * Math.cos(b - 0.5), cy + r * 0.62 * Math.sin(b - 0.5)); } }
  if (d.k === 'hub') { out.push({ t: 'ellipse', x: cx - 90, y: cy - 50, w: 180, h: 100, bg: B.primary, text: 'Central idea', fs: 18, fw: 700, align: 'center', color: '#fff', g }); for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3, x = cx + 290 * Math.cos(a), y = cy + 170 * Math.sin(a); out.splice(0, 0, { t: 'line', x: Math.min(cx, x), y: Math.min(cy, y), w: Math.max(2, Math.abs(x - cx)), h: Math.max(2, Math.abs(y - cy)), flip: (x < cx) !== (y < cy), bc: B.accent, bw: 2, g }); box(x - 75, y - 26, 150, 52, 'Idea ' + (i + 1)); } }
  if (d.k === 'compare') { [0, 1].forEach((i) => { const x = cx - 330 + i * 340; box(x, cy - 160, 320, 56, i ? 'Option B' : 'Option A', B.primary, '#fff'); out.push({ t: 'rect', x, y: cy - 96, w: 320, h: 250, bg: '#fff', bc: '#d9dde6', bw: 1, radius: 12, text: '• Point\n• Point\n• Point', fs: 16, align: 'left', color: B.dark, g }); }); }
  if (d.k === 'matrix') { [[0, 0], [1, 0], [0, 1], [1, 1]].forEach(([i, j], n) => box(cx - 300 + i * 305, cy - 200 + j * 205, 295, 195, ['High / Low', 'High / High', 'Low / Low', 'Low / High'][n], n % 3 === 0 ? B.light : '#fff')); }
  if (d.k === 'timeline') { out.push({ t: 'rect', x: cx - 400, y: cy - 3, w: 800, h: 6, bg: B.accent, radius: 3, g }); for (let i = 0; i < 5; i++) { const x = cx - 400 + i * 200; out.push({ t: 'ellipse', x: x - 12, y: cy - 12, w: 24, h: 24, bg: B.primary, g }); out.push({ t: 'text', x: x - 80, y: cy + (i % 2 ? 24 : -82), w: 160, h: 56, text: 'Event ' + (i + 1) + '\nYear', fs: 15, fw: 600, align: 'center', color: B.dark, g }); } }
  edPush(); ED.sel.clear();
  out.forEach((e) => { e.id = edUid(); e.x = Math.round(e.x); e.y = Math.round(e.y); e.w = Math.round(e.w); e.h = Math.round(e.h); edEls().push(e); ED.sel.add(e.id); });
  edChanged();
};
ACT.edUseTpl = (d) => {
  const t = (ST.tpl.builtin || []).concat(ST.tpl.institutional || []).find((x) => x.id === d.id);
  if (!t) return;
  busy(null, async () => {
    // institutional templates and multi-page built-ins: fetch the full page set by creating nothing — the server builds it
    const full = await call('stTemplates');
    const src = full.builtin.concat(full.institutional).find((x) => x.id === d.id);
    edPush();
    const pg = JSON.parse(JSON.stringify(src.preview.page)); pg.id = 'p' + edUid(); pg.elements.forEach((e) => { e.id = edUid(); });
    ED.it.pages.splice(ED.page + 1, 0, pg); ED.page++;
    ED.sel.clear(); edChanged(); edThumbs(true);
  });
};
ACT.edUpload = (d, el) => {
  const f = el.files && el.files[0]; if (!f) return;
  busy(null, async () => {
    const up = await uploadFile(f);
    const a = await call('stAsset', { fileId: up.id });
    const img = await new Promise((res) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => res(null); im.src = URL.createObjectURL(f); });
    ST.img[a.id] = img ? img.src : '';
    const max = Math.min(ED.it.size.w * 0.6, ED.it.size.h * 0.7), r = img ? img.width / img.height : 1.5;
    const w = Math.round(r >= 1 ? max : max * r), h = Math.round(r >= 1 ? max / r : max);
    const sel = edSelEls()[0];
    if (sel && sel.t === 'image' && !sel.src) { edPush(); sel.src = a.id; sel.alt = sel.alt || ''; edChanged(); } else edAdd({ t: 'image', w, h, src: a.id, alt: '', fit: 'contain' });
    toast('Image added — add alternative text in the Design panel.');
    edLoadUploads();
  });
};
async function edLoadUploads() {
  const box = $('#edUploads'); if (!box) return;
  const list = await call('stAssets');
  box.innerHTML = list.length ? list.slice(0, 40).map((f) => '<button class="st-lup" data-act="edUseImg" data-id="' + esc(f.id) + '" title="' + esc(f.name) + '"><img class="st-img" data-fid="' + esc(f.id) + '" alt="' + esc(f.name) + '"></button>').join('') : '<p class="small muted">Your uploaded images appear here.</p>';
  stHydrate(box);
}
ACT.edUseImg = (d) => edAdd({ t: 'image', w: 320, h: 220, src: d.id, alt: '', fit: 'contain' });
ACT.edBrandColor = (d) => { if (!ED.sel.size) { toast('Select an element first.', 'err'); return; } edPush(); edSelEls().forEach((x) => { if (x.t === 'text' || x.t === 'icon') x.color = d.c; else if (x.t === 'line') x.bc = d.c; else if (x.t === 'table') x.hc = d.c; else x.bg = d.c; }); edChanged(); };
ACT.edBrandFonts = () => { edPush(); edEls().forEach((x) => { if (x.t === 'text' || x.text) x.ff = Number(x.fs) >= 26 ? ST.brand.fontHead : ST.brand.fontBody; }); edChanged(); };
ACT.edBrandLogo = () => edAdd({ t: 'image', x: ED.it.size.w - 180, y: 24, w: 150, h: 64, src: ST.brand.logoFileId, alt: (ST.brand.name || 'Institution') + ' logo', fit: 'contain' });
ACT.edBrandFooter = () => { const it = ED.it, B = ST.brand; edPush(); const g = 'g' + edUid(); [{ t: 'rect', x: 0, y: it.size.h - 6, w: it.size.w, h: 6, bg: B.accent, g }, { t: 'text', x: 24, y: it.size.h - 32, w: it.size.w - 48, h: 20, text: [B.name, B.footer].filter(Boolean).join(' · '), fs: 12, color: B.muted, ff: B.fontBody, g }].forEach((e) => { e.id = edUid(); edEls().push(e); }); edChanged(); };

/* ---------- AI panel (canvas and document editors) ---------- */
function edAiPanel() {
  const fmt = ED.it.format;
  return '<div class="st-aip">' +
    (fmt === 'canvas' ? '<form data-form="edAiPages"><label class="label" for="edAiPrompt">Generate pages</label><textarea id="edAiPrompt" name="prompt" rows="3" maxlength="2000" placeholder="e.g. 5 slides on the types of offers, with examples"></textarea><div class="row" style="gap:.4rem;margin-top:.4rem"><input type="number" name="n" min="1" max="20" value="5" aria-label="Number of pages" style="width:70px"><button class="btn btn-sm btn-primary">' + icon('sparkle', 'i-sm') + 'Add pages</button></div></form>'
      : '<form data-form="edAiDoc"><label class="label" for="edAiPrompt">Write a section</label><textarea id="edAiPrompt" name="prompt" rows="3" maxlength="2000" placeholder="e.g. A section on remedies for breach of contract with two examples"></textarea><button class="btn btn-sm btn-primary" style="margin-top:.4rem">' + icon('sparkle', 'i-sm') + 'Insert at cursor</button></form>') +
    '<div class="label" style="margin-top:1rem">Improve the selected text</div><div class="st-aibtns">' + [['simplify', 'Simplify'], ['expand', 'Expand'], ['academic', 'More academic'], ['friendly', 'Student-friendly'], ['structure', 'Improve structure'], ['grammar', 'Fix grammar'], ['examples', 'Add examples'], ['applications', 'Real-world applications'], ['summarize', 'Summarise']].map((m) => '<button class="btn btn-sm" data-act="edImprove" data-m="' + m[0] + '">' + m[1] + '</button>').join('') + '</div>' +
    '<div class="label" style="margin-top:1rem">Transform this ' + esc(ED.it.kindLabel.toLowerCase()) + ' into</div><div class="st-aibtns">' + ['notes', 'presentation', 'quiz', 'flashcards', 'infographic', 'case', 'discussion', 'assignment', 'revision', 'videoscript'].filter((k) => k !== ED.it.kind && (S.me.role !== 'student' || ['presentation', 'flashcards', 'infographic', 'revision', 'videoscript'].indexOf(k) >= 0)).map((k) => '<button class="btn btn-sm" data-act="edTransformTo" data-k="' + k + '">' + esc(stKindLabel(k)) + '</button>').join('') + '</div>' +
    '<p class="xs muted" style="margin-top:.8rem">The Copilot uses this content and your course outcomes. It does not follow instructions found inside your material, and everything it writes is marked for review.</p></div>';
}
FORMS.edAiPages = (f, btn) => busy(btn, async () => {
  const r = await call('stGenerate', { kind: ED.it.kind === 'infographic' || ED.it.kind === 'poster' ? ED.it.kind : 'presentation', prompt: f.elements.prompt.value, topic: f.elements.prompt.value, slides: Number(f.elements.n.value) + 1, courseId: ED.it.meta.courseId, unitId: ED.it.meta.unitId, preview: true, sourceText: ED.it.pages.length > 1 ? '' : '' });
  let pages = r.content.pages || [];
  if (pages.length > 1 && ED.it.kind !== 'infographic') pages = pages.slice(1); // skip the generated title slide
  const sw = ED.it.size.w / (r.content.size ? r.content.size.w : ED.it.size.w), sh = ED.it.size.h / (r.content.size ? r.content.size.h : ED.it.size.h);
  edPush();
  pages.forEach((pg) => { pg.id = 'p' + edUid(); pg.elements.forEach((e) => { e.id = edUid(); if (sw !== 1 || sh !== 1) { e.x = Math.round(e.x * sw); e.w = Math.round(e.w * sw); e.y = Math.round(e.y * sh); e.h = Math.round(e.h * sh); } }); });
  ED.it.pages.splice(ED.page + 1, 0, ...pages); ED.page += 1;
  edMarkAi(r.provider, r.outline);
  edChanged(); edThumbs(true);
  toast(pages.length + ' page(s) added' + (r.outline ? ' as an outline — complete the [bracketed] parts.' : '. Review them before publishing.'));
});
FORMS.edAiDoc = (f, btn) => busy(btn, async () => {
  const r = await call('stGenerate', { kind: 'document', prompt: f.elements.prompt.value, topic: f.elements.prompt.value, courseId: ED.it.meta.courseId, unitId: ED.it.meta.unitId, preview: true });
  edDocInsert('\n' + r.content.doc.replace(/^#\s.*\n/, '') + '\n');
  edMarkAi(r.provider, r.outline);
  toast(r.outline ? 'Outline inserted — complete the [bracketed] parts.' : 'Section inserted. Review it before publishing.');
});
function edMarkAi(provider, outline) { if (!ED.it.ai) ED.it.ai = { generated: true, provider, outline, reviewed: false }; else ED.it.ai.reviewed = false; }
ACT.edImprove = (d, btn) => {
  let text = '', apply;
  if (ED.it.format === 'doc') {
    const ta = $('#edDoc'); const a = ta.selectionStart, b = ta.selectionEnd;
    text = ta.value.slice(a, b);
    apply = (t) => { edPush(); ta.setRangeText(t, a, b, 'select'); ED.it.doc = ta.value; edChanged(); edDocPreview(); };
  } else {
    const el = edSelEls().find((x) => x.text);
    if (el) { text = el.text; apply = (t) => { edPush(); el.text = t; edChanged(); }; }
  }
  if (!text || !text.trim()) { toast(ED.it.format === 'doc' ? 'Select some text in the document first.' : 'Select a text box first.', 'err'); return; }
  busy(btn, async () => {
    const r = await call('stImprove', { mode: d.m, text });
    openModal(modalHead('Suggested rewrite', r.builtin ? 'Built-in rewrite (no AI provider connected) — basic rules only.' : 'AI-generated — review before keeping it.') + '<div class="modal-body"><div class="st-compare"><div><div class="xs muted">Before</div><div class="st-cmp-box">' + esc(text) + '</div></div><div><div class="xs muted">After</div><textarea id="edImpOut" class="st-cmp-box" rows="8">' + esc(r.text) + '</textarea></div></div>' +
      '<div class="form-actions"><button class="btn" data-act="close">Discard</button><button class="btn btn-primary" data-act="edImpApply">Use this</button></div></div>', 'wide');
    ED.impApply = apply;
  });
};
ACT.edImpApply = () => { const t = $('#edImpOut').value; closeModal(); if (ED.impApply) ED.impApply(t); };
ACT.edTransformTo = (d, btn) => busy(btn, async () => { await edSave(); const r = await call('stTransform', { id: ED.it.id, to: d.k }); toast(stKindLabel(d.k) + ' created' + (r.outline ? ' as an outline' : '') + '.'); go('/studio/edit/' + r.id); });
ACT.edTransform = () => { ED.panel = 'ai'; if (ED.it.format === 'canvas') ACT.edPanel({ p: 'ai' }); else { const b = $('#edLeft'); if (b) { edLeft(); b.scrollIntoView(); } } };

/* ---------- right panel: Design / Details / Review ---------- */
ACT.edRight = (d) => { ED.rpanel = d.p; $$('.st-rtab').forEach((b) => b.classList.toggle('active', b.dataset.p === d.p)); edRight(); const rp = $('#edRight'); if (rp && window.innerWidth < 1100) rp.scrollIntoView({ behavior: 'smooth' }); };
function edRight() {
  const box = $('#edRight'); if (!box || !ED) return;
  if (ED.rpanel === 'details') { box.innerHTML = edDetailsHtml(); return; }
  if (ED.rpanel === 'review') { box.innerHTML = edReviewHtml(); return; }
  if (ED.it.format !== 'canvas') { box.innerHTML = edDetailsHtml(); return; }
  const els = edSelEls(), ro = !ED.it.perms.edit;
  const inp = (k, label, val, type, attrs) => '<label class="st-prop"><span>' + label + '</span><input type="' + (type || 'number') + '" value="' + esc(val == null ? '' : val) + '" data-input="edProp" data-k="' + k + '" data-delay="250"' + (attrs || '') + (ro ? ' disabled' : '') + '></label>';
  const colorInp = (k, label, val) => '<label class="st-prop"><span>' + label + '</span><span class="row" style="gap:4px"><input type="color" value="' + esc(/^#[0-9a-f]{6}$/i.test(val || '') ? val : '#ffffff') + '" data-change="edPropC" data-k="' + k + '"' + (ro ? ' disabled' : '') + '>' + (k !== 'color' ? '<button class="btn-icon sm" data-act="edPropClear" data-k="' + k + '" title="None" aria-label="No ' + label + '">' + icon('x') + '</button>' : '') + '</span></label>';
  if (!els.length) {
    const pg = edPg();
    box.innerHTML = '<h3 class="st-ph">Page ' + (ED.page + 1) + ' of ' + ED.it.pages.length + '</h3>' + colorInp('pagebg', 'Background', pg.bg) +
      '<label class="st-prop col"><span>Speaker / teaching notes</span><textarea rows="6" data-input="edNotes" data-delay="400"' + (ro ? ' readonly' : '') + '>' + esc(pg.notes || '') + '</textarea></label>' +
      '<p class="xs muted">Size: ' + ED.it.size.w + ' × ' + ED.it.size.h + '. Tip: double-click text to edit; Shift-click to select several; Ctrl+G groups; arrows nudge; Alt while dragging turns snapping off.</p>';
    return;
  }
  const e = els[0], multi = els.length > 1;
  let h = '<h3 class="st-ph">' + (multi ? els.length + ' elements' : ({ text: 'Text', rect: 'Shape', ellipse: 'Shape', line: 'Line', image: 'Image', table: 'Table', chart: 'Chart', icon: 'Icon' }[e.t])) + '</h3>';
  if (!multi) h += '<div class="st-props2">' + inp('x', 'X', e.x) + inp('y', 'Y', e.y) + inp('w', 'Width', e.w) + inp('h', 'Height', e.h) + inp('rot', 'Rotate°', e.rot || 0) + inp('op', 'Opacity', e.op == null ? 1 : e.op, 'number', ' step="0.1" min="0" max="1"') + '</div>';
  const hasText = els.some((x) => x.t === 'text' || x.text != null);
  if (hasText) {
    h += '<div class="st-sub">Typography</div><div class="st-props2"><label class="st-prop"><span>Font</span><select data-change="edPropS" data-k="ff"' + (ro ? ' disabled' : '') + '>' + Object.keys(ST_FONTS).map((f) => '<option value="' + f + '"' + (e.ff === f ? ' selected' : '') + '>' + ({ sans: 'Sans', serif: 'Serif', display: 'Display', mono: 'Mono' }[f]) + '</option>').join('') + '</select></label>' + inp('fs', 'Size', e.fs || 18) + inp('lh', 'Line height', e.lh || 1.3, 'number', ' step="0.05"') + colorInp('color', 'Colour', e.color || '#1b1b1f') + '</div>' +
      '<div class="st-btnrow" role="group" aria-label="Text style"><button class="btn-icon sm' + (Number(e.fw) >= 600 ? ' on' : '') + '" data-act="edToggle" data-k="fw" title="Bold" aria-label="Bold">' + icon('bold') + '</button><button class="btn-icon sm' + (e.fi ? ' on' : '') + '" data-act="edToggle" data-k="fi" title="Italic" aria-label="Italic">' + icon('italic') + '</button><button class="btn-icon sm' + (e.u ? ' on' : '') + '" data-act="edToggle" data-k="u" title="Underline" aria-label="Underline">' + icon('underline') + '</button><button class="btn-icon sm' + (e.list ? ' on' : '') + '" data-act="edToggle" data-k="list" title="Bulleted list" aria-label="Bulleted list">' + icon('listUl') + '</button>' +
      ['left', 'center', 'right', 'justify'].map((a) => '<button class="btn-icon sm' + ((e.align || 'left') === a ? ' on' : '') + '" data-act="edAlign" data-a="' + a + '" title="Align ' + a + '" aria-label="Align ' + a + '">' + icon({ left: 'alignLeft', center: 'alignCenter', right: 'alignRight', justify: 'alignJustify' }[a]) + '</button>').join('') + '</div>' +
      (!multi ? '<label class="st-prop col"><span>Text</span><textarea rows="4" data-input="edProp" data-k="text" data-delay="350"' + (ro ? ' readonly' : '') + '>' + esc(e.text || '') + '</textarea></label>' : '');
  }
  if (els.some((x) => ['rect', 'ellipse', 'text'].indexOf(x.t) >= 0)) h += '<div class="st-sub">Fill and border</div><div class="st-props2">' + colorInp('bg', 'Fill', e.bg) + colorInp('bc', 'Border', e.bc) + inp('bw', 'Border width', e.bw || 0) + (e.t !== 'ellipse' ? inp('radius', 'Corner radius', e.radius || 0) : '') + '</div>';
  if (e.t === 'line' && !multi) h += '<div class="st-sub">Line</div><div class="st-props2">' + colorInp('bc', 'Colour', e.bc || '#8a93a6') + inp('bw', 'Width', e.bw || 2) + '</div><div class="st-btnrow"><button class="btn btn-sm' + (e.arrow ? ' btn-soft' : '') + '" data-act="edToggle" data-k="arrow">Arrow</button><button class="btn btn-sm' + (e.dash ? ' btn-soft' : '') + '" data-act="edToggle" data-k="dash">Dashed</button><button class="btn btn-sm" data-act="edToggle" data-k="flip">Flip</button></div>';
  if (e.t === 'image' && !multi) h += '<div class="st-sub">Image</div><label class="st-prop col"><span>Alternative text (required)</span><textarea rows="2" maxlength="500" data-input="edProp" data-k="alt" data-delay="300" placeholder="Describe the image for screen-reader users"' + (ro ? ' readonly' : '') + '>' + esc(e.alt || '') + '</textarea></label><label class="st-prop"><span>Fit</span><select data-change="edPropS" data-k="fit"' + (ro ? ' disabled' : '') + '>' + ['contain', 'cover', 'fill'].map((f) => '<option' + (e.fit === f ? ' selected' : '') + '>' + f + '</option>').join('') + '</select></label>' + (ro ? '' : '<label class="btn btn-sm" style="margin-top:.4rem">' + icon('upload', 'i-sm') + 'Replace image<input type="file" hidden accept=".png,.jpg,.jpeg,.gif,.webp" data-change="edUpload"></label>');
  if (e.t === 'icon' && !multi) h += '<div class="st-props2">' + colorInp('color', 'Colour', e.color || '#1f3a6e') + '</div>';
  if (e.t === 'table' && !multi) h += '<div class="st-sub">Table data</div><label class="st-prop col"><span>One row per line, cells separated by |</span><textarea rows="6" data-input="edTable" data-delay="400"' + (ro ? ' readonly' : '') + '>' + esc((e.rows || []).map((r) => r.join(' | ')).join('\n')) + '</textarea></label><div class="st-props2">' + inp('fs', 'Text size', e.fs || 14) + colorInp('hc', 'Header colour', e.hc || '#1f3a6e') + '</div><label class="check"><input type="checkbox" data-change="edPropB" data-k="header"' + (e.header !== false ? ' checked' : '') + (ro ? ' disabled' : '') + '><span>First row is a header</span></label>';
  if (e.t === 'chart' && !multi) { const c = e.chart || {}; h += '<div class="st-sub">Chart</div><label class="st-prop"><span>Type</span><select data-change="edChartT"' + (ro ? ' disabled' : '') + '>' + ['column', 'bar', 'line', 'pie'].map((t) => '<option' + (c.type === t ? ' selected' : '') + '>' + t + '</option>').join('') + '</select></label><label class="st-prop col"><span>Title (also read by screen readers)</span><input type="text" value="' + esc(c.title || '') + '" data-input="edChartTitle" data-delay="300"' + (ro ? ' readonly' : '') + '></label><label class="st-prop col"><span>Data: label, value per line</span><textarea rows="6" data-input="edChartData" data-delay="400"' + (ro ? ' readonly' : '') + '>' + esc((c.labels || []).map((l, i) => l + ', ' + ((c.values || [])[i] || 0)).join('\n')) + '</textarea></label>'; }
  if (!ro) h += '<div class="st-sub">Arrange</div><div class="st-btnrow"><button class="btn btn-sm" data-act="edOrder" data-o="front">Bring to front</button><button class="btn btn-sm" data-act="edOrder" data-o="up">Forward</button><button class="btn btn-sm" data-act="edOrder" data-o="down">Backward</button><button class="btn btn-sm" data-act="edOrder" data-o="back">Send to back</button></div>' +
    (multi ? '<div class="st-btnrow">' + [['l', 'alignLeft', 'Align left edges'], ['c', 'alignCenter', 'Align centres'], ['r', 'alignRight', 'Align right edges'], ['t', 'up', 'Align tops'], ['m', 'minus', 'Align middles'], ['b', 'down', 'Align bottoms']].map((a) => '<button class="btn-icon sm" data-act="edAlignEls" data-a="' + a[0] + '" title="' + a[2] + '" aria-label="' + a[2] + '">' + icon(a[1]) + '</button>').join('') + '<button class="btn btn-sm" data-act="edGroup">Group</button></div>' : '<div class="st-btnrow"><button class="btn btn-sm" data-act="edCenterPage" data-a="h">Centre horizontally</button><button class="btn btn-sm" data-act="edCenterPage" data-a="v">Centre vertically</button></div>') +
    '<div class="st-btnrow"><button class="btn btn-sm" data-act="edDupSel">' + icon('copy', 'i-sm') + 'Duplicate</button><button class="btn btn-sm btn-ghost danger" data-act="edDelete">' + icon('trash', 'i-sm') + 'Delete</button></div>';
  box.innerHTML = h;
}
INPUTS.edProp = (el) => { if (!ED) return; const k = el.dataset.k; const v = el.type === 'number' ? Number(el.value) : el.value; edPush(); edSelEls().forEach((x) => { x[k] = v; }); edChanged({ right: false }); };
INPUTS.edNotes = (el) => { edPush(); edPg().notes = el.value; edChanged({ right: false, draw: false }); };
ACT.edPropC = (d, el) => { edPush(); if (d.k === 'pagebg') edPg().bg = el.value; else edSelEls().forEach((x) => { x[d.k] = el.value; }); edChanged({ right: false }); };
ACT.edPropClear = (d) => { edPush(); edSelEls().forEach((x) => { delete x[d.k]; if (d.k === 'bc') x.bw = 0; }); edChanged(); };
ACT.edPropS = (d, el) => { edPush(); edSelEls().forEach((x) => { x[d.k] = el.value; }); edChanged({ right: false }); };
ACT.edPropB = (d, el) => { edPush(); edSelEls().forEach((x) => { x[d.k] = el.checked; }); edChanged({ right: false }); };
ACT.edToggle = (d) => { edPush(); edSelEls().forEach((x) => { if (d.k === 'fw') x.fw = Number(x.fw) >= 600 ? 400 : 700; else x[d.k] = !x[d.k]; }); edChanged(); };
ACT.edAlign = (d) => { edPush(); edSelEls().forEach((x) => { x.align = d.a; }); edChanged(); };
INPUTS.edTable = (el) => { const e = edSelEls()[0]; if (!e) return; edPush(); e.rows = el.value.split('\n').map((r) => r.split('|').map((c) => c.trim())); edChanged({ right: false }); };
ACT.edChartT = (d, el) => { const e = edSelEls()[0]; edPush(); e.chart.type = el.value; edChanged({ right: false }); };
INPUTS.edChartTitle = (el) => { const e = edSelEls()[0]; edPush(); e.chart.title = el.value; edChanged({ right: false }); };
INPUTS.edChartData = (el) => { const e = edSelEls()[0]; edPush(); const rows = el.value.split('\n').map((l) => l.split(',')).filter((r) => r[0].trim()); e.chart.labels = rows.map((r) => r[0].trim()); e.chart.values = rows.map((r) => Number(String(r[1] || '0').trim()) || 0); edChanged({ right: false }); };
ACT.edOrder = (d) => {
  edPush();
  const all = edEls(), sel = all.filter((x) => ED.sel.has(x.id)), rest = all.filter((x) => !ED.sel.has(x.id));
  if (d.o === 'front') edPg().elements = rest.concat(sel);
  else if (d.o === 'back') edPg().elements = sel.concat(rest);
  else { const arr = all.slice(); const idxs = sel.map((x) => arr.indexOf(x)); (d.o === 'up' ? idxs.reverse() : idxs).forEach((i) => { const j = i + (d.o === 'up' ? 1 : -1); if (j >= 0 && j < arr.length && !ED.sel.has(arr[j].id)) [arr[i], arr[j]] = [arr[j], arr[i]]; }); edPg().elements = arr; }
  edChanged(); edLeft();
};
ACT.edAlignEls = (d) => { const els = edSelEls(), b = edBox(els); edPush(); els.forEach((x) => { if (d.a === 'l') x.x = b.x; if (d.a === 'r') x.x = b.x + b.w - x.w; if (d.a === 'c') x.x = Math.round(b.x + (b.w - x.w) / 2); if (d.a === 't') x.y = b.y; if (d.a === 'b') x.y = b.y + b.h - x.h; if (d.a === 'm') x.y = Math.round(b.y + (b.h - x.h) / 2); }); edChanged(); };
ACT.edCenterPage = (d) => { edPush(); edSelEls().forEach((x) => { if (d.a === 'h') x.x = Math.round((ED.it.size.w - x.w) / 2); else x.y = Math.round((ED.it.size.h - x.h) / 2); }); edChanged(); };
ACT.edDupSel = () => edPaste(edSelEls());

/* ---------- Details: course, unit, topic, outcomes, Bloom, difficulty, tags ---------- */
function edDetailsHtml() {
  const it = ED.it, m = it.meta, ro = !it.perms.edit;
  const courses = ST.courses || [];
  if (!ST.courses) stCourses().then(() => { if (ED && ED.rpanel === 'details' || (ED && ED.it.format !== 'canvas' && ED.rpanel === 'design')) edRight(); });
  const c = courses.find((x) => x.id === m.courseId);
  const chk = (name, list, sel) => list.length ? '<div class="st-oc">' + list.map((o) => '<label class="check" title="' + esc(o.text) + '"><input type="checkbox" name="' + name + '" value="' + esc(o.code) + '"' + (sel.indexOf(o.code) >= 0 ? ' checked' : '') + (ro ? ' disabled' : '') + '><span><b>' + esc(o.code) + '</b> ' + esc(o.text.slice(0, 90)) + '</span></label>').join('') + '</div>' : '<p class="xs muted">None defined for this course.</p>';
  return '<form data-form="edMeta" class="st-meta"><h3 class="st-ph">Academic details</h3>' +
    '<label class="st-prop col"><span>Course</span><select name="courseId" data-change="edMetaCourse"' + (ro ? ' disabled' : '') + '><option value="">—</option>' + courses.map((x) => '<option value="' + esc(x.id) + '"' + (x.id === m.courseId ? ' selected' : '') + '>' + esc(x.shortname + ' · ' + x.fullname) + '</option>').join('') + '</select></label>' +
    '<label class="st-prop col"><span>Unit</span><select name="unitId"' + (ro ? ' disabled' : '') + '><option value="">—</option>' + (c ? c.units.map((u) => '<option value="' + esc(u.id) + '"' + (u.id === m.unitId ? ' selected' : '') + '>' + esc(u.title) + '</option>').join('') : '') + '</select></label>' +
    '<label class="st-prop col"><span>Topic</span><input type="text" name="topic" maxlength="200" value="' + esc(m.topic) + '" list="edTopics"' + (ro ? ' readonly' : '') + '><datalist id="edTopics">' + (c ? c.units.reduce((a, u) => a.concat(u.topics), []).map((t) => '<option value="' + esc(t) + '">').join('') : '') + '</datalist></label>' +
    (c ? '<div class="st-sub">Course outcomes</div>' + chk('co', c.co, m.co) + '<div class="st-sub">Programme outcomes</div>' + chk('po', c.po, m.po) + (c.pso.length ? '<div class="st-sub">Programme-specific outcomes</div>' + chk('pso', c.pso, m.pso) : '') : '<p class="xs muted">Choose a course to map its outcomes. Outcomes are set under Studio → Outcomes & syllabus.</p>') +
    '<div class="st-sub">Bloom’s taxonomy</div><div class="st-oc row-wrap">' + ['Remember', 'Understand', 'Apply', 'Analyze', 'Evaluate', 'Create'].map((b) => '<label class="check"><input type="checkbox" name="bloom" value="' + b + '"' + (m.bloom.indexOf(b) >= 0 ? ' checked' : '') + (ro ? ' disabled' : '') + '><span>' + b + '</span></label>').join('') + '</div>' +
    '<label class="st-prop col"><span>Difficulty</span><select name="difficulty"' + (ro ? ' disabled' : '') + '><option value="">—</option>' + ['Easy', 'Moderate', 'Difficult'].map((x) => '<option' + (m.difficulty === x ? ' selected' : '') + '>' + x + '</option>').join('') + '</select></label>' +
    '<label class="st-prop col"><span>Tags (comma separated)</span><input type="text" name="tags" value="' + esc(m.tags.join(', ')) + '"' + (ro ? ' readonly' : '') + '></label><label class="st-prop col"><span>Folder</span><input type="text" name="folder" maxlength="60" value="' + esc(m.folder) + '"' + (ro ? ' readonly' : '') + '></label>' +
    (ro ? '' : '<div class="st-btnrow"><button class="btn btn-sm" type="button" data-act="edSuggest">' + icon('sparkle', 'i-sm') + 'Suggest mappings</button><button class="btn btn-sm btn-primary" type="submit">Save details</button></div><div id="edSuggest"></div>') + '</form>' +
    (it.family.length ? '<div class="st-sub">Linked learning objects</div><div class="st-family sm">' + it.family.map((x) => '<a class="st-fam" href="#/studio/edit/' + esc(x.id) + '">' + icon(stKindIcon(x.kind)) + '<span><b>' + esc(x.kindLabel) + '</b><span class="xs muted">' + esc(x.title) + '</span></span>' + (x.outdated ? badge('Source changed', 'warning') : '') + '</a>').join('') + '</div>' : '') +
    (it.published.length ? '<div class="st-sub">Published to</div>' + it.published.map((p) => '<div class="small">' + icon('send', 'i-sm') + ' ' + esc(p.course) + ' — ' + esc({ studio: 'Studio activity', quiz: 'LMS quiz', assignment: 'Assignment', forum: 'Forum' }[p.as]) + ' · ' + esc(rel(p.at)) + ' <a href="#/mod/' + esc(p.moduleId) + '">Open</a></div>').join('') : '');
}
ACT.edMetaCourse = (d, el) => { ED.it.meta.courseId = el.value; ED.it.meta.unitId = ''; ED.it.meta.co = []; ED.it.meta.po = []; ED.it.meta.pso = []; edRight(); };
FORMS.edMeta = (f, btn) => busy(btn, async () => {
  const vals = (n) => Array.from(f.querySelectorAll('input[name="' + n + '"]:checked')).map((x) => x.value);
  const el = f.elements;
  const r = await call('stMeta', { id: ED.it.id, meta: { courseId: el.courseId.value, unitId: el.unitId.value, topic: el.topic.value, co: vals('co'), po: vals('po'), pso: vals('pso'), bloom: vals('bloom'), difficulty: el.difficulty.value, tags: el.tags.value.split(',').map((x) => x.trim()).filter(Boolean), folder: el.folder.value } });
  ED.it.meta = r.meta; toast('Details saved.'); edRight();
});
ACT.edSuggest = (d, btn) => busy(btn, async () => {
  await edSave();
  const r = await call('stSuggest', { id: ED.it.id });
  $('#edSuggest').innerHTML = '<div class="st-suggest"><b class="small">Suggested</b> <span class="xs muted">' + esc(r.reason) + '</span><div class="st-chips">' +
    r.bloom.map((b) => '<button class="badge" data-act="edAccept" data-n="bloom" data-v="' + esc(b) + '">+ ' + esc(b) + '</button>').join(' ') +
    (r.co || []).map((c) => '<button class="badge primary" data-act="edAccept" data-n="co" data-v="' + esc(c.code) + '" title="Shared words: ' + esc(c.reason.join(', ')) + '">+ ' + esc(c.code) + '</button>').join(' ') +
    (r.po || []).map((c) => '<button class="badge info" data-act="edAccept" data-n="po" data-v="' + esc(c.code) + '" title="Shared words: ' + esc(c.reason.join(', ')) + '">+ ' + esc(c.code) + '</button>').join(' ') +
    (r.difficulty ? '<button class="badge" data-act="edAccept" data-n="difficulty" data-v="' + esc(r.difficulty) + '">Difficulty: ' + esc(r.difficulty) + '</button>' : '') + '</div><p class="xs muted">Click a suggestion to tick it, then Save details. Ignore any that do not fit.</p></div>';
});
ACT.edAccept = (d) => { const f = $('form[data-form="edMeta"]'); if (d.n === 'difficulty') f.elements.difficulty.value = d.v; else { const x = f.querySelector('input[name="' + d.n + '"][value="' + CSS.escape(d.v) + '"]'); if (x) x.checked = true; } };

/* ---------- Review: AI verification, accessibility, workflow, comments ---------- */
function edA11y() {
  const it = ED.it, issues = [];
  const lum = (h) => { const m = /^#?([0-9a-f]{6})$/i.exec(h || ''); if (!m) return null; return [0, 2, 4].map((i) => parseInt(m[1].substr(i, 2), 16) / 255).map((c) => (c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4))).reduce((a, c, i) => a + c * [0.2126, 0.7152, 0.0722][i], 0); };
  const ratio = (a, b) => { const x = lum(a), y = lum(b); if (x == null || y == null) return null; return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
  if (it.format === 'canvas') it.pages.forEach((p, pi) => {
    const texts = p.elements.filter((e) => (e.t === 'text' || e.text) && String(e.text || '').trim());
    p.elements.forEach((e) => {
      if (e.t === 'image' && !String(e.alt || '').trim()) issues.push({ lv: 'error', pi, id: e.id, t: 'Image missing alternative text.' });
      if (e.t === 'chart' && !String((e.chart || {}).title || '').trim()) issues.push({ lv: 'warn', pi, id: e.id, t: 'Chart has no title.' });
    });
    texts.forEach((e) => {
      const behind = e.bg ? e : p.elements.filter((x) => x !== e && (x.t === 'rect' || x.t === 'ellipse') && x.bg && x.bg !== 'transparent' && x.x <= e.x + 2 && x.y <= e.y + 2 && x.x + x.w >= e.x + e.w - 2 && x.y + x.h >= e.y + e.h - 2).pop();
      const r = ratio(e.color || '#1b1b1f', behind ? behind.bg : p.bg);
      const large = Number(e.fs) >= 24 || (Number(e.fw) >= 700 && Number(e.fs) >= 19);
      if (r != null && r < (large ? 3 : 4.5)) issues.push({ lv: 'error', pi, id: e.id, t: 'Contrast issue: "' + String(e.text).slice(0, 26) + '" is ' + r.toFixed(1) + ':1 (needs ' + (large ? 3 : 4.5) + ':1).' });
      if (Number(e.fs) < 12) issues.push({ lv: 'warn', pi, id: e.id, t: 'Very small text (' + e.fs + 'px).' });
    });
    if (texts.length && !texts.some((e) => Number(e.fs) >= 24 || Number(e.fw) >= 700)) issues.push({ lv: 'warn', pi, t: 'No heading-sized text on this page.' });
    const wc = texts.reduce((n, e) => n + String(e.text).split(/\s+/).filter(Boolean).length, 0);
    if (['presentation', 'pitch', 'portfolio'].indexOf(it.kind) >= 0 && wc > 90) issues.push({ lv: 'warn', pi, t: 'Dense slide (' + wc + ' words).' });
  });
  if (it.format === 'doc') { let last = 1; String(it.doc || '').split('\n').forEach((l, i) => { const m = /^(#{1,6})\s/.exec(l); if (m) { if (m[1].length > last + 1) issues.push({ lv: 'warn', t: 'Heading hierarchy issue on line ' + (i + 1) + ' (a level is skipped).' }); last = m[1].length; } if (/!\[\s*\]\(/.test(l)) issues.push({ lv: 'error', t: 'Image missing alternative text (line ' + (i + 1) + ').' }); if (/\[(click here|here|link)\]\(/i.test(l)) issues.push({ lv: 'warn', t: 'Link text "here" does not say where it goes (line ' + (i + 1) + ').' }); }); }
  if (it.format === 'quiz') it.questions.forEach((q, i) => { if (!q.explanation) issues.push({ lv: 'warn', t: 'Question ' + (i + 1) + ' has no explanation for students.' }); });
  return issues;
}
function edReviewHtml() {
  const it = ED.it, p = it.perms, issues = edA11y();
  let h = '<h3 class="st-ph">Review</h3>';
  if (it.ai) h += '<div class="st-rsec"><div class="st-sub">AI content</div>' + (it.ai.reviewed ? notice('Reviewed and verified by the author.', 'ok') : notice('Generated by ' + esc(it.ai.provider || 'the Copilot') + (it.ai.outline ? ' as an outline' : '') + '. Verify facts, references, legal provisions, statistics, dates and terminology before publishing.', 'warn', 'sparkle')) + (p.edit ? '<label class="check"><input type="checkbox" data-change="edAiOk"' + (it.ai.reviewed ? ' checked' : '') + '><span>I have reviewed and verified this content</span></label>' : '') + '</div>';
  h += '<div class="st-rsec"><div class="st-sub">Accessibility checker</div>' + (issues.length ? '<ul class="st-issues">' + issues.slice(0, 40).map((x) => '<li class="' + x.lv + '">' + icon(x.lv === 'error' ? 'alert' : 'info', 'i-sm') + '<span>' + (x.pi != null ? '<button class="link" data-act="edIssue" data-pi="' + x.pi + '" data-id="' + esc(x.id || '') + '">Page ' + (x.pi + 1) + '</button> — ' : '') + esc(x.t) + '</span></li>').join('') + '</ul>' : notice('No accessibility issues found.', 'ok')) + '</div>';
  h += '<div class="st-rsec"><div class="st-sub">Workflow</div><p class="small">' + stStatus(it.status) + (it.deptApproved ? ' ' + badge('Department-approved', 'success', 'shield') : '') + (it.workflow.waitingOn.length ? ' <span class="xs muted">waiting on ' + esc(it.workflow.waitingOn.join(', ')) + '</span>' : '') + '</p>' +
    (p.review ? '<form data-form="edReview"><textarea name="note" rows="2" maxlength="2000" placeholder="Note for the author"></textarea><div class="st-btnrow"><button class="btn btn-sm btn-primary" name="a" value="approve">' + icon('check', 'i-sm') + 'Approve</button><button class="btn btn-sm" name="a" value="changes">Request changes</button></div></form>' : '') +
    (stIsStaff() && p.edit && ['draft', 'approved', 'published'].indexOf(it.status) >= 0 && it.status !== 'review' ? '<button class="btn btn-sm" data-act="edSubmitReview">' + icon('send', 'i-sm') + 'Submit for review</button>' : '') +
    (it.workflow.trail.length ? '<ol class="st-trail">' + it.workflow.trail.slice().reverse().slice(0, 12).map((t) => '<li><span class="xs muted">' + esc(rel(t.at)) + ' · ' + esc(t.by) + '</span><br>' + esc(t.action) + (t.note ? ' — <i>' + esc(t.note) + '</i>' : '') + '</li>').join('') + '</ol>' : '') + '</div>';
  h += '<div class="st-rsec"><div class="st-sub">Comments</div>' + (it.comments.length ? it.comments.map((c) => '<div class="st-comment' + (c.resolved ? ' resolved' : '') + '"><div class="xs muted">' + esc(c.by) + ' · ' + esc(rel(c.at)) + (c.suggestion ? ' · suggestion' : '') + (c.page ? ' · page ' + esc(c.page) : '') + '</div><div class="small">' + esc(c.text).replace(/@([A-Za-z0-9._-]+)/g, '<b>@$1</b>') + '</div>' + (p.comment ? '<button class="link xs" data-act="edResolve" data-id="' + esc(c.id) + '">' + (c.resolved ? 'Reopen' : 'Resolve') + '</button>' : '') + '</div>').join('') : '<p class="small muted">No comments yet.</p>') +
    (p.comment ? '<form data-form="edComment"><textarea name="text" rows="2" maxlength="3000" placeholder="Comment — @username to mention a colleague"></textarea><div class="st-btnrow"><label class="check"><input type="checkbox" name="sugg"><span>Suggestion</span></label><span class="spacer"></span><button class="btn btn-sm btn-primary">Comment</button></div></form>' : '') + '</div>';
  return h;
}
ACT.edIssue = (d) => { if (d.pi !== '') ACT.edGoPage({ i: Number(d.pi) }); if (d.id) { ED.sel.clear(); ED.sel.add(d.id); edOverlay(); } };
ACT.edAiOk = (d, el) => busy(null, async () => { await edSave(); const r = await call('stAiReviewed', { id: ED.it.id, reviewed: el.checked }); ED.it.ai = r.ai; ED.it.workflow = r.workflow; toast(el.checked ? 'Marked as reviewed.' : 'Review mark removed.'); $$('.st-ainote').forEach((x) => { if (el.checked) x.remove(); }); edRight(); });
FORMS.edComment = (f, btn) => busy(btn, async () => { ED.it.comments = await call('stComment', { id: ED.it.id, text: f.elements.text.value, page: ED.it.format === 'canvas' ? String(ED.page + 1) : '', suggestion: f.elements.sugg.checked }); edRight(); });
ACT.edResolve = (d) => busy(null, async () => { ED.it.comments = await call('stComment', { id: ED.it.id, resolve: d.id }); edRight(); });
FORMS.edReview = (f, btn) => busy(btn, async () => { const r = await call('stReview', { id: ED.it.id, action: btn.value, note: f.elements.note.value }); Object.assign(ED.it, { status: r.status, workflow: r.workflow, perms: r.perms }); toast(btn.value === 'approve' ? 'Approved.' : 'Changes requested.'); edRight(); });
ACT.edSubmitReview = () => formModal('Submit for review', 'Reviewers are notified. Editing stays possible; reviewers see the latest version.', 'edSubmitReview',
  field('Peer reviewer (optional)', '<input type="search" data-input="edPeerSearch" data-delay="250" placeholder="Search colleagues" aria-label="Search colleagues"><input type="hidden" name="peerId"><div id="edPeerRes" class="st-people"></div>') + field('Note', '<textarea name="note" rows="2" maxlength="1000"></textarea>'), 'Submit', 'narrow');
INPUTS.edPeerSearch = async (el) => { const list = await call('stPeople', { q: el.value }); $('#edPeerRes').innerHTML = list.filter((u) => u.role !== 'student').map((u) => '<button type="button" class="st-person" data-act="edPeerPick" data-id="' + esc(u.id) + '" data-n="' + esc(u.name) + '">' + avatar(u.name, 'sm') + esc(u.name) + '</button>').join(''); };
ACT.edPeerPick = (d, el) => { const f = el.closest('form'); f.elements.peerId.value = d.id; $('#edPeerRes').innerHTML = '<span class="badge primary">' + esc(d.n) + '</span>'; };
FORMS.edSubmitReview = (f, btn) => busy(btn, async () => { await edSave(); const r = await call('stSubmitReview', { id: ED.it.id, peerId: f.elements.peerId.value, note: f.elements.note.value }); Object.assign(ED.it, { status: r.status, workflow: r.workflow }); closeModal(); toast('Submitted for review.'); go('/studio/edit/' + ED.it.id); });

ACT.edSourceOk = (d, btn) => busy(btn, async () => { await call('stSourceOk', { id: ED.it.id }); go('/studio/edit/' + ED.it.id); });

/* ---------- share, versions, export, publish, submit, live ---------- */
INPUTS.edTitle = (el) => { if (!ED || !ED.it.perms.edit) return; ED.it.title = el.value; edChanged({ draw: false, right: false }); };
ACT.edShare = () => {
  const it = ED.it, sh = it.share;
  ED.shareList = (sh.people || []).slice();
  formModal('Share “' + it.title + '”', 'Collaborators can view or edit. Comments and mentions notify them.', 'edShare',
    field('Add people', '<input type="search" data-input="edShareSearch" data-delay="250" placeholder="Name or username" aria-label="Find people"><div id="edShareRes" class="st-people"></div>') + '<div id="edShareList">' + edShareList() + '</div>' +
    (stIsStaff() ? check('department', 'Share with my department (view)', sh.department) + check('library', sh.library === 'approved' ? 'In the university library' : sh.library === 'pending' ? 'Waiting for library approval' : 'Propose for the university library (an academic administrator approves)', !!sh.library) : ''), 'Save', 'wide');
};
function edShareList() { return (ED.shareList || []).length ? ED.shareList.map((p, i) => '<div class="st-shrow">' + avatar(p.name, 'sm') + '<span>' + esc(p.name) + '</span><span class="spacer"></span><select data-change="edShareAcc" data-i="' + i + '" aria-label="Access"><option value="view"' + (p.access === 'view' ? ' selected' : '') + '>Can view and comment</option><option value="edit"' + (p.access === 'edit' ? ' selected' : '') + '>Can edit</option></select><button type="button" class="btn-icon sm" data-act="edShareDel" data-i="' + i + '" aria-label="Remove">' + icon('x') + '</button></div>').join('') : '<p class="small muted">Only you can see this.</p>'; }
INPUTS.edShareSearch = async (el) => { const list = await call('stPeople', { q: el.value }); $('#edShareRes').innerHTML = list.map((u) => '<button type="button" class="st-person" data-act="edShareAdd" data-id="' + esc(u.id) + '" data-n="' + esc(u.name) + '">' + avatar(u.name, 'sm') + esc(u.name) + ' <span class="xs muted">' + esc(u.role) + '</span></button>').join(''); };
ACT.edShareAdd = (d) => { if (!ED.shareList.some((p) => p.id === d.id)) ED.shareList.push({ id: d.id, name: d.n, access: 'view' }); $('#edShareList').innerHTML = edShareList(); };
ACT.edShareAcc = (d, el) => { ED.shareList[Number(d.i)].access = el.value; };
ACT.edShareDel = (d) => { ED.shareList.splice(Number(d.i), 1); $('#edShareList').innerHTML = edShareList(); };
FORMS.edShare = (f, btn) => busy(btn, async () => { const r = await call('stShare', { id: ED.it.id, users: ED.shareList, department: f.elements.department ? f.elements.department.checked : undefined, library: f.elements.library ? f.elements.library.checked : undefined }); ED.it.share = r.share; closeModal(); toast('Sharing updated.'); });
ACT.edVersions = () => busy(null, async () => {
  await edSave();
  const list = await call('stVersions', { id: ED.it.id });
  openModal(modalHead('Version history', plural(list.length, 'version') + ' — autosaves are kept for the most recent edits; named versions are kept.') + '<div class="modal-body"><div class="table-wrap"><table class="table"><thead><tr><th>Version</th><th>When</th><th>By</th><th>Note</th><th></th></tr></thead><tbody>' +
    list.map((v) => '<tr><td><b>v' + v.n + '</b></td><td class="small nowrap">' + esc(fmt(v.at)) + '</td><td class="small">' + esc(v.by) + '</td><td class="small">' + esc(v.note) + '</td><td class="actions nowrap"><button class="btn btn-sm btn-ghost" data-act="edCompare" data-n="' + v.n + '">Compare</button>' + (ED.it.perms.edit ? '<button class="btn btn-sm btn-ghost" data-act="edRestore" data-n="' + v.n + '">Restore</button>' : '') + '<button class="btn btn-sm btn-ghost" data-act="edDupVer" data-n="' + v.n + '">Copy</button></td></tr>').join('') + '</tbody></table></div><div id="edCmp"></div></div>', 'xwide');
});
ACT.edCompare = (d, btn) => busy(btn, async () => { const r = await call('stCompare', { id: ED.it.id, a: d.n, b: 'current' }); $('#edCmp').innerHTML = '<h3 class="st-h3">v' + r.a + ' → current</h3><p class="small muted">Pages: ' + r.pages[0] + ' → ' + r.pages[1] + (r.title[0] !== r.title[1] ? ' · title changed' : '') + '</p><div class="st-diff">' + r.removed.map((l) => '<div class="del">− ' + esc(l) + '</div>').join('') + r.added.map((l) => '<div class="add">+ ' + esc(l) + '</div>').join('') + (r.removed.length + r.added.length ? '' : '<p class="small muted">No text changes (layout or styling only).</p>') + '</div>'; });
ACT.edRestore = async (d) => { if (!await confirmBox('Restore version ' + d.n + '?', '<p>The current state is saved as a version first, so nothing is lost.</p>', 'Restore')) return; busy(null, async () => { await call('stRestore', { id: ED.it.id, n: d.n }); toast('Version restored.'); go('/studio/edit/' + ED.it.id); }); };
ACT.edDupVer = (d) => busy(null, async () => { const r = await call('stDuplicate', { id: ED.it.id, version: d.n }); closeModal(); toast('Copy of version ' + d.n + ' created.'); go('/studio/edit/' + r.id); });
ACT.edSaveVersion = () => formModal('Save a named version', '', 'edSaveVersion', field('Name', '<input type="text" name="note" maxlength="200" required autofocus placeholder="e.g. Before HOD review">'), 'Save', 'narrow');
FORMS.edSaveVersion = (f, btn) => busy(btn, async () => { ED.dirty = true; await edSave(f.elements.note.value); closeModal(); toast('Version saved.'); });
ACT.edExport = (d, btn) => busy(btn, async () => {
  await edSave();
  if (d.f === 'pdf') { go('/studio/print/' + ED.it.id); return; }
  if (d.f === 'png' || d.f === 'jpg' || d.f === 'pngall') { await stExportImage(ED.it, d.f === 'jpg' ? 'jpg' : 'png', d.f === 'pngall'); return; }
  const r = await call('stExport', { id: ED.it.id, format: d.f });
  downloadBase64(r.name, r.data, r.mime);
});
ACT.edPublish = () => busy(null, async () => {
  await edSave();
  const courses = (await stCourses()).filter((c) => c.editor);
  if (!courses.length) { toast('You do not teach any courses yet.', 'err'); return; }
  const it = ED.it;
  const def = it.kind === 'quiz' ? 'quiz' : it.kind === 'assignment' ? 'assignment' : it.kind === 'discussion' ? 'forum' : 'studio';
  formModal('Publish to course', 'Course → section → settings. It appears in the course straight away (no downloading or uploading).', 'edPublish',
    (it.ai && !it.ai.reviewed ? notice('This content is AI-generated and not yet marked as reviewed. Review it and tick the box in the Review panel first.', 'warn', 'sparkle') : '') +
    '<div class="form-grid">' + field('Course', '<select name="courseId" data-change="edPubCourse" required><option value="">Choose…</option>' + courses.map((c) => '<option value="' + esc(c.id) + '"' + (c.id === it.meta.courseId ? ' selected' : '') + '>' + esc(c.shortname + ' · ' + c.fullname) + '</option>').join('') + '</select>') + field('Section', '<select name="sectionId" id="edPubSec" required><option value="">—</option></select>') + '</div>' +
    field('Publish as', '<select name="as">' + [['studio', 'Studio content (students open it in the viewer)']].concat(it.format === 'quiz' && it.kind === 'quiz' ? [['quiz', 'LMS quiz (auto-graded, in the gradebook)']] : []).concat(it.format === 'doc' ? [['assignment', 'Assignment (students submit; in the gradebook)'], ['forum', 'Discussion forum']] : []).map((o) => '<option value="' + o[0] + '"' + (o[0] === def ? ' selected' : '') + '>' + o[1] + '</option>').join('') + '</select>') +
    '<div class="form-grid-3">' + field('Due date (assignments)', '<input type="datetime-local" name="dueAt" value="' + esc(toLocalInput(Date.now() + 7 * 86400000)) + '">') + field('Maximum marks', '<input type="number" name="maxGrade" min="1" max="1000" value="20">') + field('Quiz time limit (min)', '<input type="number" name="durationMin" min="1" max="600" value="20">') + '</div>' +
    field('Introduction (optional)', '<textarea name="description" rows="2" maxlength="3000"></textarea>') + check('visible', 'Visible to students now', true), 'Publish', 'wide');
  const sel = $('select[name=courseId]'); if (sel && sel.value) ACT.edPubCourse({}, sel);
});
ACT.edPubCourse = (d, el) => busy(null, async () => { const sec = $('#edPubSec'); if (!el.value) { sec.innerHTML = '<option value="">—</option>'; return; } const c = await call('getCourse', { courseId: el.value }); const cc = (ST.courses || []).find((x) => x.id === el.value), u = cc && cc.units.find((x) => x.id === ED.it.meta.unitId);
  sec.innerHTML = c.sections.map((s) => '<option value="' + esc(s.id) + '"' + (u && s.title === u.title ? ' selected' : '') + '>' + esc(s.title) + '</option>').join(''); });
FORMS.edPublish = (f, btn) => busy(btn, async () => {
  const el = f.elements;
  const r = await call('stPublish', { id: ED.it.id, courseId: el.courseId.value, sectionId: el.sectionId.value, as: el.as.value, dueAt: fromLocalInput(el.dueAt.value), maxGrade: el.maxGrade.value, durationMin: el.durationMin.value, description: el.description.value, visible: el.visible.checked });
  closeModal();
  openModal(modalHead('Published', '') + '<div class="modal-body">' + notice('It is now in the course' + (el.visible.checked ? ' and visible to students.' : ' (hidden until you show it).'), 'ok') + r.notes.map((n) => notice(esc(n), 'warn')).join('') + '<div class="form-actions"><button class="btn" data-act="close">Keep editing</button><a class="btn btn-primary" href="#/mod/' + esc(r.moduleId) + '" data-act="close">Open in the course</a></div></div>');
  go('/studio/edit/' + ED.it.id);
});
ACT.edSubmitWork = () => busy(null, async () => {
  await edSave();
  const list = await call('stAssignments');
  if (!list.length) { toast('None of your courses has an assignment that accepts online submissions.', 'err'); return; }
  formModal('Submit to assignment', 'Your teacher sees this version, even if you keep editing.', 'edSubmitWork', field('Assignment', '<select name="moduleId">' + list.map((a) => '<option value="' + esc(a.id) + '">' + esc(a.course + ' · ' + a.title) + (a.dueAt ? ' (due ' + esc(fmtDate(a.dueAt)) + ')' : '') + '</option>').join('') + '</select>') + field('Note to your teacher (optional)', '<textarea name="note" rows="2" maxlength="3000"></textarea>'), 'Submit', 'narrow');
});
FORMS.edSubmitWork = (f, btn) => busy(btn, async () => { const r = await call('stSubmit', { id: ED.it.id, moduleId: f.elements.moduleId.value, note: f.elements.note.value }); closeModal(); toast('Submitted (version ' + r.version + ').'); });
ACT.edLive = () => busy(null, async () => {
  await edSave();
  const courses = (await stCourses()).filter((c) => c.editor);
  formModal('Launch live activity', 'Students in the course get a notification and answer from their LMS. You control the pace and when answers are revealed.', 'edLive', field('Course', '<select name="courseId">' + courses.map((c) => '<option value="' + esc(c.id) + '"' + (c.id === ED.it.meta.courseId ? ' selected' : '') + '>' + esc(c.shortname + ' · ' + c.fullname) + '</option>').join('') + '</select>'), 'Launch', 'narrow');
});
FORMS.edLive = (f, btn) => busy(btn, async () => { const r = await call('stLiveStart', { id: ED.it.id, courseId: f.elements.courseId.value }); closeModal(); go('/studio/live/' + r.id); });
ACT.edAsTemplate = () => formModal('Save as institutional template', 'Faculty (and students, if you choose) can start new work from it.', 'edAsTemplate', field('Template name', '<input type="text" name="name" maxlength="120" required value="' + esc(ED.it.title) + '">') + field('For', '<select name="audience"><option value="both">Faculty and students</option><option value="faculty">Faculty only</option><option value="student">Students only</option></select>'), 'Save template', 'narrow');
FORMS.edAsTemplate = (f, btn) => busy(btn, async () => { await edSave(); await call('stSaveTemplate', { id: ED.it.id, name: f.elements.name.value, audience: f.elements.audience.value }); ST.tpl = null; closeModal(); toast('Template saved.'); });
ACT.edArchive = () => busy(null, async () => { await call('stArchive', { id: ED.it.id, restore: ED.it.status === 'archived' }); toast(ED.it.status === 'archived' ? 'Restored.' : 'Archived.'); go('/studio/edit/' + ED.it.id); });
ACT.edDelete = async () => { if (!await confirmBox('Move to trash?', '<p>You can restore it from Library → Trash.' + (ED.it.published.length ? ' It stays in the courses it was published to until you remove those activities.' : '') + '</p>', 'Move to trash', true)) return; busy(null, async () => { await call('stDelete', { id: ED.it.id, confirm: true }); ED.dirty = false; toast('Moved to trash.'); go('/studio/library'); }); };
ACT.edInsights = () => busy(null, async () => {
  const r = await call('stLearning', { id: ED.it.id });
  const g = (x) => (x.quizAvg == null ? '—' : x.quizAvg + '% (' + x.quizN + ')');
  openModal(modalHead('Learning insights', 'Students who engaged with this resource compared with those who did not, in each course it is published to.') + '<div class="modal-body">' + notice(esc(r.note), '', 'info') +
    (r.rows.length ? '<div class="table-wrap"><table class="table"><thead><tr><th>Course</th><th>Engaged</th><th>Quiz average (engaged)</th><th>Not engaged</th><th>Quiz average (not engaged)</th><th>Assignment submission</th></tr></thead><tbody>' + r.rows.map((x) => '<tr><td><b>' + esc(x.course) + '</b></td><td class="tnum">' + x.engaged.n + '</td><td class="tnum">' + (x.enough ? g(x.engaged) : '—') + '</td><td class="tnum">' + x.notEngaged.n + '</td><td class="tnum">' + (x.enough ? g(x.notEngaged) : '—') + '</td><td class="small">' + (x.enough ? x.engaged.submitted + '% vs ' + x.notEngaged.submitted + '%' : 'Not enough students to compare') + '</td></tr>').join('') + '</tbody></table></div>' : '<p class="small muted">Publish to a course to see insights.</p>') + '<div class="form-actions"><button class="btn btn-primary" data-act="close">Close</button></div></div>', 'xwide');
});

/* =====================================================================
   DOCUMENT EDITOR
   ===================================================================== */
function edDocLayout(ro) {
  return '<div class="st-body doc"><aside class="st-left"><div class="st-lpanel" id="edLeft"></div></aside><main class="st-center doc">' +
    (ro ? '' : '<div class="st-doctools" role="toolbar" aria-label="Formatting">' + [['h2', 'heading', 'Heading'], ['h3', 'text', 'Subheading'], ['b', 'bold', 'Bold'], ['i', 'italic', 'Italic'], ['ul', 'listUl', 'Bulleted list'], ['ol', 'listOl', 'Numbered list'], ['quote', 'reply', 'Quote'], ['table', 'table', 'Table'], ['link', 'link', 'Link'], ['hr', 'minus', 'Divider']].map((t) => '<button class="btn-icon sm" data-act="edFmt" data-f="' + t[0] + '" title="' + t[2] + '" aria-label="' + t[2] + '">' + icon(t[1]) + '</button>').join('') + '<span class="spacer"></span><label class="check inline"><input type="checkbox" data-change="edDocSplit"' + (ED.split !== false ? ' checked' : '') + '><span>Preview</span></label></div>') +
    '<div class="st-docwrap' + (ED.split !== false || ro ? ' split' : '') + '">' + (ro ? '' : '<textarea id="edDoc" class="st-doc" spellcheck="true" aria-label="Document text (Markdown)" data-input="edDoc" data-delay="120">' + esc(ED.it.doc) + '</textarea>') + '<article class="prose lg st-docprev" id="edDocPrev">' + md(ED.it.doc) + '</article></div></main>' +
    '<aside class="st-right"><div class="st-rtabs" role="tablist">' + [['details', 'Details'], ['review', 'Review']].map((t) => '<button role="tab" class="st-rtab' + ((ED.rpanel === t[0] || (t[0] === 'details' && ED.rpanel === 'design')) ? ' active' : '') + '" data-act="edRight" data-p="' + t[0] + '">' + t[1] + '</button>').join('') + '</div><div id="edRight" class="st-rpanel"></div></aside></div>';
}
let edDocPrevT = null;
INPUTS.edDoc = (el) => { if (!ED) return; if (!ED.docTyping) { edPush(); ED.docTyping = true; setTimeout(() => { if (ED) ED.docTyping = false; }, 2500); } ED.it.doc = el.value; edChanged({ draw: false }); clearTimeout(edDocPrevT); edDocPrevT = setTimeout(edDocPreview, 300); edLeftOutline(); };
function edDocPreview() { const p = $('#edDocPrev'); if (p && ED) p.innerHTML = md(ED.it.doc); }
ACT.edDocSplit = (d, el) => { ED.split = el.checked; $('.st-docwrap').classList.toggle('split', el.checked); };
function edDocInsert(text) { const ta = $('#edDoc'); if (!ta) return; edPush(); ta.setRangeText(text, ta.selectionStart, ta.selectionEnd, 'end'); ED.it.doc = ta.value; edChanged({ draw: false }); edDocPreview(); ta.focus(); }
ACT.edFmt = (d) => {
  const ta = $('#edDoc'); const a = ta.selectionStart, b = ta.selectionEnd, sel = ta.value.slice(a, b) || '';
  const wrap = (l, r, ph) => { edPush(); ta.setRangeText(l + (sel || ph) + r, a, b, 'select'); };
  const lines = (pre) => { edPush(); ta.setRangeText((sel || 'Item').split('\n').map((x, i) => (typeof pre === 'function' ? pre(i) : pre) + x.replace(/^(\s*[-*]\s+|\s*\d+\.\s+|#+\s+|>\s?)/, '')).join('\n'), a, b, 'select'); };
  if (d.f === 'b') wrap('**', '**', 'bold text'); else if (d.f === 'i') wrap('*', '*', 'italic text');
  else if (d.f === 'h2') lines('## '); else if (d.f === 'h3') lines('### '); else if (d.f === 'ul') lines('- '); else if (d.f === 'ol') lines((i) => (i + 1) + '. '); else if (d.f === 'quote') lines('> ');
  else if (d.f === 'link') wrap('[', '](https://)', 'link text'); else if (d.f === 'hr') { edPush(); ta.setRangeText('\n---\n', a, b, 'end'); }
  else if (d.f === 'table') { edPush(); ta.setRangeText('\n| Column 1 | Column 2 | Column 3 |\n|---|---|---|\n|  |  |  |\n|  |  |  |\n', a, b, 'end'); }
  ED.it.doc = ta.value; edChanged({ draw: false }); edDocPreview(); edLeftOutline(); ta.focus();
};
function edLeftOutline() {
  const box = $('#edOutline'); if (!box || !ED) return;
  const heads = String(ED.it.doc).split('\n').map((l, i) => ({ m: /^(#{1,4})\s+(.*)$/.exec(l), i })).filter((x) => x.m);
  box.innerHTML = heads.length ? heads.map((x) => '<button class="st-outl l' + x.m[1].length + '" data-act="edJump" data-line="' + x.i + '">' + esc(x.m[2].slice(0, 60)) + '</button>').join('') : '<p class="xs muted">Headings appear here.</p>';
}
ACT.edJump = (d) => { const ta = $('#edDoc'); if (!ta) return; const pos = ta.value.split('\n').slice(0, Number(d.line)).join('\n').length + 1; ta.focus(); ta.setSelectionRange(pos, pos); ta.scrollTop = ta.scrollHeight * Number(d.line) / Math.max(1, ta.value.split('\n').length) - 40; };

/* ---------- left panel for non-canvas editors: outline + AI ---------- */
function edLeftText() {
  const box = $('#edLeft'); if (!box) return;
  box.innerHTML = (ED.it.format === 'doc' ? '<h3 class="st-ph">Outline</h3><div id="edOutline"></div>' : '') + (ED.it.perms.edit ? '<h3 class="st-ph">' + icon('sparkle', 'i-sm') + ' Academic Copilot</h3>' + (ED.it.format === 'doc' ? edAiPanel() : edQuizAi()) : '');
  edLeftOutline();
}

/* =====================================================================
   QUIZ EDITOR
   ===================================================================== */
function edQuizLayout(ro) {
  return '<div class="st-body doc"><aside class="st-left"><div class="st-lpanel" id="edLeft"></div></aside><main class="st-center doc"><div class="st-qwrap" id="edQ">' + edQuizList() + '</div>' + (ro ? '' : '<button class="btn" data-act="edQAdd">' + icon('plus') + 'Add question</button>') + '</main>' +
    '<aside class="st-right"><div class="st-rtabs" role="tablist">' + [['details', 'Details'], ['review', 'Review']].map((t) => '<button role="tab" class="st-rtab' + ((ED.rpanel === t[0] || (t[0] === 'details' && ED.rpanel === 'design')) ? ' active' : '') + '" data-act="edRight" data-p="' + t[0] + '">' + t[1] + '</button>').join('') + '</div><div id="edRight" class="st-rpanel"></div></aside></div>';
}
function edQuizList() {
  const qs = ED.it.questions, ro = !ED.it.perms.edit, c = (ST.courses || []).find((x) => x.id === ED.it.meta.courseId);
  if (!qs.length) return emptyState('quiz', 'No questions yet', 'Add questions, or let the Copilot draft some.', '', false);
  return qs.map((q, i) => '<section class="card st-qcard" data-i="' + i + '"><div class="card-body"><div class="row-wrap" style="gap:.5rem"><b>Q' + (i + 1) + '</b>' +
    '<select data-change="edQ" data-i="' + i + '" data-k="type" aria-label="Question type"' + (ro ? ' disabled' : '') + '>' + [['mcq', 'Multiple choice (one answer)'], ['multi', 'Multiple response'], ['tf', 'True / false'], ['short', 'Short answer / word cloud']].map((t) => '<option value="' + t[0] + '"' + (q.type === t[0] ? ' selected' : '') + '>' + t[1] + '</option>').join('') + '</select>' +
    '<select data-change="edQ" data-i="' + i + '" data-k="bloom" aria-label="Bloom level"' + (ro ? ' disabled' : '') + '>' + ['Remember', 'Understand', 'Apply', 'Analyze', 'Evaluate', 'Create'].map((b) => '<option' + (q.bloom === b ? ' selected' : '') + '>' + b + '</option>').join('') + '</select>' +
    '<select data-change="edQ" data-i="' + i + '" data-k="difficulty" aria-label="Difficulty"' + (ro ? ' disabled' : '') + '>' + ['Easy', 'Moderate', 'Difficult'].map((b) => '<option' + (q.difficulty === b ? ' selected' : '') + '>' + b + '</option>').join('') + '</select>' +
    (c && c.co.length ? '<select data-change="edQ" data-i="' + i + '" data-k="co" aria-label="Course outcome"' + (ro ? ' disabled' : '') + '><option value="">CO —</option>' + c.co.map((o) => '<option' + (q.co === o.code ? ' selected' : '') + '>' + esc(o.code) + '</option>').join('') + '</select>' : '') +
    '<label class="st-marks">Marks <input type="number" min="0.5" max="100" step="0.5" value="' + q.marks + '" data-input="edQ" data-i="' + i + '" data-k="marks" data-delay="300"' + (ro ? ' disabled' : '') + '></label><span class="spacer"></span>' +
    (ro ? '' : '<button class="btn-icon sm" data-act="edQMove" data-i="' + i + '" data-d="-1" aria-label="Move up">' + icon('up') + '</button><button class="btn-icon sm" data-act="edQMove" data-i="' + i + '" data-d="1" aria-label="Move down">' + icon('down') + '</button><button class="btn-icon sm danger" data-act="edQDel" data-i="' + i + '" aria-label="Delete question">' + icon('trash') + '</button>') + '</div>' +
    '<textarea class="st-qtext" rows="2" data-input="edQ" data-i="' + i + '" data-k="text" data-delay="300" aria-label="Question text"' + (ro ? ' readonly' : '') + '>' + esc(q.text) + '</textarea>' +
    (q.type === 'short' ? '<label class="st-prop col"><span>Model answer (optional; leave empty for a poll / word cloud)</span><input type="text" value="' + esc(q.correct || '') + '" data-input="edQ" data-i="' + i + '" data-k="correct" data-delay="300"' + (ro ? ' readonly' : '') + '></label>'
      : '<div class="st-qopts">' + q.options.map((o, j) => '<div class="st-qopt"><input type="' + (q.type === 'multi' ? 'checkbox' : 'radio') + '" name="c' + i + '" ' + ((q.type === 'multi' ? (q.correct || []).indexOf(j) >= 0 : Number(q.correct) === j) ? 'checked' : '') + ' data-change="edQCorrect" data-i="' + i + '" data-j="' + j + '" aria-label="Correct answer ' + 'ABCDEF'.charAt(j) + '"' + (ro ? ' disabled' : '') + '><span class="st-ql">' + 'ABCDEF'.charAt(j) + '</span>' +
        '<input type="text" value="' + esc(o) + '" data-input="edQOpt" data-i="' + i + '" data-j="' + j + '" data-delay="300" aria-label="Option ' + 'ABCDEF'.charAt(j) + '"' + (ro || q.type === 'tf' ? ' readonly' : '') + '>' + (ro || q.type === 'tf' || q.options.length <= 2 ? '' : '<button class="btn-icon sm" data-act="edQOptDel" data-i="' + i + '" data-j="' + j + '" aria-label="Remove option">' + icon('x') + '</button>') + '</div>').join('') +
        (ro || q.type === 'tf' || q.options.length >= 6 ? '' : '<button class="btn btn-sm btn-ghost" data-act="edQOptAdd" data-i="' + i + '">' + icon('plus', 'i-sm') + 'Option</button>') + '</div>') +
    '<label class="st-prop col"><span>Explanation (shown after answering)</span><textarea rows="2" data-input="edQ" data-i="' + i + '" data-k="explanation" data-delay="300"' + (ro ? ' readonly' : '') + '>' + esc(q.explanation || '') + '</textarea></label></div></section>').join('');
}
function edQuizAi() {
  return '<form data-form="edQAi" class="st-aip"><label class="label" for="edQAiT">Add questions</label><input id="edQAiT" type="text" name="topic" maxlength="300" placeholder="Topic or learning outcome" value="' + esc(ED.it.meta.topic || '') + '"><div class="row" style="gap:.4rem;margin-top:.4rem"><input type="number" name="n" min="1" max="30" value="5" style="width:70px" aria-label="How many"><button class="btn btn-sm btn-primary">' + icon('sparkle', 'i-sm') + 'Generate</button></div>' +
    '<details class="st-src"><summary class="xs">Use source material</summary><textarea name="source" rows="5" maxlength="100000" placeholder="Paste notes; questions are drawn from them."></textarea></details></form><p class="xs muted">Generated questions are marked for review. Check every answer key.</p>';
}
FORMS.edQAi = (f, btn) => busy(btn, async () => {
  const r = await call('stGenerate', { kind: 'quiz', topic: f.elements.topic.value, prompt: f.elements.topic.value, count: f.elements.n.value, sourceText: f.elements.source.value, courseId: ED.it.meta.courseId, unitId: ED.it.meta.unitId, preview: true });
  edPush(); r.content.questions.forEach((q) => { q.id = edUid(); ED.it.questions.push(q); });
  edMarkAi(r.provider, r.outline); edChanged({ draw: false }); $('#edQ').innerHTML = edQuizList();
  toast(r.content.questions.length + ' question(s) added' + (r.outline ? ' as templates to complete.' : '. Check the answer keys.'));
});
INPUTS.edQ = (el) => { const q = ED.it.questions[Number(el.dataset.i)]; if (!q) return; edPush(); q[el.dataset.k] = el.type === 'number' ? Number(el.value) : el.value; edChanged({ draw: false }); };
ACT.edQ = (d, el) => {
  const q = ED.it.questions[Number(d.i)]; edPush(); q[d.k] = el.value;
  if (d.k === 'type') { if (el.value === 'tf') { q.options = ['True', 'False']; q.correct = 0; } else if (el.value === 'short') { q.options = []; q.correct = ''; } else { if (q.options.length < 2) q.options = ['Option A', 'Option B', 'Option C', 'Option D']; q.correct = el.value === 'multi' ? [0] : 0; } $('#edQ').innerHTML = edQuizList(); }
  edChanged({ draw: false });
};
ACT.edQCorrect = (d, el) => { const q = ED.it.questions[Number(d.i)]; edPush(); const j = Number(d.j); if (q.type === 'multi') { const s = new Set(q.correct || []); if (el.checked) s.add(j); else s.delete(j); q.correct = [...s].sort(); } else q.correct = j; edChanged({ draw: false }); };
INPUTS.edQOpt = (el) => { const q = ED.it.questions[Number(el.dataset.i)]; edPush(); q.options[Number(el.dataset.j)] = el.value; edChanged({ draw: false }); };
ACT.edQOptAdd = (d) => { const q = ED.it.questions[Number(d.i)]; edPush(); q.options.push('Option ' + 'ABCDEF'.charAt(q.options.length)); edChanged({ draw: false }); $('#edQ').innerHTML = edQuizList(); };
ACT.edQOptDel = (d) => { const q = ED.it.questions[Number(d.i)], j = Number(d.j); edPush(); q.options.splice(j, 1); if (q.type === 'multi') q.correct = (q.correct || []).filter((x) => x !== j).map((x) => (x > j ? x - 1 : x)); else if (Number(q.correct) >= q.options.length) q.correct = 0; edChanged({ draw: false }); $('#edQ').innerHTML = edQuizList(); };
ACT.edQAdd = () => { edPush(); ED.it.questions.push({ id: edUid(), type: 'mcq', text: '', options: ['', '', '', ''], correct: 0, explanation: '', marks: 1, bloom: 'Understand', difficulty: 'Moderate', co: '' }); edChanged({ draw: false }); $('#edQ').innerHTML = edQuizList(); const all = $$('.st-qtext'); if (all.length) all[all.length - 1].focus(); };
ACT.edQDel = (d) => { edPush(); ED.it.questions.splice(Number(d.i), 1); edChanged({ draw: false }); $('#edQ').innerHTML = edQuizList(); };
ACT.edQMove = (d) => { const i = Number(d.i), j = i + Number(d.d), Q = ED.it.questions; if (j < 0 || j >= Q.length) return; edPush(); [Q[i], Q[j]] = [Q[j], Q[i]]; edChanged({ draw: false }); $('#edQ').innerHTML = edQuizList(); };

/* =====================================================================
   FLASHCARD EDITOR
   ===================================================================== */
function edCardsLayout(ro) {
  return '<div class="st-body doc"><aside class="st-left"><div class="st-lpanel" id="edLeft"></div></aside><main class="st-center doc"><div id="edC">' + edCardsList() + '</div>' + (ro ? '' : '<button class="btn" data-act="edCAdd">' + icon('plus') + 'Add card</button>') + '</main>' +
    '<aside class="st-right"><div class="st-rtabs" role="tablist">' + [['details', 'Details'], ['review', 'Review']].map((t) => '<button role="tab" class="st-rtab' + ((ED.rpanel === t[0] || (t[0] === 'details' && ED.rpanel === 'design')) ? ' active' : '') + '" data-act="edRight" data-p="' + t[0] + '">' + t[1] + '</button>').join('') + '</div><div id="edRight" class="st-rpanel"></div></aside></div>';
}
function edCardsList() {
  const ro = !ED.it.perms.edit;
  return ED.it.cards.length ? '<div class="st-cards">' + ED.it.cards.map((c, i) => '<div class="card st-cardrow"><div class="card-body"><span class="xs muted">Card ' + (i + 1) + '</span><input type="text" value="' + esc(c.front) + '" placeholder="Front (term or question)" data-input="edC" data-i="' + i + '" data-k="front" data-delay="300" aria-label="Front of card ' + (i + 1) + '"' + (ro ? ' readonly' : '') + '><textarea rows="2" placeholder="Back (meaning or answer)" data-input="edC" data-i="' + i + '" data-k="back" data-delay="300" aria-label="Back of card ' + (i + 1) + '"' + (ro ? ' readonly' : '') + '>' + esc(c.back) + '</textarea>' + (ro ? '' : '<button class="btn-icon sm danger" data-act="edCDel" data-i="' + i + '" aria-label="Delete card">' + icon('trash') + '</button>') + '</div></div>').join('') + '</div>' : emptyState('copy', 'No cards yet', 'Add cards or transform notes into flashcards.', '', false);
}
INPUTS.edC = (el) => { const c = ED.it.cards[Number(el.dataset.i)]; edPush(); c[el.dataset.k] = el.value; edChanged({ draw: false }); };
ACT.edCAdd = () => { edPush(); ED.it.cards.push({ front: '', back: '' }); edChanged({ draw: false }); $('#edC').innerHTML = edCardsList(); };
ACT.edCDel = (d) => { edPush(); ED.it.cards.splice(Number(d.i), 1); edChanged({ draw: false }); $('#edC').innerHTML = edCardsList(); };
