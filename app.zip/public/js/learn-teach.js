'use strict';
/* =====================================================================
   LEARNING PATHS — faculty and administrator side
   Course list, content (topics, skills, lessons, questions with variants),
   analytics, students (inspect and override recommendations), course
   settings, and the institution's Learning settings.
   Editors keep their state in LPE and re-render on structural changes;
   every save is validated again on the server.
   ===================================================================== */
const LPE = { courseId: '', kind: '', obj: null, id: '', author: null };
const LP_DIFF = { 1: 'Introductory', 2: 'Core', 3: 'Stretch' };
const LP_STATE_TONE = { draft: '', review: 'warning', published: 'success', archived: '' };
function lpState(st) { return badge(st.charAt(0).toUpperCase() + st.slice(1), LP_STATE_TONE[st] || ''); }
function lpTeachTabs(cid, tab) {
  const t = [['content', 'Content', 'layers'], ['analytics', 'Analytics', 'chart'], ['students', 'Students', 'users'], ['settings', 'Settings', 'settings']];
  return '<nav class="tabs" aria-label="Learning path sections">' + t.map((x) => '<a class="tab' + (x[0] === tab ? ' active' : '') + '" href="#/learn/teach/' + esc(cid) + '?tab=' + x[0] + '"' + (x[0] === tab ? ' aria-current="page"' : '') + '>' + icon(x[2]) + x[1] + '</a>').join('') + '</nav>';
}
function lpOff(admin) { return notice('Learning Paths is switched off for the institution. ' + (admin ? '<a href="#/learn/admin">Open Learning settings</a> to switch it on.' : 'An administrator can switch it on in Learning settings.'), 'warn'); }

/* =====================================================================
   COURSES I TEACH
   ===================================================================== */
async function viewLpTeachHome() {
  if (S.me.role === 'student') { go('/learn'); return null; }
  const d = await call('lpTeachCourses');
  return {
    title: 'Learning paths',
    html: pageHead('Learning paths', { sub: 'Short lessons, adaptive practice, reviews and progress dashboards for your courses.', actions: d.admin ? '<a class="btn" href="#/learn/admin">' + icon('settings') + 'Learning settings</a>' : '' }) +
      (d.on ? '' : lpOff(d.admin)) +
      (d.courses.length ? '<div class="lp-subjects">' + d.courses.map((c) => '<article class="card card-pad lp-subject cc-' + esc(c.color) + '"><div class="faint small">' + esc(c.short) + '</div><h3>' + esc(c.name) + '</h3>' +
        '<p>' + (c.enabled ? badge('On for students', 'success', 'check') : badge('Not on for students', '')) + '</p><ul class="lp-kv"><li><span>Published lessons</span><b>' + c.lessons + '</b></li><li><span>Drafts</span><b>' + c.drafts + '</b></li><li><span>Practice questions</span><b>' + c.items + '</b></li><li><span>Skills</span><b>' + c.skills + '</b></li><li><span>Students</span><b>' + c.students + '</b></li></ul>' +
        (d.on ? '<div class="row-wrap"><a class="btn btn-primary btn-sm" href="#/learn/teach/' + esc(c.id) + '">Open</a><a class="btn btn-sm" href="#/learn/teach/' + esc(c.id) + '?tab=analytics">Analytics</a></div>' : '') + '</article>').join('') + '</div>' : emptyState('book', 'No courses to set up', 'Courses you teach appear here.'))
  };
}

/* =====================================================================
   ONE COURSE
   ===================================================================== */
async function viewLpTeach(cid, params) {
  const tab = (params && params.get('tab')) || 'content';
  const a = await call('lpAuthor', { courseId: cid });
  LPE.author = a;
  let body = '';
  if (tab === 'content') body = lpContentHtml(a);
  else if (tab === 'analytics') body = await lpAnalyticsHtml(cid);
  else if (tab === 'students') body = await lpStudentsHtml(cid);
  else body = lpCourseSettingsHtml(a);
  return {
    title: a.course.short + ' · Learning path',
    html: pageHead(a.course.name, { crumbs: [['Learning paths', '/learn/teach'], [a.course.short]], sub: (a.cfg.enabled ? badge('On for students', 'success', 'check') : badge('Not on for students yet', 'warning')) + ' · curriculum version ' + a.cfg.version }) + lpTeachTabs(cid, tab) + body
  };
}
function lpContentHtml(a) {
  const cid = a.course.id;
  const skillName = {};
  a.skills.forEach((k) => { skillName[k.id] = k.name; });
  const units = a.sections.map((sec) => {
    const topics = a.topics.filter((t) => t.sectionId === sec.id);
    return '<section class="card lp-unit"><div class="card-head"><h2>' + esc(sec.name) + '</h2><button class="btn btn-sm" data-act="lpeTopic" data-section="' + esc(sec.id) + '">' + icon('plus') + 'Topic</button></div>' +
      (topics.length ? topics.map((t) => {
        const skills = a.skills.filter((k) => k.topicId === t.id);
        const lessons = a.lessons.filter((l) => l.topicId === t.id).sort((x, y) => x.position - y.position);
        return '<div class="lp-topic"><div class="row-wrap lp-topic-h"><h3>' + esc(t.name) + '</h3><span class="spacer"></span><button class="btn btn-sm btn-ghost" data-act="lpeTopic" data-id="' + esc(t.id) + '" data-section="' + esc(sec.id) + '" aria-label="Rename topic ' + esc(t.name) + '">' + icon('edit') + '</button>' +
          '<button class="btn btn-sm" data-act="lpeSkill" data-topic="' + esc(t.id) + '">' + icon('plus') + 'Skill</button><a class="btn btn-sm" href="#/learn/teach/' + esc(cid) + '/lesson/new?topic=' + esc(t.id) + '">' + icon('plus') + 'Lesson</a></div>' +
          '<div class="lp-skillchips">' + (skills.length ? skills.map((k) => '<button class="lp-chip" data-act="lpeSkill" data-id="' + esc(k.id) + '" data-topic="' + esc(t.id) + '">' + icon('target') + esc(k.name) + ' <span class="faint">' + k.items + ' q</span>' + (k.prereqIds.length ? ' <span class="faint" title="Prerequisites">after ' + esc(k.prereqIds.map((p) => skillName[p]).filter(Boolean).join(', ')) + '</span>' : '') + '</button>').join('') : '<span class="muted small">No skills yet — add the skills this topic builds.</span>') + '</div>' +
          (lessons.length ? '<ol class="lp-lesson-list">' + lessons.map((l) => '<li><div><b>' + esc(l.title) + '</b> ' + lpState(l.status) + (l.required ? '' : ' ' + badge('Optional', '')) +
            '<div class="small muted">' + l.minutes + ' min · ' + plural(l.itemIds.length, 'activity', 'activities') + ' · v' + (l.major || 1) + '.' + l.v + (l.warnings.length ? ' · ' + icon('alert') + plural(l.warnings.length, 'check') + ' to review' : '') + '</div></div>' +
            '<div class="row-wrap"><button class="btn-icon sm" data-act="lpeMoveLesson" data-id="' + esc(l.id) + '" data-dir="up" aria-label="Move up">' + icon('up') + '</button><button class="btn-icon sm" data-act="lpeMoveLesson" data-id="' + esc(l.id) + '" data-dir="down" aria-label="Move down">' + icon('down') + '</button>' +
            '<a class="btn btn-sm" href="#/learn/lesson/' + esc(l.id) + '">' + icon('eye') + 'Preview</a><a class="btn btn-sm" href="#/learn/teach/' + esc(cid) + '/lesson/' + esc(l.id) + '">' + icon('edit') + 'Edit</a>' + lpStatusButtons('lpeLessonStatus', l) + '</div></li>').join('') + '</ol>' : '<p class="muted small">No lessons yet.</p>') + '</div>';
      }).join('') : '<p class="card-pad muted">No topics in this unit yet.</p>') + '</section>';
  }).join('');
  const items = '<section class="card"><div class="card-head"><h2>Practice questions</h2><div class="row-wrap">' + (a.features.aiDrafts ? '<button class="btn btn-sm" data-act="lpeAi">' + icon('sparkles') + 'Draft with AI</button>' : '') + '<a class="btn btn-sm btn-primary" href="#/learn/teach/' + esc(cid) + '/item/new">' + icon('plus') + 'Question</a></div></div>' +
    (a.items.length ? '<div class="table-wrap"><table class="table"><thead><tr><th scope="col">Question</th><th scope="col">Type</th><th scope="col">Skills</th><th scope="col">Difficulty</th><th scope="col">Status</th><th scope="col"><span class="sr">Actions</span></th></tr></thead><tbody>' +
      a.items.filter((i) => i.status !== 'deleted').map((i) => '<tr><td><b>' + esc(i.title || i.variants[0].prompt.slice(0, 70) || '(untitled)') + '</b>' + (i.variants.length > 1 ? ' <span class="faint small">' + i.variants.length + ' variants</span>' : '') + (i.ai ? ' ' + badge(i.aiReviewed ? 'AI draft · reviewed' : 'AI draft · needs review', i.aiReviewed ? '' : 'warning', 'sparkles') : '') + (i.purpose === 'assessment' ? ' ' + badge('Assessment only', '') : '') +
        (i.warnings.length ? '<div class="small muted">' + icon('alert') + esc(i.warnings[0]) + (i.warnings.length > 1 ? ' (+' + (i.warnings.length - 1) + ')' : '') + '</div>' : '') + '</td><td>' + esc(LP_TYPES[i.type]) + '</td><td class="small">' + esc(i.skillIds.map((x) => skillName[x]).filter(Boolean).join(', ')) + '</td><td>' + LP_DIFF[i.difficulty] + '</td><td>' + lpState(i.status) + '</td>' +
        '<td><div class="row-wrap"><button class="btn btn-sm" data-act="lpePreview" data-id="' + esc(i.id) + '">' + icon('eye') + 'Try</button><a class="btn btn-sm" href="#/learn/teach/' + esc(cid) + '/item/' + esc(i.id) + '">' + icon('edit') + 'Edit</a>' + lpStatusButtons('lpeItemStatus', i) + '</div></td></tr>').join('') + '</tbody></table></div>' : '<p class="card-pad muted">No questions yet. Add skills first, then write questions for them.</p>') + '</section>';
  const intro = !a.cfg.enabled ? notice('Students do not see this learning path yet. When the content is ready, switch it on under <a href="#/learn/teach/' + esc(cid) + '?tab=settings">Settings</a>.', '', 'info') : '';
  return intro + '<p class="muted small">Subject → Unit (your course sections) → Topic → Skill → Lesson and practice questions. Drafts are invisible to students; publishing makes them available.</p>' + units + items;
}
function lpStatusButtons(act, x) {
  const b = (st, label, tone) => '<button class="btn btn-sm ' + (tone || '') + '" data-act="' + act + '" data-id="' + esc(x.id) + '" data-status="' + st + '">' + label + '</button>';
  if (x.status === 'draft') return b('review', 'Ready for review') + b('published', 'Publish', 'btn-primary');
  if (x.status === 'review') return b('published', 'Publish', 'btn-primary') + b('draft', 'Back to draft');
  if (x.status === 'published') return b('draft', 'Unpublish') + b('archived', 'Archive', 'btn-ghost');
  return b('draft', 'Restore');
}
ACT.lpeLessonStatus = (d, btn) => busy(btn, async () => { await call('lpSetLessonStatus', { id: d.id, status: d.status }); toast('Lesson ' + (d.status === 'published' ? 'published.' : 'updated.')); refresh(); });
ACT.lpeItemStatus = (d, btn) => busy(btn, async () => { await call('lpSetItemStatus', { id: d.id, status: d.status }); toast('Question ' + (d.status === 'published' ? 'published.' : 'updated.')); refresh(); });
ACT.lpeMoveLesson = (d, btn) => busy(btn, async () => { await call('lpMoveLesson', { id: d.id, dir: d.dir }); refresh(); });
ACT.lpeTopic = (d) => {
  const a = LPE.author;
  const t = d.id ? a.topics.find((x) => x.id === d.id) : null;
  formModal(t ? 'Rename topic' : 'New topic', 'Topics group the skills and lessons of a unit.', 'lpeTopic', '<input type="hidden" name="id" value="' + esc(d.id || '') + '">' +
    field('Unit', '<select class="input" name="sectionId">' + a.sections.map((s) => '<option value="' + esc(s.id) + '"' + (s.id === d.section ? ' selected' : '') + '>' + esc(s.name) + '</option>').join('') + '</select>') +
    field('Topic name', '<input class="input" name="name" maxlength="120" required value="' + esc(t ? t.name : '') + '">'), 'Save');
};
FORMS.lpeTopic = (f, btn) => busy(btn, async () => { await call('lpSaveTopic', { courseId: LPE.author.course.id, id: f.elements.id.value, sectionId: f.elements.sectionId.value, name: f.elements.name.value }); closeModal(); refresh(); });
ACT.lpeSkill = (d) => {
  const a = LPE.author;
  const k = d.id ? a.skills.find((x) => x.id === d.id) : null;
  const others = a.skills.filter((x) => !k || x.id !== k.id);
  formModal(k ? 'Edit skill' : 'New skill', 'A skill is something students can do — questions are tagged with it, and proficiency is estimated per skill.', 'lpeSkill',
    '<input type="hidden" name="id" value="' + esc(d.id || '') + '"><input type="hidden" name="topicId" value="' + esc(d.topic) + '">' +
    field('Skill', '<input class="input" name="name" maxlength="120" required value="' + esc(k ? k.name : '') + '" placeholder="e.g. Calculate the after-tax cost of debt">') +
    field('Description', '<textarea class="input" name="description" rows="2" maxlength="600">' + esc(k ? k.description : '') + '</textarea>', 'Optional') +
    (others.length ? '<fieldset class="fieldset"><legend>Practise only after (prerequisites)</legend><div class="lp-checks">' + others.map((o) => check('pre_' + o.id, esc(o.name), k && k.prereqIds.indexOf(o.id) >= 0)).join('') + '</div><p class="small muted">Students get questions for this skill once they are at least “Practising” the prerequisites. You can always unlock or assign practice for one student.</p></fieldset>' : '') +
    (k ? '<p><button class="btn btn-sm btn-danger" type="button" data-act="lpeDelSkill" data-id="' + esc(k.id) + '">' + icon('trash') + 'Delete skill</button></p>' : ''), 'Save');
};
FORMS.lpeSkill = (f, btn) => busy(btn, async () => {
  const pre = $$('input[type=checkbox]', f).filter((x) => x.checked && x.name.indexOf('pre_') === 0).map((x) => x.name.slice(4));
  await call('lpSaveSkill', { courseId: LPE.author.course.id, id: f.elements.id.value, topicId: f.elements.topicId.value, name: f.elements.name.value, description: f.elements.description.value, prereqIds: pre });
  closeModal(); refresh();
});
ACT.lpeDelSkill = (d, btn) => busy(btn, async () => { if (!(await confirmBox('Delete this skill?', 'Its proficiency history stays in the records; questions must be re-tagged or archived first.', 'Delete', true))) return; await call('lpDeleteSkill', { id: d.id }); refresh(); });
ACT.lpeAi = () => {
  const a = LPE.author;
  if (!a.skills.length) { toast('Add a skill first.', 'err'); return; }
  formModal('Draft questions with AI', 'Drafts are saved as drafts. Every one must be checked by you before it can be published. No references or citations are generated.', 'lpeAi',
    field('Skill', '<select class="input" name="skillId">' + a.skills.map((k) => '<option value="' + esc(k.id) + '">' + esc(k.name) + '</option>').join('') + '</select>') +
    field('How many', '<input class="input" type="number" name="count" min="1" max="8" value="4">') +
    field('Notes for the AI', '<textarea class="input" name="notes" rows="3" maxlength="1500" placeholder="e.g. use examples from small businesses in Tamil Nadu; include one case"></textarea>', 'Optional'), 'Draft');
};
FORMS.lpeAi = (f, btn) => busy(btn, async () => {
  const r = await call('lpAiDraft', { courseId: LPE.author.course.id, skillId: f.elements.skillId.value, count: Number(f.elements.count.value), notes: f.elements.notes.value });
  closeModal(); toast(r.made + ' draft' + (r.made === 1 ? '' : 's') + ' added' + (r.skipped.length ? ' (' + r.skipped.length + ' skipped)' : '') + '. Review each before publishing.'); refresh();
});
/* ---------- preview a question as a student would see it ---------- */
ACT.lpePreview = (d, btn) => busy(btn, async () => {
  const r = await call('lpPreviewItem', { id: d.id, vi: Number(d.vi || 0) });
  LPE.preview = { id: d.id, vi: Number(d.vi || 0), item: r.item, n: r.variants, hints: r.hints };
  const it = r.item;
  const body = it.type === 'case' ? '<div class="lp-case prose">' + md(it.scenario) + '</div>' + it.parts.map((p, k) => '<div class="lp-part"><div class="lp-part-n">Question ' + (k + 1) + '</div>' + lpPartHtml(p.type, p.prompt, p.data, 'p' + k) + '</div>').join('') : lpPartHtml(it.type, it.prompt, it.data, 'a');
  openModal(modalHead('Try it: ' + (it.title || LP_TYPES[it.type]), 'Variant ' + (LPE.preview.vi + 1) + ' of ' + r.variants + ' · nothing is recorded') + '<div class="modal-body"><form data-form="lpePreview" novalidate><div class="lp-q-body">' + body + '</div>' +
    (r.hints.length ? '<details class="small"><summary>Hints (' + r.hints.length + ')</summary><ol>' + r.hints.map((h) => '<li>' + esc(h) + '</li>').join('') + '</ol></details>' : '') +
    (r.warnings.length ? notice(r.warnings.map(esc).join('<br>'), 'warn') : '') + '<div class="lp-fb" role="status" aria-live="polite"></div><div class="form-actions">' +
    (r.variants > 1 ? '<button class="btn" type="button" data-act="lpePreview" data-id="' + esc(d.id) + '" data-vi="' + ((LPE.preview.vi + 1) % r.variants) + '">Next variant</button>' : '') + '<button class="btn" type="button" data-act="close">Close</button><button class="btn btn-primary" type="submit">Check answer</button></div></form></div>', 'wide');
});
FORMS.lpePreview = (f, btn) => busy(btn, async () => {
  const P = LPE.preview;
  const r = await call('lpPreviewItem', { id: P.id, vi: P.vi, answer: lpCollect(f, P.item) });
  $('.lp-fb', f).innerHTML = '<div class="lp-fb-card ' + (r.correct === false ? 'no' : 'ok') + '"><p class="lp-verdict ' + (r.correct === false ? 'no' : 'ok') + '">' + icon(r.correct === false ? 'xCircle' : 'checkCircle') + '<b>' + (r.correct === null ? (r.complete ? 'Long enough' : 'Too short') : r.correct ? 'Correct' : 'Not quite (' + Math.round(r.score * 100) + '%)') + '</b></p>' +
    (r.misconception ? '<p class="lp-misc">' + icon('alert') + esc(r.misconception) + '</p>' : '') + (r.expected ? '<div class="lp-answer"><b>Answer:</b> ' + esc(r.expected) + '</div>' : '') + (r.explanation ? '<div class="prose small">' + md(r.explanation) + '</div>' : '') + '</div>';
});

/* =====================================================================
   EDITOR STATE HELPERS
   ===================================================================== */
function lpePath(obj, path) { return String(path).split('.').reduce((o, k) => (o == null ? o : o[k]), obj); }
function lpeSet(obj, path, v) { const ks = String(path).split('.'); const last = ks.pop(); const o = ks.reduce((x, k) => x[k], obj); o[last] = v; }
function lpeVal(el) { if (el.type === 'checkbox') return el.checked; if (el.dataset.kind === 'number') return el.value === '' ? '' : Number(el.value); if (el.dataset.kind === 'lines') return el.value.split('\n').map((x) => x.trim()).filter(Boolean); return el.value; }
INPUTS.lpe = (el) => { if (LPE.obj) { lpeSet(LPE.obj, el.dataset.path, lpeVal(el)); LPE.dirty = true; } };
ACT.lpeChange = (d, el) => { if (!LPE.obj) return; lpeSet(LPE.obj, d.path, lpeVal(el)); LPE.dirty = true; if (d.rerender) lpeRender(); };
function lpeIn(path, value, attrs) { return '<input class="input" data-input="lpe" data-delay="0" data-path="' + esc(path) + '" value="' + esc(value == null ? '' : value) + '"' + (attrs || '') + '>'; }
function lpeNum(path, value, attrs) { return '<input class="input" type="number" data-kind="number" data-input="lpe" data-delay="0" data-path="' + esc(path) + '" value="' + esc(value == null ? '' : value) + '"' + (attrs || '') + '>'; }
function lpeArea(path, value, rows, attrs) { return '<textarea class="input" rows="' + (rows || 3) + '" data-input="lpe" data-delay="0" data-path="' + esc(path) + '"' + (attrs || '') + '>' + esc(value == null ? '' : value) + '</textarea>'; }
function lpeLines(path, list, rows, ph) { return '<textarea class="input" rows="' + (rows || 3) + '" data-kind="lines" data-input="lpe" data-delay="0" data-path="' + esc(path) + '" placeholder="' + esc(ph || 'One per line') + '">' + esc((list || []).join('\n')) + '</textarea>'; }
function lpeSel(path, value, opts, rerender) { return '<select class="input" data-change="lpeChange" data-path="' + esc(path) + '"' + (rerender ? ' data-rerender="1"' : '') + '>' + opts.map((o) => '<option value="' + esc(o[0]) + '"' + (String(o[0]) === String(value) ? ' selected' : '') + '>' + esc(o[1]) + '</option>').join('') + '</select>'; }
function lpeChk(path, value, label, hint, rerender) { return '<label class="check"><input type="checkbox" data-change="lpeChange" data-path="' + esc(path) + '"' + (rerender ? ' data-rerender="1"' : '') + (value ? ' checked' : '') + '><span>' + label + (hint ? '<span class="hint">' + hint + '</span>' : '') + '</span></label>'; }
function lpeRowBtns(path, i, n) {
  return '<span class="lp-rowbtns"><button type="button" class="btn-icon sm" data-act="lpeMove" data-path="' + esc(path) + '" data-i="' + i + '" data-dir="-1" aria-label="Move up"' + (i === 0 ? ' disabled' : '') + '>' + icon('up') + '</button><button type="button" class="btn-icon sm" data-act="lpeMove" data-path="' + esc(path) + '" data-i="' + i + '" data-dir="1" aria-label="Move down"' + (i === n - 1 ? ' disabled' : '') + '>' + icon('down') + '</button><button type="button" class="btn-icon sm danger" data-act="lpeDel" data-path="' + esc(path) + '" data-i="' + i + '" aria-label="Remove">' + icon('x') + '</button></span>';
}
ACT.lpeMove = (d) => { const arr = lpePath(LPE.obj, d.path); const i = Number(d.i), j = i + Number(d.dir); if (j < 0 || j >= arr.length) return; const t = arr[i]; arr[i] = arr[j]; arr[j] = t; lpeRender(); };
ACT.lpeDel = (d) => { const arr = lpePath(LPE.obj, d.path); arr.splice(Number(d.i), 1); lpeRender(); };
ACT.lpeAdd = (d) => { const arr = lpePath(LPE.obj, d.path); arr.push(lpeTpl(d.tpl, arr)); lpeRender(); };
function lpeTpl(kind, arr) {
  const nextId = () => { const used = new Set((arr || []).map((x) => x.id)); for (const c of 'abcdefghij') if (!used.has(c)) return c; return 'o' + Date.now(); };
  switch (kind) {
    case 'option': return { id: nextId(), text: '' };
    case 'pair': return { left: '', right: '' };
    case 'step': return { text: '' };
    case 'wrong': return { value: '', text: '' };
    case 'misc': return { when: '', text: '' };
    case 'blank': return { accept: '' };
    case 'part': return { type: 'mcq', prompt: '', data: lpeData('mcq') };
    case 'text': return { kind: 'text', text: '' };
    case 'video': return { kind: 'video', url: '', title: '', transcript: '' };
    case 'example': return { kind: 'example', title: 'Worked example', problem: '', steps: [], answer: '' };
    default: return {};
  }
}
function lpeData(type) {
  const o = (n) => Array.from({ length: n }, (_, i) => ({ id: 'abcd'[i], text: '' }));
  return {
    mcq: { options: o(4), correct: 'a' }, multi: { options: o(4), correct: ['a'] }, fill: { text: '', blanks: [] },
    match: { pairs: [{ left: '', right: '' }, { left: '', right: '' }, { left: '', right: '' }] }, order: { steps: [{ text: '' }, { text: '' }, { text: '' }] },
    numeric: { answer: '', unit: '', unitAliases: '', tolerance: 0, tolerancePct: 0, decimals: 2, unitRequired: false, wrong: [] },
    short: { accept: '', keywords: '' }, reflection: { minWords: 20 }
  }[type] || {};
}
/** Stored item → editable shape (lists edited as "a | b" text where that is simpler). */
function lpeDataToEditor(type, d) {
  d = JSON.parse(JSON.stringify(d || {}));
  if (type === 'fill') d.blanks = (d.blanks || []).map((b) => ({ accept: (b.accept || []).join(' | ') }));
  if (type === 'short') { d.accept = (d.accept || []).join(' | '); d.keywords = (d.keywords || []).join(' | '); }
  if (type === 'numeric') d.unitAliases = (d.units || []).slice(1).join(' | ');
  return d;
}
function lpeDataFromEditor(type, d) {
  d = JSON.parse(JSON.stringify(d || {}));
  const split = (s) => String(s || '').split('|').map((x) => x.trim()).filter(Boolean);
  if (type === 'fill') d.blanks = (d.blanks || []).map((b) => ({ accept: split(b.accept) }));
  if (type === 'short') { d.accept = split(d.accept); d.keywords = split(d.keywords); }
  if (type === 'numeric') { d.unitAliases = split(d.unitAliases).join('|'); d.wrong = (d.wrong || []).filter((w) => w.value !== '' && w.text); }
  return d;
}

/* =====================================================================
   QUESTION EDITOR
   ===================================================================== */
async function viewLpItemEdit(cid, id) {
  const a = await call('lpAuthor', { courseId: cid });
  LPE.author = a; LPE.courseId = cid; LPE.kind = 'item'; LPE.dirty = false;
  const it = id !== 'new' ? a.items.find((x) => x.id === id) : null;
  if (id !== 'new' && !it) throw new Error('Question not found.');
  LPE.id = it ? it.id : '';
  LPE.obj = it ? {
    type: it.type, title: it.title, skillIds: it.skillIds.slice(), difficulty: it.difficulty, level: it.level, context: it.context, purpose: it.purpose, hints: it.hints.slice(), explanation: it.explanation, misconceptions: it.misconceptions.map((m) => Object.assign({}, m)), ai: it.ai, aiReviewed: it.aiReviewed, reviewed: false,
    variants: it.variants.map((v) => (it.type === 'case' ? { scenario: v.scenario, prompt: v.prompt, parts: v.parts.map((p) => ({ type: p.type, prompt: p.prompt, data: lpeDataToEditor(p.type, p.data) })) } : { prompt: v.prompt, data: lpeDataToEditor(it.type, v.data) }))
  } : { type: 'mcq', title: '', skillIds: [], difficulty: 2, level: 'recall', context: 'academic', purpose: 'practice', hints: [], explanation: '', misconceptions: [], variants: [{ prompt: '', data: lpeData('mcq') }] };
  LPE.tab = 0;
  return {
    title: it ? 'Edit question' : 'New question',
    html: pageHead(it ? 'Edit question' : 'New question', { crumbs: [['Learning paths', '/learn/teach'], [a.course.short, '/learn/teach/' + cid], [it ? 'Edit question' : 'New question']], sub: it ? lpState(it.status) + ' · version ' + it.v : 'Questions start as drafts.' }) +
      '<div id="lpe-body"></div>',
    after: lpeRender
  };
}
function lpePartEditor(type, base, d) {
  const p = base + '.data';
  switch (type) {
    case 'mcq': case 'multi':
      return '<fieldset class="fieldset"><legend>Options — mark the correct ' + (type === 'mcq' ? 'one' : 'ones') + '</legend>' + d.options.map((o, i) => '<div class="lp-erow">' +
        (type === 'mcq' ? '<input type="radio" name="' + esc(p) + '" aria-label="Option ' + (i + 1) + ' is correct" data-change="lpeMcq" data-path="' + esc(p) + '" data-id="' + esc(o.id) + '"' + (d.correct === o.id ? ' checked' : '') + '>' : '<input type="checkbox" aria-label="Option ' + (i + 1) + ' is correct" data-change="lpeMulti" data-path="' + esc(p) + '" data-id="' + esc(o.id) + '"' + (d.correct.indexOf(o.id) >= 0 ? ' checked' : '') + '>') +
        lpeIn(p + '.options.' + i + '.text', o.text, ' aria-label="Option ' + (i + 1) + '" placeholder="Option ' + (i + 1) + '"') + lpeRowBtns(p + '.options', i, d.options.length) + '</div>').join('') +
        (d.options.length < 10 ? '<button type="button" class="btn btn-sm" data-act="lpeAdd" data-path="' + esc(p + '.options') + '" data-tpl="option">' + icon('plus') + 'Option</button>' : '') + '<p class="small muted">Options are shuffled for each student.</p></fieldset>';
    case 'fill': {
      const n = (String(d.text).match(/\{\{\d+\}\}/g) || []).length;
      while (d.blanks.length < n) d.blanks.push({ accept: '' });
      d.blanks.length = n;
      return field('Text with blanks', '<textarea class="input" rows="3" data-input="lpe" data-delay="0" data-change="lpeChange" data-rerender="1" data-path="' + esc(p + '.text') + '">' + esc(d.text) + '</textarea>', 'Write {{1}}, {{2}} … where the blanks go.') +
        (n ? d.blanks.map((b, i) => field('Accepted answers for blank ' + (i + 1), lpeIn(p + '.blanks.' + i + '.accept', b.accept), 'Separate alternatives with |  (not case-sensitive)')).join('') : '<p class="small muted">No blanks yet.</p>');
    }
    case 'match':
      return '<fieldset class="fieldset"><legend>Pairs (the right-hand side is shuffled)</legend>' + d.pairs.map((x, i) => '<div class="lp-erow">' + lpeIn(p + '.pairs.' + i + '.left', x.left, ' aria-label="Left ' + (i + 1) + '" placeholder="Term"') + icon('right') + lpeIn(p + '.pairs.' + i + '.right', x.right, ' aria-label="Right ' + (i + 1) + '" placeholder="Matches"') + lpeRowBtns(p + '.pairs', i, d.pairs.length) + '</div>').join('') +
        '<button type="button" class="btn btn-sm" data-act="lpeAdd" data-path="' + esc(p + '.pairs') + '" data-tpl="pair">' + icon('plus') + 'Pair</button></fieldset>';
    case 'order':
      return '<fieldset class="fieldset"><legend>Steps in the correct order (students see them shuffled)</legend>' + d.steps.map((x, i) => '<div class="lp-erow"><span class="lp-n">' + (i + 1) + '</span>' + lpeIn(p + '.steps.' + i + '.text', x.text, ' aria-label="Step ' + (i + 1) + '"') + lpeRowBtns(p + '.steps', i, d.steps.length) + '</div>').join('') +
        '<button type="button" class="btn btn-sm" data-act="lpeAdd" data-path="' + esc(p + '.steps') + '" data-tpl="step">' + icon('plus') + 'Step</button></fieldset>';
    case 'numeric':
      return '<div class="form-grid-3">' + field('Correct answer', lpeNum(p + '.answer', d.answer, ' step="any"')) + field('Unit', lpeIn(p + '.unit', d.unit, ' placeholder="₹, %, years, days…"')) + field('Also accept units', lpeIn(p + '.unitAliases', d.unitAliases, ' placeholder="rs | inr"')) +
        field('Tolerance (±)', lpeNum(p + '.tolerance', d.tolerance, ' step="any" min="0"')) + field('Tolerance (%)', lpeNum(p + '.tolerancePct', d.tolerancePct, ' step="any" min="0" max="50"')) + field('Decimals shown', lpeNum(p + '.decimals', d.decimals, ' min="0" max="6"')) + '</div>' +
        lpeChk(p + '.unitRequired', d.unitRequired, 'Students must type the unit') +
        '<fieldset class="fieldset"><legend>Common wrong answers (optional)</legend><p class="small muted">When a student gives one of these, they see your explanation of the mistake.</p>' + d.wrong.map((w, i) => '<div class="lp-erow">' + lpeNum(p + '.wrong.' + i + '.value', w.value, ' step="any" aria-label="Wrong value" style="max-width:9rem"') + lpeIn(p + '.wrong.' + i + '.text', w.text, ' aria-label="Why it is wrong" placeholder="What went wrong"') + lpeRowBtns(p + '.wrong', i, d.wrong.length) + '</div>').join('') +
        '<button type="button" class="btn btn-sm" data-act="lpeAdd" data-path="' + esc(p + '.wrong') + '" data-tpl="wrong">' + icon('plus') + 'Common mistake</button></fieldset>';
    case 'short':
      return field('Accepted answers', lpeIn(p + '.accept', d.accept), 'Separate with |. Matching ignores case and punctuation.') + field('Or: required keywords', lpeIn(p + '.keywords', d.keywords), 'Separate with |. The answer is accepted when it contains all of them.');
    case 'reflection':
      return field('Minimum words', lpeNum(p + '.minWords', d.minWords, ' min="5" max="400"'), 'Reflections are not marked right or wrong.');
    default: return '';
  }
}
ACT.lpeMcq = (d) => { lpePath(LPE.obj, d.path).correct = d.id; };
ACT.lpeMulti = (d, el) => { const o = lpePath(LPE.obj, d.path); o.correct = o.correct.filter((x) => x !== d.id); if (el.checked) o.correct.push(d.id); };
ACT.lpeType = (d, el) => { const o = LPE.obj; o.type = el.value; o.variants = [o.type === 'case' ? { scenario: '', prompt: '', parts: [lpeTpl('part')] } : { prompt: (o.variants[0] || {}).prompt || '', data: lpeData(o.type) }]; LPE.tab = 0; lpeRender(); };
ACT.lpePartType = (d, el) => { const part = lpePath(LPE.obj, d.path); part.type = el.value; part.data = lpeData(el.value); lpeRender(); };
ACT.lpeVariant = (d) => { LPE.tab = Number(d.i); lpeRender(); };
ACT.lpeAddVariant = () => { const o = LPE.obj; if (o.variants.length >= 8) return; o.variants.push(JSON.parse(JSON.stringify(o.variants[LPE.tab]))); LPE.tab = o.variants.length - 1; lpeRender(); };
ACT.lpeDelVariant = () => { const o = LPE.obj; if (o.variants.length < 2) return; o.variants.splice(LPE.tab, 1); LPE.tab = 0; lpeRender(); };
function lpeItemHtml() {
  const o = LPE.obj, a = LPE.author;
  const vi = Math.min(LPE.tab, o.variants.length - 1);
  const v = o.variants[vi];
  const base = 'variants.' + vi;
  const variantEditor = o.type === 'case'
    ? field('Case scenario', lpeArea(base + '.scenario', v.scenario, 6), 'Markdown: **bold**, lists with -') + field('Introduction (optional)', lpeArea(base + '.prompt', v.prompt, 2)) +
      v.parts.map((pt, k) => '<fieldset class="fieldset lp-part-ed"><legend>Question ' + (k + 1) + '</legend><div class="row-wrap">' + '<select class="input" style="max-width:14rem" aria-label="Question type" data-change="lpePartType" data-path="' + esc(base + '.parts.' + k) + '">' + ['mcq', 'multi', 'fill', 'match', 'order', 'numeric', 'short'].map((t) => '<option value="' + t + '"' + (t === pt.type ? ' selected' : '') + '>' + LP_TYPES[t] + '</option>').join('') + '</select>' + lpeRowBtns(base + '.parts', k, v.parts.length) + '</div>' +
        field('Question', lpeArea(base + '.parts.' + k + '.prompt', pt.prompt, 2)) + lpePartEditor(pt.type, base + '.parts.' + k, pt.data) + '</fieldset>').join('') +
      (v.parts.length < 6 ? '<button type="button" class="btn btn-sm" data-act="lpeAdd" data-path="' + esc(base + '.parts') + '" data-tpl="part">' + icon('plus') + 'Question in this case</button>' : '')
    : field('Question', lpeArea(base + '.prompt', v.prompt, 3), 'Markdown supported.') + lpePartEditor(o.type, base, v.data);
  return '<div class="lp-editor"><div class="card card-pad"><div class="form-grid">' +
      field('Type', '<select class="input" data-change="lpeType">' + Object.keys(LP_TYPES).map((t) => '<option value="' + t + '"' + (t === o.type ? ' selected' : '') + '>' + LP_TYPES[t] + '</option>').join('') + '</select>', LPE.id ? 'Changing the type clears the answer details.' : '') +
      field('Short title', lpeIn('title', o.title, ' maxlength="160" placeholder="Shown to you in lists and analytics"')) +
      field('Difficulty', lpeSel('difficulty', o.difficulty, [[1, 'Introductory'], [2, 'Core'], [3, 'Stretch']])) +
      field('Thinking', lpeSel('level', o.level, [['recognition', 'Recognise'], ['recall', 'Recall'], ['application', 'Apply']])) +
      field('Context', lpeSel('context', o.context, [['academic', 'Academic'], ['real-world', 'Real-world scenario']])) +
      field('Use', lpeSel('purpose', o.purpose, [['practice', 'Practice (formative)'], ['assessment', 'Assessment only — never shown in practice']])) + '</div>' +
      '<fieldset class="fieldset"><legend>Skills</legend><div class="lp-checks">' + (a.skills.length ? a.skills.map((k) => '<label class="check"><input type="checkbox" data-change="lpeSkillTag" data-id="' + esc(k.id) + '"' + (o.skillIds.indexOf(k.id) >= 0 ? ' checked' : '') + '><span>' + esc(k.name) + '</span></label>').join('') : '<p class="muted">Add skills on the Content tab first.</p>') + '</div></fieldset></div>' +
    '<div class="card"><div class="card-head"><h2>Question and answer</h2><div class="row-wrap">' + o.variants.map((x, i) => '<button type="button" class="btn btn-sm' + (i === vi ? ' btn-primary' : '') + '" data-act="lpeVariant" data-i="' + i + '" aria-pressed="' + (i === vi) + '">Variant ' + (i + 1) + '</button>').join('') +
      (o.variants.length < 8 && o.type !== 'reflection' ? '<button type="button" class="btn btn-sm" data-act="lpeAddVariant">' + icon('copy') + 'Add variant</button>' : '') + (o.variants.length > 1 ? '<button type="button" class="btn btn-sm btn-ghost" data-act="lpeDelVariant">Remove this variant</button>' : '') + '</div></div>' +
      '<div class="card-pad">' + (o.variants.length > 1 ? '<p class="small muted">Variants test the same idea with different numbers or examples. Students get a different variant when they meet the question again, so they cannot pass by remembering answers.</p>' : '') + variantEditor + '</div></div>' +
    '<div class="card card-pad"><h2>Feedback</h2>' + field('Hints, in order', lpeLines('hints', o.hints, 3, 'One hint per line — from a gentle nudge to a bigger one'), 'Using a hint is recorded: the answer then counts as “with help”.') +
      field('Explanation', lpeArea('explanation', o.explanation, 3), 'Shown after a correct answer, after two tries, or when the student asks to see the answer.') +
      (o.type !== 'reflection' ? '<fieldset class="fieldset"><legend>Misconceptions (optional)</legend><p class="small muted">When a student’s answer matches (an option letter, an exact wrong answer, or “any”), they see your explanation.</p>' + o.misconceptions.map((m, i) => '<div class="lp-erow">' + lpeIn('misconceptions.' + i + '.when', m.when, ' aria-label="When the answer is" placeholder="Answer (or option id, or any)" style="max-width:14rem"') + lpeIn('misconceptions.' + i + '.text', m.text, ' aria-label="Explanation" placeholder="Why that answer is tempting, and what to think instead"') + lpeRowBtns('misconceptions', i, o.misconceptions.length) + '</div>').join('') +
        '<button type="button" class="btn btn-sm" data-act="lpeAdd" data-path="misconceptions" data-tpl="misc">' + icon('plus') + 'Misconception</button></fieldset>' : '') + '</div>' +
    (o.ai ? '<div class="card card-pad">' + notice('This question was drafted by AI. Check the facts, numbers and wording; it cannot be published until you confirm.', o.aiReviewed ? '' : 'warn', 'sparkles') + (o.aiReviewed ? '<p>' + icon('check') + ' Reviewed.</p>' : lpeChk('reviewed', o.reviewed, 'I have reviewed this question and it is correct')) + '</div>' : '') +
    '<div class="form-actions lp-save-bar"><a class="btn" href="#/learn/teach/' + esc(LPE.courseId) + '">Back</a>' + (LPE.id ? '<button class="btn" type="button" data-act="lpePreview" data-id="' + esc(LPE.id) + '">' + icon('eye') + 'Try saved version</button>' : '') + '<button class="btn btn-primary" type="button" data-act="lpeSaveItem">' + icon('check') + 'Save</button></div></div>';
}
ACT.lpeSkillTag = (d, el) => { const o = LPE.obj; o.skillIds = o.skillIds.filter((x) => x !== d.id); if (el.checked) o.skillIds.push(d.id); };
function lpeRender() {
  const box = $('#lpe-body');
  if (!box || !LPE.obj) return;
  const f = document.activeElement && document.activeElement.dataset ? document.activeElement.dataset.path : null;
  box.innerHTML = LPE.kind === 'item' ? lpeItemHtml() : lpeLessonHtml();
  if (f) { const el = box.querySelector('[data-path="' + CSS.escape(f) + '"]'); if (el) el.focus(); }
}
ACT.lpeSaveItem = (d, btn) => busy(btn, async () => {
  const o = LPE.obj;
  const item = Object.assign({}, o, { variants: o.variants.map((v) => (o.type === 'case' ? { scenario: v.scenario, prompt: v.prompt, parts: v.parts.map((p) => ({ type: p.type, prompt: p.prompt, data: lpeDataFromEditor(p.type, p.data) })) } : { prompt: v.prompt, data: lpeDataFromEditor(o.type, v.data) })) });
  const r = await call('lpSaveItem', { courseId: LPE.courseId, id: LPE.id, item, reviewed: !!o.reviewed });
  LPE.dirty = false;
  toast('Saved.' + (r.warnings.length ? ' ' + r.warnings.length + ' accessibility check' + (r.warnings.length === 1 ? '' : 's') + ' to review.' : ''));
  if (!LPE.id) { go('/learn/teach/' + LPE.courseId + '/item/' + r.id); return; }
  LPE.id = r.id;
});

/* =====================================================================
   LESSON EDITOR
   ===================================================================== */
async function viewLpLessonEdit(cid, id, params) {
  const a = await call('lpAuthor', { courseId: cid });
  LPE.author = a; LPE.courseId = cid; LPE.kind = 'lesson'; LPE.dirty = false;
  const l = id !== 'new' ? a.lessons.find((x) => x.id === id) : null;
  if (id !== 'new' && !l) throw new Error('Lesson not found.');
  LPE.id = l ? l.id : '';
  LPE.status = l ? l.status : 'draft';
  LPE.obj = l ? { title: l.title, topicId: l.topicId, minutes: l.minutes, required: l.required, dueAt: l.dueAt ? toDateInput(l.dueAt) : '', objectives: l.objectives.slice(), skillIds: l.skillIds.slice(), prereqIds: l.prereqIds.slice(), itemIds: l.itemIds.slice(), blocks: JSON.parse(JSON.stringify(l.blocks)).map((b) => (b.kind === 'video' ? Object.assign(b, { url: b.provider === 'youtube' ? 'https://youtu.be/' + b.vid : 'https://vimeo.com/' + b.vid }) : b)), significant: false }
    : { title: '', topicId: (params && params.get('topic')) || (a.topics[0] && a.topics[0].id) || '', minutes: 5, required: true, dueAt: '', objectives: [], skillIds: [], prereqIds: [], itemIds: [], blocks: [{ kind: 'text', text: '' }], significant: false };
  if (!a.topics.length) return { title: 'New lesson', html: pageHead('New lesson', { crumbs: [['Learning paths', '/learn/teach'], [a.course.short, '/learn/teach/' + cid]] }) + emptyState('layers', 'Add a topic first', 'Lessons belong to a topic. Add one on the Content tab.', '<a class="btn btn-primary" href="#/learn/teach/' + esc(cid) + '">Back to content</a>') };
  return {
    title: l ? 'Edit lesson' : 'New lesson',
    html: pageHead(l ? 'Edit lesson' : 'New lesson', { crumbs: [['Learning paths', '/learn/teach'], [a.course.short, '/learn/teach/' + cid], [l ? l.title : 'New lesson']], sub: l ? lpState(l.status) + ' · version ' + (l.major || 1) + '.' + l.v : 'Lessons start as drafts.' }) + '<div id="lpe-body"></div>',
    after: lpeRender
  };
}
function lpeBlockHtml(b, i, n) {
  const p = 'blocks.' + i;
  const head = '<div class="row-wrap lp-block-h"><b>' + { text: 'Text', image: 'Image', video: 'Video', example: 'Worked example' }[b.kind] + '</b><span class="spacer"></span>' + lpeRowBtns('blocks', i, n) + '</div>';
  if (b.kind === 'text') return head + lpeArea(p + '.text', b.text, 5, ' aria-label="Text"') + '<p class="small muted">Markdown: **bold**, *italic*, lists with -, headings with ##.</p>';
  if (b.kind === 'image') return head + (b.src ? '<img class="lp-thumb" src="' + esc(b.src) + '" alt="">' : '') + field('Description for screen readers', lpeIn(p + '.alt', b.alt), 'Describe what the image shows and why it matters.') + field('Caption', lpeIn(p + '.caption', b.caption));
  if (b.kind === 'video') return head + field('YouTube or Vimeo link', lpeIn(p + '.url', b.url, ' placeholder="https://youtu.be/…"')) + field('Title', lpeIn(p + '.title', b.title)) + field('Captions or transcript', lpeArea(p + '.transcript', b.transcript, 4), 'Needed for students who cannot hear or play the video.');
  return head + field('Title', lpeIn(p + '.title', b.title)) + field('Problem', lpeArea(p + '.problem', b.problem, 3)) + field('Solution steps', lpeLines(p + '.steps', b.steps, 4, 'One step per line')) + field('Answer', lpeIn(p + '.answer', b.answer));
}
function lpeLessonHtml() {
  const o = LPE.obj, a = LPE.author;
  const items = a.items.filter((i) => i.status !== 'archived' && i.status !== 'deleted');
  const byId = {};
  items.forEach((i) => { byId[i.id] = i; });
  const others = a.lessons.filter((l) => l.id !== LPE.id);
  return '<div class="lp-editor"><div class="card card-pad"><div class="form-grid">' + field('Title', lpeIn('title', o.title, ' maxlength="160"')) +
      field('Topic', lpeSel('topicId', o.topicId, a.topics.map((t) => [t.id, (a.sections.find((s) => s.id === t.sectionId) || {}).name + ' › ' + t.name]))) +
      field('Estimated minutes', lpeNum('minutes', o.minutes, ' min="1" max="30"')) + field('Suggested completion date', '<input class="input" type="date" data-input="lpe" data-delay="0" data-path="dueAt" value="' + esc(o.dueAt) + '">', 'Optional. Students with an accommodation get their extra days automatically.') + '</div>' +
      lpeChk('required', o.required, 'Required', 'Required lessons count towards completion. Optional ones do not.') +
      field('Learning objectives', lpeLines('objectives', o.objectives, 3, 'One objective per line, e.g. “Calculate the payback period”')) +
      '<fieldset class="fieldset"><legend>Skills taught</legend><div class="lp-checks">' + a.skills.map((k) => '<label class="check"><input type="checkbox" data-change="lpeLessonSkill" data-id="' + esc(k.id) + '"' + (o.skillIds.indexOf(k.id) >= 0 ? ' checked' : '') + '><span>' + esc(k.name) + '</span></label>').join('') + '</div></fieldset>' +
      (others.length ? '<fieldset class="fieldset"><legend>Open after these lessons (prerequisites)</legend><div class="lp-checks">' + others.map((l) => '<label class="check"><input type="checkbox" data-change="lpeLessonPre" data-id="' + esc(l.id) + '"' + (o.prereqIds.indexOf(l.id) >= 0 ? ' checked' : '') + '><span>' + esc(l.title) + '</span></label>').join('') + '</div></fieldset>' : '') + '</div>' +
    '<div class="card"><div class="card-head"><h2>Content</h2><div class="row-wrap"><button type="button" class="btn btn-sm" data-act="lpeAdd" data-path="blocks" data-tpl="text">' + icon('text') + 'Text</button><label class="btn btn-sm">' + icon('image') + 'Image<input type="file" accept="image/png,image/jpeg,image/gif,image/webp" data-change="lpeImage" hidden></label><button type="button" class="btn btn-sm" data-act="lpeAdd" data-path="blocks" data-tpl="video">' + icon('video') + 'Video</button><button type="button" class="btn btn-sm" data-act="lpeAdd" data-path="blocks" data-tpl="example">' + icon('lightbulb') + 'Worked example</button></div></div>' +
      '<div class="card-pad">' + (o.blocks.length ? o.blocks.map((b, i) => '<div class="lp-block">' + lpeBlockHtml(b, i, o.blocks.length) + '</div>').join('') : '<p class="muted">Add text, an image, a video or a worked example.</p>') + '</div></div>' +
    '<div class="card"><div class="card-head"><h2>Activities in this lesson</h2></div><div class="card-pad">' + (o.itemIds.length ? '<ol class="lp-acts">' + o.itemIds.map((id, i) => '<li class="lp-erow"><span>' + esc(byId[id] ? (byId[id].title || byId[id].variants[0].prompt.slice(0, 60)) : id) + ' <span class="faint small">' + esc(byId[id] ? LP_TYPES[byId[id].type] : '') + '</span> ' + (byId[id] && byId[id].status !== 'published' ? lpState(byId[id].status) : '') + '</span>' + lpeRowBtns('itemIds', i, o.itemIds.length) + '</li>').join('') + '</ol>' : '<p class="muted">No activities yet.</p>') +
      '<div class="row-wrap"><select class="input" id="lpe-additem" aria-label="Add a question" style="max-width:28rem"><option value="">Add a question…</option>' + items.filter((i) => o.itemIds.indexOf(i.id) < 0).map((i) => '<option value="' + esc(i.id) + '">' + esc((i.title || i.variants[0].prompt.slice(0, 60)) + ' — ' + LP_TYPES[i.type]) + '</option>').join('') + '</select><button type="button" class="btn btn-sm" data-act="lpeAddItem">' + icon('plus') + 'Add</button><a class="btn btn-sm btn-ghost" href="#/learn/teach/' + esc(LPE.courseId) + '/item/new">New question</a></div>' +
      '<p class="small muted">Students try every activity before completing the lesson; getting them right is not required. A lesson can only be published when its activities are published.</p></div></div>' +
    (LPE.status === 'published' ? '<div class="card card-pad">' + lpeChk('significant', o.significant, 'This is a significant change', 'Starts a new version. Students who completed the earlier version keep their completion and are told the content was updated.') + '</div>' : '') +
    '<div class="form-actions lp-save-bar"><a class="btn" href="#/learn/teach/' + esc(LPE.courseId) + '">Back</a>' + (LPE.id ? '<a class="btn" href="#/learn/lesson/' + esc(LPE.id) + '">' + icon('eye') + 'Preview saved version</a>' : '') + '<button class="btn btn-primary" type="button" data-act="lpeSaveLesson">' + icon('check') + 'Save</button></div></div>';
}
ACT.lpeLessonSkill = (d, el) => { const o = LPE.obj; o.skillIds = o.skillIds.filter((x) => x !== d.id); if (el.checked) o.skillIds.push(d.id); };
ACT.lpeLessonPre = (d, el) => { const o = LPE.obj; o.prereqIds = o.prereqIds.filter((x) => x !== d.id); if (el.checked) o.prereqIds.push(d.id); };
ACT.lpeAddItem = () => { const v = $('#lpe-additem').value; if (!v) return; LPE.obj.itemIds.push(v); lpeRender(); };
ACT.lpeImage = async (d, el) => {
  const f = el.files && el.files[0];
  if (!f) return;
  if (f.size > 400 * 1024) { toast('Images must be 400 KB or smaller. Try a smaller or compressed image.', 'err'); return; }
  const b64 = await readFileB64(f);
  LPE.obj.blocks.push({ kind: 'image', src: 'data:' + f.type + ';base64,' + b64, alt: '', caption: '' });
  lpeRender();
};
ACT.lpeSaveLesson = (d, btn) => busy(btn, async () => {
  const o = LPE.obj;
  const payload = Object.assign({}, o, { courseId: LPE.courseId, id: LPE.id, dueAt: o.dueAt ? fromDateInput(o.dueAt) + 86399000 : 0 });
  await call('lpSaveLesson', payload);
  LPE.dirty = false;
  toast('Saved.');
  if (!LPE.id) { const a = await call('lpAuthor', { courseId: LPE.courseId }); const l = a.lessons.filter((x) => x.title === o.title).pop(); if (l) go('/learn/teach/' + LPE.courseId + '/lesson/' + l.id); }
});

/* =====================================================================
   ANALYTICS
   ===================================================================== */
async function lpAnalyticsHtml(cid) {
  const d = await call('lpAnalytics', { courseId: cid });
  const S0 = d.summary, D = d.definitions;
  const pctCell = (v) => (v == null ? '<span class="muted">—</span>' : v + '%');
  const dist = (x) => { const tot = Object.values(x).reduce((a, b) => a + b, 0); return tot ? lpDistBar(x, tot) : ''; };
  return '<div class="row-wrap lp-an-head"><span class="small muted">' + esc(d.freshness) + ' ' + lpUpdated(d.updatedAt) + '</span><span class="spacer"></span><button class="btn btn-sm" data-act="lpExport" data-id="' + esc(cid) + '">' + icon('download') + 'CSV</button></div>' +
    '<div class="stats">' + statCard('users', 'indigo', S0.students, 'Students') + statCard('book', 'blue', S0.medianCompletion == null ? '—' : S0.medianCompletion + '%', 'Median required completion') + statCard('activity', 'green', S0.activeThisWeek, 'Active in the last 7 days') + statCard('refresh', 'amber', S0.reviewBacklog, 'Reviews waiting (all students)') + statCard('target', 'violet', S0.answers7, 'Answers in the last 7 days') + '</div>' +
    '<div class="grid-2"><section class="card card-pad"><h2>Participation — last 28 days</h2>' + chartSlot('columns', { labels: d.participation.map((x) => x.day), xFmt: (x) => x.slice(5), label: 'Answers per day', series: [{ name: 'Answers', token: '1', values: d.participation.map((x) => x.answers) }], tipTitle: (i) => d.participation[i].day + ' · ' + d.participation[i].students + ' students' }) + '</section>' +
    '<section class="card card-pad"><h2>Lessons completed per week</h2>' + chartSlot('columns', { labels: d.completions.map((x) => x.week), xFmt: (x) => x.slice(5), label: 'Lessons completed per week', series: [{ name: 'Lessons completed', token: '2', values: d.completions.map((x) => x.lessons) }] }) + '</section></div>' +
    (d.units.length ? '<section class="card"><div class="card-head"><h2>Units</h2>' + lpDef(D.completion) + '</div><ul class="lp-list">' + d.units.map((u) => '<li><span style="flex:1"><b>' + esc(u.name) + '</b> <span class="small muted">' + plural(u.lessons, 'required lesson') + '</span>' + progressBar(u.avgCompletion || 0) + '</span><b>' + pctCell(u.avgCompletion) + '</b></li>').join('') + '</ul></section>' : '') +
    '<section class="card"><div class="card-head"><h2>Students who may benefit from support</h2></div>' + (d.support.length ? '<ul class="lp-list">' + d.support.map((x) => '<li><span style="flex:1"><a href="#/learn/teach/' + esc(cid) + '/student/' + esc(x.uid) + '"><b>' + esc(x.name) + '</b></a><span class="small muted">' + esc(x.notes.join(' · ')) + '</span></span><a class="btn btn-sm" href="#/learn/teach/' + esc(cid) + '/student/' + esc(x.uid) + '">Open</a></li>').join('') + '</ul>' : '<p class="card-pad muted">Nobody stands out right now.</p>') + '<p class="card-pad small muted">These notes describe recent activity only; they are not predictions or labels.</p></section>' +
    '<section class="card"><div class="card-head"><h2>Skills — hardest first</h2>' + lpDef(D.proficiency) + '</div><div class="table-wrap"><table class="table"><thead><tr><th scope="col">Skill</th><th scope="col">Questions</th><th scope="col">Answers</th><th scope="col">Right on their own</th><th scope="col">Used a hint</th><th scope="col">Students by status</th></tr></thead><tbody>' +
      d.skills.map((k) => '<tr><td><b>' + esc(k.name) + '</b></td><td>' + k.items + '</td><td>' + k.attempts + '</td><td>' + pctCell(k.independentRate) + '</td><td>' + pctCell(k.hintRate) + '</td><td style="min-width:14rem">' + dist(k.distribution) + '</td></tr>').join('') + '</tbody></table></div></section>' +
    '<section class="card"><div class="card-head"><h2>Common wrong answers</h2></div>' + (d.items.some((i) => i.common.length) ? '<ul class="lp-list">' + d.items.filter((i) => i.common.length).slice(0, 10).map((i) => '<li><span style="flex:1"><b>' + esc(i.title) + '</b>' + i.common.map((c) => '<span class="small">“' + esc(c.given) + '” × ' + c.n + (c.note ? ' — <span class="muted">' + esc(c.note) + '</span>' : ' — <span class="muted">no explanation set up yet</span>') + '</span>').join('') + '</span></li>').join('') + '</ul>' : '<p class="card-pad muted">Not enough answers yet.</p>') + '</section>' +
    '<section class="card"><div class="card-head"><h2>Question performance</h2></div><div class="table-wrap"><table class="table"><thead><tr><th scope="col">Question</th><th scope="col">Difficulty</th><th scope="col">Students</th><th scope="col">Answers</th><th scope="col">Right first time</th><th scope="col">Hints</th><th scope="col">Asked for answer</th><th scope="col">Note</th></tr></thead><tbody>' +
      d.items.map((i) => '<tr><td>' + esc(i.title) + '<div class="faint small">' + esc(LP_TYPES[i.type]) + '</div></td><td>' + LP_DIFF[i.difficulty] + '</td><td>' + i.students + '</td><td>' + i.attempts + '</td><td>' + pctCell(i.firstTry) + '</td><td>' + pctCell(i.hintRate) + '</td><td>' + pctCell(i.revealRate) + '</td><td class="small">' + esc(i.flag) + '</td></tr>').join('') + '</tbody></table></div></section>' +
    '<section class="card card-pad"><h2>Curriculum coverage</h2><ul class="lp-cover">' +
      [['Skills without published questions', d.coverage.skillsWithoutQuestions], ['Skills not taught in any published lesson', d.coverage.skillsWithoutLessons], ['Lessons without objectives', d.coverage.lessonsWithoutObjectives]].map((x) => '<li><b>' + esc(x[0]) + ':</b> ' + (x[1].length ? esc(x[1].join(', ')) : '<span class="muted">none</span>') + '</li>').join('') +
      '<li><b>Questions without an explanation:</b> ' + d.coverage.questionsWithoutExplanation + '</li><li><b>Questions without hints:</b> ' + d.coverage.questionsWithoutHints + '</li><li><b>Awaiting review:</b> ' + d.coverage.awaitingReview + '</li></ul></section>' +
    '<details class="card card-pad"><summary><b>How each number is defined</b></summary><dl class="lp-dl">' + Object.keys(D).map((k) => '<dt>' + esc(k) + '</dt><dd>' + esc(D[k]) + '</dd>').join('') + '</dl></details>';
}
ACT.lpExport = (d, btn) => busy(btn, async () => { const r = await call('lpExport', { courseId: d.id }); downloadBase64(r.name, r.data, 'text/csv'); });

/* =====================================================================
   STUDENTS
   ===================================================================== */
async function lpStudentsHtml(cid) {
  const d = await call('lpAnalytics', { courseId: cid });
  if (!d.students.length) return emptyState('users', 'No students yet', 'Students enrolled in the course appear here.');
  return '<div class="table-wrap card"><table class="table"><caption class="sr">Students</caption><thead><tr><th scope="col">Student</th><th scope="col">Required lessons</th><th scope="col">Skills</th><th scope="col">Reviews due</th><th scope="col">Active days (7)</th><th scope="col">Last active</th><th scope="col">Notes</th></tr></thead><tbody>' +
    d.students.map((r) => '<tr><td><a href="#/learn/teach/' + esc(cid) + '/student/' + esc(r.uid) + '"><b>' + esc(r.name) + '</b></a><div class="faint small">' + esc(r.username) + (r.batch ? ' · ' + esc(r.batch) : '') + '</div>' + (r.accommodated ? badge('Accommodation', '', 'shield') : '') + '</td><td>' + (r.completion.total ? r.completion.done + ' / ' + r.completion.total + ' (' + r.completion.percent + '%)' : '—') + '</td>' +
      '<td class="small">' + (r.distribution.proficient + r.distribution.review) + ' proficient · ' + r.distribution.practising + ' practising · ' + r.distribution.developing + ' developing</td><td>' + r.reviewsDue + '</td><td>' + r.activeDays7 + '</td><td class="small">' + esc(r.lastActive || '—') + '</td><td class="small">' + esc(r.support.join(' · ')) + '</td></tr>').join('') + '</tbody></table></div>';
}
async function viewLpTeachStudent(cid, uid) {
  const d = await call('lpStudent', { courseId: cid, uid });
  const a = await call('lpAuthor', { courseId: cid });
  LPE.author = a;
  const st = d.student;
  const acc = d.accommodation;
  return {
    title: st.name + ' · Learning',
    html: pageHead(st.name, { crumbs: [['Learning paths', '/learn/teach'], [a.course.short, '/learn/teach/' + cid + '?tab=students'], [st.name]], sub: esc(st.username) + (st.batch ? ' · ' + esc(st.batch) : '') + ' · time zone ' + esc(st.tz) + ' · ' + (d.completion.total ? d.completion.done + ' of ' + d.completion.total + ' required lessons' : 'no required lessons') }) +
      '<section class="card"><div class="card-head"><h2>Skills</h2><span class="small muted">' + esc(d.profVersion) + '</span></div><div class="table-wrap"><table class="table"><thead><tr><th scope="col">Skill</th><th scope="col">Status</th><th scope="col">Estimate</th><th scope="col">Evidence</th><th scope="col">Due</th><th scope="col">Ready?</th></tr></thead><tbody>' +
        d.skills.map((k) => '<tr><td>' + esc(k.name) + '</td><td>' + lpStatus(k.display) + '</td><td>' + (k.estimate == null ? '—' : Math.round(k.estimate * 100) + '%') + '</td><td class="small">' + k.evidence + ' questions · ' + k.independentItems + ' on their own · ' + k.days + ' days' + (k.sufficient ? '' : ' · <span class="muted">not enough yet</span>') + '</td><td>' + (k.due || '—') + '</td><td class="small">' + (k.ready ? 'Yes' : esc(k.waiting)) + '</td></tr>').join('') + '</tbody></table></div></section>' +
      '<div class="grid-2"><section class="card"><div class="card-head"><h2>What practice would pick next</h2><span class="small muted">' + esc(d.adaptVersion) + '</span></div>' + (d.recommendations.length ? '<ol class="lp-list">' + d.recommendations.map((r) => '<li><span style="flex:1"><b>' + esc(r.title) + '</b> <span class="faint small">variant ' + r.variant + '</span><span class="small muted">' + esc(r.reason) + ' · score ' + r.score + '</span></span></li>').join('') + '</ol>' : '<p class="card-pad muted">Nothing available yet.</p>') +
        (d.excluded.length ? '<details class="card-pad"><summary>Held back (' + d.excluded.length + ')</summary><ul class="small">' + d.excluded.map((x) => '<li>' + esc(x.title) + ' — ' + esc(x.why) + '</li>').join('') + '</ul></details>' : '') + '</section>' +
      '<section class="card"><div class="card-head"><h2>Override</h2></div><div class="card-pad"><form data-form="lpAssign" novalidate><input type="hidden" name="uid" value="' + esc(st.id) + '">' +
        '<fieldset class="fieldset"><legend>Assign practice</legend><div class="lp-checks">' + a.skills.map((k) => check('sk_' + k.id, esc(k.name), false)).join('') + '</div>' + field('Note to the student', '<input class="input" name="note" maxlength="300">', 'Optional') + field('For how many days', '<input class="input" type="number" name="days" min="1" max="60" value="7">') + '<button class="btn btn-primary btn-sm" type="submit">Assign</button></fieldset></form>' +
        (d.assignments.length ? '<p class="small"><b>Active:</b> ' + d.assignments.map((g) => esc((g.note || 'Practice') + ' until ' + fmtDate(g.until)) + ' <button class="btn btn-sm btn-ghost" data-act="lpUnassign" data-id="' + esc(g.id) + '">End</button>').join(' · ') + '</p>' : '') +
        '<form data-form="lpAccommodation" novalidate><input type="hidden" name="uid" value="' + esc(st.id) + '"><fieldset class="fieldset"><legend>Accommodation (private to staff and the student)</legend><div class="form-grid">' + field('Extra days on suggested dates', '<input class="input" type="number" name="extraDays" min="0" max="60" value="' + acc.extraDays + '">') + field('Weekly active-day goal (0 = student’s own)', '<input class="input" type="number" name="weeklyDays" min="0" max="7" value="' + acc.weeklyDays + '">') + '</div>' +
        check('noRank', 'Leave out of any ranking', acc.noRank) + field('Note', '<input class="input" name="note" maxlength="500" value="' + esc(acc.note || '') + '">', 'Never shown to classmates.') + '<button class="btn btn-sm" type="submit">Save accommodation</button></fieldset></form></div></section></div>' +
      '<section class="card"><div class="card-head"><h2>Lessons</h2></div><ul class="lp-list">' + d.lessons.map((l) => '<li><span style="flex:1">' + icon(l.done ? 'checkCircle' : l.open ? 'play' : 'lock') + ' ' + esc(l.title) + (l.unlocked ? ' ' + badge('Unlocked by teacher', 'info') : '') + '</span>' + (!l.done && !l.open ? '<button class="btn btn-sm" data-act="lpUnlock" data-lesson="' + esc(l.id) + '" data-uid="' + esc(st.id) + '">Unlock</button>' : l.unlocked && !l.done ? '<button class="btn btn-sm btn-ghost" data-act="lpUnlock" data-lesson="' + esc(l.id) + '" data-uid="' + esc(st.id) + '" data-remove="1">Remove unlock</button>' : '') + '</li>').join('') + '</ul></section>' +
      '<section class="card"><div class="card-head"><h2>Review schedule</h2></div>' + (d.reviews.length ? '<div class="table-wrap"><table class="table"><thead><tr><th scope="col">Question</th><th scope="col">Next review</th><th scope="col">Interval</th><th scope="col">Recalled in a row</th><th scope="col">Lapses</th></tr></thead><tbody>' + d.reviews.map((r) => '<tr><td>' + esc(r.title) + '</td><td>' + esc(r.due) + (r.overdue ? ' <span class="muted small">(' + r.overdue + ' days ago)</span>' : '') + '</td><td>' + plural(r.interval, 'day') + '</td><td>' + r.reps + '</td><td>' + r.lapses + '</td></tr>').join('') + '</tbody></table></div>' : '<p class="card-pad muted">No reviews scheduled yet.</p>') + '</section>'
  };
}
FORMS.lpAssign = (f, btn) => busy(btn, async () => {
  const skillIds = $$('input[type=checkbox]', f).filter((x) => x.checked && x.name.indexOf('sk_') === 0).map((x) => x.name.slice(3));
  await call('lpAssign', { courseId: LPE.author.course.id, uids: [f.elements.uid.value], skillIds, note: f.elements.note.value, days: Number(f.elements.days.value) });
  toast('Practice assigned. The student has been notified.'); refresh();
});
FORMS.lpAccommodation = (f, btn) => busy(btn, async () => {
  await call('lpAccommodation', { courseId: LPE.author.course.id, uid: f.elements.uid.value, extraDays: Number(f.elements.extraDays.value), weeklyDays: Number(f.elements.weeklyDays.value), noRank: f.elements.noRank.checked, note: f.elements.note.value });
  toast('Saved.'); refresh();
});
ACT.lpUnassign = (d, btn) => busy(btn, async () => { await call('lpUnassign', { id: d.id }); refresh(); });
ACT.lpUnlock = (d, btn) => busy(btn, async () => { await call('lpUnlock', { lessonId: d.lesson, uid: d.uid, remove: !!d.remove }); refresh(); });

/* =====================================================================
   COURSE SETTINGS
   ===================================================================== */
function lpCourseSettingsHtml(a) {
  const c = a.cfg, F = a.features;
  const modes = [['aggregate', 'Class totals only', 'Students see the class median and how many were active — no list.'], ['pseudonymous', 'Pseudonymous list', 'A list with automatic aliases instead of names.'], ['named', 'Named list', F.namedPeers ? 'Names are shown (students may still choose an alias or hide, if allowed).' : 'Not allowed by your institution’s Learning settings.']];
  return '<form class="card card-pad lp-settings" data-form="lpCourseCfg" novalidate>' +
    '<fieldset class="fieldset"><legend>Availability</legend>' + check('enabled', 'On for students', c.enabled, 'Students see the learning path, practice and reviews. Drafts stay hidden either way.') +
      field('Classmates are', '<select class="input" name="cohortBy"><option value="course"' + (c.cohortBy === 'course' ? ' selected' : '') + '>Everyone in this course</option><option value="batch"' + (c.cohortBy === 'batch' ? ' selected' : '') + '>Students of the same batch in this course</option></select>') + '</fieldset>' +
    '<fieldset class="fieldset"><legend>Class progress visibility</legend>' + modes.map((m) => '<label class="check"><input type="radio" name="mode" value="' + m[0] + '"' + (c.peer.mode === m[0] ? ' checked' : '') + (m[0] === 'named' && !F.namedPeers ? ' disabled' : '') + '><span>' + m[1] + '<span class="hint">' + esc(m[2]) + '</span></span></label>').join('') +
      (F.gamification ? check('showXp', 'Show weekly XP', c.peer.showXp) + check('showBadges', 'Show badge counts', c.peer.showBadges) : '') +
      (F.ranking ? check('ranking', 'Rank by weekly XP (needs weekly XP shown)', c.peer.ranking, 'Students who switch off comparisons, or have an accommodation to be left out, are never ranked.') : '<p class="small muted">Rankings are switched off by your institution.</p>') +
      '<p class="small muted">Groups smaller than ' + F.minCohort + ' only ever see class totals. Grades, answers, mistakes, accommodations, feedback, exact times and exam or proctoring data are never shown to classmates.</p></fieldset>' +
    (F.gamification ? '<fieldset class="fieldset"><legend>Rewards (XP)</legend><p class="small muted">Leave blank to use the default shown.</p><div class="form-grid-3">' + Object.keys(a.xpDefaults).map((k) => field({ lesson: 'Lesson completed', practice: 'Correct on their own', assisted: 'Correct with a hint', fixMistake: 'Fixed a mistake', review: 'Review (recalled)', reviewMiss: 'Review (not recalled)', reflection: 'Reflection', goal: 'Daily goal', skillUp: 'Skill improved', challenge: 'Weekly challenge', perItemLifetime: 'Days a question can earn', dailyCap: 'Daily cap for practice' }[k] || k,
      '<input class="input" type="number" min="0" name="xp_' + k + '" placeholder="' + a.xpDefaults[k] + '" value="' + (c.rewards[k] != null ? c.rewards[k] : '') + '">')).join('') + '</div></fieldset>' : '') +
    '<fieldset class="fieldset"><legend>Proficiency rules</legend><div class="form-grid">' + field('Proficient at (estimate)', '<input class="input" type="number" step="0.05" min="0.6" max="0.95" name="proficientAt" value="' + (c.prof.proficientAt || a.profDefaults.proficientAt) + '">') + field('Practising at', '<input class="input" type="number" step="0.05" min="0.3" max="0.75" name="practisingAt" value="' + (c.prof.practisingAt || a.profDefaults.practisingAt) + '">') +
      field('Different questions needed', '<input class="input" type="number" min="2" max="10" name="minEvidence" value="' + (c.prof.minEvidence || a.profDefaults.minEvidence) + '">') + field('Different days needed', '<input class="input" type="number" min="1" max="7" name="minDays" value="' + (c.prof.minDays || a.profDefaults.minDays) + '">') + '</div></fieldset>' +
    '<div class="form-actions"><button class="btn btn-primary" type="submit">Save settings</button></div></form>' +
    '<details class="card card-pad"><summary><b>Curriculum versions</b> (' + c.versions.length + ')</summary><p class="small muted">A new version starts whenever the set of required published lessons changes, or a lesson gets a significant change. Completion is always measured against the current version; earlier completions are kept.</p><ul class="small">' + c.versions.slice().reverse().slice(0, 20).map((v) => '<li>v' + v.v + ' · ' + esc(fmt(v.at)) + ' · ' + plural(v.required.length, 'required lesson') + '</li>').join('') + '</ul></details>';
}
FORMS.lpCourseCfg = (f, btn) => busy(btn, async () => {
  const a = LPE.author;
  const el = f.elements;
  const mode = f.querySelector('input[name=mode]:checked');
  const rewards = {};
  Object.keys(a.xpDefaults).forEach((k) => { const x = el['xp_' + k]; if (x && x.value !== '') rewards[k] = Number(x.value); });
  await call('lpSaveCourseCfg', { courseId: a.course.id, enabled: el.enabled.checked, cohortBy: el.cohortBy.value, peer: { mode: mode ? mode.value : 'aggregate', showXp: !!(el.showXp && el.showXp.checked), showBadges: !!(el.showBadges && el.showBadges.checked), ranking: !!(el.ranking && el.ranking.checked) }, rewards, prof: { proficientAt: Number(el.proficientAt.value), practisingAt: Number(el.practisingAt.value), minEvidence: Number(el.minEvidence.value), minDays: Number(el.minDays.value) } });
  toast('Saved.'); refresh();
});

/* =====================================================================
   INSTITUTION SETTINGS (administrators)
   ===================================================================== */
async function viewLpAdmin() {
  const d = await call('lpSettings');
  const s = d.settings;
  return {
    title: 'Learning settings',
    html: pageHead('Learning settings', { crumbs: [['Learning paths', '/learn/teach'], ['Settings']], sub: 'Institution-wide switches for Learning Paths. Methods: ' + esc(Object.values(d.versions).join(', ')) }) +
      '<form class="card card-pad lp-settings" data-form="lpAdmin" novalidate>' +
      '<fieldset class="fieldset"><legend>Rollout</legend>' + check('enabled', 'Learning Paths is on', s.enabled, 'When off, nothing changes for anyone. When on, teachers can build learning paths and switch them on per course.') + '</fieldset>' +
      '<fieldset class="fieldset"><legend>Features</legend>' + check('adaptive', 'Adaptive practice', s.adaptive, 'Off: practice follows the learning path in order.') + check('reviews', 'Spaced reviews', s.reviews) + check('gamification', 'XP, goals, streaks, badges and challenges', s.gamification) + check('peers', 'Class progress for students', s.peers) + check('aiDrafts', 'AI drafts for teachers', s.aiDrafts, 'Uses the AI provider set up for the site. Drafts always need a teacher’s review before publishing.') + '</fieldset>' +
      '<fieldset class="fieldset"><legend>Privacy of class progress</legend>' + check('namedPeers', 'Allow named classmate lists', s.namedPeers, 'Only switch on if your institution’s policy permits students to see each other’s names with progress.') +
        check('ranking', 'Allow rankings', s.ranking, 'Teachers may then rank by weekly XP. Off by default.') + check('studentChoice', 'Students may show an alias or hide from lists', s.studentChoice) +
        field('Smallest group that sees individual rows', '<input class="input" type="number" name="minCohort" min="3" max="50" value="' + s.minCohort + '">', 'Smaller groups see class totals only, so nobody can be singled out.') + '</fieldset>' +
      '<fieldset class="fieldset"><legend>Time</legend>' + field('Default time zone', '<input class="input" name="defaultTz" value="' + esc(s.defaultTz) + '">', 'Used when a student has not chosen one. Days, streaks and reviews follow the student’s time zone.') + '</fieldset>' +
      '<div class="form-actions"><button class="btn btn-primary" type="submit">Save</button></div></form>'
  };
}
FORMS.lpAdmin = (f, btn) => busy(btn, async () => {
  const e = f.elements;
  const p = {};
  ['enabled', 'adaptive', 'reviews', 'gamification', 'peers', 'aiDrafts', 'namedPeers', 'ranking', 'studentChoice'].forEach((k) => { p[k] = e[k].checked; });
  p.minCohort = Number(e.minCohort.value); p.defaultTz = e.defaultTz.value;
  await call('lpSaveSettings', p);
  toast('Saved.'); S.me = await call('me'); renderLayout(); refresh();
});
