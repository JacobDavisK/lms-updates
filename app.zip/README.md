# Jacob Davis LMS — standalone JavaScript build

A Moodle-style learning management system built with **Node.js + Express** and a
dependency-free vanilla JavaScript front end. It started as a port of the Google
Apps Script quiz app (`../Code_3.gs` + `../Index.html`) and now covers the core of
Moodle: courses, activities, enrolment, grading, forums and more.

## Run it

```bash
npm install
npm start
```

Open http://localhost:3000. On first run the server prints a temporary `admin`
password to the console; you'll set a real one on first sign-in.

Want something to click around? Build a **demo installation** (sample data only; never on a real site):

```bash
npm run seed
LMS_DEMO=1 node server.js
```

(`start-demo.cmd` / `start-demo.command` do both for you.)

This adds three courses (Business Law, Financial Accounting, Digital Marketing),
a teacher (`demo.teacher` / `Teach2026demo`) and six students
(`demo.anitha`, `demo.bharath`, … / `Learn2026demo`) with submissions, quiz
attempts, grades, forum posts and announcements.

The sign-in page then shows one-click **demo accounts** for each role:

| Role    | Username       | Password         |
|---------|----------------|------------------|
| Admin   | `demo.admin`   | `Admin2026demo`  |
| Faculty | `demo.teacher` | `Teach2026demo`  |
| Student | `demo.anitha`  | `Learn2026demo`  |
| Parent  | `demo.raman`   | `Family2026demo` |

Demo sign-ins only work when the server runs with `LMS_DEMO=1`. On any other site they
can't be switched on, and the `demo.*` accounts cannot sign in at all, because their
passwords are public. Even in a demo, these accounts can explore everything but can't
change accounts, passwords or settings.

Running it for real? See **[DEPLOY.md](DEPLOY.md)** for HTTPS, environment variables and backups.

### User demo (on a real site)

To show the LMS on your real site without exposing real students, use **Site administration →
User demo**. It creates up to four working accounts, each with the full features of its role:

- **Faculty** teaches a private *Demo Course — sandbox* with sample lessons, an assignment, a quiz
  and an announcement. It sees only the demo student and parent.
- **Student** is enrolled only in the sandbox course.
- **Parent** is linked only to the demo student.
- **Admin** is optional and off by default. It is a **full administrator** and can see
  everything on the site.

Passwords are random and shown to the administrator once; *New passwords* gives fresh ones.
They never appear on the sign-in page. The accounts expire automatically after 1–30 days, and
you can extend, disable or remove them. Removing disables the accounts and hides the sandbox
course. The sandbox course is hidden from everyone else's course catalogue.

Lost the admin password? `npm run reset-admin`.

### Run it in GitHub Codespaces (no install)

Open **https://codespaces.new/JacobDavisK/lms**, or on GitHub go to **Code → Codespaces →
Create codespace on main**.

- In about a minute the site starts with **sample data** and opens in a new tab. Sign in
  with the Admin / Faculty / Student / Parent tiles.
- The link is private to you. To show someone else, go to **Ports → port 3000 → Port
  Visibility → Public**, and set it back afterwards.
- The codespace sleeps when idle and uses your free monthly hours, so stop it when you're done.

Details are in [.devcontainer/README.md](.devcontainer/README.md).

## Features

| Area | What you get |
|---|---|
| **Dashboard** | Greeting, stat cards, timeline of what's due/overdue (or what needs grading, for teachers), course overview with progress, upcoming events, latest announcements |
| **Courses** | Full name, short name, category, summary, dates, colour theme, visibility; topic sections with summaries; course index sidebar; edit mode to add, edit, reorder (across sections), hide and delete |
| **Activities & resources** | Page (Markdown), URL, File (upload, preview, download), Text & media label, Assignment, Quiz, Forum — chosen from a Moodle-4-style activity chooser |
| **Assignments** | Due and cut-off dates, online text and/or file submissions (up to 5 × 10 MB), late flags, submission status table, grading dialog with feedback, student notifications |
| **Quizzes** | Everything from the original: timed attempts, autosave, shuffling, random subsets, negative marking, access codes, review modes, exam-mode integrity monitoring, watermark, question import, results, item analysis, regrade, void |
| **Forums** | Discussion topics, threaded replies, pinning, deletion, reply notifications |
| **Enrolment** | Teachers enrol people by search or whole batch; optional student self-enrolment from the catalogue, with an optional enrolment key |
| **Completion tracking** | Manual "Mark as done" for resources; automatic for assignments (submitted), quizzes (attempted) and forums (posted); progress rings and bars |
| **Gradebook** | Grader report (students × items, colour-coded, CSV export), student user report with feedback, grades overview across courses |
| **Calendar** | Month view of due dates, quiz windows and course dates, colour-coded by course |
| **Communication** | Course announcements, site news, in-app notifications with unread badge |
| **Search** | Global search (Ctrl K) across courses and activities |
| **Course analytics** (teachers) | Blackboard-style analytics tab per course: active students and time-in-course trends, time-vs-grade scatter, weekday × hour heatmap, content engagement, grade distribution, activity mix, 7/14/30/90-day ranges, CSV export |
| **At-risk students** | Retention-Center-style rules (inactivity, low grade, missed deadlines, low activity — adjustable), per-student reports, one-click reminders sent as notifications |
| **Insights** | Teachers: engagement and at-risk students across all their courses. Admins: site analytics — daily active users, sign-ins, time on site, activity by role, tool usage, busiest hours, most active courses, inactive students. Students: study time vs class average on the dashboard |
| **Parent portal** | Parent accounts linked to one or more students. Parents see each child's grades and teacher feedback, course progress, deadlines, overdue work, study time vs. the class, and course announcements — and nothing else |
| **Email & SMS alerts** | Students and parents are alerted about new assignments and tests, due-in-24-hours and overdue work, tests opening and closing, grades, test results, teacher reminders, and a weekly progress report. Email via SMTP; SMS via Twilio or any HTTP gateway; a log-only test mode; delivery queue with retries and a delivery log |
| **Admin** | Users (bulk add incl. parents and their children, edit, reset password), all courses, site news, settings, audit log |
| **UI** | Light/dark mode, responsive down to phones, keyboard-friendly, accessible labels |

## How it's built

```
server.js            Express: serves the app, POST /rpc (all API calls), GET /file/:id
lib/api.js           Sign-in, sessions, the API gateway, and the quiz engine
lib/lms.js           Courses, sections, activities, enrolment, assignments, forums,
                     announcements, completion, gradebook, calendar, notifications, files
lib/util.js          Shared config and validation helpers
lib/store.js         JSON-file database (data/db.json)
lib/crypto.js        Password hashing and tokens
public/index.html    App shell
public/css/tokens.css    Design tokens: colour (light + dark), type scale, spacing,
                         radius, depth, motion, layers. Change --accent-hue here
                         to re-colour the whole product.
public/css/app.css       Components, shell, pages, responsive rules and motion
public/css/features.css  Analytics charts and proctoring screens
public/js/*.js       Front end: core (router, RPC, Markdown), shell, dashboard,
                     course, activities, quiz, admin, main
scripts/             seed-demo.js, reset-admin.js
```

Every request goes through one gateway that checks the session, role and rate
limit, and every course feature then checks the caller's role **in that course**
(teacher/student), so a teacher can only manage courses they teach and students
only see visible content in courses they're enrolled in.

### Design language

Calm, typographic and spatial: a warm off-white (or near-black) page, surfaces
separated by luminance and hairlines rather than borders and shadows, one accent
colour, system fonts, and translucency only on floating layers (top bar, menus,
tab bar, sheets). The dashboard leads with one primary action (continue learning /
start grading), then a timeline of what's due, recent activity and progress.
On phones the navigation becomes a floating tab bar plus a "More" sheet, and
dialogs open as bottom sheets. Motion is short and spring-like and is switched
off under *reduce motion*.

## Security notes

- Passwords are hashed with scrypt plus a secret pepper (`LMS_PEPPER`, or `data/properties.json`).
  Older hashes are upgraded at each person's next sign-in.
- Sign-in limits: 20 attempts a minute per account, 30 per client and 600 site-wide. An account
  pauses for 15 minutes after 5 wrong passwords. Every failure shows the same message.
- First-time passwords expire (14 days by default). With SMS set up, the first sign-in also
  needs a code texted to the registered mobile.
- Sessions: 256-bit random tokens, 30-minute idle timeout, 12-hour maximum, one active session
  per user. The token is kept in `sessionStorage`, so a page reload keeps you signed in but
  closing the tab signs you out.
- Teachers can list and edit only the students in their own courses and those students'
  parents. Password resets, parent links and mobile-number changes are for administrators only:
  a teacher can enrol any student into their course, so "their" students aren't a safe scope
  for credentials.
- Face-enrolment photos are visible only to the student's teachers and administrators.
- Uploads: 20 a minute and a storage quota per person. Files never attached to anything are
  deleted after a day.
- Headers: a Content-Security-Policy with a per-page nonce, Permissions-Policy, X-Frame-Options,
  nosniff and Referrer-Policy, `no-store` on the API, and HSTS behind HTTPS.
- The server listens on 127.0.0.1 unless `HOST` is set. Put it behind HTTPS (see DEPLOY.md).
- An append-only copy of the audit log is kept in `data/audit.log`; file downloads are logged.
- `npm run test:security` runs the security regression tests, also run on every GitHub push.
  Encrypted backups: `npm run backup`.
- Files are only downloadable by people allowed to see the activity/submission they
  belong to, are always served as attachments, and the token travels in a header, not the URL.
- Markdown is rendered from escaped text with a small allow-list (links must be http/https/mailto).

## Signing in

| Who | Sign-in ID | First password |
|---|---|---|
| Students | College ID (e.g. `24-UBC-202`, any letter case) | Their registered 10-digit mobile number |
| Teachers | College / staff ID | Their registered 10-digit mobile number |
| Parents | Their 10-digit mobile number (`9876543210`; `+91 98765 43210` and `09876543210` also work) | Their child's college ID |

- **Everyone chooses their own password at the first sign-in.** The site asks before letting
  them do anything else. Passwords need at least 8 characters with a letter and a number.
- **Mobile numbers are required** for parents: each parent needs their own number, as it is how
  they sign in. Students and teachers need one for this first-password rule. Anyone without one
  gets a random temporary password, which is shown to whoever created the account.
- **Password reset** (Users → key icon) puts the account back on its first password, and they
  choose a new one again.
- **Users → First-login passwords** switches accounts that haven't signed in yet (for example,
  students imported earlier with temporary passwords) to this rule. It also lists anyone
  missing a mobile number or a linked child.
- Parents can still use their username. Administrators keep their own password and are not
  affected.

## Adding users — three separate paths

**Site administration → Users** has one button per kind of account, and tabs to list
each kind on its own (All · Students · Faculty · Parents · Administrators):

| Button | Ways in | Columns for *Paste a list* | Sign-in / first password |
|---|---|---|---|
| **Add students** | Upload class list · One student · Paste a list | college ID, full name, class, email, mobile, *parent name, parent mobile* | college ID / mobile |
| **Add faculty** (admins) | One person · Paste a list | staff ID, full name, department, email, mobile | staff ID / mobile |
| **Add parents** (admins) | One parent · Paste a list | mobile, full name, children's college IDs (`;` between), email | mobile / first child's college ID |

- The two parent columns under *Add students* are optional: fill them in and a parent
  account is created and linked in the same step. Brothers and sisters with the same
  parent mobile share one parent account; if the mobile already belongs to a parent,
  an administrator's paste links the student to that parent.
- *Add faculty* has an **Account type** choice: Faculty (teacher) or Administrator.
- *Add parents* links to students who already have accounts. Parent usernames are made
  from the mobile number (`parent.9845012345`) — parents never need to know it.
- Teachers see only **Add students** (including the optional parent columns). Adding
  faculty, adding parents to existing students, and attaching a new student to an
  existing parent are for administrators.

## Importing students from a class list

**Users → Add students → Upload class list** (teachers: *Students & parents*) accepts the
college's *Faculty Subject Wise Students* export as-is (.xlsx or .csv):

| Sl.No. | Register No | Student Name | Program & Section | Student Mobile No. | Institution Mail Id |
|---|---|---|---|---|---|

- The header row is found automatically (a title row above it is fine) and columns
  can be in any order; similar headings (Reg. No, Roll No, Name, Class, Mobile, Email…)
  are recognised too. Only *Register No* and *Student Name* are required.
- Register No becomes the username in lower case (`24-UBC-202` → `24-ubc-202`),
  ALL-CAPS names are tidied (`ADHIRAJ M` → `Adhiraj M`), Program & Section becomes the
  batch, and mobile numbers get the country code from the messaging settings.
- A preview shows every row as *New*, *Already registered*, *Duplicate* or *Skipped*
  (with the reason) before anything is saved. Invalid mobiles/emails are left blank
  rather than blocking the student.
- Options: enrol everyone in one of your courses, update details of existing students,
  and email/SMS each new student their sign-in details (when email/SMS are set up).
  Temporary passwords are shown afterwards with Copy / Download CSV.
- Old `.xls` files must be re-saved as `.xlsx`. Up to 2,000 students and 10 MB per file.

The **One student** and **Paste a list** tabs cover students who are not on the export.

## Communication — Messages

Sidebar → **Communication → Messages** (on phones: the *Messages* tab).

- **Course channels:** every course automatically has **#general** for all its students and
  teachers. Teachers add more channels — public to the course, or private with chosen members —
  and can rename, set a topic or archive them.
- **Direct messages:** students can message their teachers; teachers and admins can message
  anyone in their courses; groups of up to 10. Students messaging *other students* is off by
  default (Admin → Settings → Messages).
- **Parents ↔ subject faculty:** parents get **Message teachers** in their sidebar (and a
  *Message* button beside each subject on their child's page). A parent can message only the
  teachers of the courses their linked children take. Those teachers, and administrators, can
  message the parent back or start the conversation themselves.
  - Each person is labelled so it's clear who they are: *"Teaches Anitha · BLAW201"*, or
    *"Parent of Anitha Raman"*.
  - Parents never see course channels, students, or other parents.
- **Slack-style features:** threads, emoji reactions, @mentions (with autocomplete), editing
  (↑ edits your last message), deleting, pinned messages, file and image attachments,
  markdown (`**bold**`, `*italic*`, `` `code` ``, lists, links), message search, unread and
  mention badges, a "New" marker, typing indicators, online presence, desktop notifications.
- **Real time:** messages arrive instantly through long polling on the normal API — no extra
  server or service. People who are offline get an in-app notification for DMs and mentions.
- **Moderation:** teachers can delete any message in their course channels (audited).
  Attachments can only be downloaded by members of the conversation.
- Storage: `data/chat/` (one file per conversation), separate from the main database.

## Examinations — question papers

Sidebar → **Examinations → Question papers / QP templates**. Faculty only (teachers and
administrators); students, parents and the St. Ignatius guide never see papers or their files.

- **Templates** fix the paper's pattern so every paper looks the same: header (institution,
  logo, exam title, duration, maximum marks, register-number boxes), instructions, parts
  (answer all · either (a) or (b) · answer any *n*, count × marks), font, size, paper, margins,
  CO and cognitive-level (K1–K6 / L1–L6 / BT1–BT6) columns. Two are built in (CIA 50 marks,
  end semester 100 marks). Create one in the designer, **upload a Word paper** to read its
  header and pattern, or (administrators) attach a **custom LaTeX layout** — download
  *Sample LaTeX layout* for the `<<PLACEHOLDERS>>`.
- **Editor**: an A4 page with a Word-style ribbon — undo/redo, styles, bold/italic/underline/
  strike, super/subscript, lists with (a)/(i) numbering, indent, alignment; tables (grid picker,
  add/delete rows and columns, merge, header row, Tab between cells); pictures (PNG/JPEG,
  resize/align); equations (LaTeX with a palette and live preview); symbols; fill-in blanks;
  code blocks; sub-parts (i), (ii); OR choices; page breaks; find & replace; word count; zoom.
  Pasting from Word, Google Docs or the web is cleaned up. Autosaves with version checks
  (co-setters can't overwrite each other), keeps a version history, and shows live checks:
  empty questions, missing marks/CO/level, (a) ≠ (b) marks, parts ≠ maximum marks, repeats.
- **Import a Word paper (.docx)**: parts, numbered questions (typed or Word-numbered), (a)/(b)
  OR choices, (i)/(ii) sub-parts, marks like `(13)` or `[5 marks]`, CO/K-level tags, the
  common *Q.No | Question | Marks | CO | BL* table layout, tables, pictures and **Word
  equations (converted to LaTeX)**.
- **Review workflow**: draft → submitted (locked) → approved, or returned with comments;
  administrators are notified and decide; approved papers are locked until reopened. Every
  export is audit-logged. Co-setters are added with *Share*.
- **Output — LaTeX**: *Export → LaTeX project (.zip)* gives `main.tex` + `images/`, compiling
  with pdfLaTeX, XeLaTeX or LuaLaTeX (run twice for "Page x of y"; or upload the .zip to
  Overleaf). Typesetting: booktabs rules, a longtable whose header repeats on every page,
  microtype, Times/Latin Modern/Palatino/Helvetica, amsmath, PDF metadata, DRAFT / FOR REVIEW
  watermarks until approved, and an optional **blueprint page** (marks by CO × level).
  *Preview* shows the paginated print layout and the LaTeX source; *Print / PDF* prints from the
  browser. One-click **PDF** appears when TeX Live / MiKTeX is installed on the server
  (compiled without shell escape and with file access restricted).
- Storage: `data/exams/` (templates, one file per paper, revisions).

## Attendance

Sidebar → **Attendance → Take attendance / Attendance reports** (students: *My attendance*;
parents: *Attendance*).

- **Take attendance** per course, date and **period**. There are **5 periods of 55 minutes a
  day** (the admin can change both). Each student is simply **P** (present) or **A** (absent).
  - Everyone starts Present; tap a name to mark them absent.
  - *Quick entry* marks absentees by register number, or just the last digits: `12, 15, 21`.
  - Saving the same date and period again updates it (audited), and the page moves on to the
    next period.
  - Older records that used L / OD / ML still count: L and OD as present, ML as absent.
- **Register** grid with periods held / attended / %, shortage rows in red, the number of
  periods each student needs to recover, and a date filter. **Sessions** lists every period
  taken (edit/delete).
- **Student dashboard** (*My attendance*; parents see the same for each child):
  - **Working days** (days on which classes were held), split into days present (all periods),
    partly present, and absent
  - overall **attendance %**, periods attended, and class time attended in hours
  - whether they are on track: "you could miss 15 more periods" or "attend the next 10"
  - a colour-coded **day-by-day calendar** with one dot per period, and a full-day streak
  - month by month, and each course's % with recent absences
  - a printable report

  The student's home page also shows an **Attendance** card with the %, working days and the
  last 10 days.
- **Settings** (administrators, on the Reports page): minimum attendance (75%), periods per
  day (5), minutes per period (55), and absence alerts to parents (in-app, plus email/SMS when
  configured).
- **Excel reports** (one click): attendance register (P/A grid + summary + sessions),
  consolidated attendance (students × courses), shortage list, absentees for any period.
  Staff can also print per-student attendance reports.

### Student OD / ML requests

Students: sidebar → **Attendance → OD / ML requests**, or *Apply for OD / ML* on My attendance.

- **Apply** for **OD** (on duty) or **ML** (medical leave) with dates and a reason. Sundays are
  left out, one application covers up to 31 days, and it can go back up to 60 days.
- **Approval path, in this order:** **Class faculty → HOD → Vice Principal.** Each stage can
  approve, reject (with a reason) or raise a query. The student answers the query and the
  request returns to the same stage. Everyone involved is notified at each step, and parents
  are told on final approval.
- **Progress bar:** each application shows a progress bar (e.g. *With HOD · step 3 of 5 · 40%*)
  and a step-by-step tracker with who approved and when.
- **Only the final (Vice Principal) approval changes attendance.** Absences on those dates then
  show as **OD** / **ML**, in the student's and parent's dashboards, the teacher's register,
  Excel registers and absentee lists. OD counts as present. ML counts as present too, unless
  the admin turns that off.
- **Who approves:** set under **Leave desk → Settings → Student OD / ML approvals**. Pick the Vice
  Principal, a HOD for every class, and optionally a class faculty and HOD for each class. If
  nobody is named, the student's course teachers act as class faculty, and the administrators
  act as HOD and Vice Principal.
- Approvers handle requests on the **Leave desk** (labelled *Student*). The admin's staff
  leave Excel report includes a *Student OD-ML* sheet.

### Staff leave and movements

Sidebar → **Attendance → Leave / Movements / Leave desk** (teachers and admins).

- **Leave**: apply for **CL** (casual leave), **OD** (on duty) or **ML** (medical leave) with
  dates (or a half day) and a reason. The form shows the working days as you pick dates, with
  Sundays left out, and how much leave you will have left. The dashboard has:
  - a ring showing days left out of the allowance
  - CL / OD / ML usage bars
  - approved days per month
  - your approval path
  - every application with its progress.

  **Allowance:** the default is **12 days per leave year**. By default CL and ML count
  against it and OD does not.
- **Movements**: short permissions to step out during working hours, with date, out and return
  times, and a reason. There is a limit of **2 per calendar month**, each up to 120 minutes.
  The page shows this month's quota and the last six months.
- **Approval path**: leave and movements each have their own path, a list of stages such as
  *Head of Department → Principal*, each with named approvers. A stage with no approvers is
  handled by the administrators.
  - At each stage the approver can **approve** (the request moves on), **reject** (a reason is
    required), or **raise a query**. The applicant answers the query, and the request returns
    to the same stage.
  - Everyone involved gets an in-app notification at every step.
  - Each request shows a progress tracker (Applied → each stage → Approved) and the full
    history.
  - Applicants can withdraw a request while it is still in progress, or cancel an approved
    one before it starts. Any days it held go back to the balance.
- **Leave desk**: approvers see what's waiting for them. The sidebar badge counts the requests.
  Administrators also get:
  - a **staff dashboard**, with each person's allowance (click to change it for one person),
    CL / OD / ML used, days pending, days left, movements this month, and who is away today
  - **all requests**, with filters
  - **Settings**: total leave, which types count, the month the leave year starts, Sundays,
    movements per month and the longest movement, and both approval paths
  - a one-click **Excel** staff leave report: summary, leave register and movement register.
    Staff can download their own statement.

## Mark entry — INTERNAL MARK ENTRY (LOCF based)

Sidebar → **Examinations → Mark entry** (students: *My marks*; parents: *Marks*). The screen is
laid out like the college ERP: **Exam Date**, **Test Component**, the subject table (Subject
Code, Description, Program & Section, Entered / Total Students, Conducting and Converting
Max.Marks — click a row), then the student grid with one box per part and an **Absent** tick.

- **LOCF scheme** (administrators can change it under *LOCF scheme*):
  COMP.1 and COMP.2 are entered as K1&K2 /10 + K3&K4 /20 + K5&K6 /20 = 50 and converted to 30;
  COMP 3a and COMP 3b are entered /20 and count 20.
  Converted = marks ÷ conducting max × converting max (41 → 24.6);
  **Total (100)** = Σ converted, rounded half up (40.6 → 41); **Final (50)** = Total ÷ 2, rounded
  half up (41 → 21); **Att. Marks** from attendance bands (0 unless switched on);
  **Total Final (50)** = Final + Att. Marks. Absent is shown as **A** and counts as 0.
- **Entry**: type marks (up to two decimals, never above a part's maximum — shown in red),
  Enter/arrow keys move between boxes, paste a block from Excel, autosave plus **Save**,
  **Clear**, **Import** / **Template** (Excel per component, with preview), **Course details**
  (semester, credits, department, teacher, program & section, theory/practical).
- **Submit** locks a component and publishes it to students and parents (notified); only an
  administrator can **Unlock**. Changes to marks already entered are kept in a change log.
- **Mark Statement** prints the *Continuous Assessment Mark Statement* exactly like the ERP
  report: session and course box, Sl. No. / Dept. No. / Name / COMP.1 (30) / COMP.2 (30) /
  COMP 3a (20) / COMP 3b (20) / Total (100) / Final (50) / Att. Marks / Total Final (50) /
  Student's Signature, 18 students on the first page and 26 on the next, "Draft Printout" while
  any component is unsubmitted, and the H.O.D. / Teacher signature lines (Print / Save as PDF).
- **Excel**: the same statement plus one breakup sheet per component (K1&K2, K3&K4, K5&K6, total,
  converted) and the change log; **Consolidated (.xlsx)** gives Total Final for every student
  across your courses with a course-wise summary.
- Storage: `data/erp/` (settings and scheme, one attendance file and one marks file per course).

## St. Ignatius — the AI guide

A portrait of St. Ignatius of Loyola drifts slowly across every page (it stays still
for people who prefer reduced motion). Click it to talk; drag it anywhere; **–** sends it
back to wandering and **×** sends it away until it's called back from the account menu
(*Talk to St. Ignatius*). It's never shown during a quiz attempt or exam check-in.

- **Personal:** greets each person by name with something relevant ("your essay is
  waiting — shall we plan?"), answers about *their* courses, progress, next steps,
  deadlines, grades and feedback, quiz results, study rhythm and proctored exams.
  Parents ask about their children; teachers about grading and students needing attention.
  Replies link straight to the right page.
- **Humane:** warm, calm, practical, with a light Ignatian touch (the examen, discernment,
  the magis). If someone is distressed it responds with care and points to the counsellor
  and to Tele-MANAS 14416 when there's any risk.
- **Speaking:** the mouth moves as replies appear; optional spoken replies (device voice).
- **Safe by design:** the model never touches the database. It calls tools that run
  existing API routes *as the signed-in person*, so it can only see what they can see and
  can't change anything. It won't give answers to open quizzes or write assignments.

**Turn on the AI:** Admin → Settings → *St. Ignatius — AI guide*: paste an Anthropic API
key (console.anthropic.com) and pick a model (Claude Sonnet 5 recommended). Or set
`ANTHROPIC_API_KEY` (and optionally `ASSISTANT_MODEL`) on the server. Without a key the
guide runs in **basic mode**, answering the common questions from the same data.
With a key, each question and the parts of that person's own data needed to answer it are
sent to Anthropic.

## Quiz questions from Excel

Quiz → **Questions** tab (or **Excel template** on the quiz page):

1. **Download Excel template** — a workbook with a *Questions* sheet
   (`No. | Question | Option A | Option B | Option C | Option D | Correct answer | Marks | Explanation`),
   a *How to fill* sheet and an *Example* sheet. "Correct answer" has an A–D drop-down.
2. Fill in one question per row. C and D may be empty (true/false). The correct answer can
   be the letter, 1–4, or the exact text of the right option. Blank marks = 1.
3. **Upload the filled template** (.xlsx or .csv). A preview shows every question with the
   right answer ticked, plus any rows with problems and why. Import adds to the existing
   questions, or replaces them if nobody has attempted the quiz yet.

Columns are matched by name, so other sheets with headings like *Answer*, *Key* or
*Points* also work. Up to 500 questions per upload. The paste box is still there for quick
additions.

## Online proctoring (Assessment)

**New quizzes are proctored by default.** The quiz settings form has an *Online proctoring*
section: switch it off, or choose *Practice*, *Standard* (default) or *High-stakes*.
Students then go through the camera check-in before the attempt starts, and monitoring
runs for the whole attempt.

Sidebar → **Assessment**. Staff: *Proctoring* (hub), *Live monitor*, *Integrity reviews*.
Students: *Proctored exams* and *System check*.

- **Turn it on per quiz** under Proctoring → exam → *Proctoring settings* (presets:
  Practice / Standard / High-stakes). Choose microphone, entire-screen recording, Face ID,
  liveness challenge, photo ID card, room scan, AI detectors, sensitivity, snapshot
  interval, auto-submit after N serious flags, and live chat.
- **Check-in** (enforced by the server — a proctored attempt can't start or save answers
  without it): consent → system check (browser, camera, mic, single display, AI models,
  latency) → face & liveness (head turns + blink) → ID card → room scan → start.
- **On-device AI** (runs in the student's browser; nothing is streamed):
  MediaPipe Face Landmarker (faces, head pose, gaze, mouth), EfficientDet object detector
  (phone, book, laptop/TV, extra people), face-api.js 128-d face signatures (identity,
  re-checked at random during the exam and compared on the server), and voice-activity
  detection fused with lip movement. Browser lockdown adds tab/focus/full-screen/copy/paste,
  second-monitor, split-screen, virtual-camera and offline detection.
- **Live monitor**: risk-sorted grid with live thumbnails, status indicators, progress,
  latest flag, student messages; *Watch* for a faster live view, message/warn, end exam.
- **Review**: integrity score 0–100, automated summary, clickable timeline, evidence
  gallery, identity evidence (enrolled face, selfie, ID, room scan), event log (CSV),
  device details, and a recorded decision (Cleared / Suspicious / Misconduct) plus Void.
- **Privacy**: snapshots and timelines are deleted after the retention period
  (admin setting on the Proctoring page, default 30 days). Data: `data/proctor/`.
- Camera/mic access needs **https** (or `localhost`). The AI models (≈25 MB) download
  once from jsDelivr / Google Storage and are then cached; students should run the
  System check before exam day.

## Installer and automatic updates

**To give the LMS to someone:** send them the link https://github.com/JacobDavisK/lms-updates (or the file
`Jacob-Davis-LMS-Setup.zip` from there). They extract the zip and double-click **Install Jacob Davis LMS** —
no administrator rights, nothing else to install. It goes into `%LOCALAPPDATA%\JacobDavisLMS`, adds a Desktop
icon, and asks one question: sample data (demo) or an empty site for their own institution.

**Updates are automatic.** When the `version` in `package.json` is raised and pushed, GitHub runs the tests and, if
they pass, publishes the new program to the public repo `JacobDavisK/lms-updates` (program only — no records, no
git history). Every installed copy checks that page when it starts and every six hours, downloads the new version,
verifies its SHA-256 checksum, waits until nobody has used the site for 15 minutes, then swaps the `app` folder and
restarts. If the new version does not start, the previous one is restored and that version is skipped.
`data/` (the records) is never part of a release and is never touched. To switch updates off on one computer, set
`"autoUpdate": false` in its `config.json`.

Files: `installer/` (setup and launcher), `scripts/build-release.js`, `.github/workflows/security.yml` (release job),
tests in `tests/update.test.js` (`npm run test:update`). The copy you develop on (started with `node server.js`)
never updates itself.

## Mentoring & Student Success

A mentoring command centre for faculty, HODs, coordinators and administrators, with student and parent views
(**Mentoring** in the sidebar; configuration under **Site administration → Mentoring settings**):
mentor allocation (manual, rule-based, Excel/CSV import, full history), a Student 360° profile with a Student Success
Snapshot and Timeline, sessions with templates and confidentiality levels, goals, concerns, interventions with action
plans, follow-ups, configurable early-warning rules ("support indicators" — prompts to review, never a diagnosis),
career development, parent interactions, anonymous feedback, mentor / department / institution analytics, Excel/CSV/PDF
reports, mentoring cycles, an advisory AI assistant (local by default) and an audit log.

Details, permissions, security review and configuration: **[MENTORING.md](MENTORING.md)**. Tests: `npm run test:mentoring`.
Demo cohort (fictional, demo installations only): `npm run seed:mentoring`.

## Academic Content Studio

"Create once. Teach everywhere." A Canva-style studio (**Content Studio** in the sidebar) where faculty turn a
topic, a syllabus unit or their own notes into linked learning objects — lecture slides, notes, infographics,
cases, quizzes, discussions, assignments, flashcards and more — map them to CO/PO/PSO and Bloom levels, review
them and publish them into a course in one step (quizzes become graded LMS quizzes). Includes a canvas editor
with templates, charts, tables, icons and diagrams; document, quiz and flashcard editors; an Academic Copilot
(Anthropic, OpenAI, Google or a local model — or a built-in offline generator); comments, versions and an
approval workflow; live class activities; PDF/PNG/JPG/PowerPoint/Word exports; imports; an accessibility checker;
and analytics. Students design presentations, posters and portfolios and submit them to assignments.

Details, API, environment variables and security: **[STUDIO.md](STUDIO.md)**. Tests: `npm run test:studio`.
Demo content (demo installations only): `npm run seed:studio`.

## Business Simulation Studio

Strategy simulations built into the LMS (**Business simulations** in the sidebar). Faculty build a simulation
without code — market and economy, customer segments, companies, competitors that react, decisions (with a safe
formula language for custom ones), random and scheduled events, rounds, KPIs and configurable scoring — preview
it, publish versions and run it with a class in teams. Students run the company round by round: decisions with
what-if analysis, full financial statements, score explanations, leaderboard, decision journal, debrief and
reflection. Faculty get analytics, assessment (sent to the gradebook) and reports. Includes the Evolution Motors
EV demo and 30 more templates. Details: **[SIMULATION.md](SIMULATION.md)**. Tests: `npm run test:simulation`.
Demo: `LMS_DEMO=1 npm run seed:simulation`.

## Android and iOS apps

`mobile/` is a Capacitor app for the Play Store and App Store. It opens the college's LMS server in a native
shell, so server updates reach the app immediately, and adds an offline screen, native share-sheet downloads,
camera access for proctored exams and a privacy policy at `/privacy`. GitHub Actions builds both apps (no Android
Studio or Mac needed). Setup, signing and store listing checklist: **[MOBILE.md](MOBILE.md)**.

## Parents

Create parent accounts under **Users → Add parents** (one at a time, or paste a list).
List the children's college IDs separated by `;` to link them in one go:

```
mobile, full name, children's college IDs, email
98450 12345, Raman K, 22bcs101; 22bcs102, raman@example.com
```

Or add the parent together with the student under **Add students** (last two columns).
Scripts can still send the older combined format to `addUsers` without a `path`:
`username, full name, role, batch, email, mobile, children`.

Links can also be managed (by administrators) from a parent's **Edit account** dialog.
Teachers can add a parent only together with a new student. Parents sign in like everyone else and land on
**My family**. From there they can see attendance and marks, and use **Message teachers**
to write to their child's subject faculty.

## Email & SMS alerts

Set up under **Site administration → Settings → Email & SMS alerts**:

- **Email**: any SMTP server (Gmail with an app password, Outlook, SendGrid, your
  college mail server). Sign-in codes for staff are emailed too once SMTP is set up.
- **SMS**: Twilio, or an **HTTP gateway** — the LMS POSTs
  `{"to": "+9198…", "message": "…", "sender": "…"}` with an optional Bearer token,
  so Indian providers (MSG91, Fast2SMS, Textlocal…) can be connected through a small relay.
- **Log only** mode records messages in the delivery log without sending — use it to
  preview before going live. Use the *Send test* buttons to check your credentials.
- Choose which alert types are on, whether students and/or parents get them, and when
  the weekly progress report goes out. Each person can switch categories (tests,
  assignments, scores, progress) on or off per channel under **Profile → Alerts & contact**.

Secrets can be kept out of the database with environment variables, which override the
settings page: `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASS`,
`SMTP_FROM`, `TWILIO_SID`, `TWILIO_TOKEN`, `TWILIO_FROM`, `SMS_WEBHOOK_URL`,
`SMS_WEBHOOK_TOKEN`, `SITE_URL`.

Every alert is also an in-app notification. Due/overdue/closing reminders are checked
every 5 minutes and sent once per student. Failed messages are retried 3 times; see
**Site administration → Email & SMS log**.

## Usage analytics

Time in a course is counted one minute at a time while a student has a course page
open, the tab is visible, and they have used the keyboard, mouse or screen in the last
five minutes (quiz attempts count too). Page views, submissions, forum posts, quiz
attempts and downloads are also counted. Only daily totals are stored, in
`data/analytics.json`, kept for 400 days, so the file stays small even for hundreds of
students. Course analytics only count students; teachers' own browsing is excluded.

## Data

Everything lives in `data/db.json`, `data/analytics.json` and `data/uploads/` (plus `data/properties.json` for the
password pepper). Set `LMS_DATA_DIR` to use a different folder. Delete the folder to reset
the site completely.

## Limitations

- Emailed sign-in codes are printed to the server console (no mail service is wired up).
- Sessions are held in memory, so restarting the server signs everyone out.
- The JSON-file database suits a department or college; for thousands of concurrent users
  move `lib/store.js` onto a real database.
- Quiz questions are single-answer multiple choice (2–4 options).
